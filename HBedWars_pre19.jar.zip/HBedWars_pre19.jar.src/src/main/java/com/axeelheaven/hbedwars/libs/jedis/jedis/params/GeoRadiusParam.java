/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeoRadiusParam
/*    */   implements IParams
/*    */ {
/*    */   private boolean withCoord = false;
/*    */   private boolean withDist = false;
/*    */   private boolean withHash = false;
/* 19 */   private Integer count = null;
/*    */   
/*    */   private boolean any = false;
/*    */   
/*    */   private boolean asc = false;
/*    */   
/*    */   private boolean desc = false;
/*    */   
/*    */   public static GeoRadiusParam geoRadiusParam() {
/* 28 */     return new GeoRadiusParam();
/*    */   }
/*    */   
/*    */   public GeoRadiusParam withCoord() {
/* 32 */     this.withCoord = true;
/* 33 */     return this;
/*    */   }
/*    */   
/*    */   public GeoRadiusParam withDist() {
/* 37 */     this.withDist = true;
/* 38 */     return this;
/*    */   }
/*    */   
/*    */   public GeoRadiusParam withHash() {
/* 42 */     this.withHash = true;
/* 43 */     return this;
/*    */   }
/*    */   
/*    */   public GeoRadiusParam sortAscending() {
/* 47 */     this.asc = true;
/* 48 */     return this;
/*    */   }
/*    */   
/*    */   public GeoRadiusParam sortDescending() {
/* 52 */     this.desc = true;
/* 53 */     return this;
/*    */   }
/*    */   
/*    */   public GeoRadiusParam count(int count) {
/* 57 */     if (count > 0) {
/* 58 */       this.count = Integer.valueOf(count);
/*    */     }
/* 60 */     return this;
/*    */   }
/*    */   
/*    */   public GeoRadiusParam count(int count, boolean any) {
/* 64 */     if (count > 0) {
/* 65 */       this.count = Integer.valueOf(count);
/*    */       
/* 67 */       if (any) {
/* 68 */         this.any = true;
/*    */       }
/*    */     } 
/* 71 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 77 */     if (this.withCoord) {
/* 78 */       args.add(Protocol.Keyword.WITHCOORD);
/*    */     }
/* 80 */     if (this.withDist) {
/* 81 */       args.add(Protocol.Keyword.WITHDIST);
/*    */     }
/* 83 */     if (this.withHash) {
/* 84 */       args.add(Protocol.Keyword.WITHHASH);
/*    */     }
/*    */     
/* 87 */     if (this.count != null) {
/* 88 */       args.add(Protocol.Keyword.COUNT).add(this.count);
/* 89 */       if (this.any) {
/* 90 */         args.add(Protocol.Keyword.ANY);
/*    */       }
/*    */     } 
/*    */     
/* 94 */     if (this.asc) {
/* 95 */       args.add(Protocol.Keyword.ASC);
/* 96 */     } else if (this.desc) {
/* 97 */       args.add(Protocol.Keyword.DESC);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\GeoRadiusParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */