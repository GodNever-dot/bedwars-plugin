package com.axeelheaven.hbedwars.cosmetics.killeffects;

import com.axeelheaven.hbedwars.libs.xseries.XMaterial;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class KillEffectBlood extends KillEffect {
  public void execute(Exception lllllllllllllllIlllIlIlIllllIIIl, Player lllllllllllllllIlllIlIlIllllIlll) {
    Location lllllllllllllllIlllIlIlIllllIIlI = lllllllllllllllIlllIlIlIllllIIIl.getLocation().clone();
    lllllllllllllllIlllIlIlIllllIIlI.getWorld().playEffect(lllllllllllllllIlllIlIlIllllIIlI.clone().add(0.0D, 0.9D, 0.0D), Effect.STEP_SOUND, XMaterial.REDSTONE_BLOCK.parseMaterial());
    lllllllllllllllIlllIlIlIllllIIlI.getWorld().playEffect(lllllllllllllllIlllIlIlIllllIIlI.clone().add(0.0D, 0.5D, 0.0D), Effect.STEP_SOUND, XMaterial.REDSTONE_BLOCK.parseMaterial());
    lllllllllllllllIlllIlIlIllllIIlI.getWorld().playEffect(lllllllllllllllIlllIlIlIllllIIlI.clone().add(0.0D, 0.1D, 0.0D), Effect.STEP_SOUND, XMaterial.REDSTONE_BLOCK.parseMaterial());
  }
  
  static {
  
  }
  
  public KillEffectBlood(String lllllllllllllllIlllIlIllIIIIIIIl, byte lllllllllllllllIlllIlIlIlllllIll, boolean lllllllllllllllIlllIlIlIlllllIlI) {
    super(lllllllllllllllIlllIlIllIIIIIIIl, lllllllllllllllIlllIlIlIlllllIll, lllllllllllllllIlllIlIlIlllllIlI);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\killeffects\KillEffectBlood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */