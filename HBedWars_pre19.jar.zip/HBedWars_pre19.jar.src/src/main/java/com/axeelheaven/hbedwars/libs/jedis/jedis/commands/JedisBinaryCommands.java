package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

public interface JedisBinaryCommands extends KeyBinaryCommands, StringBinaryCommands, ListBinaryCommands, HashBinaryCommands, SetBinaryCommands, SortedSetBinaryCommands, GeoBinaryCommands, HyperLogLogBinaryCommands, StreamBinaryCommands, ScriptingKeyBinaryCommands, FunctionBinaryCommands {}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\JedisBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */