package com.axeelheaven.hbedwars.database.economy;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class EconomyManager {
  private static String llIllIIIIIII(long llllllllllllllllIllllIIIIlllIIll, double llllllllllllllllIllllIIIIlllIIIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   22: bipush #30
    //   24: iaload
    //   25: invokestatic copyOf : ([BI)[B
    //   28: ldc 'DES'
    //   30: invokespecial <init> : ([BLjava/lang/String;)V
    //   33: astore_2
    //   34: ldc 'DES'
    //   36: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   39: astore_3
    //   40: aload_3
    //   41: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   44: iconst_2
    //   45: iaload
    //   46: aload_2
    //   47: invokevirtual init : (ILjava/security/Key;)V
    //   50: new java/lang/String
    //   53: dup
    //   54: aload_3
    //   55: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   58: aload_0
    //   59: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   62: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   65: invokevirtual decode : ([B)[B
    //   68: invokevirtual doFinal : ([B)[B
    //   71: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   74: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   77: areturn
    //   78: astore_2
    //   79: aload_2
    //   80: invokevirtual printStackTrace : ()V
    //   83: aconst_null
    //   84: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	85	3	llllllllllllllllIllllIIIIlllIIII	S
    //   34	44	2	llllllllllllllllIllllIIIIllllIII	Ljavax/crypto/spec/SecretKeySpec;
    //   0	85	1	llllllllllllllllIllllIIIIlllIIlI	D
    //   0	85	0	llllllllllllllllIllllIIIIlllIlIl	Ljava/lang/String;
    //   40	38	3	llllllllllllllllIllllIIIIlllIlll	Ljavax/crypto/Cipher;
    //   0	85	0	llllllllllllllllIllllIIIIlllIIll	J
    //   0	85	2	llllllllllllllllIllllIIIIlllIIIl	D
    //   79	4	2	llllllllllllllllIllllIIIIlllIllI	Ljava/lang/Exception;
    //   0	85	1	llllllllllllllllIllllIIIIlllIlII	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	77	78	java/lang/Exception
  }
  
  private static boolean llIllIIllIlI(char llllllllllllllllIllllIIIIlIlllII, Exception llllllllllllllllIllllIIIIlIllIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 <= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean llIllIIllIIl(double llllllllllllllllIllllIIIIlIllIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static void lllIlIIIII() {
    lIIlIlIIl = new int[lllIllIlII[19]];
    lIIlIlIIl[lllIllIlII[0]] = (lllIllIlII[22] ^ lllIllIlII[23] ^ lllIllIlII[8] ^ lllIllIlII[24]) & (lllIllIlII[25] ^ lllIllIlII[26] ^ lllIllIlII[27] ^ lllIllIlII[28] ^ -lllIllIIlI[lllIllIlII[29]].length());
    lIIlIlIIl[lllIllIlII[1]] = lllIllIIlI[lllIllIlII[30]].length();
    lIIlIlIIl[lllIllIlII[2]] = lllIllIIlI[lllIllIlII[31]].length();
    lIIlIlIIl[lllIllIlII[18]] = lllIllIIlI[lllIllIlII[32]].length();
  }
  
  private static boolean llIllIIlllII(byte llllllllllllllllIllllIIIIllIIIII, Exception llllllllllllllllIllllIIIIlIlllll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public void setEconomy(Economy llllllllllllllllIllllIIIlIllIIII) {
    this.economy = llllllllllllllllIllllIIIlIllIIII;
  }
  
  private static void lllIIlllll() {
    lIIlIlIII = new String[lIIlIlIIl[lllIllIlII[18]]];
    lIIlIlIII[lIIlIlIIl[lllIllIlII[0]]] = lllIIlllIl(lllIllIIlI[lllIllIlII[33]], lllIllIIlI[lllIllIlII[34]]);
    lIIlIlIII[lIIlIlIIl[lllIllIlII[1]]] = lllIIlllIl(lllIllIIlI[lllIllIlII[35]], lllIllIIlI[lllIllIlII[36]]);
    lIIlIlIII[lIIlIlIIl[lllIllIlII[2]]] = lllIIllllI(lllIllIIlI[lllIllIlII[25]], lllIllIIlI[lllIllIlII[37]]);
  }
  
  public Economy getEconomy() {
    // Byte code:
    //   0: aload_0
    //   1: getfield economy : Lcom/axeelheaven/hbedwars/database/economy/Economy;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	llllllllllllllllIllllIIIlIIlIlll	Lcom/axeelheaven/hbedwars/database/economy/EconomyManager;
    //   0	5	0	llllllllllllllllIllllIIIlIIlIllI	Z
    //   0	5	0	llllllllllllllllIllllIIIlIIlIlIl	I
  }
  
  static {
    llIllIIllIII();
    llIllIIIlIII();
    lllIlIIIII();
    lllIIlllll();
  }
  
  private static String lllIIlllIl(String llllllllllllllllIllllIIIlIlllIll, float llllllllllllllllIllllIIIlIlllIII) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIIlI : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   10: bipush #19
    //   12: iaload
    //   13: aaload
    //   14: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   17: aload_1
    //   18: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   21: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   24: invokevirtual digest : ([B)[B
    //   27: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIIlI : [Ljava/lang/String;
    //   30: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   33: bipush #20
    //   35: iaload
    //   36: aaload
    //   37: invokespecial <init> : ([BLjava/lang/String;)V
    //   40: astore_2
    //   41: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIIlI : [Ljava/lang/String;
    //   44: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   47: bipush #21
    //   49: iaload
    //   50: aaload
    //   51: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   54: astore_3
    //   55: aload_3
    //   56: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lIIlIlIIl : [I
    //   59: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   62: iconst_2
    //   63: iaload
    //   64: iaload
    //   65: aload_2
    //   66: invokevirtual init : (ILjava/security/Key;)V
    //   69: new java/lang/String
    //   72: dup
    //   73: aload_3
    //   74: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   77: aload_0
    //   78: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   81: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   84: invokevirtual decode : ([B)[B
    //   87: invokevirtual doFinal : ([B)[B
    //   90: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   93: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   96: areturn
    //   97: astore_2
    //   98: aload_2
    //   99: invokevirtual printStackTrace : ()V
    //   102: aconst_null
    //   103: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	104	0	llllllllllllllllIllllIIIlIlllIlI	B
    //   0	104	2	llllllllllllllllIllllIIIllIIIIII	I
    //   0	104	0	llllllllllllllllIllllIIIlIlllIll	Ljava/lang/String;
    //   41	56	2	llllllllllllllllIllllIIIlIllllIl	Ljavax/crypto/spec/SecretKeySpec;
    //   0	104	0	llllllllllllllllIllllIIIlIlllIIl	C
    //   98	4	2	llllllllllllllllIllllIIIlIllllll	Ljava/lang/Exception;
    //   0	104	3	llllllllllllllllIllllIIIlIlllllI	F
    //   0	104	1	llllllllllllllllIllllIIIllIIIIlI	Ljava/lang/String;
    //   0	104	1	llllllllllllllllIllllIIIlIlllIII	F
    //   55	42	3	llllllllllllllllIllllIIIlIllllII	Ljavax/crypto/Cipher;
    //   0	104	3	llllllllllllllllIllllIIIlIllIllI	B
    //   0	104	2	llllllllllllllllIllllIIIlIllIlll	D
    //   0	104	1	llllllllllllllllIllllIIIllIIIIIl	S
    // Exception table:
    //   from	to	target	type
    //   0	96	97	java/lang/Exception
  }
  
  private static String llIllIIIIIIl(String llllllllllllllllIllllIIIlIIIlIlI, int llllllllllllllllIllllIIIlIIIIlII) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   40: iconst_0
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   58: iconst_0
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic llIllIIlllII : (II)Z
    //   69: ifeq -> 123
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: ldc '   '
    //   114: invokevirtual length : ()I
    //   117: ineg
    //   118: ifle -> 62
    //   121: aconst_null
    //   122: areturn
    //   123: aload_2
    //   124: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   127: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	128	1	llllllllllllllllIllllIIIlIIIlIIl	Ljava/lang/String;
    //   0	128	0	llllllllllllllllIllllIIIlIIIIlIl	F
    //   0	128	3	llllllllllllllllIllllIIIlIIIIIlI	I
    //   0	128	0	llllllllllllllllIllllIIIlIIIlIlI	Ljava/lang/String;
    //   0	128	4	llllllllllllllllIllllIIIlIIIIIIl	F
    //   0	128	8	llllllllllllllllIllllIIIIlllllIl	C
    //   44	84	4	llllllllllllllllIllllIIIlIIIIllI	I
    //   0	128	1	llllllllllllllllIllllIIIlIIIIlII	I
    //   37	91	3	llllllllllllllllIllllIIIlIIIIlll	[C
    //   32	96	2	llllllllllllllllIllllIIIlIIIlIII	Ljava/lang/StringBuilder;
    //   0	128	6	llllllllllllllllIllllIIIIlllllll	S
    //   0	128	2	llllllllllllllllIllllIIIlIIIIIll	D
    //   0	128	7	llllllllllllllllIllllIIIIllllllI	B
    //   0	128	5	llllllllllllllllIllllIIIlIIIIIII	Ljava/lang/Exception;
    //   79	24	8	llllllllllllllllIllllIIIlIIIlIll	C
  }
  
  private static String llIllIIIIIlI(short llllllllllllllllIllllIIIIllIIllI, String llllllllllllllllIllllIIIIllIIlll) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc 'Blowfish'
    //   21: invokespecial <init> : ([BLjava/lang/String;)V
    //   24: astore_2
    //   25: ldc 'Blowfish'
    //   27: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   30: astore_3
    //   31: aload_3
    //   32: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   35: iconst_2
    //   36: iaload
    //   37: aload_2
    //   38: invokevirtual init : (ILjava/security/Key;)V
    //   41: new java/lang/String
    //   44: dup
    //   45: aload_3
    //   46: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   49: aload_0
    //   50: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   53: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   56: invokevirtual decode : ([B)[B
    //   59: invokevirtual doFinal : ([B)[B
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   68: areturn
    //   69: astore_2
    //   70: aload_2
    //   71: invokevirtual printStackTrace : ()V
    //   74: aconst_null
    //   75: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   31	38	3	llllllllllllllllIllllIIIIllIlIlI	Ljavax/crypto/Cipher;
    //   0	76	1	llllllllllllllllIllllIIIIllIIlIl	Ljava/lang/String;
    //   0	76	0	llllllllllllllllIllllIIIIllIlIII	Ljava/lang/String;
    //   0	76	3	llllllllllllllllIllllIIIIllIIIll	Ljava/lang/String;
    //   0	76	1	llllllllllllllllIllllIIIIllIIlll	Ljava/lang/String;
    //   0	76	2	llllllllllllllllIllllIIIIllIIlII	J
    //   0	76	0	llllllllllllllllIllllIIIIllIIllI	S
    //   70	4	2	llllllllllllllllIllllIIIIllIlIIl	Ljava/lang/Exception;
    //   25	44	2	llllllllllllllllIllllIIIIllIlIll	Ljavax/crypto/spec/SecretKeySpec;
    // Exception table:
    //   from	to	target	type
    //   0	68	69	java/lang/Exception
  }
  
  private static boolean lllIlIIIlI(Exception llllllllllllllllIllllIIIlIIllIlI, short llllllllllllllllIllllIIIlIIllIIl) {
    if (llIllIIlllII(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if ((0x16 ^ 0x34 ^ 0x2B ^ 0xD) == "   ".length())
        return (59 + 10 - -13 + 46 ^ 44 + 27 - 54 + 145) & (0xBE ^ 0x84 ^ 0xBA ^ 0xA2 ^ -" ".length()); 
    } else {
    
    } 
    return lllIllIlII[0];
  }
  
  private static void llIllIIIlIII() {
    lllIllIIlI = new String[lllIllIlII[11]];
    lllIllIIlI[lllIllIlII[0]] = llIllIIIIIII("dY+bgj5QJcA=", "qTdeo");
    lllIllIIlI[lllIllIlII[1]] = llIllIIIIIIl("", "NXIZP");
    lllIllIIlI[lllIllIlII[2]] = llIllIIIIIlI("3edgUYOW/AE=", "nCEIO");
    lllIllIIlI[lllIllIlII[18]] = llIllIIIIIII("3L8pYgE90OM=", "jAFzy");
    lllIllIIlI[lllIllIlII[19]] = llIllIIIIIII("2rWXnyKBomE=", "NhuRF");
    lllIllIIlI[lllIllIlII[20]] = llIllIIIIIlI("0MHMEXpTvdqZYSx3tSCn/g==", "TznoB");
    lllIllIIlI[lllIllIlII[21]] = llIllIIIIIlI("/j3jntJ5x45tBHEdREujpw==", "IYwhg");
    lllIllIIlI[lllIllIlII[29]] = llIllIIIIIlI("O9smD7LWVCU=", "cEsRf");
    lllIllIIlI[lllIllIlII[30]] = llIllIIIIIII("ZnrJ3VYvodg=", "gzxgO");
    lllIllIIlI[lllIllIlII[31]] = llIllIIIIIII("Y2q1K2Qz2N4=", "OJNhB");
    lllIllIIlI[lllIllIlII[32]] = llIllIIIIIII("5NnWb838+sg=", "DMQXi");
    lllIllIIlI[lllIllIlII[33]] = llIllIIIIIII("SqspdXES8xcxAhuiAa04DrZvQE/97LlF9aV2XfMvF4PbynbFQ2fanw==", "kNBcx");
    lllIllIIlI[lllIllIlII[34]] = llIllIIIIIII("RmGPbO+jA3c=", "HncLZ");
    lllIllIIlI[lllIllIlII[35]] = llIllIIIIIlI("FM43FVHUCHfyHf01Y+RJXQ==", "KGyyi");
    lllIllIIlI[lllIllIlII[36]] = llIllIIIIIlI("jNfe4m1Kb4A=", "YEuEm");
    lllIllIIlI[lllIllIlII[25]] = llIllIIIIIIl("PxQfPRYPImsXKUcnFT0gFA==", "wcRGS");
    lllIllIIlI[lllIllIlII[37]] = llIllIIIIIlI("hIt64WpaeQ8=", "vVjrO");
    lllIllIIlI[lllIllIlII[38]] = llIllIIIIIIl("", "WBrzW");
    lllIllIIlI[lllIllIlII[39]] = llIllIIIIIlI("UK0kOOnDL6I=", "CDjzz");
  }
  
  private static String lllIIllllI(String llllllllllllllllIllllIIIllIlIIlI, String llllllllllllllllIllllIIIllIllIlI) {
    String str = new String(Base64.getDecoder().decode(llllllllllllllllIllllIIIllIlIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIllllIIIllIllIll = new StringBuilder();
    char[] llllllllllllllllIllllIIIllIlIlII = llllllllllllllllIllllIIIllIllIlI.toCharArray();
    int llllllllllllllllIllllIIIllIllIII = lIIlIlIIl[lllIllIlII[0]];
    char[] arrayOfChar1 = str.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIIlIlIIl[lllIllIlII[0]];
    while (llIllIIllIIl(lllIlIIIlI(j, i))) {
      char llllllllllllllllIllllIIIllIlIIll = arrayOfChar1[j];
      lllIllIIlI[lllIllIlII[0]].length();
      llllllllllllllllIllllIIIllIllIII++;
      j++;
      "".length();
      if (llIllIIllIlI(lllIllIIlI[lllIllIlII[2]].length(), (lllIllIlII[3] + lllIllIlII[4] - lllIllIlII[5] + lllIllIlII[6] ^ lllIllIlII[7] + lllIllIlII[8] - lllIllIlII[9] + lllIllIlII[10]) & (lllIllIlII[11] + lllIllIlII[12] - lllIllIlII[13] + lllIllIlII[14] ^ lllIllIlII[15] + lllIllIlII[9] - lllIllIlII[16] + lllIllIlII[17] ^ -lllIllIIlI[lllIllIlII[18]].length())))
        return null; 
    } 
    return String.valueOf(llllllllllllllllIllllIIIllIllIll);
  }
  
  private static boolean llIllIIllIll(int llllllllllllllllIllllIIIIlIlIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 <= null);
  }
  
  private static boolean lllIlIIIIl(int llllllllllllllllIllllIIIlIllIIll) {
    if (llIllIIllIIl(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return (0x8B ^ 0xAE) & (0x66 ^ 0x43 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lllIllIlII[0];
  }
  
  public EconomyManager(byte llllllllllllllllIllllIIIlIlIIIII) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aconst_null
    //   6: putfield economy : Lcom/axeelheaven/hbedwars/database/economy/Economy;
    //   9: aload_1
    //   10: invokevirtual getSettings : ()Lcom/axeelheaven/hbedwars/custom/config/HConfiguration;
    //   13: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lIIlIlIII : [Ljava/lang/String;
    //   16: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lIIlIlIIl : [I
    //   19: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   22: iconst_0
    //   23: iaload
    //   24: iaload
    //   25: aaload
    //   26: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   29: astore_2
    //   30: aload_2
    //   31: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lIIlIlIII : [Ljava/lang/String;
    //   34: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lIIlIlIIl : [I
    //   37: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   40: iconst_1
    //   41: iaload
    //   42: iaload
    //   43: aaload
    //   44: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   47: invokestatic lllIlIIIIl : (I)Z
    //   50: invokestatic llIllIIllIIl : (I)Z
    //   53: ifeq -> 108
    //   56: aload_0
    //   57: new com/axeelheaven/hbedwars/database/economy/types/EconomyVault
    //   60: dup
    //   61: aload_1
    //   62: invokespecial <init> : (Lcom/axeelheaven/hbedwars/BedWars;)V
    //   65: putfield economy : Lcom/axeelheaven/hbedwars/database/economy/Economy;
    //   68: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIIlI : [Ljava/lang/String;
    //   71: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   74: bipush #38
    //   76: iaload
    //   77: aaload
    //   78: invokevirtual length : ()I
    //   81: ldc ''
    //   83: invokevirtual length : ()I
    //   86: pop2
    //   87: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIIlI : [Ljava/lang/String;
    //   90: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   93: bipush #39
    //   95: iaload
    //   96: aaload
    //   97: invokevirtual length : ()I
    //   100: invokestatic llIllIIllIll : (I)Z
    //   103: ifeq -> 146
    //   106: aconst_null
    //   107: athrow
    //   108: aload_2
    //   109: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lIIlIlIII : [Ljava/lang/String;
    //   112: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lIIlIlIIl : [I
    //   115: getstatic com/axeelheaven/hbedwars/database/economy/EconomyManager.lllIllIlII : [I
    //   118: iconst_2
    //   119: iaload
    //   120: iaload
    //   121: aaload
    //   122: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   125: invokestatic lllIlIIIIl : (I)Z
    //   128: invokestatic llIllIIllIIl : (I)Z
    //   131: ifeq -> 146
    //   134: aload_0
    //   135: new com/axeelheaven/hbedwars/database/economy/types/EconomyPlayerPoints
    //   138: dup
    //   139: aload_1
    //   140: invokespecial <init> : (Lcom/axeelheaven/hbedwars/BedWars;)V
    //   143: putfield economy : Lcom/axeelheaven/hbedwars/database/economy/Economy;
    //   146: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   30	117	2	llllllllllllllllIllllIIIlIlIIIlI	Ljava/lang/String;
    //   0	147	1	llllllllllllllllIllllIIIlIlIIlII	I
    //   0	147	0	llllllllllllllllIllllIIIlIlIIlIl	Ljava/lang/String;
    //   0	147	0	llllllllllllllllIllllIIIlIlIIIIl	D
    //   0	147	2	llllllllllllllllIllllIIIlIlIIlll	B
    //   0	147	2	llllllllllllllllIllllIIIlIIlllll	J
    //   0	147	0	llllllllllllllllIllllIIIlIlIIllI	Lcom/axeelheaven/hbedwars/database/economy/EconomyManager;
    //   0	147	1	llllllllllllllllIllllIIIlIlIIIII	B
    //   0	147	1	llllllllllllllllIllllIIIlIlIIIll	Lcom/axeelheaven/hbedwars/BedWars;
  }
  
  private static void llIllIIllIII() {
    lllIllIlII = new int[40];
    lllIllIlII[0] = (0x25 ^ 0x16) & (0x95 ^ 0xA6 ^ 0xFFFFFFFF);
    lllIllIlII[1] = " ".length();
    lllIllIlII[2] = "  ".length();
    lllIllIlII[3] = 0x7F ^ 0x3B;
    lllIllIlII[4] = 85 + 86 - 165 + 123;
    lllIllIlII[5] = 129 + 141 - 233 + 125;
    lllIllIlII[6] = 210 + 202 - 379 + 206 ^ 56 + 53 - -8 + 25;
    lllIllIlII[7] = 0x5 ^ 0x66;
    lllIllIlII[8] = 0x7D ^ 0x65;
    lllIllIlII[9] = 143 + 108 - 97 + 93 ^ 158 + 152 - 284 + 173;
    lllIllIlII[10] = 0x1D ^ 0x36 ^ 0x4E ^ 0x53;
    lllIllIlII[11] = 0x92 ^ 0x97 ^ 0x44 ^ 0x52;
    lllIllIlII[12] = 17 + 95 - 10 + 50;
    lllIllIlII[13] = 0x26 ^ 0x5B;
    lllIllIlII[14] = 0xCF ^ 0x98 ^ 0x4F ^ 0x61;
    lllIllIlII[15] = 0x9E ^ 0xBB;
    lllIllIlII[16] = -(45 + 31 - 36 + 103 ^ 62 + 17 - 22 + 81);
    lllIllIlII[17] = 0x40 ^ 0x8;
    lllIllIlII[18] = "   ".length();
    lllIllIlII[19] = 0x49 ^ 0x4D;
    lllIllIlII[20] = 0xB3 ^ 0xB6;
    lllIllIlII[21] = 0x3 ^ 0x5;
    lllIllIlII[22] = 0xB1 ^ 0xA6 ^ 0x69 ^ 0x64;
    lllIllIlII[23] = 0xB ^ 0x2 ^ 0x29 ^ 0x5B;
    lllIllIlII[24] = 0xA ^ 0x69 ^ 0x5C ^ 0x69;
    lllIllIlII[25] = 0x35 ^ 0x1 ^ 0x1B ^ 0x20;
    lllIllIlII[26] = 0xDE ^ 0x8E;
    lllIllIlII[27] = 0x62 ^ 0x7D;
    lllIllIlII[28] = 0x50 ^ 0x3F;
    lllIllIlII[29] = 0x45 ^ 0x42;
    lllIllIlII[30] = 0x6F ^ 0x47 ^ 0xA9 ^ 0x89;
    lllIllIlII[31] = 0x58 ^ 0x8 ^ 0x26 ^ 0x7F;
    lllIllIlII[32] = 0x80 ^ 0x8A;
    lllIllIlII[33] = 0x61 ^ 0x6A;
    lllIllIlII[34] = 0x8C ^ 0x80;
    lllIllIlII[35] = 0x1B ^ 0x57 ^ 0xC ^ 0x4D;
    lllIllIlII[36] = 0xCF ^ 0x97 ^ 0x2E ^ 0x78;
    lllIllIlII[37] = 116 + 80 - 97 + 55 ^ 64 + 52 - 2 + 24;
    lllIllIlII[38] = 0x1B ^ 0xA;
    lllIllIlII[39] = 0x1B ^ 0x22 ^ 0x37 ^ 0x1C;
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\database\economy\EconomyManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */