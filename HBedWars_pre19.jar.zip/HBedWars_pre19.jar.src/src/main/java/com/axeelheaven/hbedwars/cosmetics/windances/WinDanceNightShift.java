package com.axeelheaven.hbedwars.cosmetics.windances;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.api.arena.Arena;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.entity.Player;

public class WinDanceNightShift extends WinDance {
  private static boolean lIIIllllIIllI(short llllllllllllllllIIIllIIllIIIIlIl, byte llllllllllllllllIIIllIIllIIIIIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public WinDanceNightShift(boolean llllllllllllllllIIIllIIlllllIIll, String llllllllllllllllIIIllIIlllllllll, float llllllllllllllllIIIllIIllllIlllI, float llllllllllllllllIIIllIIllllllIlI) {
    super(llllllllllllllllIIIllIIlllllllll, llllllllllllllllIIIllIIllllIlllI, llllllllllllllllIIIllIIllllllIlI);
    this.plugin = llllllllllllllllIIIllIIlllllIIll;
    this.runnable = new HashMap<>();
  }
  
  private static String lIIIllIllIllI(String llllllllllllllllIIIllIIllIlIIIII, int llllllllllllllllIIIllIIllIIlllIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc 'Blowfish'
    //   21: invokespecial <init> : ([BLjava/lang/String;)V
    //   24: astore_2
    //   25: ldc 'Blowfish'
    //   27: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   30: astore_3
    //   31: aload_3
    //   32: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceNightShift.lIIlIIIIlIl : [I
    //   35: iconst_1
    //   36: iaload
    //   37: aload_2
    //   38: invokevirtual init : (ILjava/security/Key;)V
    //   41: new java/lang/String
    //   44: dup
    //   45: aload_3
    //   46: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   49: aload_0
    //   50: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   53: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   56: invokevirtual decode : ([B)[B
    //   59: invokevirtual doFinal : ([B)[B
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   68: areturn
    //   69: astore_2
    //   70: aload_2
    //   71: invokevirtual printStackTrace : ()V
    //   74: aconst_null
    //   75: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   31	38	3	llllllllllllllllIIIllIIllIlIIIlI	Ljavax/crypto/Cipher;
    //   70	4	2	llllllllllllllllIIIllIIllIlIIIIl	Ljava/lang/Exception;
    //   0	76	0	llllllllllllllllIIIllIIllIIllllI	C
    //   0	76	0	llllllllllllllllIIIllIIllIlIIIII	Ljava/lang/String;
    //   0	76	1	llllllllllllllllIIIllIIllIIlllll	Ljava/lang/String;
    //   0	76	2	llllllllllllllllIIIllIIllIIlllII	S
    //   25	44	2	llllllllllllllllIIIllIIllIlIIIll	Ljavax/crypto/spec/SecretKeySpec;
    //   0	76	1	llllllllllllllllIIIllIIllIIlllIl	I
    //   0	76	3	llllllllllllllllIIIllIIllIIllIll	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	68	69	java/lang/Exception
  }
  
  private static String lIIIllIllIlII(String llllllllllllllllIIIllIIllIIlIIll, String llllllllllllllllIIIllIIllIIlIIlI) {
    try {
      SecretKeySpec llllllllllllllllIIIllIIllIIlIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIIllIIllIIlIIlI.getBytes(StandardCharsets.UTF_8)), lIIlIIIIlIl[9]), "DES");
      Cipher llllllllllllllllIIIllIIllIIlIlIl = Cipher.getInstance("DES");
      llllllllllllllllIIIllIIllIIlIlIl.init(lIIlIIIIlIl[1], llllllllllllllllIIIllIIllIIlIllI);
      return new String(llllllllllllllllIIIllIIllIIlIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIIIllIIllIIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception llllllllllllllllIIIllIIllIIlIlII) {
      llllllllllllllllIIIllIIllIIlIlII.printStackTrace();
      return null;
    } 
  }
  
  private static boolean llIIllIIllI(boolean llllllllllllllllIIIllIIlllIIIlII) {
    if (lIIIllllIIlIl(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (-(0x44 ^ 0x5A ^ 0xD8 ^ 0xC3) >= 0)
        return (0x81 ^ 0x86 ^ 0xC4 ^ 0x8F) & (0xF4 ^ 0x8F ^ 0xB7 ^ 0x80 ^ -" ".length()); 
    } else {
    
    } 
    return lIIlIIIIlIl[0];
  }
  
  public void execute(Player llllllllllllllllIIIllIlIIIIllIlI, Arena llllllllllllllllIIIllIlIIIlIIllI) {
    // Byte code:
    //   0: new java/util/concurrent/atomic/AtomicInteger
    //   3: dup
    //   4: aload_2
    //   5: invokevirtual getArenaTask : ()Lcom/axeelheaven/hbedwars/arena/task/ArenaTask;
    //   8: invokevirtual getEndSeconds : ()I
    //   11: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceNightShift.lllllllII : [I
    //   14: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceNightShift.lIIlIIIIlIl : [I
    //   17: iconst_0
    //   18: iaload
    //   19: iaload
    //   20: imul
    //   21: invokespecial <init> : (I)V
    //   24: astore_3
    //   25: aload_2
    //   26: invokevirtual getSpectator : ()Lorg/bukkit/Location;
    //   29: astore #4
    //   31: aload_0
    //   32: getfield runnable : Ljava/util/HashMap;
    //   35: aload_1
    //   36: aload_0
    //   37: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   40: invokevirtual getServer : ()Lorg/bukkit/Server;
    //   43: invokeinterface getScheduler : ()Lorg/bukkit/scheduler/BukkitScheduler;
    //   48: aload_0
    //   49: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   52: aload_0
    //   53: aload_3
    //   54: aload_1
    //   55: aload_2
    //   56: aload #4
    //   58: <illegal opcode> run : (Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceNightShift;Ljava/util/concurrent/atomic/AtomicInteger;Lorg/bukkit/entity/Player;Lcom/axeelheaven/hbedwars/api/arena/Arena;Lorg/bukkit/Location;)Ljava/lang/Runnable;
    //   63: lconst_1
    //   64: lconst_1
    //   65: invokeinterface scheduleSyncRepeatingTask : (Lorg/bukkit/plugin/Plugin;Ljava/lang/Runnable;JJ)I
    //   70: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   73: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   76: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceNightShift.lIIIllllllI : [Ljava/lang/String;
    //   79: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceNightShift.lIIlIIIIlIl : [I
    //   82: iconst_0
    //   83: iaload
    //   84: aaload
    //   85: invokevirtual length : ()I
    //   88: pop2
    //   89: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   31	59	4	llllllllllllllllIIIllIlIIIlIlIll	Lorg/bukkit/Location;
    //   0	90	2	llllllllllllllllIIIllIlIIIIlIlIl	I
    //   0	90	2	llllllllllllllllIIIllIlIIIlIIllI	Lcom/axeelheaven/hbedwars/api/arena/Arena;
    //   0	90	1	llllllllllllllllIIIllIlIIIIlIllI	C
    //   0	90	4	llllllllllllllllIIIllIlIIIIlIIll	Ljava/lang/String;
    //   0	90	3	llllllllllllllllIIIllIlIIIIlIlII	Ljava/lang/String;
    //   25	65	3	llllllllllllllllIIIllIlIIIIlllII	Ljava/util/concurrent/atomic/AtomicInteger;
    //   0	90	1	llllllllllllllllIIIllIlIIIIllIlI	Lorg/bukkit/entity/Player;
    //   0	90	4	llllllllllllllllIIIllIlIIIlIIIII	Ljava/lang/Exception;
    //   0	90	1	llllllllllllllllIIIllIlIIIlIlIII	D
    //   0	90	0	llllllllllllllllIIIllIlIIIlIIIlI	Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceNightShift;
    //   0	90	2	llllllllllllllllIIIllIlIIIlIlllI	S
    //   0	90	3	llllllllllllllllIIIllIlIIIIllllI	Ljava/lang/Exception;
    //   0	90	0	llllllllllllllllIIIllIlIIIIllIII	I
    //   0	90	0	llllllllllllllllIIIllIlIIIlIIlII	F
  }
  
  private static boolean lIIIllllIIlll(int llllllllllllllllIIIllIIlIlllIllI, short llllllllllllllllIIIllIIlIlllIlIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean llIIllIIlIl(Exception llllllllllllllllIIIllIlIIIIIlllI, String llllllllllllllllIIIllIlIIIIIllIl) {
    if (lIIIllllIIIll(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (((166 + 23 - 54 + 72 ^ 138 + 131 - 134 + 62) & (82 + 115 - 54 + 29 ^ 114 + 128 - 157 + 81 ^ -" ".length())) != ((0x11 ^ 0x68 ^ 0xC0 ^ 0x88) & (0x68 ^ 0x30 ^ 0xF2 ^ 0x9B ^ -" ".length())))
        return (199 + 76 - 164 + 98 ^ 161 + 1 - 121 + 153) & (80 + 110 - 151 + 174 ^ 175 + 28 - 171 + 166 ^ -" ".length()); 
    } else {
    
    } 
    return lIIlIIIIlIl[0];
  }
  
  private static String lIIIllIllIlIl(String llllllllllllllllIIIllIIllIllIlIl, double llllllllllllllllIIIllIIllIlIllll) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceNightShift.lIIlIIIIlIl : [I
    //   40: iconst_0
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceNightShift.lIIlIIIIlIl : [I
    //   58: iconst_0
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic lIIIllllIIlll : (II)Z
    //   69: ifeq -> 155
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: bipush #106
    //   114: bipush #77
    //   116: ixor
    //   117: bipush #45
    //   119: bipush #58
    //   121: ixor
    //   122: ixor
    //   123: bipush #37
    //   125: bipush #74
    //   127: ixor
    //   128: bipush #10
    //   130: bipush #85
    //   132: ixor
    //   133: ixor
    //   134: ldc_w ' '
    //   137: invokevirtual length : ()I
    //   140: ineg
    //   141: ixor
    //   142: iand
    //   143: ldc_w ' '
    //   146: invokevirtual length : ()I
    //   149: ineg
    //   150: if_icmpgt -> 62
    //   153: aconst_null
    //   154: areturn
    //   155: aload_2
    //   156: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   159: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	160	2	llllllllllllllllIIIllIIllIlIlllI	F
    //   0	160	1	llllllllllllllllIIIllIIllIllIlII	Ljava/lang/String;
    //   0	160	7	llllllllllllllllIIIllIIllIlIlIIl	C
    //   0	160	8	llllllllllllllllIIIllIIllIlIlIII	J
    //   0	160	3	llllllllllllllllIIIllIIllIlIllIl	B
    //   79	24	8	llllllllllllllllIIIllIIllIllIllI	C
    //   44	116	4	llllllllllllllllIIIllIIllIllIIIl	I
    //   0	160	4	llllllllllllllllIIIllIIllIlIllII	Ljava/lang/Exception;
    //   0	160	0	llllllllllllllllIIIllIIllIllIIII	Z
    //   0	160	0	llllllllllllllllIIIllIIllIllIlIl	Ljava/lang/String;
    //   0	160	1	llllllllllllllllIIIllIIllIlIllll	D
    //   0	160	5	llllllllllllllllIIIllIIllIlIlIll	Z
    //   0	160	6	llllllllllllllllIIIllIIllIlIlIlI	Z
    //   32	128	2	llllllllllllllllIIIllIIllIllIIll	Ljava/lang/StringBuilder;
    //   37	123	3	llllllllllllllllIIIllIIllIllIIlI	[C
  }
  
  private static void lIIIllIllIlll() {
    lIIIllllllI = new String[lIIlIIIIlIl[8]];
    lIIIllllllI[lIIlIIIIlIl[0]] = lIIIllIllIlII("/KCV++nMjUY=", "OGVGW");
    lIIIllllllI[lIIlIIIIlIl[2]] = lIIIllIllIlIl("TQ==", "mWRhj");
    lIIIllllllI[lIIlIIIIlIl[1]] = lIIIllIllIlII("lNvM1eGbeTM=", "MLgPq");
    lIIIllllllI[lIIlIIIIlIl[4]] = lIIIllIllIlIl("", "HXQex");
    lIIIllllllI[lIIlIIIIlIl[5]] = lIIIllIllIlIl("SlZ2", "jvVdg");
    lIIIllllllI[lIIlIIIIlIl[6]] = lIIIllIllIlIl("Ug==", "rZFWX");
    lIIIllllllI[lIIlIIIIlIl[7]] = lIIIllIllIllI("4x6xHbW0l7A=", "OsHij");
  }
  
  private static boolean lIIIllllIIlIl(String llllllllllllllllIIIllIIlIlllIIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean llIIllIIlll(double llllllllllllllllIIIllIlIIIIIlIlI) {
    if (lIIIllllIIlII(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return (0x3B ^ 0x7C ^ 0xB6 ^ 0xB9) & (0x86 ^ 0xB3 ^ 0x1E ^ 0x63 ^ -" ".length()) & ((0x34 ^ 0x4A ^ 0x50 ^ 0x79) & (0x88 ^ 0xA9 ^ 0x5E ^ 0x28 ^ -" ".length()) ^ -" ".length()); 
    } else {
    
    } 
    return lIIlIIIIlIl[0];
  }
  
  private static boolean lIIIllllIIlII(char llllllllllllllllIIIllIIlIllIllIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  static {
    lIIIllllIIIlI();
    lIIIllIllIlll();
    llIIllIIlII();
  }
  
  private static boolean lIIIllllIIIll(int llllllllllllllllIIIllIIlIllllIll, double llllllllllllllllIIIllIIlIllllIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static void llIIllIIlII() {
    lllllllII = new int[lIIlIIIIlIl[1]];
    lllllllII[lIIlIIIIlIl[0]] = lIIlIIIIlIl[2] ^ lIIlIIIIlIl[3];
    lllllllII[lIIlIIIIlIl[2]] = lIIIllllllI[lIIlIIIIlIl[2]].length();
  }
  
  private static void lIIIllllIIIlI() {
    lIIlIIIIlIl = new int[10];
    lIIlIIIIlIl[0] = (0x6B ^ 0x3E) & (0xE3 ^ 0xB6 ^ 0xFFFFFFFF);
    lIIlIIIIlIl[1] = "  ".length();
    lIIlIIIIlIl[2] = " ".length();
    lIIlIIIIlIl[3] = 0x0 ^ 0x9;
    lIIlIIIIlIl[4] = "   ".length();
    lIIlIIIIlIl[5] = 149 + 2 - 20 + 28 ^ 96 + 49 - -2 + 8;
    lIIlIIIIlIl[6] = 0x80 ^ 0x85;
    lIIlIIIIlIl[7] = 170 + 65 - 126 + 77 ^ 173 + 159 - 241 + 97;
    lIIlIIIIlIl[8] = 0x52 ^ 0x19 ^ 0x76 ^ 0x3A;
    lIIlIIIIlIl[9] = 0xF ^ 0x7;
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\windances\WinDanceNightShift.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */