package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.BitCountOption;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.BitOP;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.BitPosParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GetExParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.LCSParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.SetParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.StrAlgoLCSParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LCSMatchResult;
import java.util.List;

public interface StringPipelineCommands {
  Response<String> set(String paramString1, String paramString2);
  
  Response<String> set(String paramString1, String paramString2, SetParams paramSetParams);
  
  Response<String> get(String paramString);
  
  Response<String> getDel(String paramString);
  
  Response<String> getEx(String paramString, GetExParams paramGetExParams);
  
  Response<Boolean> setbit(String paramString, long paramLong, boolean paramBoolean);
  
  Response<Boolean> getbit(String paramString, long paramLong);
  
  Response<Long> setrange(String paramString1, long paramLong, String paramString2);
  
  Response<String> getrange(String paramString, long paramLong1, long paramLong2);
  
  Response<String> getSet(String paramString1, String paramString2);
  
  Response<Long> setnx(String paramString1, String paramString2);
  
  Response<String> setex(String paramString1, long paramLong, String paramString2);
  
  Response<String> psetex(String paramString1, long paramLong, String paramString2);
  
  Response<List<String>> mget(String... paramVarArgs);
  
  Response<String> mset(String... paramVarArgs);
  
  Response<Long> msetnx(String... paramVarArgs);
  
  Response<Long> incr(String paramString);
  
  Response<Long> incrBy(String paramString, long paramLong);
  
  Response<Double> incrByFloat(String paramString, double paramDouble);
  
  Response<Long> decr(String paramString);
  
  Response<Long> decrBy(String paramString, long paramLong);
  
  Response<Long> append(String paramString1, String paramString2);
  
  Response<String> substr(String paramString, int paramInt1, int paramInt2);
  
  Response<Long> strlen(String paramString);
  
  Response<Long> bitcount(String paramString);
  
  Response<Long> bitcount(String paramString, long paramLong1, long paramLong2);
  
  Response<Long> bitcount(String paramString, long paramLong1, long paramLong2, BitCountOption paramBitCountOption);
  
  Response<Long> bitpos(String paramString, boolean paramBoolean);
  
  Response<Long> bitpos(String paramString, boolean paramBoolean, BitPosParams paramBitPosParams);
  
  Response<List<Long>> bitfield(String paramString, String... paramVarArgs);
  
  Response<List<Long>> bitfieldReadonly(String paramString, String... paramVarArgs);
  
  Response<Long> bitop(BitOP paramBitOP, String paramString, String... paramVarArgs);
  
  @Deprecated
  Response<LCSMatchResult> strAlgoLCSKeys(String paramString1, String paramString2, StrAlgoLCSParams paramStrAlgoLCSParams);
  
  Response<LCSMatchResult> lcs(String paramString1, String paramString2, LCSParams paramLCSParams);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\StringPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */