package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.Rawable;

public interface ProtocolCommand extends Rawable {}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\ProtocolCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */