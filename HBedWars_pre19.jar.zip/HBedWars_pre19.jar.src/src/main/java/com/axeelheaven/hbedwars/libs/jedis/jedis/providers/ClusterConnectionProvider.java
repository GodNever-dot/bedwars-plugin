/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.providers;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.ClusterCommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Connection;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.ConnectionPool;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.HostAndPort;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.JedisClientConfig;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.JedisClusterInfoCache;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisClusterOperationException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisConnectionException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ClusterConnectionProvider
/*     */   implements ConnectionProvider
/*     */ {
/*     */   protected final JedisClusterInfoCache cache;
/*     */   
/*     */   public ClusterConnectionProvider(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig) {
/*  26 */     this.cache = new JedisClusterInfoCache(clientConfig, clusterNodes);
/*  27 */     initializeSlotsCache(clusterNodes, clientConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public ClusterConnectionProvider(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig) {
/*  32 */     this.cache = new JedisClusterInfoCache(clientConfig, poolConfig, clusterNodes);
/*  33 */     initializeSlotsCache(clusterNodes, clientConfig);
/*     */   }
/*     */   
/*     */   private void initializeSlotsCache(Set<HostAndPort> startNodes, JedisClientConfig clientConfig) {
/*  37 */     ArrayList<HostAndPort> startNodeList = new ArrayList<>(startNodes);
/*  38 */     Collections.shuffle(startNodeList);
/*     */     
/*  40 */     for (HostAndPort hostAndPort : startNodeList) {
/*  41 */       try (Connection jedis = new Connection(hostAndPort, clientConfig)) {
/*  42 */         this.cache.discoverClusterNodesAndSlots(jedis);
/*     */         return;
/*  44 */       } catch (JedisConnectionException jedisConnectionException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  49 */     throw new JedisClusterOperationException("Could not initialize cluster slots cache.");
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  54 */     this.cache.reset();
/*     */   }
/*     */   
/*     */   public void renewSlotCache() {
/*  58 */     this.cache.renewClusterSlots(null);
/*     */   }
/*     */   
/*     */   public void renewSlotCache(Connection jedis) {
/*  62 */     this.cache.renewClusterSlots(jedis);
/*     */   }
/*     */   
/*     */   public Map<String, ConnectionPool> getNodes() {
/*  66 */     return this.cache.getNodes();
/*     */   }
/*     */   
/*     */   public HostAndPort getNode(int slot) {
/*  70 */     return (slot >= 0) ? this.cache.getSlotNode(slot) : null;
/*     */   }
/*     */   
/*     */   public Connection getConnection(HostAndPort node) {
/*  74 */     return (node != null) ? this.cache.setupNodeIfNotExist(node).getResource() : getConnection();
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection getConnection(CommandArguments args) {
/*  79 */     int slot = ((ClusterCommandArguments)args).getCommandHashSlot();
/*  80 */     return (slot >= 0) ? getConnectionFromSlot(slot) : getConnection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() {
/*  89 */     List<ConnectionPool> pools = this.cache.getShuffledNodesPool();
/*     */     
/*  91 */     JedisException suppressed = null;
/*  92 */     for (ConnectionPool pool : pools) {
/*  93 */       Connection jedis = null;
/*     */       try {
/*  95 */         jedis = pool.getResource();
/*  96 */         if (jedis == null) {
/*     */           continue;
/*     */         }
/*     */         
/* 100 */         jedis.ping();
/* 101 */         return jedis;
/*     */       }
/* 103 */       catch (JedisException ex) {
/* 104 */         if (suppressed == null) {
/* 105 */           suppressed = ex;
/*     */         }
/* 107 */         if (jedis != null) {
/* 108 */           jedis.close();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 113 */     JedisClusterOperationException noReachableNode = new JedisClusterOperationException("No reachable node in cluster.");
/* 114 */     if (suppressed != null) {
/* 115 */       noReachableNode.addSuppressed((Throwable)suppressed);
/*     */     }
/* 117 */     throw noReachableNode;
/*     */   }
/*     */   
/*     */   public Connection getConnectionFromSlot(int slot) {
/* 121 */     ConnectionPool connectionPool = this.cache.getSlotPool(slot);
/* 122 */     if (connectionPool != null)
/*     */     {
/* 124 */       return connectionPool.getResource();
/*     */     }
/*     */ 
/*     */     
/* 128 */     renewSlotCache();
/* 129 */     connectionPool = this.cache.getSlotPool(slot);
/* 130 */     if (connectionPool != null) {
/* 131 */       return connectionPool.getResource();
/*     */     }
/*     */     
/* 134 */     return getConnection();
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\providers\ClusterConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */