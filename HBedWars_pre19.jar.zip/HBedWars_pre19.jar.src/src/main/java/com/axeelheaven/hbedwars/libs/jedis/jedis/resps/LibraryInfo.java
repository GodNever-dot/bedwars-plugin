/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Builder;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.BuilderFactory;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LibraryInfo
/*    */ {
/*    */   private final String libraryName;
/*    */   private final String engine;
/*    */   private final String description;
/*    */   private final List<Map<String, Object>> functions;
/*    */   private final String libraryCode;
/*    */   
/*    */   public LibraryInfo(String libraryName, String engineName, String description, List<Map<String, Object>> functions) {
/* 21 */     this(libraryName, engineName, description, functions, null);
/*    */   }
/*    */   
/*    */   public LibraryInfo(String libraryName, String engineName, String description, List<Map<String, Object>> functions, String code) {
/* 25 */     this.libraryName = libraryName;
/* 26 */     this.engine = engineName;
/* 27 */     this.description = description;
/* 28 */     this.functions = functions;
/* 29 */     this.libraryCode = code;
/*    */   }
/*    */   
/*    */   public String getLibraryName() {
/* 33 */     return this.libraryName;
/*    */   }
/*    */   
/*    */   public String getEngine() {
/* 37 */     return this.engine;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 41 */     return this.description;
/*    */   }
/*    */   
/*    */   public List<Map<String, Object>> getFunctions() {
/* 45 */     return this.functions;
/*    */   }
/*    */   
/*    */   public String getLibraryCode() {
/* 49 */     return this.libraryCode;
/*    */   }
/*    */   
/* 52 */   public static final Builder<LibraryInfo> LIBRARY_BUILDER = new Builder<LibraryInfo>()
/*    */     {
/*    */       public LibraryInfo build(Object data) {
/* 55 */         List<Object> objectList = (List<Object>)data;
/* 56 */         String libname = (String)BuilderFactory.STRING.build(objectList.get(1));
/* 57 */         String engine = (String)BuilderFactory.STRING.build(objectList.get(3));
/* 58 */         String desc = (String)BuilderFactory.STRING.build(objectList.get(5));
/* 59 */         List<Object> rawFunctions = (List<Object>)objectList.get(7);
/* 60 */         List<Map<String, Object>> functions = (List<Map<String, Object>>)rawFunctions.stream().map(o -> (Map)BuilderFactory.ENCODED_OBJECT_MAP.build(o)).collect(Collectors.toList());
/* 61 */         if (objectList.size() <= 8) {
/* 62 */           return new LibraryInfo(libname, engine, desc, functions);
/*    */         }
/* 64 */         String code = (String)BuilderFactory.STRING.build(objectList.get(9));
/* 65 */         return new LibraryInfo(libname, engine, desc, functions, code);
/*    */       }
/*    */     };
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\LibraryInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */