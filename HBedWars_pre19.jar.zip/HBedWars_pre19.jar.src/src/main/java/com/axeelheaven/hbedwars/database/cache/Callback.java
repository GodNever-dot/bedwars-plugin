package com.axeelheaven.hbedwars.database.cache;

public interface Callback<T> {
    void done(T result);
    void error(Throwable error);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\database\cache\Callback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */