package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.BitCountOption;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.BitOP;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.BitPosParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GetExParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.LCSParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.SetParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.StrAlgoLCSParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LCSMatchResult;
import java.util.List;

public interface StringCommands {
  String set(String paramString1, String paramString2);
  
  String set(String paramString1, String paramString2, SetParams paramSetParams);
  
  String get(String paramString);
  
  String getDel(String paramString);
  
  String getEx(String paramString, GetExParams paramGetExParams);
  
  boolean setbit(String paramString, long paramLong, boolean paramBoolean);
  
  boolean getbit(String paramString, long paramLong);
  
  long setrange(String paramString1, long paramLong, String paramString2);
  
  String getrange(String paramString, long paramLong1, long paramLong2);
  
  String getSet(String paramString1, String paramString2);
  
  long setnx(String paramString1, String paramString2);
  
  String setex(String paramString1, long paramLong, String paramString2);
  
  String psetex(String paramString1, long paramLong, String paramString2);
  
  List<String> mget(String... paramVarArgs);
  
  String mset(String... paramVarArgs);
  
  long msetnx(String... paramVarArgs);
  
  long incr(String paramString);
  
  long incrBy(String paramString, long paramLong);
  
  double incrByFloat(String paramString, double paramDouble);
  
  long decr(String paramString);
  
  long decrBy(String paramString, long paramLong);
  
  long append(String paramString1, String paramString2);
  
  String substr(String paramString, int paramInt1, int paramInt2);
  
  long strlen(String paramString);
  
  long bitcount(String paramString);
  
  long bitcount(String paramString, long paramLong1, long paramLong2);
  
  long bitcount(String paramString, long paramLong1, long paramLong2, BitCountOption paramBitCountOption);
  
  long bitpos(String paramString, boolean paramBoolean);
  
  long bitpos(String paramString, boolean paramBoolean, BitPosParams paramBitPosParams);
  
  List<Long> bitfield(String paramString, String... paramVarArgs);
  
  List<Long> bitfieldReadonly(String paramString, String... paramVarArgs);
  
  long bitop(BitOP paramBitOP, String paramString, String... paramVarArgs);
  
  @Deprecated
  LCSMatchResult strAlgoLCSKeys(String paramString1, String paramString2, StrAlgoLCSParams paramStrAlgoLCSParams);
  
  LCSMatchResult lcs(String paramString1, String paramString2, LCSParams paramLCSParams);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\StringCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */