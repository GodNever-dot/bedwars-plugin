/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLParameters;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultJedisClientConfig
/*     */   implements JedisClientConfig
/*     */ {
/*     */   private final int connectionTimeoutMillis;
/*     */   private final int socketTimeoutMillis;
/*     */   private final int blockingSocketTimeoutMillis;
/*     */   private final String user;
/*     */   private volatile String password;
/*     */   private final int database;
/*     */   private final String clientName;
/*     */   private final boolean ssl;
/*     */   private final SSLSocketFactory sslSocketFactory;
/*     */   private final SSLParameters sslParameters;
/*     */   private final HostnameVerifier hostnameVerifier;
/*     */   private final HostAndPortMapper hostAndPortMapper;
/*     */   
/*     */   private DefaultJedisClientConfig(int connectionTimeoutMillis, int soTimeoutMillis, int blockingSocketTimeoutMillis, String user, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier, HostAndPortMapper hostAndPortMapper) {
/*  30 */     this.connectionTimeoutMillis = connectionTimeoutMillis;
/*  31 */     this.socketTimeoutMillis = soTimeoutMillis;
/*  32 */     this.blockingSocketTimeoutMillis = blockingSocketTimeoutMillis;
/*  33 */     this.user = user;
/*  34 */     this.password = password;
/*  35 */     this.database = database;
/*  36 */     this.clientName = clientName;
/*  37 */     this.ssl = ssl;
/*  38 */     this.sslSocketFactory = sslSocketFactory;
/*  39 */     this.sslParameters = sslParameters;
/*  40 */     this.hostnameVerifier = hostnameVerifier;
/*  41 */     this.hostAndPortMapper = hostAndPortMapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getConnectionTimeoutMillis() {
/*  46 */     return this.connectionTimeoutMillis;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSocketTimeoutMillis() {
/*  51 */     return this.socketTimeoutMillis;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBlockingSocketTimeoutMillis() {
/*  56 */     return this.blockingSocketTimeoutMillis;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUser() {
/*  61 */     return this.user;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPassword() {
/*  66 */     return this.password;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void updatePassword(String password) {
/*  71 */     if (!Objects.equals(this.password, password)) {
/*  72 */       this.password = password;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDatabase() {
/*  78 */     return this.database;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClientName() {
/*  83 */     return this.clientName;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSsl() {
/*  88 */     return this.ssl;
/*     */   }
/*     */ 
/*     */   
/*     */   public SSLSocketFactory getSslSocketFactory() {
/*  93 */     return this.sslSocketFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public SSLParameters getSslParameters() {
/*  98 */     return this.sslParameters;
/*     */   }
/*     */ 
/*     */   
/*     */   public HostnameVerifier getHostnameVerifier() {
/* 103 */     return this.hostnameVerifier;
/*     */   }
/*     */ 
/*     */   
/*     */   public HostAndPortMapper getHostAndPortMapper() {
/* 108 */     return this.hostAndPortMapper;
/*     */   }
/*     */   
/*     */   public static Builder builder() {
/* 112 */     return new Builder();
/*     */   }
/*     */   
/*     */   public static class Builder
/*     */   {
/* 117 */     private int connectionTimeoutMillis = 2000;
/* 118 */     private int socketTimeoutMillis = 2000;
/* 119 */     private int blockingSocketTimeoutMillis = 0;
/*     */     
/* 121 */     private String user = null;
/* 122 */     private String password = null;
/* 123 */     private int database = 0;
/* 124 */     private String clientName = null;
/*     */     
/*     */     private boolean ssl = false;
/* 127 */     private SSLSocketFactory sslSocketFactory = null;
/* 128 */     private SSLParameters sslParameters = null;
/* 129 */     private HostnameVerifier hostnameVerifier = null;
/*     */     
/* 131 */     private HostAndPortMapper hostAndPortMapper = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultJedisClientConfig build() {
/* 137 */       return new DefaultJedisClientConfig(this.connectionTimeoutMillis, this.socketTimeoutMillis, this.blockingSocketTimeoutMillis, this.user, this.password, this.database, this.clientName, this.ssl, this.sslSocketFactory, this.sslParameters, this.hostnameVerifier, this.hostAndPortMapper);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder timeoutMillis(int timeoutMillis) {
/* 143 */       this.connectionTimeoutMillis = timeoutMillis;
/* 144 */       this.socketTimeoutMillis = timeoutMillis;
/* 145 */       return this;
/*     */     }
/*     */     
/*     */     public Builder connectionTimeoutMillis(int connectionTimeoutMillis) {
/* 149 */       this.connectionTimeoutMillis = connectionTimeoutMillis;
/* 150 */       return this;
/*     */     }
/*     */     
/*     */     public Builder socketTimeoutMillis(int socketTimeoutMillis) {
/* 154 */       this.socketTimeoutMillis = socketTimeoutMillis;
/* 155 */       return this;
/*     */     }
/*     */     
/*     */     public Builder blockingSocketTimeoutMillis(int blockingSocketTimeoutMillis) {
/* 159 */       this.blockingSocketTimeoutMillis = blockingSocketTimeoutMillis;
/* 160 */       return this;
/*     */     }
/*     */     
/*     */     public Builder user(String user) {
/* 164 */       this.user = user;
/* 165 */       return this;
/*     */     }
/*     */     
/*     */     public Builder password(String password) {
/* 169 */       this.password = password;
/* 170 */       return this;
/*     */     }
/*     */     
/*     */     public Builder database(int database) {
/* 174 */       this.database = database;
/* 175 */       return this;
/*     */     }
/*     */     
/*     */     public Builder clientName(String clientName) {
/* 179 */       this.clientName = clientName;
/* 180 */       return this;
/*     */     }
/*     */     
/*     */     public Builder ssl(boolean ssl) {
/* 184 */       this.ssl = ssl;
/* 185 */       return this;
/*     */     }
/*     */     
/*     */     public Builder sslSocketFactory(SSLSocketFactory sslSocketFactory) {
/* 189 */       this.sslSocketFactory = sslSocketFactory;
/* 190 */       return this;
/*     */     }
/*     */     
/*     */     public Builder sslParameters(SSLParameters sslParameters) {
/* 194 */       this.sslParameters = sslParameters;
/* 195 */       return this;
/*     */     }
/*     */     
/*     */     public Builder hostnameVerifier(HostnameVerifier hostnameVerifier) {
/* 199 */       this.hostnameVerifier = hostnameVerifier;
/* 200 */       return this;
/*     */     }
/*     */     
/*     */     public Builder hostAndPortMapper(HostAndPortMapper hostAndPortMapper) {
/* 204 */       this.hostAndPortMapper = hostAndPortMapper;
/* 205 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */   
/*     */   public static DefaultJedisClientConfig create(int connectionTimeoutMillis, int soTimeoutMillis, int blockingSocketTimeoutMillis, String user, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier, HostAndPortMapper hostAndPortMapper) {
/* 213 */     return new DefaultJedisClientConfig(connectionTimeoutMillis, soTimeoutMillis, blockingSocketTimeoutMillis, user, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier, hostAndPortMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultJedisClientConfig copyConfig(JedisClientConfig copy) {
/* 219 */     return new DefaultJedisClientConfig(copy.getConnectionTimeoutMillis(), copy
/* 220 */         .getSocketTimeoutMillis(), copy.getBlockingSocketTimeoutMillis(), copy.getUser(), copy
/* 221 */         .getPassword(), copy.getDatabase(), copy.getClientName(), copy.isSsl(), copy
/* 222 */         .getSslSocketFactory(), copy.getSslParameters(), copy.getHostnameVerifier(), copy
/* 223 */         .getHostAndPortMapper());
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\DefaultJedisClientConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */