package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.params.CommandListFilterByParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.CommandDocument;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.CommandInfo;
import com.axeelheaven.hbedwars.libs.jedis.jedis.util.KeyValue;
import java.util.List;
import java.util.Map;

public interface CommandCommands {
  long commandCount();
  
  Map<String, CommandDocument> commandDocs(String... paramVarArgs);
  
  List<String> commandGetKeys(String... paramVarArgs);
  
  List<KeyValue<String, List<String>>> commandGetKeysAndFlags(String... paramVarArgs);
  
  Map<String, CommandInfo> commandInfo(String... paramVarArgs);
  
  List<String> commandList();
  
  List<String> commandListFilterBy(CommandListFilterByParams paramCommandListFilterByParams);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\CommandCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */