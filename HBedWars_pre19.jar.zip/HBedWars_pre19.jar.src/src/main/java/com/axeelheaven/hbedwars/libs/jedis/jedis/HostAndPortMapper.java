package com.axeelheaven.hbedwars.libs.jedis.jedis;

public interface HostAndPortMapper {
  HostAndPort getHostAndPort(HostAndPort paramHostAndPort);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\HostAndPortMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */