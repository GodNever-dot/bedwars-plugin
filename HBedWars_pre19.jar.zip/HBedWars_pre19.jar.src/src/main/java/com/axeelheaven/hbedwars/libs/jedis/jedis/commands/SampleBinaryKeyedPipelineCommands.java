package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import java.util.List;

public interface SampleBinaryKeyedPipelineCommands {
  Response<Long> waitReplicas(byte[] paramArrayOfbyte, int paramInt, long paramLong);
  
  Response<Object> eval(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  Response<Object> evalsha(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  Response<List<Boolean>> scriptExists(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  Response<byte[]> scriptLoad(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  Response<String> scriptFlush(byte[] paramArrayOfbyte);
  
  Response<String> scriptFlush(byte[] paramArrayOfbyte, FlushMode paramFlushMode);
  
  Response<String> scriptKill(byte[] paramArrayOfbyte);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\SampleBinaryKeyedPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */