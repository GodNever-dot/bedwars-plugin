package com.axeelheaven.hbedwars.cosmetics.woodskins;

import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.Map;

public class WoodSkinManager {
    private final BedWars plugin;
    private final Map<String, WoodSkin> skins;
    
    public WoodSkinManager(BedWars plugin) {
        this.plugin = plugin;
        this.skins = new HashMap<>();
    }
    
    public void registerSkin(String id, WoodSkin skin) {
        this.skins.put(id, skin);
    }
    
    public WoodSkin getSkin(String id) {
        return this.skins.get(id);
    }
    
    public void applySkin(Block block, String id) {
        WoodSkin skin = getSkin(id);
        if (skin != null && block.getType() == Material.WOOD) {
            block.setData(skin.getData());
        }
    }
    
    public Map<String, WoodSkin> getSkins() {
        return this.skins;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\woodskins\WoodSkinManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */