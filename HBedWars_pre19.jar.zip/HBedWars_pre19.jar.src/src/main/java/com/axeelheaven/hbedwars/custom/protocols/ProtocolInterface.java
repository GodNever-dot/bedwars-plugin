package com.axeelheaven.hbedwars.custom.protocols;

import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.entity.Player;

public interface ProtocolInterface {
  void stop(BedWars paramBedWars);
  
  void start(BedWars paramBedWars);

  void sendPacket(Player player, Object packet);
  Object getHandle(Player player);
  Object getConnection(Object handle);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\protocols\ProtocolInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */