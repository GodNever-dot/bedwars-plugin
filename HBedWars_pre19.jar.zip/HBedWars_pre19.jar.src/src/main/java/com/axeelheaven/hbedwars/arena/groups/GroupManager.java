package com.axeelheaven.hbedwars.arena.groups;

import com.axeelheaven.hbedwars.BedWars;
import java.util.HashMap;
import java.util.Map;

public class GroupManager {
    private final BedWars plugin;
    private final Map<String, Group> groups;
    
    public GroupManager(BedWars plugin) {
        this.plugin = plugin;
        this.groups = new HashMap<>();
    }
    
    public void registerGroup(String name, Group group) {
        this.groups.put(name, group);
    }
    
    public Group getGroup(String name) {
        return this.groups.get(name);
    }
    
    public Map<String, Group> getGroups() {
        return this.groups;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\arena\groups\GroupManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */