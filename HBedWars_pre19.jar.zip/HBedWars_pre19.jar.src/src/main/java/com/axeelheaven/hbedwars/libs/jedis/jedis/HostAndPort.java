/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.slf4j.Logger;
/*    */ import com.axeelheaven.hbedwars.libs.slf4j.LoggerFactory;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ public class HostAndPort
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -519876229978427751L;
/* 12 */   protected static Logger log = LoggerFactory.getLogger(HostAndPort.class);
/*    */   
/*    */   private final String host;
/*    */   private final int port;
/*    */   
/*    */   public HostAndPort(String host, int port) {
/* 18 */     this.host = host;
/* 19 */     this.port = port;
/*    */   }
/*    */   
/*    */   public String getHost() {
/* 23 */     return this.host;
/*    */   }
/*    */   
/*    */   public int getPort() {
/* 27 */     return this.port;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 32 */     if (obj == null) return false; 
/* 33 */     if (obj == this) return true; 
/* 34 */     if (!(obj instanceof HostAndPort)) return false;
/*    */     
/* 36 */     HostAndPort other = (HostAndPort)obj;
/*    */     
/* 38 */     return (this.port == other.port && this.host.equals(other.host));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 43 */     return 31 * this.host.hashCode() + this.port;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 48 */     return this.host + ":" + this.port;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static HostAndPort from(String string) {
/* 57 */     int lastColon = string.lastIndexOf(":");
/* 58 */     String host = string.substring(0, lastColon);
/* 59 */     int port = Integer.parseInt(string.substring(lastColon + 1));
/* 60 */     return new HostAndPort(host, port);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\HostAndPort.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */