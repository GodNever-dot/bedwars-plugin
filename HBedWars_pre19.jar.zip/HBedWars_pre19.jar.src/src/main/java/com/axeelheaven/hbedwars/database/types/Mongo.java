package com.axeelheaven.hbedwars.database.types;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.database.Database;
import com.axeelheaven.hbedwars.database.cache.Callback;
import com.axeelheaven.hbedwars.database.profile.HData;
import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoDatabase;
import java.util.UUID;

public class Mongo extends Database {
    private final BedWars plugin;
    private MongoClient mongoClient;
    private MongoDatabase database;
    private String tableName;
    private String host;
    private String port;
    private String databaseName;

    public Mongo(BedWars plugin) {
        this.plugin = plugin;
        this.tableName = plugin.getSettings().getString("database.table");
        this.host = plugin.getSettings().getString("database.host");
        this.port = plugin.getSettings().getString("database.port");
        this.databaseName = plugin.getSettings().getString("database.name");
    }

    @Override
    public boolean connect() {
        try {
            this.mongoClient = new MongoClient(new ServerAddress(this.host, Integer.parseInt(this.port)));
            this.database = this.mongoClient.getDatabase(this.databaseName);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void get(Callback callback) {
        // Implementation for getting data
    }

    @Override
    public boolean exists(UUID uuid) {
        return this.database.getCollection(this.tableName).find(new org.bson.Document("uuid", uuid.toString())).first() != null;
    }

    @Override
    public void create(UUID uuid, String name) {
        if (!exists(uuid)) {
            this.database.getCollection(this.tableName).insertOne(
                new org.bson.Document("uuid", uuid.toString())
                    .append("name", name)
            );
        }
    }

    @Override
    public void load(HData data) {
        // Implementation for loading data
    }

    @Override
    public void save(HData data) {
        // Implementation for saving data
    }

    @Override
    public boolean tables() {
        try {
            if (!this.database.listCollectionNames().into(new java.util.ArrayList<>()).contains(this.tableName)) {
                this.database.createCollection(this.tableName);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void close() {
        if (this.mongoClient != null) {
            this.mongoClient.close();
        }
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\database\types\Mongo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */