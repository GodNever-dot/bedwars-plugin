package com.axeelheaven.hbedwars.cosmetics.toppers;

import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class TopperEdit {
    private final BedWars plugin;
    private final Location location;
    private final Material material;
    private final byte data;
    
    public TopperEdit(BedWars plugin, Location location, Material material, byte data) {
        this.plugin = plugin;
        this.location = location;
        this.material = material;
        this.data = data;
    }
    
    public void apply(Player player) {
        Block block = location.getBlock();
        block.setType(material);
        block.setData(data);
    }
    
    public Location getLocation() {
        return location;
    }
    
    public Material getMaterial() {
        return material;
    }
    
    public byte getData() {
        return data;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\toppers\TopperEdit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */