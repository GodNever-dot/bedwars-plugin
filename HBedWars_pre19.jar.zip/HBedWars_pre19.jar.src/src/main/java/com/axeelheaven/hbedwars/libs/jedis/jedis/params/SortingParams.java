/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SortingParams
/*     */   implements IParams
/*     */ {
/*  24 */   private final List<byte[]> params = (List)new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortingParams by(String pattern) {
/*  39 */     return by(SafeEncoder.encode(pattern));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortingParams by(byte[] pattern) {
/*  55 */     this.params.add(Protocol.Keyword.BY.getRaw());
/*  56 */     this.params.add(pattern);
/*  57 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortingParams nosort() {
/*  68 */     this.params.add(Protocol.Keyword.BY.getRaw());
/*  69 */     this.params.add(Protocol.Keyword.NOSORT.getRaw());
/*  70 */     return this;
/*     */   }
/*     */   
/*     */   public Collection<byte[]> getParams() {
/*  74 */     return (Collection)Collections.unmodifiableCollection(this.params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortingParams desc() {
/*  82 */     this.params.add(Protocol.Keyword.DESC.getRaw());
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortingParams asc() {
/*  91 */     this.params.add(Protocol.Keyword.ASC.getRaw());
/*  92 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortingParams limit(int start, int count) {
/* 102 */     this.params.add(Protocol.Keyword.LIMIT.getRaw());
/* 103 */     this.params.add(Protocol.toByteArray(start));
/* 104 */     this.params.add(Protocol.toByteArray(count));
/* 105 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortingParams alpha() {
/* 114 */     this.params.add(Protocol.Keyword.ALPHA.getRaw());
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortingParams get(String... patterns) {
/* 133 */     for (String pattern : patterns) {
/* 134 */       this.params.add(Protocol.Keyword.GET.getRaw());
/* 135 */       this.params.add(SafeEncoder.encode(pattern));
/*     */     } 
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortingParams get(byte[]... patterns) {
/* 155 */     for (byte[] pattern : patterns) {
/* 156 */       this.params.add(Protocol.Keyword.GET.getRaw());
/* 157 */       this.params.add(pattern);
/*     */     } 
/* 159 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addParams(CommandArguments args) {
/* 164 */     for (byte[] param : this.params)
/* 165 */       args.add(param); 
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\SortingParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */