/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamConsumersInfo
/*    */ {
/*    */   public static final String NAME = "name";
/*    */   public static final String IDLE = "idle";
/*    */   public static final String PENDING = "pending";
/*    */   private final String name;
/*    */   private final long idle;
/*    */   private final long pending;
/*    */   private final Map<String, Object> consumerInfo;
/*    */   
/*    */   public StreamConsumersInfo(Map<String, Object> map) {
/* 27 */     this.consumerInfo = map;
/* 28 */     this.name = (String)map.get("name");
/* 29 */     this.idle = ((Long)map.get("idle")).longValue();
/* 30 */     this.pending = ((Long)map.get("pending")).longValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 35 */     return this.name;
/*    */   }
/*    */   
/*    */   public long getIdle() {
/* 39 */     return this.idle;
/*    */   }
/*    */   
/*    */   public long getPending() {
/* 43 */     return this.pending;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Object> getConsumerInfo() {
/* 50 */     return this.consumerInfo;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\StreamConsumersInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */