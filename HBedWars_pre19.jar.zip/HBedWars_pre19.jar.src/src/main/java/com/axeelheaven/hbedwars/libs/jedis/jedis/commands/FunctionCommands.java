package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FunctionRestorePolicy;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.FunctionLoadParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.FunctionStats;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LibraryInfo;
import java.util.List;

public interface FunctionCommands {
  Object fcall(String paramString, List<String> paramList1, List<String> paramList2);
  
  Object fcallReadonly(String paramString, List<String> paramList1, List<String> paramList2);
  
  String functionDelete(String paramString);
  
  byte[] functionDump();
  
  String functionFlush();
  
  String functionFlush(FlushMode paramFlushMode);
  
  String functionKill();
  
  List<LibraryInfo> functionList();
  
  List<LibraryInfo> functionList(String paramString);
  
  List<LibraryInfo> functionListWithCode();
  
  List<LibraryInfo> functionListWithCode(String paramString);
  
  String functionLoad(String paramString1, String paramString2, String paramString3);
  
  String functionLoad(String paramString1, String paramString2, FunctionLoadParams paramFunctionLoadParams, String paramString3);
  
  String functionRestore(byte[] paramArrayOfbyte);
  
  String functionRestore(byte[] paramArrayOfbyte, FunctionRestorePolicy paramFunctionRestorePolicy);
  
  FunctionStats functionStats();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\FunctionCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */