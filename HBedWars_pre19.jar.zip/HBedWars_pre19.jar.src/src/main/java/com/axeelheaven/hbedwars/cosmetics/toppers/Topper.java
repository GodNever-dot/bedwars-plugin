package com.axeelheaven.hbedwars.cosmetics.toppers;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.custom.config.HConfiguration;
import com.axeelheaven.hbedwars.libs.xseries.XMaterial;
import com.axeelheaven.hbedwars.util.CardinalDirection;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class Topper {
  private static boolean llIIlIlIlIIIlI(byte lllllllllllllllllIIIlIIlIlllIlII, int lllllllllllllllllIIIlIIlIlllIIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean llIIlIIllllI(Exception lllllllllllllllllIIIlIIllIIlIIII, Exception lllllllllllllllllIIIlIIllIIIllll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public boolean isFree() {
    if (llIIlIIlllIl(lIIllIllII(this.price, llIIllII[llIlIlIlll[0]]))) {
      "".length();
      if (llIIlIIllllI(llIlIlIllI[llIlIlIlll[0]].length(), llIlIlIllI[llIlIlIlll[2]].length()))
        return (llIlIlIlll[3] + llIlIlIlll[4] - llIlIlIlll[5] + llIlIlIlll[6] ^ llIlIlIlll[7] + llIlIlIlll[8] - llIlIlIlll[9] + llIlIlIlll[10]) & (llIlIlIlll[11] ^ llIlIlIlll[12] ^ llIlIlIlll[13] ^ llIlIlIlll[14] ^ -llIlIlIllI[llIlIlIlll[15]].length()); 
    } else {
    
    } 
    return llIIllII[llIlIlIlll[1]];
  }
  
  public Topper(char lllllllllllllllllIIIlIlIIIIIlIll, boolean lllllllllllllllllIIIlIlIIIIlIIlI, long lllllllllllllllllIIIlIlIIIIIlIIl, Exception lllllllllllllllllIIIlIlIIIIIIlll) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   9: aload_0
    //   10: aload_2
    //   11: putfield id : Ljava/lang/String;
    //   14: aload_0
    //   15: iload_3
    //   16: putfield price : I
    //   19: aload_0
    //   20: iload #4
    //   22: putfield permission : Z
    //   25: aload_0
    //   26: new java/util/ArrayList
    //   29: dup
    //   30: invokespecial <init> : ()V
    //   33: putfield blocks : Ljava/util/List;
    //   36: aload_1
    //   37: invokevirtual getToppers : ()Lcom/axeelheaven/hbedwars/custom/config/HConfiguration;
    //   40: astore #5
    //   42: aload #5
    //   44: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIlIll : [Ljava/lang/String;
    //   47: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   50: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   53: iconst_1
    //   54: iaload
    //   55: iaload
    //   56: aaload
    //   57: invokevirtual isSet : (Ljava/lang/String;)Z
    //   60: invokestatic lIIllIlIll : (I)Z
    //   63: invokestatic llIIlIIlllIl : (I)Z
    //   66: ifeq -> 449
    //   69: aload #5
    //   71: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIlIll : [Ljava/lang/String;
    //   74: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   77: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   80: iconst_0
    //   81: iaload
    //   82: iaload
    //   83: aaload
    //   84: invokevirtual getConfigurationSection : (Ljava/lang/String;)Lorg/bukkit/configuration/ConfigurationSection;
    //   87: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   90: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   93: iconst_1
    //   94: iaload
    //   95: iaload
    //   96: invokeinterface getKeys : (Z)Ljava/util/Set;
    //   101: invokeinterface iterator : ()Ljava/util/Iterator;
    //   106: astore #6
    //   108: aload #6
    //   110: invokeinterface hasNext : ()Z
    //   115: invokestatic lIIllIlIll : (I)Z
    //   118: invokestatic llIIlIIlllIl : (I)Z
    //   121: ifeq -> 449
    //   124: aload #6
    //   126: invokeinterface next : ()Ljava/lang/Object;
    //   131: checkcast java/lang/String
    //   134: astore #7
    //   136: aload #5
    //   138: new java/lang/StringBuilder
    //   141: dup
    //   142: invokespecial <init> : ()V
    //   145: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIlIll : [Ljava/lang/String;
    //   148: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   151: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   154: iconst_2
    //   155: iaload
    //   156: iaload
    //   157: aaload
    //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: aload #7
    //   163: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIlIll : [Ljava/lang/String;
    //   169: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   172: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   175: bipush #15
    //   177: iaload
    //   178: iaload
    //   179: aaload
    //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   186: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   189: aload_2
    //   190: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   193: invokestatic lIIllIlIll : (I)Z
    //   196: invokestatic llIIlIIlllIl : (I)Z
    //   199: ifeq -> 395
    //   202: aload_0
    //   203: getfield blocks : Ljava/util/List;
    //   206: new java/util/ArrayList
    //   209: dup
    //   210: aload #5
    //   212: new java/lang/StringBuilder
    //   215: dup
    //   216: invokespecial <init> : ()V
    //   219: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIlIll : [Ljava/lang/String;
    //   222: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   225: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   228: bipush #16
    //   230: iaload
    //   231: iaload
    //   232: aaload
    //   233: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: aload #7
    //   238: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   241: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIlIll : [Ljava/lang/String;
    //   244: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   247: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   250: bipush #17
    //   252: iaload
    //   253: iaload
    //   254: aaload
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   261: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   264: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIlIll : [Ljava/lang/String;
    //   267: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   270: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   273: bipush #18
    //   275: iaload
    //   276: iaload
    //   277: aaload
    //   278: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   281: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   284: invokespecial <init> : (Ljava/util/Collection;)V
    //   287: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   292: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIllI : [Ljava/lang/String;
    //   295: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   298: bipush #89
    //   300: iaload
    //   301: aaload
    //   302: invokevirtual length : ()I
    //   305: pop2
    //   306: aload_0
    //   307: aload #5
    //   309: new java/lang/StringBuilder
    //   312: dup
    //   313: invokespecial <init> : ()V
    //   316: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIlIll : [Ljava/lang/String;
    //   319: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   322: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   325: bipush #19
    //   327: iaload
    //   328: iaload
    //   329: aaload
    //   330: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   333: aload #7
    //   335: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   338: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIlIll : [Ljava/lang/String;
    //   341: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   344: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   347: bipush #20
    //   349: iaload
    //   350: iaload
    //   351: aaload
    //   352: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   355: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   358: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   361: invokestatic valueOf : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/util/CardinalDirection;
    //   364: putfield cardinalDirection : Lcom/axeelheaven/hbedwars/util/CardinalDirection;
    //   367: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIllI : [Ljava/lang/String;
    //   370: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   373: bipush #90
    //   375: iaload
    //   376: aaload
    //   377: invokevirtual length : ()I
    //   380: ldc ''
    //   382: invokevirtual length : ()I
    //   385: pop2
    //   386: aconst_null
    //   387: invokestatic llIIlIlIIlIl : (Ljava/lang/Object;)Z
    //   390: ifeq -> 449
    //   393: aconst_null
    //   394: athrow
    //   395: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIllI : [Ljava/lang/String;
    //   398: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   401: bipush #91
    //   403: iaload
    //   404: aaload
    //   405: invokevirtual length : ()I
    //   408: ldc ''
    //   410: invokevirtual length : ()I
    //   413: pop2
    //   414: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIllI : [Ljava/lang/String;
    //   417: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   420: bipush #92
    //   422: iaload
    //   423: aaload
    //   424: invokevirtual length : ()I
    //   427: ineg
    //   428: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIllI : [Ljava/lang/String;
    //   431: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   434: bipush #93
    //   436: iaload
    //   437: aaload
    //   438: invokevirtual length : ()I
    //   441: invokestatic llIIlIlIIlll : (II)Z
    //   444: ifeq -> 108
    //   447: aconst_null
    //   448: athrow
    //   449: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	450	1	lllllllllllllllllIIIlIlIIIIlIlll	I
    //   136	259	7	lllllllllllllllllIIIlIlIIIIllIlI	Ljava/lang/String;
    //   0	450	3	lllllllllllllllllIIIlIlIIIIlIIll	S
    //   0	450	6	lllllllllllllllllIIIlIlIIIIllIIl	D
    //   0	450	2	lllllllllllllllllIIIlIlIIIIIlIlI	B
    //   0	450	3	lllllllllllllllllIIIlIlIIIIIlIIl	J
    //   0	450	5	lllllllllllllllllIIIlIlIIIIIllIl	C
    //   0	450	4	lllllllllllllllllIIIlIlIIIIlIIIl	Z
    //   0	450	2	lllllllllllllllllIIIlIlIIIIlIIlI	Z
    //   0	450	1	lllllllllllllllllIIIlIlIIIIIlIll	C
    //   0	450	2	lllllllllllllllllIIIlIlIIIIIlllI	Ljava/lang/String;
    //   0	450	4	lllllllllllllllllIIIlIlIIIIlIlII	J
    //   0	450	3	lllllllllllllllllIIIlIlIIIIlIlIl	I
    //   0	450	0	lllllllllllllllllIIIlIlIIIIllIll	C
    //   0	450	7	lllllllllllllllllIIIlIlIIIIIIlIl	Ljava/lang/Exception;
    //   0	450	1	lllllllllllllllllIIIlIlIIIIlIIII	Lcom/axeelheaven/hbedwars/BedWars;
    //   0	450	5	lllllllllllllllllIIIlIlIIIIIIlll	Ljava/lang/Exception;
    //   0	450	0	lllllllllllllllllIIIlIlIIIIIllII	Z
    //   0	450	4	lllllllllllllllllIIIlIlIIIIIlIII	Z
    //   0	450	0	lllllllllllllllllIIIlIlIIIIllIII	Lcom/axeelheaven/hbedwars/cosmetics/toppers/Topper;
    //   0	450	7	lllllllllllllllllIIIlIlIIIIlIllI	J
    //   0	450	6	lllllllllllllllllIIIlIlIIIIIIllI	B
    //   42	408	5	lllllllllllllllllIIIlIlIIIIIllll	Lcom/axeelheaven/hbedwars/custom/config/HConfiguration;
  }
  
  private static boolean llIIlIlIIlll(Exception lllllllllllllllllIIIlIIllIIIIlII, boolean lllllllllllllllllIIIlIIllIIIIIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIIllIlIll(char lllllllllllllllllIIIlIIlllIIIlIl) {
    if (llIIlIIlllIl(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (-(0x46 ^ 0x43) >= 0)
        return (0xEB ^ 0xA4) & (0x31 ^ 0x7E ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIlIlIlll[1];
  }
  
  public void paste(double lllllllllllllllllIIIlIlIIIlIllll) {
    Iterator<String> iterator = this.blocks.iterator();
    while (llIIlIIlllIl(lIIllIlIll(iterator.hasNext()))) {
      String lllllllllllllllllIIIlIlIIIllllll = iterator.next();
      String[] lllllllllllllllllIIIlIlIIlIIlIIl = lllllllllllllllllIIIlIlIIIllllll.split(llIIlIll[llIIllII[llIlIlIlll[21]]]);
      if (llIIlIIlllIl(lIIllIllII(lllllllllllllllllIIIlIlIIlIIlIIl.length, llIIllII[llIlIlIlll[17]]))) {
        "".length();
        if (llIIlIlIIIIl(-llIlIlIllI[llIlIlIlll[23]].length()))
          return; 
        continue;
      } 
      double lllllllllllllllllIIIlIlIIlIIIIII = Double.parseDouble(lllllllllllllllllIIIlIlIIlIIlIIl[llIIllII[llIlIlIlll[1]]]);
      double lllllllllllllllllIIIlIlIIIlllIIl = Double.parseDouble(lllllllllllllllllIIIlIlIIlIIlIIl[llIIllII[llIlIlIlll[0]]]);
      double lllllllllllllllllIIIlIlIIIllllII = Double.parseDouble(lllllllllllllllllIIIlIlIIlIIlIIl[llIIllII[llIlIlIlll[2]]]);
      Material lllllllllllllllllIIIlIlIIIllIIIl = Material.matchMaterial(lllllllllllllllllIIIlIlIIlIIlIIl[llIIllII[llIlIlIlll[15]]]);
      byte lllllllllllllllllIIIlIlIIIllIllI = Byte.parseByte(lllllllllllllllllIIIlIlIIlIIlIIl[llIIllII[llIlIlIlll[16]]]);
      Location lllllllllllllllllIIIlIlIIlIIIllI = lllllllllllllllllIIIlIlIIIlIllll.clone();
      CardinalDirection lllllllllllllllllIIIlIlIIlIIIlII = CardinalDirection.getDirection(lllllllllllllllllIIIlIlIIIlIllll);
      if (llIIlIIlllIl(lIIllIlIll(this.cardinalDirection.equals(CardinalDirection.NORTH)))) {
        if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.SOUTH)))) {
          llIlIlIllI[llIlIlIlll[24]].length();
          "".length();
          if (llIIlIIlllll(llIlIlIllI[llIlIlIlll[25]].length(), llIlIlIllI[llIlIlIlll[26]].length()))
            return; 
        } else if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.WEST)))) {
          llIlIlIllI[llIlIlIlll[27]].length();
          "".length();
          if (llIIlIIlllll(llIlIlIllI[llIlIlIlll[29]].length(), llIlIlIllI[llIlIlIlll[30]].length()))
            return; 
        } else if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.EAST)))) {
          llIlIlIllI[llIlIlIlll[31]].length();
          "".length();
          if (llIIlIIlllll(llIlIlIllI[llIlIlIlll[33]].length(), llIlIlIllI[llIlIlIlll[34]].length()))
            return; 
        } else {
          llIlIlIllI[llIlIlIlll[35]].length();
          "".length();
          if (llIIlIlIIIlI((llIlIlIlll[36] ^ llIlIlIlll[37]) & (llIlIlIlll[38] ^ llIlIlIlll[39] ^ llIlIlIlll[40]), (llIlIlIlll[41] ^ llIlIlIlll[42]) & (llIlIlIlll[43] ^ llIlIlIlll[13] ^ llIlIlIlll[40])))
            return; 
        } 
      } else if (llIIlIIlllIl(lIIllIlIll(this.cardinalDirection.equals(CardinalDirection.SOUTH)))) {
        if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.NORTH)))) {
          llIlIlIllI[llIlIlIlll[44]].length();
          "".length();
          if (llIIlIIlllll((llIlIlIlll[45] ^ llIlIlIlll[46]) & (llIlIlIlll[28] ^ llIlIlIlll[47] ^ llIlIlIlll[40]), -llIlIlIllI[llIlIlIlll[48]].length()))
            return; 
        } else if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.WEST)))) {
          llIlIlIllI[llIlIlIlll[49]].length();
          "".length();
          if (llIIlIlIIIll(-llIlIlIllI[llIlIlIlll[50]].length()))
            return; 
        } else if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.EAST)))) {
          llIlIlIllI[llIlIlIlll[43]].length();
          "".length();
          if (llIIlIlIIlII(llIlIlIllI[llIlIlIlll[52]].length()))
            return; 
        } else {
          llIlIlIllI[llIlIlIlll[53]].length();
          "".length();
          if (llIIlIIlllIl((llIlIlIlll[29] ^ llIlIlIlll[55] ^ llIlIlIlll[26] ^ llIlIlIlll[56]) & (llIlIlIlll[57] ^ llIlIlIlll[58] ^ llIlIlIlll[59] ^ llIlIlIlll[60] ^ -llIlIlIllI[llIlIlIlll[61]].length())))
            return; 
        } 
      } else if (llIIlIIlllIl(lIIllIlIll(this.cardinalDirection.equals(CardinalDirection.EAST)))) {
        if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.WEST)))) {
          llIlIlIllI[llIlIlIlll[60]].length();
          "".length();
          if (llIIlIlIIlIl(null))
            return; 
        } else if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.NORTH)))) {
          llIlIlIllI[llIlIlIlll[7]].length();
          "".length();
          if (llIIlIlIIllI(llIlIlIlll[64] ^ llIlIlIlll[65] ^ llIlIlIlll[66] ^ llIlIlIlll[0], llIlIlIllI[llIlIlIlll[67]].length()))
            return; 
        } else if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.SOUTH)))) {
          llIlIlIllI[llIlIlIlll[68]].length();
          "".length();
          if (llIIlIlIIIII(llIlIlIllI[llIlIlIlll[9]].length()))
            return; 
        } else {
          llIlIlIllI[llIlIlIlll[70]].length();
          "".length();
          if (llIIlIlIIlIl(null))
            return; 
        } 
      } else if (llIIlIIlllIl(lIIllIlIll(this.cardinalDirection.equals(CardinalDirection.WEST)))) {
        if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.EAST)))) {
          llIlIlIllI[llIlIlIlll[72]].length();
          "".length();
          if (llIIlIlIIIlI(llIlIlIllI[llIlIlIlll[73]].length(), llIlIlIllI[llIlIlIlll[74]].length()))
            return; 
        } else if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.NORTH)))) {
          llIlIlIllI[llIlIlIlll[75]].length();
          "".length();
          if (llIIlIlIIlll(llIlIlIllI[llIlIlIlll[66]].length(), llIlIlIllI[llIlIlIlll[59]].length()))
            return; 
        } else if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIlIIlIIIlII.equals(CardinalDirection.SOUTH)))) {
          llIlIlIllI[llIlIlIlll[77]].length();
          "".length();
          if (llIIlIlIIIlI(llIlIlIlll[79] ^ llIlIlIlll[80], llIlIlIlll[81] ^ llIlIlIlll[82]))
            return; 
        } else {
          llIlIlIllI[llIlIlIlll[83]].length();
        } 
      } 
      Block lllllllllllllllllIIIlIlIIlIIIIll = lllllllllllllllllIIIlIlIIlIIIllI.getBlock();
      lllllllllllllllllIIIlIlIIlIIIIll.setType(lllllllllllllllllIIIlIlIIIllIIIl);
      lllllllllllllllllIIIlIlIIlIIIIll.setData(lllllllllllllllllIIIlIlIIIllIllI);
      llIlIlIllI[llIlIlIlll[39]].length();
      "".length();
      if (llIIlIlIIIlI(llIlIlIlll[83] + llIlIlIlll[56] - llIlIlIlll[85] + llIlIlIlll[37] ^ llIlIlIlll[86] + llIlIlIlll[66] - llIlIlIlll[39] + llIlIlIlll[29], llIlIlIlll[87] ^ llIlIlIlll[88] ^ llIlIlIlll[33] ^ llIlIlIlll[2]))
        return; 
    } 
  }
  
  private static boolean llIIlIlIIlII(long lllllllllllllllllIIIlIIlIlllllIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static void lIlllIlIIlII() {
    llIlIlIllI = new String[llIlIlIlll[164]];
    llIlIlIllI[llIlIlIlll[1]] = lIlllIlIIIIl("qgRg5OfrfGM=", "KFxlB");
    llIlIlIllI[llIlIlIlll[0]] = lIlllIlIIIIl("tapSlLYf7Yg=", "mgmpG");
    llIlIlIllI[llIlIlIlll[2]] = lIlllIlIIIlI("BrX3da1nlSk=", "GxOcx");
    llIlIlIllI[llIlIlIlll[15]] = lIlllIlIIIIl("DjWLCAbPsuQ=", "Pltfa");
    llIlIlIllI[llIlIlIlll[16]] = lIlllIlIIIIl("+/qXcO4z5a0=", "feOHh");
    llIlIlIllI[llIlIlIlll[17]] = lIlllIlIIIIl("yxn0+Paf3uTYpEfjpS85TQ==", "hifkO");
    llIlIlIllI[llIlIlIlll[18]] = lIlllIlIIIlI("yw3VLaZ1xJeRiRtj7C0WpA==", "QETHx");
    llIlIlIllI[llIlIlIlll[19]] = lIlllIlIIIlI("mY6oK2X3Hig=", "zgJyb");
    llIlIlIllI[llIlIlIlll[20]] = lIlllIlIIIIl("a9oWjWknwq0=", "jcoyH");
    llIlIlIllI[llIlIlIlll[21]] = lIlllIlIIIIl("LjlJURY2bhU=", "HDVfo");
    llIlIlIllI[llIlIlIlll[22]] = lIlllIlIIIIl("O/dBT8h6mcs=", "lKhhQ");
    llIlIlIllI[llIlIlIlll[23]] = lIlllIlIIIll("aXRO", "ITnMe");
    llIlIlIllI[llIlIlIlll[24]] = lIlllIlIIIIl("HT1AUUaNm9E=", "GtBmM");
    llIlIlIllI[llIlIlIlll[6]] = lIlllIlIIIlI("jFCnOhJJPsE=", "bRSpW");
    llIlIlIllI[llIlIlIlll[25]] = lIlllIlIIIIl("Z7ozhVjeiWE=", "jyePH");
    llIlIlIllI[llIlIlIlll[26]] = lIlllIlIIIIl("kRyL+tuG5vI=", "EfHEg");
    llIlIlIllI[llIlIlIlll[27]] = lIlllIlIIIll("", "gNZQH");
    llIlIlIllI[llIlIlIlll[28]] = lIlllIlIIIIl("wqhvGJLdT10=", "AIBsp");
    llIlIlIllI[llIlIlIlll[29]] = lIlllIlIIIlI("VhKhqPwE1sg=", "uBpZw");
    llIlIlIllI[llIlIlIlll[30]] = lIlllIlIIIll("cXpW", "QZvWp");
    llIlIlIllI[llIlIlIlll[31]] = lIlllIlIIIlI("XrFERvvugwk=", "BMiRD");
    llIlIlIllI[llIlIlIlll[32]] = lIlllIlIIIll("", "ckYji");
    llIlIlIllI[llIlIlIlll[33]] = lIlllIlIIIIl("fEfEv0ecPrM=", "qRTST");
    llIlIlIllI[llIlIlIlll[34]] = lIlllIlIIIIl("NddcWQbxkz8=", "JqeIg");
    llIlIlIllI[llIlIlIlll[35]] = lIlllIlIIIll("", "pvfqa");
    llIlIlIllI[llIlIlIlll[13]] = lIlllIlIIIIl("5jiTDSDvLYw=", "lsFXV");
    llIlIlIllI[llIlIlIlll[44]] = lIlllIlIIIlI("AsJDuK3qG64=", "vkPEt");
    llIlIlIllI[llIlIlIlll[38]] = lIlllIlIIIll("", "FEMWh");
    llIlIlIllI[llIlIlIlll[48]] = lIlllIlIIIll("dw==", "WwPkQ");
    llIlIlIllI[llIlIlIlll[49]] = lIlllIlIIIlI("q75UiXjr/ic=", "lHUpY");
    llIlIlIllI[llIlIlIlll[10]] = lIlllIlIIIIl("kGj94ix5+Kk=", "mOokn");
    llIlIlIllI[llIlIlIlll[50]] = lIlllIlIIIlI("P01IM0+uC2k=", "MVNni");
    llIlIlIllI[llIlIlIlll[43]] = lIlllIlIIIIl("J9GoWpEeEm8=", "EjEod");
    llIlIlIllI[llIlIlIlll[51]] = lIlllIlIIIll("", "NueDp");
    llIlIlIllI[llIlIlIlll[52]] = lIlllIlIIIlI("WhiIR2P0M24=", "iPFsw");
    llIlIlIllI[llIlIlIlll[53]] = lIlllIlIIIlI("XqF9L1xyxS4=", "hrgrN");
    llIlIlIllI[llIlIlIlll[54]] = lIlllIlIIIlI("d1u45N1T1Hg=", "ZSkHH");
    llIlIlIllI[llIlIlIlll[61]] = lIlllIlIIIll("WQ==", "yzoJS");
    llIlIlIllI[llIlIlIlll[60]] = lIlllIlIIIll("", "MMybG");
    llIlIlIllI[llIlIlIlll[62]] = lIlllIlIIIll("", "wlPWw");
    llIlIlIllI[llIlIlIlll[7]] = lIlllIlIIIll("", "TVzHY");
    llIlIlIllI[llIlIlIlll[63]] = lIlllIlIIIll("", "DBXUl");
    llIlIlIllI[llIlIlIlll[67]] = lIlllIlIIIll("aWpJ", "IJiDL");
    llIlIlIllI[llIlIlIlll[68]] = lIlllIlIIIll("", "upMqw");
    llIlIlIllI[llIlIlIlll[69]] = lIlllIlIIIIl("JPBBq0NoV9k=", "nLqQI");
    llIlIlIllI[llIlIlIlll[9]] = lIlllIlIIIIl("806MJ+BBB8A=", "fsMLg");
    llIlIlIllI[llIlIlIlll[70]] = lIlllIlIIIlI("vADFzBswU8w=", "aDoCB");
    llIlIlIllI[llIlIlIlll[71]] = lIlllIlIIIlI("jxsL5XWMQcw=", "QeQSU");
    llIlIlIllI[llIlIlIlll[72]] = lIlllIlIIIIl("sgzVBX5gP2w=", "QWMyL");
    llIlIlIllI[llIlIlIlll[47]] = lIlllIlIIIll("", "rTNOO");
    llIlIlIllI[llIlIlIlll[73]] = lIlllIlIIIlI("dmILGa4zJQ8=", "hPTVr");
    llIlIlIllI[llIlIlIlll[74]] = lIlllIlIIIIl("bzNTHTw/0+c=", "pWJzY");
    llIlIlIllI[llIlIlIlll[75]] = lIlllIlIIIlI("dHSLPOzj1Fc=", "MZMSS");
    llIlIlIllI[llIlIlIlll[76]] = lIlllIlIIIlI("QT/qk4pqKQs=", "ZxSMM");
    llIlIlIllI[llIlIlIlll[66]] = lIlllIlIIIlI("RjdSKHkZops=", "rOdtG");
    llIlIlIllI[llIlIlIlll[59]] = lIlllIlIIIIl("gpRyjJwnoGc=", "yNjUu");
    llIlIlIllI[llIlIlIlll[77]] = lIlllIlIIIlI("iZ0ZVBdEbnk=", "XgjVc");
    llIlIlIllI[llIlIlIlll[78]] = lIlllIlIIIll("", "kBakc");
    llIlIlIllI[llIlIlIlll[83]] = lIlllIlIIIll("", "aNoxN");
    llIlIlIllI[llIlIlIlll[39]] = lIlllIlIIIIl("dYX/it5aHUs=", "GmrKx");
    llIlIlIllI[llIlIlIlll[84]] = lIlllIlIIIIl("ct0RBsjANbE=", "uWkiN");
    llIlIlIllI[llIlIlIlll[89]] = lIlllIlIIIIl("2iUvWcrUPAc=", "MzNYD");
    llIlIlIllI[llIlIlIlll[90]] = lIlllIlIIIlI("SYgJ0Qdf/j8=", "SGSSN");
    llIlIlIllI[llIlIlIlll[91]] = lIlllIlIIIll("", "eLrmC");
    llIlIlIllI[llIlIlIlll[92]] = lIlllIlIIIll("Rg==", "fzdaD");
    llIlIlIllI[llIlIlIlll[93]] = lIlllIlIIIlI("kbHpU+E328o=", "icHib");
    llIlIlIllI[llIlIlIlll[94]] = lIlllIlIIIIl("gg3kXW+3pgo=", "ZSvrN");
    llIlIlIllI[llIlIlIlll[95]] = lIlllIlIIIIl("IsE0PVvcghM=", "fbGyN");
    llIlIlIllI[llIlIlIlll[96]] = lIlllIlIIIIl("Y8hid9AOmU0=", "juVJh");
    llIlIlIllI[llIlIlIlll[97]] = lIlllIlIIIll("T3o=", "oZTID");
    llIlIlIllI[llIlIlIlll[5]] = lIlllIlIIIIl("n/5X/9tQqwg=", "MOlkl");
    llIlIlIllI[llIlIlIlll[12]] = lIlllIlIIIlI("cCRQ7IdLS9A=", "vIwDI");
    llIlIlIllI[llIlIlIlll[107]] = lIlllIlIIIll("eQ==", "YcFIs");
    llIlIlIllI[llIlIlIlll[125]] = lIlllIlIIIlI("P/mYuJMoIFI=", "iZnbC");
    llIlIlIllI[llIlIlIlll[130]] = lIlllIlIIIIl("ud9TQVqWVjQ=", "wonsd");
    llIlIlIllI[llIlIlIlll[131]] = lIlllIlIIIll("DyAQ", "KeCmf");
    llIlIlIllI[llIlIlIlll[132]] = lIlllIlIIIIl("APM3GCtjyfM=", "mLwqI");
    llIlIlIllI[llIlIlIlll[135]] = lIlllIlIIIlI("zR89x3aeZzU=", "qRNMs");
    llIlIlIllI[llIlIlIlll[136]] = lIlllIlIIIlI("4Dc/4iaW2VQ=", "dvPwu");
    llIlIlIllI[llIlIlIlll[137]] = lIlllIlIIIlI("TiJdojEkRAc=", "XtYCQ");
    llIlIlIllI[llIlIlIlll[58]] = lIlllIlIIIIl("gYgBxNhWOQg=", "hSsyo");
    llIlIlIllI[llIlIlIlll[11]] = lIlllIlIIIll("", "fqCbB");
    llIlIlIllI[llIlIlIlll[138]] = lIlllIlIIIIl("5kmvdosuxBi4ZI/w8QiDrw==", "FbiHS");
    llIlIlIllI[llIlIlIlll[115]] = lIlllIlIIIIl("niPrGV1u4jA=", "BfgKv");
    llIlIlIllI[llIlIlIlll[124]] = lIlllIlIIIll("MBMsQSkSAxc+HUh/", "uBOyj");
    llIlIlIllI[llIlIlIlll[139]] = lIlllIlIIIIl("EY3v5K8CRAs=", "BVMhh");
    llIlIlIllI[llIlIlIlll[140]] = lIlllIlIIIlI("kNbeonbIOqZvVEhcWYKUiF1obaOMvwpWgI1GIzzW0B8=", "SjKBO");
    llIlIlIllI[llIlIlIlll[55]] = lIlllIlIIIll("NwcsJRY=", "RBEfd");
    llIlIlIllI[llIlIlIlll[118]] = lIlllIlIIIIl("jDPHnTjiVzM=", "PLIdI");
    llIlIlIllI[llIlIlIlll[141]] = lIlllIlIIIll("AiMhNy0=", "tKpqA");
    llIlIlIllI[llIlIlIlll[142]] = lIlllIlIIIlI("moA9L/XvMVvzDjewQA8KzQ==", "jhskF");
    llIlIlIllI[llIlIlIlll[143]] = lIlllIlIIIlI("Jy0WivUy5Hs=", "OghJp");
    llIlIlIllI[llIlIlIlll[144]] = lIlllIlIIIIl("d30sSVdwjBdtjLhM3sONug==", "hwfvY");
    llIlIlIllI[llIlIlIlll[36]] = lIlllIlIIIll("Ixk1ISM=", "vvXvh");
    llIlIlIllI[llIlIlIlll[145]] = lIlllIlIIIll("AANwfw==", "SnHBj");
    llIlIlIllI[llIlIlIlll[146]] = lIlllIlIIIlI("kKbyZLJeFds=", "fHWLI");
    llIlIlIllI[llIlIlIlll[147]] = lIlllIlIIIlI("3s9yKQqXXYophuIzXaCUsKXqLYQgycKmI1ibmeiCvrw=", "BNsDz");
    llIlIlIllI[llIlIlIlll[148]] = lIlllIlIIIll("Gy0XNh4=", "pfqeL");
    llIlIlIllI[llIlIlIlll[103]] = lIlllIlIIIll("AwM6NiMWSB4FHQQFCBszf1UQERIGEG9J", "LgRtv");
    llIlIlIllI[llIlIlIlll[121]] = lIlllIlIIIIl("OulbbwXTPgo=", "alMiX");
    llIlIlIllI[llIlIlIlll[149]] = lIlllIlIIIll("fiQkITx4DzpnEX9I", "KutUh");
    llIlIlIllI[llIlIlIlll[113]] = lIlllIlIIIll("CA40BhU=", "XhVwx");
    llIlIlIllI[llIlIlIlll[116]] = lIlllIlIIIll("Li8WQz8dLzYBS2B1", "XHwry");
    llIlIlIllI[llIlIlIlll[150]] = lIlllIlIIIll("PBEGLBQ=", "yijhU");
    llIlIlIllI[llIlIlIlll[151]] = lIlllIlIIIlI("H6Ou6GRia8vvfCTACs7nCw==", "GDiRc");
    llIlIlIllI[llIlIlIlll[127]] = lIlllIlIIIlI("lJ+yN8U3jrg=", "dbCcz");
    llIlIlIllI[llIlIlIlll[152]] = lIlllIlIIIlI("yjWxYsqOi9U=", "jFhvR");
    llIlIlIllI[llIlIlIlll[105]] = lIlllIlIIIll("ChkMAA4=", "zPhGZ");
    llIlIlIllI[llIlIlIlll[129]] = lIlllIlIIIll("CkM1AyUzFCoXFStL", "bvZBs");
    llIlIlIllI[llIlIlIlll[111]] = lIlllIlIIIlI("FJ6TJ3f+Qvs=", "ysJPu");
    llIlIlIllI[llIlIlIlll[14]] = lIlllIlIIIIl("sYbTCJ9JOC3bkiVLWRJUsvHrSxcarUDw1K6RQMZPnNQ=", "dyGoz");
    llIlIlIllI[llIlIlIlll[153]] = lIlllIlIIIlI("Ix6k+FS+ZCE=", "qbIDI");
    llIlIlIllI[llIlIlIlll[110]] = lIlllIlIIIll("NB9oeBIVAyMcIiF2", "RKPOt");
    llIlIlIllI[llIlIlIlll[154]] = lIlllIlIIIll("Py0CJxI=", "WKZnw");
    llIlIlIllI[llIlIlIlll[112]] = lIlllIlIIIll("WSE3DhwrHDsSFQs7W08tKWYFHSkYF19H", "nVbzE");
    llIlIlIllI[llIlIlIlll[155]] = lIlllIlIIIIl("EnlxBYCOL7k=", "MfmDk");
    llIlIlIllI[llIlIlIlll[134]] = lIlllIlIIIll("IBAiOD4lBQE=", "vTgps");
    llIlIlIllI[llIlIlIlll[56]] = lIlllIlIIIlI("w5WT67BjuF4=", "AFNGV");
    llIlIlIllI[llIlIlIlll[156]] = lIlllIlIIIlI("SG2Eqr1z2fFpdfZlo3OFqJt/ryohK7dHruNy5sO6O5o=", "zgEwC");
    llIlIlIllI[llIlIlIlll[157]] = lIlllIlIIIIl("2GwoDQxJpCI=", "JmeRW");
    llIlIlIllI[llIlIlIlll[85]] = lIlllIlIIIlI("Z2zElxuL0yDp+C7eLyKxtUiKsFByybqr", "zGHkJ");
    llIlIlIllI[llIlIlIlll[158]] = lIlllIlIIIIl("Kn9hj+oFFI8=", "riKnT");
    llIlIlIllI[llIlIlIlll[8]] = lIlllIlIIIll("MyceOFUNZQEdAxwAPQYuFhcSPyRFMklM", "uUtqe");
    llIlIlIllI[llIlIlIlll[159]] = lIlllIlIIIlI("Ev2mT1Ox61w=", "JjeYe");
    llIlIlIllI[llIlIlIlll[123]] = lIlllIlIIIIl("c+WDP5Jb9ECkgmD80mtyUw==", "ssLWW");
    llIlIlIllI[llIlIlIlll[37]] = lIlllIlIIIIl("KVMfr9mqNME=", "JjSTp");
    llIlIlIllI[llIlIlIlll[57]] = lIlllIlIIIIl("LV32U33FG0jKNZw7+0BTp1U4RWLNunhKWQS/CZf0QC0=", "saGci");
    llIlIlIllI[llIlIlIlll[160]] = lIlllIlIIIlI("h8/X8durG/o=", "SlDNA");
    llIlIlIllI[llIlIlIlll[80]] = lIlllIlIIIll("DTAQLhQDWgEbOzNV", "jhuwq");
    llIlIlIllI[llIlIlIlll[87]] = lIlllIlIIIll("Ej8pJw0=", "WreDi");
    llIlIlIllI[llIlIlIlll[102]] = lIlllIlIIIlI("PYul+tDFinvZvEqurUfLrw==", "VraHH");
    llIlIlIllI[llIlIlIlll[161]] = lIlllIlIIIIl("l/nnyhvEukI=", "FRJeR");
    llIlIlIllI[llIlIlIlll[79]] = lIlllIlIIIIl("WGsi5f7uhHQ=", "pLjFI");
    llIlIlIllI[llIlIlIlll[98]] = lIlllIlIIIll("CzAiFgU=", "zJwqI");
    llIlIlIllI[llIlIlIlll[162]] = lIlllIlIIIIl("NaAo/BE+ShA=", "qWLUx");
    llIlIlIllI[llIlIlIlll[163]] = lIlllIlIIIIl("3ryvAs6cqWQ=", "giYDv");
    llIlIlIllI[llIlIlIlll[119]] = lIlllIlIIIlI("CJbUwnYd4Xo=", "ccbSX");
    llIlIlIllI[llIlIlIlll[128]] = lIlllIlIIIIl("zboaaari3Ck=", "naffc");
  }
  
  private static String lIIllIIlll(String lllllllllllllllllIIIlIIllllIlllI, String lllllllllllllllllIIIlIIlllllIlII) {
    try {
      SecretKeySpec lllllllllllllllllIIIlIIllllIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(llIlIlIllI[llIlIlIlll[125]]).digest(lllllllllllllllllIIIlIIlllllIlII.getBytes(StandardCharsets.UTF_8)), llIIllII[llIlIlIlll[20]]), llIlIlIllI[llIlIlIlll[130]]);
      Cipher lllllllllllllllllIIIlIIllllIllII = Cipher.getInstance(llIlIlIllI[llIlIlIlll[131]]);
      lllllllllllllllllIIIlIIllllIllII.init(llIIllII[llIlIlIlll[2]], lllllllllllllllllIIIlIIllllIllIl);
      return new String(lllllllllllllllllIIIlIIllllIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIlIIllllIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIIIlIIlllllIIII) {
      Exception exception1;
      exception1.printStackTrace();
      return null;
    } 
  }
  
  private static String lIlllIlIIIlI(char lllllllllllllllllIIIlIIllIlllIll, String lllllllllllllllllIIIlIIllIllllII) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: ldc_w 'Blowfish'
    //   23: invokespecial <init> : ([BLjava/lang/String;)V
    //   26: astore_2
    //   27: ldc_w 'Blowfish'
    //   30: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   33: astore_3
    //   34: aload_3
    //   35: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   38: iconst_2
    //   39: iaload
    //   40: aload_2
    //   41: invokevirtual init : (ILjava/security/Key;)V
    //   44: new java/lang/String
    //   47: dup
    //   48: aload_3
    //   49: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   52: aload_0
    //   53: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   56: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   59: invokevirtual decode : ([B)[B
    //   62: invokevirtual doFinal : ([B)[B
    //   65: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   68: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   71: areturn
    //   72: astore_2
    //   73: aload_2
    //   74: invokevirtual printStackTrace : ()V
    //   77: aconst_null
    //   78: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	79	1	lllllllllllllllllIIIlIIllIlllIlI	J
    //   73	4	2	lllllllllllllllllIIIlIIllIlllllI	Ljava/lang/Exception;
    //   0	79	3	lllllllllllllllllIIIlIIllIlllIII	C
    //   27	45	2	lllllllllllllllllIIIlIIlllIIIIII	Ljavax/crypto/spec/SecretKeySpec;
    //   0	79	0	lllllllllllllllllIIIlIIllIllllIl	Ljava/lang/String;
    //   0	79	1	lllllllllllllllllIIIlIIllIllllII	Ljava/lang/String;
    //   0	79	0	lllllllllllllllllIIIlIIllIlllIll	C
    //   0	79	2	lllllllllllllllllIIIlIIllIlllIIl	Z
    //   34	38	3	lllllllllllllllllIIIlIIllIllllll	Ljavax/crypto/Cipher;
    // Exception table:
    //   from	to	target	type
    //   0	71	72	java/lang/Exception
  }
  
  private static String lIlllIlIIIIl(boolean lllllllllllllllllIIIlIIllIlIlllI, String lllllllllllllllllIIIlIIllIlIllll) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   23: bipush #20
    //   25: iaload
    //   26: invokestatic copyOf : ([BI)[B
    //   29: ldc_w 'DES'
    //   32: invokespecial <init> : ([BLjava/lang/String;)V
    //   35: astore_2
    //   36: ldc_w 'DES'
    //   39: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   42: astore_3
    //   43: aload_3
    //   44: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   47: iconst_2
    //   48: iaload
    //   49: aload_2
    //   50: invokevirtual init : (ILjava/security/Key;)V
    //   53: new java/lang/String
    //   56: dup
    //   57: aload_3
    //   58: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   61: aload_0
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   68: invokevirtual decode : ([B)[B
    //   71: invokevirtual doFinal : ([B)[B
    //   74: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   77: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   80: areturn
    //   81: astore_2
    //   82: aload_2
    //   83: invokevirtual printStackTrace : ()V
    //   86: aconst_null
    //   87: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	88	3	lllllllllllllllllIIIlIIllIlIlIll	D
    //   0	88	0	lllllllllllllllllIIIlIIllIllIIII	Ljava/lang/String;
    //   36	45	2	lllllllllllllllllIIIlIIllIllIIll	Ljavax/crypto/spec/SecretKeySpec;
    //   0	88	1	lllllllllllllllllIIIlIIllIlIllIl	F
    //   0	88	1	lllllllllllllllllIIIlIIllIlIllll	Ljava/lang/String;
    //   0	88	2	lllllllllllllllllIIIlIIllIlIllII	Ljava/lang/String;
    //   0	88	0	lllllllllllllllllIIIlIIllIlIlllI	Z
    //   43	38	3	lllllllllllllllllIIIlIIllIllIIlI	Ljavax/crypto/Cipher;
    //   82	4	2	lllllllllllllllllIIIlIIllIllIIIl	Ljava/lang/Exception;
    // Exception table:
    //   from	to	target	type
    //   0	80	81	java/lang/Exception
  }
  
  public synchronized void save(char lllllllllllllllllIIIlIIlllIlIIll, Location lllllllllllllllllIIIlIIlllIllIlI) {
    this.cardinalDirection = CardinalDirection.getDirection(lllllllllllllllllIIIlIIlllIllIlI);
    Iterator<Block> iterator = lllllllllllllllllIIIlIIlllIlIIll.getBlocks().iterator();
    while (llIIlIIlllIl(lIIllIlIll(iterator.hasNext()))) {
      Block lllllllllllllllllIIIlIIlllIlIIlI = iterator.next();
      if (llIIlIIlllIl(lIIllIlIll(lllllllllllllllllIIIlIIlllIlIIlI.getType().equals(XMaterial.AIR.parseMaterial())))) {
        "".length();
        if (llIIlIIlllIl((llIlIlIlll[133] ^ llIlIlIlll[100]) & (llIlIlIlll[134] ^ llIlIlIlll[73] ^ llIlIlIlll[40])))
          return; 
        continue;
      } 
      int lllllllllllllllllIIIlIIlllIllllI = lllllllllllllllllIIIlIIlllIlIIlI.getLocation().getBlockX() - lllllllllllllllllIIIlIIlllIllIlI.getBlockX();
      int lllllllllllllllllIIIlIIlllIlllll = lllllllllllllllllIIIlIIlllIlIIlI.getLocation().getBlockY() - lllllllllllllllllIIIlIIlllIllIlI.getBlockY();
      int lllllllllllllllllIIIlIIlllIlllIl = lllllllllllllllllIIIlIIlllIlIIlI.getLocation().getBlockZ() - lllllllllllllllllIIIlIIlllIllIlI.getBlockZ();
      llIlIlIllI[llIlIlIlll[135]].length();
      "".length();
      if (llIIlIlIIIlI(llIlIlIllI[llIlIlIlll[137]].length(), llIlIlIllI[llIlIlIlll[58]].length()))
        return; 
    } 
    HConfiguration lllllllllllllllllIIIlIIlllIlIlII = this.plugin.getToppers();
    lllllllllllllllllIIIlIIlllIlIlII.set(String.valueOf((new StringBuilder()).append(llIIlIll[llIIllII[llIlIlIlll[25]]]).append(this.id).append(llIIlIll[llIIllII[llIlIlIlll[26]]])), this.id);
    lllllllllllllllllIIIlIIlllIlIlII.set(String.valueOf((new StringBuilder()).append(llIIlIll[llIIllII[llIlIlIlll[27]]]).append(this.id).append(llIIlIll[llIIllII[llIlIlIlll[28]]])), Integer.valueOf(this.price));
    lllllllllllllllllIIIlIIlllIlIlII.set(String.valueOf((new StringBuilder()).append(llIIlIll[llIIllII[llIlIlIlll[29]]]).append(this.id).append(llIIlIll[llIIllII[llIlIlIlll[30]]])), Boolean.valueOf(this.permission));
    lllllllllllllllllIIIlIIlllIlIlII.set(String.valueOf((new StringBuilder()).append(llIIlIll[llIIllII[llIlIlIlll[31]]]).append(this.id).append(llIIlIll[llIIllII[llIlIlIlll[32]]])), this.cardinalDirection.name());
    lllllllllllllllllIIIlIIlllIlIlII.set(String.valueOf((new StringBuilder()).append(llIIlIll[llIIllII[llIlIlIlll[33]]]).append(this.id).append(llIIlIll[llIIllII[llIlIlIlll[34]]])), String.valueOf(this.blocks).replace(llIIlIll[llIIllII[llIlIlIlll[35]]], llIIlIll[llIIllII[llIlIlIlll[13]]]).replace(llIIlIll[llIIllII[llIlIlIlll[44]]], llIIlIll[llIIllII[llIlIlIlll[38]]]));
    llIlIlIllI[llIlIlIlll[11]].length();
  }
  
  public CardinalDirection getCardinalDirection() {
    // Byte code:
    //   0: aload_0
    //   1: getfield cardinalDirection : Lcom/axeelheaven/hbedwars/util/CardinalDirection;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIIIlIlIIIIIIIll	Lcom/axeelheaven/hbedwars/cosmetics/toppers/Topper;
    //   0	5	0	lllllllllllllllllIIIlIlIIIIIIIlI	J
    //   0	5	0	lllllllllllllllllIIIlIlIIIIIIIIl	F
  }
  
  static {
    llIIlIIlllII();
    lIlllIlIIlII();
    lIIllIlIlI();
    lIIllIlIIl();
  }
  
  private static boolean llIIlIlIIIII(char lllllllllllllllllIIIlIIlIllllIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < null);
  }
  
  private static void llIIlIIlllII() {
    llIlIlIlll = new int[165];
    llIlIlIlll[0] = " ".length();
    llIlIlIlll[1] = "  ".length() & ("  ".length() ^ -" ".length());
    llIlIlIlll[2] = "  ".length();
    llIlIlIlll[3] = 146 + 1 - 88 + 97;
    llIlIlIlll[4] = 105 + 85 - 162 + 115;
    llIlIlIlll[5] = 0x1F ^ 0x7D ^ 0x84 ^ 0xA0;
    llIlIlIlll[6] = 127 + 74 - 150 + 125 ^ 45 + 41 - -85 + 18;
    llIlIlIlll[7] = 0xA5 ^ 0x8D;
    llIlIlIlll[8] = 0x1B ^ 0x61;
    llIlIlIlll[9] = 0x33 ^ 0x1B ^ 0x7D ^ 0x78;
    llIlIlIlll[10] = 0xA9 ^ 0x80 ^ 0x2D ^ 0x1A;
    llIlIlIlll[11] = 0x15 ^ 0x44;
    llIlIlIlll[12] = 0x3 ^ 0x17 ^ 0x1F ^ 0x4C;
    llIlIlIlll[13] = 0x89 ^ 0x90;
    llIlIlIlll[14] = 0xD6 ^ 0xB8;
    llIlIlIlll[15] = "   ".length();
    llIlIlIlll[16] = 64 + 137 - 87 + 39 ^ 50 + 11 - 49 + 145;
    llIlIlIlll[17] = 129 + 101 - 202 + 123 ^ 12 + 29 - 9 + 114;
    llIlIlIlll[18] = 13 + 106 - 56 + 89 ^ 84 + 121 - 55 + 8;
    llIlIlIlll[19] = 58 + 30 - 33 + 128 ^ 2 + 158 - -12 + 4;
    llIlIlIlll[20] = 0xAC ^ 0xA4;
    llIlIlIlll[21] = 0x9 ^ 0x0;
    llIlIlIlll[22] = 0x1 ^ 0xB;
    llIlIlIlll[23] = 0x67 ^ 0x6C;
    llIlIlIlll[24] = 0xB3 ^ 0xBF;
    llIlIlIlll[25] = 0x1E ^ 0x52 ^ 0x72 ^ 0x30;
    llIlIlIlll[26] = 0xBD ^ 0xB2;
    llIlIlIlll[27] = 0xF ^ 0x1F;
    llIlIlIlll[28] = 0x3B ^ 0x2D ^ 0xB9 ^ 0xBE;
    llIlIlIlll[29] = 0x54 ^ 0x46;
    llIlIlIlll[30] = 170 + 84 - 148 + 76 ^ 5 + 18 - -40 + 102;
    llIlIlIlll[31] = 0x15 ^ 0x25 ^ 0xB5 ^ 0x91;
    llIlIlIlll[32] = 0x89 ^ 0x9C;
    llIlIlIlll[33] = 17 + 17 - -4 + 106 ^ 43 + 37 - 4 + 58;
    llIlIlIlll[34] = 0x43 ^ 0x0 ^ 0xC6 ^ 0x92;
    llIlIlIlll[35] = 83 + 124 - 148 + 87 ^ 55 + 112 - 100 + 71;
    llIlIlIlll[36] = 0x7B ^ 0x26;
    llIlIlIlll[37] = 0xFD ^ 0xC4 ^ 0xF9 ^ 0xBD;
    llIlIlIlll[38] = 0x47 ^ 0x6C ^ 0xA4 ^ 0x94;
    llIlIlIlll[39] = 0x8E ^ 0xB5;
    llIlIlIlll[40] = -" ".length();
    llIlIlIlll[41] = (0xD7 ^ 0x9B) + (0xFC ^ 0xA3) - (0x46 ^ 0x51) + (0x5A ^ 0x4D);
    llIlIlIlll[42] = 66 + 43 - 80 + 117;
    llIlIlIlll[43] = 0x6C ^ 0x4C;
    llIlIlIlll[44] = 22 + 65 - -88 + 9 ^ 111 + 159 - 134 + 26;
    llIlIlIlll[45] = (0x8B ^ 0x96) + 146 + 7 - 82 + 111 - (0x3C ^ 0x19) + (0x76 ^ 0x7D);
    llIlIlIlll[46] = (0x4E ^ 0x69) + (0x48 ^ 0x5D) - -(0xC4 ^ 0x8C) + (0x70 ^ 0x65);
    llIlIlIlll[47] = 0xAC ^ 0x9D;
    llIlIlIlll[48] = 0x46 ^ 0x5A;
    llIlIlIlll[49] = 123 + 102 - 89 + 2 ^ 9 + 15 - -42 + 85;
    llIlIlIlll[50] = 0x21 ^ 0x56 ^ 0xE ^ 0x66;
    llIlIlIlll[51] = 0x64 ^ 0x45;
    llIlIlIlll[52] = 165 + 146 - 139 + 10 ^ 136 + 20 - 61 + 53;
    llIlIlIlll[53] = 142 + 129 - 122 + 38 ^ 91 + 148 - 193 + 106;
    llIlIlIlll[54] = 0x58 ^ 0x7C;
    llIlIlIlll[55] = 0x18 ^ 0x4F;
    llIlIlIlll[56] = 0x6F ^ 0x73 ^ 0xF2 ^ 0x9B;
    llIlIlIlll[57] = 137 + 139 - 171 + 120 ^ 78 + 112 - 150 + 119;
    llIlIlIlll[58] = 0xF6 ^ 0xA6;
    llIlIlIlll[59] = 122 + 91 - 141 + 64 ^ 174 + 108 - 265 + 174;
    llIlIlIlll[60] = 0x4D ^ 0x2A ^ 0x38 ^ 0x79;
    llIlIlIlll[61] = 0x81 ^ 0xA4;
    llIlIlIlll[62] = 0x84 ^ 0x8D ^ 0x91 ^ 0xBF;
    llIlIlIlll[63] = 0x38 ^ 0x11;
    llIlIlIlll[64] = 125 + 26 - -58 + 38;
    llIlIlIlll[65] = 44 + 166 - 170 + 156;
    llIlIlIlll[66] = 0xC7 ^ 0xA9 ^ 0x2B ^ 0x73;
    llIlIlIlll[67] = 103 + 134 - 168 + 87 ^ 160 + 76 - 187 + 133;
    llIlIlIlll[68] = 0x1 ^ 0x2A;
    llIlIlIlll[69] = 0x31 ^ 0x1D;
    llIlIlIlll[70] = 0x20 ^ 0x28 ^ 0x31 ^ 0x17;
    llIlIlIlll[71] = 0x64 ^ 0x7F ^ 0x34 ^ 0x0;
    llIlIlIlll[72] = "   ".length() ^ 0x25 ^ 0x16;
    llIlIlIlll[73] = 0x57 ^ 0x35 ^ 0x7A ^ 0x2A;
    llIlIlIlll[74] = 0x89 ^ 0xC4 ^ 0xDE ^ 0xA0;
    llIlIlIlll[75] = 0x85 ^ 0xB1;
    llIlIlIlll[76] = 174 + 107 - 147 + 55 ^ 92 + 27 - 114 + 131;
    llIlIlIlll[77] = 0xA8 ^ 0x90;
    llIlIlIlll[78] = 0x91 ^ 0xA8;
    llIlIlIlll[79] = 64 + 85 - 77 + 60;
    llIlIlIlll[80] = (0x27 ^ 0x3C) + (0x8 ^ 0x64) - (0x1B ^ 0x59) + (0xD ^ 0x36);
    llIlIlIlll[81] = (0x8A ^ 0x9D) + (0xC1 ^ 0xBD) - (0xDF ^ 0xBF) + 75 + 40 - 30 + 57;
    llIlIlIlll[82] = 59 + 23 - -3 + 112;
    llIlIlIlll[83] = 0x4C ^ 0x76;
    llIlIlIlll[84] = 199 + 49 - 46 + 50 ^ 142 + 152 - 266 + 164;
    llIlIlIlll[85] = 0xEC ^ 0x8F ^ 0xAC ^ 0xB7;
    llIlIlIlll[86] = (0x8B ^ 0xB0) + (0x49 ^ 0x76) - (0xCD ^ 0x94) + 6 + 23 - -85 + 16;
    llIlIlIlll[87] = 56 + 52 - 15 + 36;
    llIlIlIlll[88] = (0x3C ^ 0x15) + (0x70 ^ 0x53) - -(0x8E ^ 0x86) + (0x35 ^ 0x8);
    llIlIlIlll[89] = 0x93 ^ 0xC4 ^ 0x75 ^ 0x1F;
    llIlIlIlll[90] = 0x58 ^ 0x66;
    llIlIlIlll[91] = 39 + 34 - 33 + 108 ^ 140 + 40 - 147 + 138;
    llIlIlIlll[92] = 0x3A ^ 0x7A;
    llIlIlIlll[93] = 0x34 ^ 0x64 ^ 0xD ^ 0x1C;
    llIlIlIlll[94] = 0xF5 ^ 0xB7;
    llIlIlIlll[95] = 118 + 105 - 65 + 41 ^ 50 + 18 - 30 + 94;
    llIlIlIlll[96] = 129 + 75 - 92 + 111 ^ 58 + 19 - 47 + 125;
    llIlIlIlll[97] = 0x1 ^ 0x44;
    llIlIlIlll[98] = (0x39 ^ 0x4E) + (0x90 ^ 0xAF) - (0xD1 ^ 0x8A) + (0x99 ^ 0xB3);
    llIlIlIlll[99] = 162 + 168 - 227 + 70;
    llIlIlIlll[100] = (0x8 ^ 0x6E) + (0xEE ^ 0x95) - 14 + 119 - 25 + 82 + 55 + 138 - 72 + 19;
    llIlIlIlll[101] = 70 + 150 - 173 + 121;
    llIlIlIlll[102] = (0xE5 ^ 0xC7) + (0xF4 ^ 0x87) - (0xC5 ^ 0x88) + (0xB0 ^ 0x8A);
    llIlIlIlll[103] = 0xD6 ^ 0xB4;
    llIlIlIlll[104] = 31 + 8 - 33 + 138;
    llIlIlIlll[105] = 0x56 ^ 0x3D;
    llIlIlIlll[106] = (0xBF ^ 0x85) + 127 + 15 - 55 + 47 - (0xC ^ 0x37) + (0x1D ^ 0xD);
    llIlIlIlll[107] = 0x8 ^ 0x40;
    llIlIlIlll[108] = (0xEB ^ 0xB5) + 164 + 198 - 361 + 201 - 221 + 20 - 97 + 110 + 36 + 23 - -7 + 107;
    llIlIlIlll[109] = 96 + 125 - 174 + 89 + (0x58 ^ 0x52) - (0xE ^ 0x3E) + (0xDB ^ 0x85);
    llIlIlIlll[110] = 3 + 51 - 4 + 126 ^ 98 + 151 - 57 + 0;
    llIlIlIlll[111] = 85 + 127 - -26 + 0 ^ 78 + 28 - 12 + 37;
    llIlIlIlll[112] = 0xB0 ^ 0xC2;
    llIlIlIlll[113] = 0x27 ^ 0x29 ^ 0xA8 ^ 0xC3;
    llIlIlIlll[114] = ((0x2A ^ 0x49) & (0x41 ^ 0x22 ^ 0xFFFFFFFF)) + 69 + 65 - 75 + 83 - (0x3D ^ 0x60) + (0x6B ^ 0x1A);
    llIlIlIlll[115] = 0x7A ^ 0x42 ^ 0x1E ^ 0x75;
    llIlIlIlll[116] = 153 + 64 - 94 + 71 ^ 35 + 84 - 70 + 115;
    llIlIlIlll[117] = 27 + 201 - 51 + 49;
    llIlIlIlll[118] = 0x2A ^ 0x1D ^ 0x4B ^ 0x24;
    llIlIlIlll[119] = 102 + 2 - 98 + 130;
    llIlIlIlll[120] = 190 + 39 - 216 + 201;
    llIlIlIlll[121] = 0x1E ^ 0x7D;
    llIlIlIlll[122] = (0x1D ^ 0x3E) + (0xF2 ^ 0x89) - (0xB5 ^ 0xBE) + (0x71 ^ 0x79);
    llIlIlIlll[123] = 0x1E ^ 0x62;
    llIlIlIlll[124] = 30 + 39 - -47 + 100 ^ 66 + 74 - 54 + 54;
    llIlIlIlll[125] = 0x61 ^ 0x5B ^ 0xEA ^ 0x99;
    llIlIlIlll[126] = (0xE ^ 0x25) + (0x2C ^ 0x4F) - 123 + 22 - 125 + 110 + 59 + 83 - -8 + 41;
    llIlIlIlll[127] = 0x91 ^ 0xB7 ^ 0x2B ^ 0x64;
    llIlIlIlll[128] = (0x47 ^ 0x26) + (0x75 ^ 0x27) - 32 + 74 - 63 + 118 + (0xFD ^ 0x8A);
    llIlIlIlll[129] = 0xE ^ 0x62;
    llIlIlIlll[130] = 0x8 ^ 0x42;
    llIlIlIlll[131] = 0x5D ^ 0x53 ^ 0xD0 ^ 0x95;
    llIlIlIlll[132] = 0x5B ^ 0x17;
    llIlIlIlll[133] = 185 + 102 - 205 + 114 + 89 + 137 - 181 + 95 - 63 + 101 - 71 + 35 + (0x1A ^ 0x3);
    llIlIlIlll[134] = 0x7C ^ 0x1B ^ 0x36 ^ 0x25;
    llIlIlIlll[135] = 0x16 ^ 0x47 ^ 0x6F ^ 0x73;
    llIlIlIlll[136] = 0xD6 ^ 0x98;
    llIlIlIlll[137] = 197 + 102 - 139 + 94 ^ 106 + 33 - 93 + 131;
    llIlIlIlll[138] = 0x8 ^ 0x43 ^ 0x4C ^ 0x55;
    llIlIlIlll[139] = 0x0 ^ 0x55;
    llIlIlIlll[140] = 0x4B ^ 0x1D;
    llIlIlIlll[141] = 0x6C ^ 0x4F ^ 0xF0 ^ 0x8A;
    llIlIlIlll[142] = 0xC2 ^ 0x98;
    llIlIlIlll[143] = 0x4B ^ 0x10;
    llIlIlIlll[144] = 24 + 107 - -64 + 51 ^ 8 + 96 - -29 + 37;
    llIlIlIlll[145] = 0x6D ^ 0x33;
    llIlIlIlll[146] = 0x42 ^ 0x5A ^ 0x43 ^ 0x4;
    llIlIlIlll[147] = 0x2E ^ 0x4E;
    llIlIlIlll[148] = 0xD9 ^ 0xB8;
    llIlIlIlll[149] = 143 + 138 - 258 + 208 ^ 13 + 32 - -28 + 58;
    llIlIlIlll[150] = 0x60 ^ 0x7;
    llIlIlIlll[151] = 81 + 182 - 220 + 210 ^ 57 + 4 - 47 + 135;
    llIlIlIlll[152] = 0x2A ^ 0xD ^ 0x29 ^ 0x64;
    llIlIlIlll[153] = 111 + 117 - 188 + 209 ^ 33 + 43 - 37 + 111;
    llIlIlIlll[154] = 0xFC ^ 0x8D;
    llIlIlIlll[155] = 0x41 ^ 0x32;
    llIlIlIlll[156] = 0x97 ^ 0x88 ^ 0x72 ^ 0x1B;
    llIlIlIlll[157] = 0xCC ^ 0xBB;
    llIlIlIlll[158] = 0x30 ^ 0x49;
    llIlIlIlll[159] = 51 + 133 - 13 + 58 ^ 80 + 88 - 28 + 18;
    llIlIlIlll[160] = (0x0 ^ 0x4F) + (0xA8 ^ 0xAC) - -(0x3 ^ 0x2B) + (0xBC ^ 0xB8);
    llIlIlIlll[161] = (0x15 ^ 0x52) + (0x9D ^ 0xA9) - (0x68 ^ 0x3E) + (0x2B ^ 0x75);
    llIlIlIlll[162] = 106 + 123 - 116 + 21;
    llIlIlIlll[163] = (0x5D ^ 0xE) + (0xA ^ 0x38) - "  ".length() + (0x9B ^ 0x9F);
    llIlIlIlll[164] = 65 + 8 - -24 + 41;
  }
  
  private static boolean lIIllIllII(char lllllllllllllllllIIIlIlIlIIIIIIl, long lllllllllllllllllIIIlIlIlIIIIIll) {
    if (llIIlIIlllll(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if ((0x52 ^ 0x17 ^ 0xF8 ^ 0xB9) != (123 + 141 - 180 + 69 ^ 29 + 99 - 13 + 42))
        return (56 + 45 - 68 + 137 ^ 56 + 115 - 3 + 13) & (0x71 ^ 0x4B ^ 0x22 ^ 0x7 ^ -" ".length()); 
    } else {
    
    } 
    return llIlIlIlll[1];
  }
  
  private static String lIIllIlIII(Exception lllllllllllllllllIIIlIlIlIIIllll, Exception lllllllllllllllllIIIlIlIlIIIlIII) {
    try {
      SecretKeySpec lllllllllllllllllIIIlIlIlIIIllII = new SecretKeySpec(MessageDigest.getInstance(llIlIlIllI[llIlIlIlll[16]]).digest(lllllllllllllllllIIIlIlIlIIIlIII.getBytes(StandardCharsets.UTF_8)), llIlIlIllI[llIlIlIlll[17]]);
      Cipher lllllllllllllllllIIIlIlIlIIIlIll = Cipher.getInstance(llIlIlIllI[llIlIlIlll[18]]);
      lllllllllllllllllIIIlIlIlIIIlIll.init(llIIllII[llIlIlIlll[2]], lllllllllllllllllIIIlIlIlIIIllII);
      return new String(lllllllllllllllllIIIlIlIlIIIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIlIlIlIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIIIlIlIlIIlIIIl) {
      Exception exception1;
      exception1.printStackTrace();
      return null;
    } 
  }
  
  private static boolean llIIlIIlllll(short lllllllllllllllllIIIlIIllIIIllII, byte lllllllllllllllllIIIlIIllIIIlIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static String lIlllIlIIIll(String lllllllllllllllllIIIlIIllIlIIIII, String lllllllllllllllllIIIlIIllIIlllll) {
    lllllllllllllllllIIIlIIllIIllIll = new String(Base64.getDecoder().decode(lllllllllllllllllIIIlIIllIlIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIIlIIllIIllllI = new StringBuilder();
    char[] lllllllllllllllllIIIlIIllIIlllIl = lllllllllllllllllIIIlIIllIIlllll.toCharArray();
    int lllllllllllllllllIIIlIIllIIlllII = llIlIlIlll[1];
    char[] arrayOfChar1 = lllllllllllllllllIIIlIIllIIllIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIlIlIlll[1];
    while (llIIlIIlllll(j, i)) {
      char lllllllllllllllllIIIlIIllIlIIIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllllIIIlIIllIIlllII++;
      j++;
      "".length();
      if (-"   ".length() > 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllllIIIlIIllIIllllI);
  }
  
  public boolean isPermission() {
    // Byte code:
    //   0: aload_0
    //   1: getfield permission : Z
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIIIlIIlllllllll	Z
    //   0	5	0	lllllllllllllllllIIIlIIlllllllIl	J
    //   0	5	0	lllllllllllllllllIIIlIIllllllllI	Lcom/axeelheaven/hbedwars/cosmetics/toppers/Topper;
  }
  
  private static boolean llIIlIlIIlIl(boolean lllllllllllllllllIIIlIIllIIIIIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  public String getId() {
    return ((Topper)super).id;
  }
  
  private static boolean llIIlIIlllIl(char lllllllllllllllllIIIlIIlIlllllll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean llIIlIlIIllI(Exception lllllllllllllllllIIIlIIllIIIlIII, Exception lllllllllllllllllIIIlIIllIIIIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 <= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean llIIlIlIIIll(char lllllllllllllllllIIIlIIlIllllIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= null);
  }
  
  private static String lIIllIIllI(String lllllllllllllllllIIIlIlIIlllIIIl, int lllllllllllllllllIIIlIlIIllIIllI) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   43: iconst_1
    //   44: iaload
    //   45: iaload
    //   46: istore #4
    //   48: aload_0
    //   49: invokevirtual toCharArray : ()[C
    //   52: astore #5
    //   54: aload #5
    //   56: arraylength
    //   57: istore #6
    //   59: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIIllII : [I
    //   62: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   65: iconst_1
    //   66: iaload
    //   67: iaload
    //   68: istore #7
    //   70: iload #7
    //   72: iload #6
    //   74: invokestatic lIIllIllII : (II)Z
    //   77: invokestatic llIIlIIlllIl : (I)Z
    //   80: ifeq -> 165
    //   83: aload #5
    //   85: iload #7
    //   87: caload
    //   88: istore #8
    //   90: aload_2
    //   91: iload #8
    //   93: aload_3
    //   94: iload #4
    //   96: aload_3
    //   97: arraylength
    //   98: irem
    //   99: caload
    //   100: ixor
    //   101: i2c
    //   102: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   105: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIllI : [Ljava/lang/String;
    //   108: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   111: bipush #19
    //   113: iaload
    //   114: aaload
    //   115: invokevirtual length : ()I
    //   118: pop2
    //   119: iinc #4, 1
    //   122: iinc #7, 1
    //   125: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIllI : [Ljava/lang/String;
    //   128: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   131: bipush #20
    //   133: iaload
    //   134: aaload
    //   135: invokevirtual length : ()I
    //   138: ldc ''
    //   140: invokevirtual length : ()I
    //   143: pop2
    //   144: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIllI : [Ljava/lang/String;
    //   147: getstatic com/axeelheaven/hbedwars/cosmetics/toppers/Topper.llIlIlIlll : [I
    //   150: bipush #21
    //   152: iaload
    //   153: aaload
    //   154: invokevirtual length : ()I
    //   157: invokestatic llIIlIlIIIII : (I)Z
    //   160: ifeq -> 70
    //   163: aconst_null
    //   164: areturn
    //   165: aload_2
    //   166: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   169: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	170	7	lllllllllllllllllIIIlIlIIllIIIII	C
    //   0	170	0	lllllllllllllllllIIIlIlIIllIllIl	Ljava/lang/String;
    //   0	170	2	lllllllllllllllllIIIlIlIIllIIlIl	D
    //   0	170	1	lllllllllllllllllIIIlIlIIllIlIII	Ljava/lang/String;
    //   0	170	6	lllllllllllllllllIIIlIlIIllIIIIl	Z
    //   0	170	2	lllllllllllllllllIIIlIlIIlllIIll	J
    //   37	133	3	lllllllllllllllllIIIlIlIIlllIIlI	[C
    //   32	138	2	lllllllllllllllllIIIlIlIIllIlIlI	Ljava/lang/StringBuilder;
    //   0	170	7	lllllllllllllllllIIIlIlIIllIllll	Ljava/lang/Exception;
    //   0	170	5	lllllllllllllllllIIIlIlIIllIIIlI	S
    //   0	170	1	lllllllllllllllllIIIlIlIIllIIllI	I
    //   0	170	8	lllllllllllllllllIIIlIlIIlllIIII	D
    //   0	170	6	lllllllllllllllllIIIlIlIIllIlIIl	S
    //   0	170	5	lllllllllllllllllIIIlIlIIlllIlII	F
    //   0	170	1	lllllllllllllllllIIIlIlIIlllIllI	Z
    //   0	170	4	lllllllllllllllllIIIlIlIIllIIIll	F
    //   0	170	0	lllllllllllllllllIIIlIlIIlllIIIl	Ljava/lang/String;
    //   90	32	8	lllllllllllllllllIIIlIlIIllIlIll	C
    //   0	170	3	lllllllllllllllllIIIlIlIIlllIlIl	Z
    //   48	122	4	lllllllllllllllllIIIlIlIIllIlllI	I
    //   0	170	0	lllllllllllllllllIIIlIlIIllIIlll	B
    //   0	170	4	lllllllllllllllllIIIlIlIIllIllII	J
    //   0	170	3	lllllllllllllllllIIIlIlIIllIIlII	I
    //   0	170	8	lllllllllllllllllIIIlIlIIlIlllll	I
  }
  
  private static void lIIllIlIlI() {
    llIIllII = new int[llIlIlIlll[49]];
    llIIllII[llIlIlIlll[1]] = llIlIlIllI[llIlIlIlll[94]].length() & (llIlIlIllI[llIlIlIlll[95]].length() ^ llIlIlIlll[40]);
    llIIllII[llIlIlIlll[0]] = llIlIlIllI[llIlIlIlll[96]].length();
    llIIllII[llIlIlIlll[2]] = llIlIlIllI[llIlIlIlll[97]].length();
    llIIllII[llIlIlIlll[15]] = llIlIlIllI[llIlIlIlll[5]].length();
    llIIllII[llIlIlIlll[16]] = llIlIlIlll[87] ^ llIlIlIlll[98];
    llIIllII[llIlIlIlll[17]] = llIlIlIllI[llIlIlIlll[12]].length() ^ llIlIlIlll[41] ^ llIlIlIlll[99];
    llIIllII[llIlIlIlll[18]] = llIlIlIlll[11] ^ llIlIlIlll[55];
    llIIllII[llIlIlIlll[19]] = llIlIlIlll[100] ^ llIlIlIlll[101];
    llIIllII[llIlIlIlll[20]] = llIlIlIlll[89] ^ llIlIlIlll[12] ^ llIlIlIlll[58] ^ llIlIlIlll[52];
    llIIllII[llIlIlIlll[21]] = llIlIlIlll[87] + llIlIlIlll[102] - llIlIlIlll[103] + llIlIlIlll[18] ^ llIlIlIlll[104] + llIlIlIlll[105] - llIlIlIlll[106] + llIlIlIlll[107];
    llIIllII[llIlIlIlll[22]] = llIlIlIlll[108] ^ llIlIlIlll[109] ^ llIlIlIlll[110] ^ llIlIlIlll[111];
    llIIllII[llIlIlIlll[23]] = llIlIlIlll[26] ^ llIlIlIlll[112] ^ llIlIlIlll[68] ^ llIlIlIlll[36];
    llIIllII[llIlIlIlll[24]] = llIlIlIlll[13] ^ llIlIlIlll[9] ^ llIlIlIlll[113] ^ llIlIlIlll[36];
    llIIllII[llIlIlIlll[6]] = llIlIlIlll[100] ^ llIlIlIlll[114];
    llIIllII[llIlIlIlll[25]] = llIlIlIlll[26] ^ llIlIlIlll[0];
    llIIllII[llIlIlIlll[26]] = llIlIlIlll[15] ^ llIlIlIlll[24];
    llIIllII[llIlIlIlll[27]] = llIlIlIlll[2] ^ llIlIlIlll[115] ^ llIlIlIlll[47] ^ llIlIlIlll[110];
    llIIllII[llIlIlIlll[28]] = llIlIlIlll[89] ^ llIlIlIlll[69];
    llIIllII[llIlIlIlll[29]] = llIlIlIlll[80] + llIlIlIlll[116] - llIlIlIlll[117] + llIlIlIlll[57] ^ llIlIlIlll[48] + llIlIlIlll[96] - llIlIlIlll[118] + llIlIlIlll[119];
    llIIllII[llIlIlIlll[30]] = llIlIlIlll[120] ^ llIlIlIlll[82];
    llIIllII[llIlIlIlll[31]] = llIlIlIlll[121] + llIlIlIlll[122] - llIlIlIlll[123] + llIlIlIlll[38] ^ llIlIlIlll[10] + llIlIlIlll[78] - llIlIlIlll[40] + llIlIlIlll[47];
    llIIllII[llIlIlIlll[32]] = llIlIlIlll[66] ^ llIlIlIlll[53];
    llIIllII[llIlIlIlll[33]] = llIlIlIlll[46] ^ llIlIlIlll[4];
    llIIllII[llIlIlIlll[34]] = llIlIlIllI[llIlIlIlll[107]].length() ^ llIlIlIlll[94] ^ llIlIlIlll[124];
    llIIllII[llIlIlIlll[35]] = llIlIlIlll[22] ^ llIlIlIlll[75] ^ llIlIlIlll[13] ^ llIlIlIlll[91];
    llIIllII[llIlIlIlll[13]] = llIlIlIlll[58] ^ llIlIlIlll[125];
    llIIllII[llIlIlIlll[44]] = llIlIlIlll[126] ^ llIlIlIlll[41] ^ llIlIlIlll[127] ^ llIlIlIlll[30];
    llIIllII[llIlIlIlll[38]] = llIlIlIlll[23] + llIlIlIlll[128] - llIlIlIlll[107] + llIlIlIlll[58] ^ llIlIlIlll[63] + llIlIlIlll[129] - llIlIlIlll[51] + llIlIlIlll[30];
    llIIllII[llIlIlIlll[48]] = llIlIlIlll[72] ^ llIlIlIlll[69];
  }
  
  private static boolean llIIlIlIIIIl(char lllllllllllllllllIIIlIIlIlllIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > null);
  }
  
  public List<String> getBlocks() {
    return this.blocks;
  }
  
  private static void lIIllIlIIl() {
    llIIlIll = new String[llIIllII[llIlIlIlll[48]]];
    llIIlIll[llIIllII[llIlIlIlll[1]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[138]], llIlIlIllI[llIlIlIlll[115]]);
    llIIlIll[llIIllII[llIlIlIlll[0]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[124]], llIlIlIllI[llIlIlIlll[139]]);
    llIIlIll[llIIllII[llIlIlIlll[2]]] = lIIllIIlll(llIlIlIllI[llIlIlIlll[140]], llIlIlIllI[llIlIlIlll[55]]);
    llIIlIll[llIIllII[llIlIlIlll[15]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[118]], llIlIlIllI[llIlIlIlll[141]]);
    llIIlIll[llIIllII[llIlIlIlll[16]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[142]], llIlIlIllI[llIlIlIlll[143]]);
    llIIlIll[llIIllII[llIlIlIlll[17]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[144]], llIlIlIllI[llIlIlIlll[36]]);
    llIIlIll[llIIllII[llIlIlIlll[18]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[145]], llIlIlIllI[llIlIlIlll[146]]);
    llIIlIll[llIIllII[llIlIlIlll[19]]] = lIIllIIlll(llIlIlIllI[llIlIlIlll[147]], llIlIlIllI[llIlIlIlll[148]]);
    llIIlIll[llIIllII[llIlIlIlll[20]]] = lIIllIIlll(llIlIlIllI[llIlIlIlll[103]], llIlIlIllI[llIlIlIlll[121]]);
    llIIlIll[llIIllII[llIlIlIlll[21]]] = lIIllIIlll(llIlIlIllI[llIlIlIlll[149]], llIlIlIllI[llIlIlIlll[113]]);
    llIIlIll[llIIllII[llIlIlIlll[22]]] = lIIllIlIII(llIlIlIllI[llIlIlIlll[116]], llIlIlIllI[llIlIlIlll[150]]);
    llIIlIll[llIIllII[llIlIlIlll[23]]] = lIIllIIlll(llIlIlIllI[llIlIlIlll[151]], llIlIlIllI[llIlIlIlll[127]]);
    llIIlIll[llIIllII[llIlIlIlll[24]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[152]], llIlIlIllI[llIlIlIlll[105]]);
    llIIlIll[llIIllII[llIlIlIlll[6]]] = lIIllIIlll(llIlIlIllI[llIlIlIlll[129]], llIlIlIllI[llIlIlIlll[111]]);
    llIIlIll[llIIllII[llIlIlIlll[25]]] = lIIllIIlll(llIlIlIllI[llIlIlIlll[14]], llIlIlIllI[llIlIlIlll[153]]);
    llIIlIll[llIIllII[llIlIlIlll[26]]] = lIIllIIlll(llIlIlIllI[llIlIlIlll[110]], llIlIlIllI[llIlIlIlll[154]]);
    llIIlIll[llIIllII[llIlIlIlll[27]]] = lIIllIlIII(llIlIlIllI[llIlIlIlll[112]], llIlIlIllI[llIlIlIlll[155]]);
    llIIlIll[llIIllII[llIlIlIlll[28]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[134]], llIlIlIllI[llIlIlIlll[56]]);
    llIIlIll[llIIllII[llIlIlIlll[29]]] = lIIllIIlll(llIlIlIllI[llIlIlIlll[156]], llIlIlIllI[llIlIlIlll[157]]);
    llIIlIll[llIIllII[llIlIlIlll[30]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[85]], llIlIlIllI[llIlIlIlll[158]]);
    llIIlIll[llIIllII[llIlIlIlll[31]]] = lIIllIlIII(llIlIlIllI[llIlIlIlll[8]], llIlIlIllI[llIlIlIlll[159]]);
    llIIlIll[llIIllII[llIlIlIlll[32]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[123]], llIlIlIllI[llIlIlIlll[37]]);
    llIIlIll[llIIllII[llIlIlIlll[33]]] = lIIllIIlll(llIlIlIllI[llIlIlIlll[57]], llIlIlIllI[llIlIlIlll[160]]);
    llIIlIll[llIIllII[llIlIlIlll[34]]] = lIIllIlIII(llIlIlIllI[llIlIlIlll[80]], llIlIlIllI[llIlIlIlll[87]]);
    llIIlIll[llIIllII[llIlIlIlll[35]]] = lIIllIlIII(llIlIlIllI[llIlIlIlll[102]], llIlIlIllI[llIlIlIlll[161]]);
    llIIlIll[llIIllII[llIlIlIlll[13]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[79]], llIlIlIllI[llIlIlIlll[98]]);
    llIIlIll[llIIllII[llIlIlIlll[44]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[162]], llIlIlIllI[llIlIlIlll[163]]);
    llIIlIll[llIIllII[llIlIlIlll[38]]] = lIIllIIllI(llIlIlIllI[llIlIlIlll[119]], llIlIlIllI[llIlIlIlll[128]]);
  }
  
  public int getPrice() {
    // Byte code:
    //   0: aload_0
    //   1: getfield price : I
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIIIlIIllllllIll	Lcom/axeelheaven/hbedwars/cosmetics/toppers/Topper;
    //   0	5	0	lllllllllllllllllIIIlIIllllllIIl	B
    //   0	5	0	lllllllllllllllllIIIlIIllllllIlI	S
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\toppers\Topper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */