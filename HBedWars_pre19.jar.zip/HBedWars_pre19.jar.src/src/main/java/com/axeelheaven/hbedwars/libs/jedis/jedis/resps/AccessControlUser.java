/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AccessControlUser
/*    */ {
/*  9 */   private final List<String> flags = new ArrayList<>();
/* 10 */   private final List<String> keys = new ArrayList<>();
/* 11 */   private final List<String> passwords = new ArrayList<>();
/* 12 */   private final List<String> channels = new ArrayList<>();
/*    */ 
/*    */   
/*    */   private String commands;
/*    */ 
/*    */   
/*    */   public void addFlag(String flag) {
/* 19 */     this.flags.add(flag);
/*    */   }
/*    */   
/*    */   public List<String> getFlags() {
/* 23 */     return this.flags;
/*    */   }
/*    */   
/*    */   public void addKey(String key) {
/* 27 */     this.keys.add(key);
/*    */   }
/*    */   
/*    */   public List<String> getKeys() {
/* 31 */     return this.keys;
/*    */   }
/*    */   
/*    */   public void addKeys(String keys) {
/* 35 */     if (!keys.isEmpty()) {
/* 36 */       this.keys.addAll(Arrays.asList(keys.split(" ")));
/*    */     }
/*    */   }
/*    */   
/*    */   public void addPassword(String password) {
/* 41 */     this.passwords.add(password);
/*    */   }
/*    */   
/*    */   public List<String> getPassword() {
/* 45 */     return this.passwords;
/*    */   }
/*    */   
/*    */   public void addChannel(String channel) {
/* 49 */     this.channels.add(channel);
/*    */   }
/*    */   
/*    */   public List<String> getChannels() {
/* 53 */     return this.channels;
/*    */   }
/*    */   
/*    */   public void addChannels(String channels) {
/* 57 */     if (!channels.isEmpty()) {
/* 58 */       this.channels.addAll(Arrays.asList(channels.split(" ")));
/*    */     }
/*    */   }
/*    */   
/*    */   public String getCommands() {
/* 63 */     return this.commands;
/*    */   }
/*    */   
/*    */   public void setCommands(String commands) {
/* 67 */     this.commands = commands;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     return "AccessControlUser{flags=" + this.flags + ", passwords=" + this.passwords + ", commands='" + this.commands + "', keys='" + this.keys + "', channels='" + this.channels + "'}";
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\AccessControlUser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */