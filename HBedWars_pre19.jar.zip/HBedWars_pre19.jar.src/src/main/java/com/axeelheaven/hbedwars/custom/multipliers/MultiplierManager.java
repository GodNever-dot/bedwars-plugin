package com.axeelheaven.hbedwars.custom.multipliers;

import com.axeelheaven.hbedwars.BedWars;
import java.util.ArrayList;
import java.util.List;

public class MultiplierManager {
  private final BedWars plugin;
  private final List<Multiplier> multipliers;

  public MultiplierManager(BedWars plugin) {
    this.plugin = plugin;
    this.multipliers = new ArrayList<>();
  }
  
  public List<Multiplier> getMultipliers() {
    return this.multipliers;
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\multipliers\MultiplierManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */