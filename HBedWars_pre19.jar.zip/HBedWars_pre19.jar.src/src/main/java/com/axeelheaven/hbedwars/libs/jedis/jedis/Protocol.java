/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.Rawable;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.commands.ProtocolCommand;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisAccessControlException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisAskDataException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisBusyException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisClusterException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisConnectionException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisDataException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisMovedDataException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisNoScriptException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.RedisInputStream;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.RedisOutputStream;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public final class Protocol
/*     */ {
/*     */   public static final String DEFAULT_HOST = "127.0.0.1";
/*  26 */   public static final Charset CHARSET = StandardCharsets.UTF_8; public static final int DEFAULT_PORT = 6379; public static final int DEFAULT_SENTINEL_PORT = 26379; public static final int DEFAULT_TIMEOUT = 2000;
/*     */   public static final int DEFAULT_DATABASE = 0;
/*     */   public static final int CLUSTER_HASHSLOTS = 16384;
/*     */   public static final byte DOLLAR_BYTE = 36;
/*     */   public static final byte ASTERISK_BYTE = 42;
/*     */   public static final byte PLUS_BYTE = 43;
/*     */   public static final byte MINUS_BYTE = 45;
/*     */   public static final byte COLON_BYTE = 58;
/*  34 */   public static final byte[] BYTES_TRUE = toByteArray(1);
/*  35 */   public static final byte[] BYTES_FALSE = toByteArray(0);
/*  36 */   public static final byte[] BYTES_TILDE = SafeEncoder.encode("~");
/*  37 */   public static final byte[] BYTES_EQUAL = SafeEncoder.encode("=");
/*  38 */   public static final byte[] BYTES_ASTERISK = SafeEncoder.encode("*");
/*     */   
/*  40 */   public static final byte[] POSITIVE_INFINITY_BYTES = "+inf".getBytes();
/*  41 */   public static final byte[] NEGATIVE_INFINITY_BYTES = "-inf".getBytes();
/*     */   
/*     */   private static final String ASK_PREFIX = "ASK ";
/*     */   
/*     */   private static final String MOVED_PREFIX = "MOVED ";
/*     */   
/*     */   private static final String CLUSTERDOWN_PREFIX = "CLUSTERDOWN ";
/*     */   
/*     */   private static final String BUSY_PREFIX = "BUSY ";
/*     */   
/*     */   private static final String NOSCRIPT_PREFIX = "NOSCRIPT ";
/*     */   private static final String WRONGPASS_PREFIX = "WRONGPASS";
/*     */   private static final String NOPERM_PREFIX = "NOPERM";
/*     */   
/*     */   public static void sendCommand(RedisOutputStream os, CommandArguments args) {
/*     */     try {
/*  57 */       os.write((byte)42);
/*  58 */       os.writeIntCrLf(args.size());
/*  59 */       for (Rawable arg : args) {
/*  60 */         os.write((byte)36);
/*  61 */         byte[] bin = arg.getRaw();
/*  62 */         os.writeIntCrLf(bin.length);
/*  63 */         os.write(bin);
/*  64 */         os.writeCrLf();
/*     */       } 
/*  66 */     } catch (IOException e) {
/*  67 */       throw new JedisConnectionException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void processError(RedisInputStream is) {
/*  72 */     String message = is.readLine();
/*     */ 
/*     */     
/*  75 */     if (message.startsWith("MOVED ")) {
/*  76 */       String[] movedInfo = parseTargetHostAndSlot(message);
/*     */ 
/*     */       
/*  79 */       throw new JedisMovedDataException(message, HostAndPort.from(movedInfo[1]), Integer.parseInt(movedInfo[0]));
/*  80 */     }  if (message.startsWith("ASK ")) {
/*  81 */       String[] askInfo = parseTargetHostAndSlot(message);
/*     */ 
/*     */       
/*  84 */       throw new JedisAskDataException(message, HostAndPort.from(askInfo[1]), Integer.parseInt(askInfo[0]));
/*  85 */     }  if (message.startsWith("CLUSTERDOWN "))
/*  86 */       throw new JedisClusterException(message); 
/*  87 */     if (message.startsWith("BUSY "))
/*  88 */       throw new JedisBusyException(message); 
/*  89 */     if (message.startsWith("NOSCRIPT "))
/*  90 */       throw new JedisNoScriptException(message); 
/*  91 */     if (message.startsWith("WRONGPASS"))
/*  92 */       throw new JedisAccessControlException(message); 
/*  93 */     if (message.startsWith("NOPERM")) {
/*  94 */       throw new JedisAccessControlException(message);
/*     */     }
/*  96 */     throw new JedisDataException(message);
/*     */   }
/*     */   
/*     */   public static String readErrorLineIfPossible(RedisInputStream is) {
/* 100 */     byte b = is.readByte();
/*     */     
/* 102 */     if (b != 45) {
/* 103 */       return null;
/*     */     }
/* 105 */     return is.readLine();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] parseTargetHostAndSlot(String clusterRedirectResponse) {
/* 118 */     String[] response = new String[2];
/* 119 */     String[] messageInfo = clusterRedirectResponse.split(" ");
/* 120 */     response[0] = messageInfo[1];
/* 121 */     response[1] = messageInfo[2];
/* 122 */     return response;
/*     */   }
/*     */   
/*     */   private static Object process(RedisInputStream is) {
/* 126 */     byte b = is.readByte();
/* 127 */     switch (b) {
/*     */       case 43:
/* 129 */         return processStatusCodeReply(is);
/*     */       case 36:
/* 131 */         return processBulkReply(is);
/*     */       case 42:
/* 133 */         return processMultiBulkReply(is);
/*     */       case 58:
/* 135 */         return processInteger(is);
/*     */       case 45:
/* 137 */         processError(is);
/* 138 */         return null;
/*     */     } 
/* 140 */     throw new JedisConnectionException("Unknown reply: " + (char)b);
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] processStatusCodeReply(RedisInputStream is) {
/* 145 */     return is.readLineBytes();
/*     */   }
/*     */   
/*     */   private static byte[] processBulkReply(RedisInputStream is) {
/* 149 */     int len = is.readIntCrLf();
/* 150 */     if (len == -1) {
/* 151 */       return null;
/*     */     }
/*     */     
/* 154 */     byte[] read = new byte[len];
/* 155 */     int offset = 0;
/* 156 */     while (offset < len) {
/* 157 */       int size = is.read(read, offset, len - offset);
/* 158 */       if (size == -1) {
/* 159 */         throw new JedisConnectionException("It seems like server has closed the connection.");
/*     */       }
/* 161 */       offset += size;
/*     */     } 
/*     */ 
/*     */     
/* 165 */     is.readByte();
/* 166 */     is.readByte();
/*     */     
/* 168 */     return read;
/*     */   }
/*     */   
/*     */   private static Long processInteger(RedisInputStream is) {
/* 172 */     return Long.valueOf(is.readLongCrLf());
/*     */   }
/*     */   
/*     */   private static List<Object> processMultiBulkReply(RedisInputStream is) {
/* 176 */     int num = is.readIntCrLf();
/* 177 */     if (num == -1) {
/* 178 */       return null;
/*     */     }
/* 180 */     List<Object> ret = new ArrayList(num);
/* 181 */     for (int i = 0; i < num; i++) {
/*     */       try {
/* 183 */         ret.add(process(is));
/* 184 */       } catch (JedisDataException e) {
/* 185 */         ret.add(e);
/*     */       } 
/*     */     } 
/* 188 */     return ret;
/*     */   }
/*     */   
/*     */   public static Object read(RedisInputStream is) {
/* 192 */     return process(is);
/*     */   }
/*     */   
/*     */   public static final byte[] toByteArray(boolean value) {
/* 196 */     return value ? BYTES_TRUE : BYTES_FALSE;
/*     */   }
/*     */   
/*     */   public static final byte[] toByteArray(int value) {
/* 200 */     return SafeEncoder.encode(String.valueOf(value));
/*     */   }
/*     */   
/*     */   public static final byte[] toByteArray(long value) {
/* 204 */     return SafeEncoder.encode(String.valueOf(value));
/*     */   }
/*     */   
/*     */   public static final byte[] toByteArray(double value) {
/* 208 */     if (value == Double.POSITIVE_INFINITY)
/* 209 */       return POSITIVE_INFINITY_BYTES; 
/* 210 */     if (value == Double.NEGATIVE_INFINITY) {
/* 211 */       return NEGATIVE_INFINITY_BYTES;
/*     */     }
/* 213 */     return SafeEncoder.encode(String.valueOf(value));
/*     */   }
/*     */   
/*     */   public enum Command
/*     */     implements ProtocolCommand
/*     */   {
/* 219 */     PING, SET, GET, GETDEL, GETEX, QUIT, EXISTS, DEL, UNLINK, TYPE, FLUSHDB, KEYS, RANDOMKEY, MOVE,
/* 220 */     RENAME, RENAMENX, DBSIZE, EXPIRE, EXPIREAT, TTL, SELECT, FLUSHALL, GETSET, MGET, SETNX, SETEX,
/* 221 */     MSET, MSETNX, DECRBY, DECR, INCRBY, INCR, APPEND, SUBSTR, HSET, HGET, HSETNX, HMSET, HMGET,
/* 222 */     HINCRBY, HEXISTS, HDEL, HLEN, HKEYS, HVALS, HGETALL, HRANDFIELD, HINCRBYFLOAT, HSTRLEN, MIGRATE,
/* 223 */     RPUSH, LPUSH, LLEN, LRANGE, LTRIM, LINDEX, LSET, LREM, LPOP, RPOP, BLPOP, BRPOP, LINSERT, LPOS,
/* 224 */     RPOPLPUSH, BRPOPLPUSH, BLMOVE, LMOVE, SADD, SMEMBERS, SREM, SPOP, SMOVE, SCARD, SRANDMEMBER,
/* 225 */     SINTER, SINTERSTORE, SUNION, SUNIONSTORE, SDIFF, SDIFFSTORE, SISMEMBER, SMISMEMBER, SINTERCARD,
/* 226 */     MULTI, DISCARD, EXEC, WATCH, UNWATCH, SORT, SORT_RO, AUTH, INFO, SHUTDOWN, MONITOR, CONFIG, LCS,
/* 227 */     SUBSCRIBE, PUBLISH, UNSUBSCRIBE, PSUBSCRIBE, PUNSUBSCRIBE, PUBSUB, STRLEN, LPUSHX, RPUSHX, ECHO,
/* 228 */     ZADD, ZDIFF, ZDIFFSTORE, ZRANGE, ZREM, ZINCRBY, ZRANK, ZREVRANK, ZREVRANGE, ZRANDMEMBER, ZCARD,
/* 229 */     ZSCORE, ZPOPMAX, ZPOPMIN, ZCOUNT, ZUNION, ZUNIONSTORE, ZINTER, ZINTERSTORE, ZRANGEBYSCORE,
/* 230 */     ZREVRANGEBYSCORE, ZREMRANGEBYRANK, ZREMRANGEBYSCORE, ZLEXCOUNT, ZRANGEBYLEX, ZREVRANGEBYLEX,
/* 231 */     ZREMRANGEBYLEX, ZMSCORE, ZRANGESTORE, ZINTERCARD, SAVE, BGSAVE, BGREWRITEAOF, LASTSAVE, PERSIST,
/* 232 */     SETBIT, GETBIT, BITPOS, SETRANGE, GETRANGE, EVAL, EVALSHA, SCRIPT, SLOWLOG, OBJECT, BITCOUNT,
/* 233 */     BITOP, SENTINEL, DUMP, RESTORE, PEXPIRE, PEXPIREAT, PTTL, INCRBYFLOAT, PSETEX, CLIENT, TIME,
/* 234 */     SCAN, HSCAN, SSCAN, ZSCAN, WAIT, CLUSTER, ASKING, READONLY, READWRITE, SLAVEOF, REPLICAOF, COPY,
/* 235 */     PFADD, PFCOUNT, PFMERGE, MODULE, ACL, GEOADD, GEODIST, GEOHASH, GEOPOS, GEORADIUS, GEORADIUS_RO,
/* 236 */     GEORADIUSBYMEMBER, GEORADIUSBYMEMBER_RO, BITFIELD, TOUCH, SWAPDB, MEMORY, BZPOPMIN, BZPOPMAX,
/* 237 */     XADD, XLEN, XDEL, XTRIM, XRANGE, XREVRANGE, XREAD, XACK, XGROUP, XREADGROUP, XPENDING, XCLAIM,
/* 238 */     XAUTOCLAIM, XINFO, BITFIELD_RO, ROLE, FAILOVER, GEOSEARCH, GEOSEARCHSTORE, EVAL_RO, EVALSHA_RO,
/* 239 */     LOLWUT, EXPIRETIME, PEXPIRETIME, FUNCTION, FCALL, FCALL_RO, LMPOP, BLMPOP, ZMPOP, BZMPOP,
/* 240 */     COMMAND, STRALGO;
/*     */     
/*     */     private final byte[] raw;
/*     */     
/*     */     Command() {
/* 245 */       this.raw = SafeEncoder.encode(name());
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getRaw() {
/* 250 */       return this.raw;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Keyword
/*     */     implements Rawable {
/* 256 */     AGGREGATE, ALPHA, ASC, BY, DESC, GET, LIMIT, NO, NOSORT, ONE, SET, STORE, WEIGHTS, WITHSCORES,
/* 257 */     RESETSTAT, REWRITE, RESET, FLUSH, EXISTS, LOAD, LEN, HELP, SCHEDULE, MATCH, COUNT, TYPE, KEYS,
/* 258 */     REFCOUNT, ENCODING, IDLETIME, FREQ, REPLACE, GETNAME, SETNAME, LIST, ID, KILL, PAUSE, UNBLOCK,
/* 259 */     STREAMS, CREATE, MKSTREAM, SETID, DESTROY, DELCONSUMER, MAXLEN, GROUP, IDLE, TIME, BLOCK, NOACK,
/* 260 */     RETRYCOUNT, STREAM, GROUPS, CONSUMERS, JUSTID, WITHVALUES, NOMKSTREAM, MINID, CREATECONSUMER,
/* 261 */     SETUSER, GETUSER, DELUSER, WHOAMI, USERS, CAT, GENPASS, LOG, SAVE, DRYRUN, COPY, AUTH, AUTH2,
/* 262 */     NX, XX, EX, PX, EXAT, PXAT, CH, ABSTTL, KEEPTTL, INCR, INFO, CHANNELS, NUMPAT, NUMSUB, NOW, REV,
/* 263 */     WITHCOORD, WITHDIST, WITHHASH, ANY, FROMMEMBER, FROMLONLAT, BYRADIUS, BYBOX, BYLEX, BYSCORE,
/* 264 */     STOREDIST, TO, FORCE, TIMEOUT, DB, UNLOAD, ABORT, IDX, MINMATCHLEN, WITHMATCHLEN, FULL,
/* 265 */     DELETE, LIBRARYNAME, WITHCODE, DESCRIPTION, GETKEYS, GETKEYSANDFLAGS, DOCS, FILTERBY, DUMP,
/* 266 */     MODULE, ACLCAT, PATTERN, DOCTOR, USAGE, SAMPLES, PURGE, STATS,
/* 267 */     LCS, STRINGS;
/*     */     
/*     */     private final byte[] raw;
/*     */     
/*     */     Keyword() {
/* 272 */       this.raw = SafeEncoder.encode(name());
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getRaw() {
/* 277 */       return this.raw;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum SentinelKeyword
/*     */     implements Rawable {
/* 283 */     MYID, MASTERS, MASTER, SENTINELS, SLAVES, REPLICAS, RESET, FAILOVER, REMOVE, SET, MONITOR,
/* 284 */     GET_MASTER_ADDR_BY_NAME("GET-MASTER-ADDR-BY-NAME");
/*     */     
/*     */     private final byte[] raw;
/*     */     
/*     */     SentinelKeyword() {
/* 289 */       this.raw = SafeEncoder.encode(name());
/*     */     }
/*     */     
/*     */     SentinelKeyword(String str) {
/* 293 */       this.raw = SafeEncoder.encode(str);
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getRaw() {
/* 298 */       return this.raw;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum ResponseKeyword
/*     */     implements Rawable {
/* 304 */     SUBSCRIBE, PSUBSCRIBE, UNSUBSCRIBE, PUNSUBSCRIBE, MESSAGE, PMESSAGE, PONG;
/*     */     
/*     */     private final byte[] raw;
/*     */     
/*     */     ResponseKeyword() {
/* 309 */       this.raw = SafeEncoder.encode(name().toLowerCase(Locale.ENGLISH));
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getRaw() {
/* 314 */       return this.raw;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum ClusterKeyword
/*     */     implements Rawable {
/* 320 */     MEET, RESET, INFO, FAILOVER, SLOTS, NODES, REPLICAS, SLAVES, MYID, ADDSLOTS, DELSLOTS,
/* 321 */     GETKEYSINSLOT, SETSLOT, NODE, MIGRATING, IMPORTING, STABLE, FORGET, FLUSHSLOTS, KEYSLOT,
/* 322 */     COUNTKEYSINSLOT, SAVECONFIG, REPLICATE, LINKS, ADDSLOTSRANGE, DELSLOTSRANGE, BUMPEPOCH;
/*     */     
/*     */     private final byte[] raw;
/*     */     
/*     */     ClusterKeyword() {
/* 327 */       this.raw = SafeEncoder.encode(name());
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getRaw() {
/* 332 */       return this.raw;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\Protocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */