package com.axeelheaven.hbedwars.cosmetics.windances;

import com.axeelheaven.hbedwars.BedWars;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.concurrent.ThreadLocalRandom;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class WinDanceVulcan extends WinDance {
  private static boolean lllIlIIlIlIl(double llllllllllllllllIllIIllIlIlIIlII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static void lIIIlIIlIII() {
    lIllIIlll = new int[llllllIIlI[3]];
    lIllIIlll[llllllIIlI[1]] = llllllIIlI[4] ^ llllllIIlI[5] ^ llllllIIlI[6] ^ llllllIIlI[7];
    lIllIIlll[llllllIIlI[0]] = llllllIIIl[llllllIIlI[3]].length();
    lIllIIlll[llllllIIlI[2]] = (llllllIIlI[8] + llllllIIlI[9] - llllllIIlI[10] + llllllIIlI[11] ^ llllllIIlI[12] + llllllIIlI[13] - llllllIIlI[14] + llllllIIlI[15]) & (llllllIIlI[16] ^ llllllIIlI[11] ^ llllllIIlI[17] ^ llllllIIlI[18] ^ -llllllIIIl[llllllIIlI[19]].length());
  }
  
  private static boolean lIIIlIIlIll(byte llllllllllllllllIllIIllIlIlllIII) {
    if (lllIlIIlIlll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ("   ".length() == "  ".length())
        return (0x30 ^ 0x75) & (0xEC ^ 0xA9 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llllllIIlI[1];
  }
  
  private static boolean lIIIlIIlIlI(String llllllllllllllllIllIIllIllIlIlIl) {
    if (lllIlIIlIlII(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (-(83 + 24 - 74 + 97 ^ 64 + 129 - 108 + 49) >= 0)
        return (0x68 ^ 0x49 ^ 0x32 ^ 0x44) & (0x18 ^ 0x79 ^ 0x50 ^ 0x66 ^ -" ".length()); 
    } else {
    
    } 
    return llllllIIlI[1];
  }
  
  static {
    lllIlIIlIIll();
    lllIlIIlIIlI();
    lIIIlIIlIII();
  }
  
  private static void lllIlIIlIIlI() {
    llllllIIIl = new String[llllllIIlI[21]];
    llllllIIIl[llllllIIlI[1]] = lllIlIIlIIIl("69AEK0i8slE=", "rskis");
    llllllIIIl[llllllIIlI[0]] = lllIlIIlIIIl("N0X1m4owDFo=", "pfUOu");
    llllllIIIl[llllllIIlI[2]] = lllIlIIlIIIl("XVne8uijDwY=", "vJpTN");
    llllllIIIl[llllllIIlI[3]] = lllIlIIlIIIl("v8veucmoZiI=", "qKrQX");
    llllllIIIl[llllllIIlI[19]] = lllIlIIlIIIl("A+D/Ky3VBlI=", "wwCZa");
    llllllIIIl[llllllIIlI[20]] = lllIlIIlIIIl("07E7DlEVt9Y=", "kKFlA");
  }
  
  public void execute(byte llllllllllllllllIllIIllIllIIIIII, int llllllllllllllllIllIIllIllIIIIIl) {
    // Byte code:
    //   0: new java/util/concurrent/atomic/AtomicInteger
    //   3: dup
    //   4: aload_2
    //   5: invokevirtual getArenaTask : ()Lcom/axeelheaven/hbedwars/arena/task/ArenaTask;
    //   8: invokevirtual getEndSeconds : ()I
    //   11: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceVulcan.lIllIIlll : [I
    //   14: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceVulcan.llllllIIlI : [I
    //   17: iconst_1
    //   18: iaload
    //   19: iaload
    //   20: imul
    //   21: invokespecial <init> : (I)V
    //   24: astore_3
    //   25: aload_1
    //   26: invokeinterface getWorld : ()Lorg/bukkit/World;
    //   31: astore #4
    //   33: aload_0
    //   34: getfield runnable : Ljava/util/HashMap;
    //   37: aload_1
    //   38: aload_0
    //   39: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   42: invokevirtual getServer : ()Lorg/bukkit/Server;
    //   45: invokeinterface getScheduler : ()Lorg/bukkit/scheduler/BukkitScheduler;
    //   50: aload_0
    //   51: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   54: aload_0
    //   55: aload_3
    //   56: aload_1
    //   57: aload_2
    //   58: aload #4
    //   60: <illegal opcode> run : (Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceVulcan;Ljava/util/concurrent/atomic/AtomicInteger;Lorg/bukkit/entity/Player;Lcom/axeelheaven/hbedwars/api/arena/Arena;Lorg/bukkit/World;)Ljava/lang/Runnable;
    //   65: ldc2_w 3
    //   68: ldc2_w 3
    //   71: invokeinterface scheduleSyncRepeatingTask : (Lorg/bukkit/plugin/Plugin;Ljava/lang/Runnable;JJ)I
    //   76: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   79: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   82: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceVulcan.llllllIIIl : [Ljava/lang/String;
    //   85: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceVulcan.llllllIIlI : [I
    //   88: bipush #20
    //   90: iaload
    //   91: aaload
    //   92: invokevirtual length : ()I
    //   95: pop2
    //   96: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	97	2	llllllllllllllllIllIIllIlIllllII	I
    //   33	64	4	llllllllllllllllIllIIllIllIIIllI	Lorg/bukkit/World;
    //   0	97	3	llllllllllllllllIllIIllIllIIIIll	Ljava/lang/String;
    //   0	97	0	llllllllllllllllIllIIllIlIllllll	S
    //   25	72	3	llllllllllllllllIllIIllIllIIIIlI	Ljava/util/concurrent/atomic/AtomicInteger;
    //   0	97	0	llllllllllllllllIllIIllIlIlllllI	S
    //   0	97	1	llllllllllllllllIllIIllIlIllllIl	I
    //   0	97	4	llllllllllllllllIllIIllIlIlllIlI	S
    //   0	97	1	llllllllllllllllIllIIllIllIIIIII	B
    //   0	97	4	llllllllllllllllIllIIllIllIIIlIl	J
    //   0	97	3	llllllllllllllllIllIIllIlIlllIll	J
    //   0	97	2	llllllllllllllllIllIIllIllIIIIIl	I
    //   0	97	0	llllllllllllllllIllIIllIllIIIlII	Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceVulcan;
    //   0	97	1	llllllllllllllllIllIIllIllIIIlll	Lorg/bukkit/entity/Player;
    //   0	97	2	llllllllllllllllIllIIllIllIIlIII	Lcom/axeelheaven/hbedwars/api/arena/Arena;
  }
  
  private static boolean lIIIlIIlIIl(Exception llllllllllllllllIllIIllIllIlIIII, byte llllllllllllllllIllIIllIllIlIIIl) {
    if (lllIlIIlIllI(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (-" ".length() >= "  ".length())
        return (0x57 ^ 0x7E) & (0xD ^ 0x24 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llllllIIlI[1];
  }
  
  private static void lllIlIIlIIll() {
    llllllIIlI = new int[23];
    llllllIIlI[0] = " ".length();
    llllllIIlI[1] = "  ".length() & ("  ".length() ^ -" ".length());
    llllllIIlI[2] = "  ".length();
    llllllIIlI[3] = "   ".length();
    llllllIIlI[4] = 0x77 ^ 0x38 ^ 0xFD ^ 0x80;
    llllllIIlI[5] = 0x7B ^ 0x8;
    llllllIIlI[6] = 111 + 74 - 125 + 90 + (0xD3 ^ 0x80) - 18 + 103 - 34 + 53 + (0x45 ^ 0x2B);
    llllllIIlI[7] = (0x85 ^ 0x92) + (0x9E ^ 0x89) - -(0x72 ^ 0x27) + (0x36 ^ 0x3F);
    llllllIIlI[8] = 139 + 111 - 199 + 98 + (0x6B ^ 0x53) - 192 + 179 - 172 + 2 + 61 + 98 - -8 + 4;
    llllllIIlI[9] = 166 + 55 - 160 + 108;
    llllllIIlI[10] = (0xA9 ^ 0xC4) + (0xB0 ^ 0x8D) - (0x58 ^ 0x5D) + (0x40 ^ 0x65);
    llllllIIlI[11] = 63 + 139 - 43 + 90 ^ 93 + 136 - 77 + 44;
    llllllIIlI[12] = 0x86 ^ 0xB6;
    llllllIIlI[13] = 0x12 ^ 0xB ^ 0x52 ^ 0x6B;
    llllllIIlI[14] = -(0x17 ^ 0x2D);
    llllllIIlI[15] = 0x86 ^ 0x91 ^ 0xDA ^ 0xC2;
    llllllIIlI[16] = 0xC ^ 0x4C;
    llllllIIlI[17] = 109 + 103 - 142 + 148 + 187 + 75 - 54 + 7 - (0xFFFF85FF & 0x7B7B) + 121 + 90 - 183 + 155;
    llllllIIlI[18] = (0xEE ^ 0x80) + (0xC2 ^ 0x9E) - (0x35 ^ 0x28) + (0x74 ^ 0x61);
    llllllIIlI[19] = 0x5A ^ 0x24 ^ 0xFB ^ 0x81;
    llllllIIlI[20] = 0x2 ^ 0x7;
    llllllIIlI[21] = 0x46 ^ 0x9 ^ 0xD ^ 0x44;
    llllllIIlI[22] = "   ".length() ^ 0x3D ^ 0x36;
  }
  
  private static boolean lllIlIIlIlII(double llllllllllllllllIllIIllIlIlIIIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean lllIlIIlIllI(int llllllllllllllllIllIIllIlIlIIlll, byte llllllllllllllllIllIIllIlIlIIllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static String lllIlIIlIIIl(String llllllllllllllllIllIIllIlIlIllll, Exception llllllllllllllllIllIIllIlIlIllII) {
    try {
      SecretKeySpec llllllllllllllllIllIIllIlIllIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIIllIlIlIllII.getBytes(StandardCharsets.UTF_8)), llllllIIlI[22]), "DES");
      Cipher llllllllllllllllIllIIllIlIllIIIl = Cipher.getInstance("DES");
      llllllllllllllllIllIIllIlIllIIIl.init(llllllIIlI[2], llllllllllllllllIllIIllIlIllIIlI);
      return new String(llllllllllllllllIllIIllIlIllIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIIllIlIlIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception llllllllllllllllIllIIllIlIllIIII) {
      llllllllllllllllIllIIllIlIllIIII.printStackTrace();
      return null;
    } 
  }
  
  public WinDanceVulcan(int llllllllllllllllIllIIllIllllIIlI, String llllllllllllllllIllIIllIllllIlll, int llllllllllllllllIllIIllIlllllIII, Exception llllllllllllllllIllIIllIlllIllll) {
    super(llllllllllllllllIllIIllIllllIlll, llllllllllllllllIllIIllIlllllIII, llllllllllllllllIllIIllIlllIllll);
    this.plugin = llllllllllllllllIllIIllIllllIIlI;
    this.runnable = new HashMap<>();
  }
  
  private double random() {
    return -0.7D + ThreadLocalRandom.current().nextDouble();
  }
  
  private static boolean lllIlIIlIlll(boolean llllllllllllllllIllIIllIlIlIIIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\windances\WinDanceVulcan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */