package com.axeelheaven.hbedwars.cosmetics.killeffects;

import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.entity.Player;

public abstract class KillEffect {
    protected final BedWars plugin;
    
    public KillEffect(BedWars plugin) {
        this.plugin = plugin;
    }
    
    public abstract void play(Player killer, Player victim);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\killeffects\KillEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */