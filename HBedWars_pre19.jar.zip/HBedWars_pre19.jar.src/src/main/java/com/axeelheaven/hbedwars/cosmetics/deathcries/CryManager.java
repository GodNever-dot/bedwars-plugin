package com.axeelheaven.hbedwars.cosmetics.deathcries;

import java.util.HashMap;
import java.util.Map;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.database.HData;

public class CryManager {
    private final BedWars plugin;
    private final Map<String, DeathCry> cries;
    
    public CryManager(BedWars plugin) {
        this.plugin = plugin;
        this.cries = new HashMap<>();
        reload();
    }
    
    public void registerCry(String name, DeathCry cry) {
        this.cries.put(name, cry);
    }
    
    public DeathCry getCry(String name) {
        return this.cries.get(name);
    }
    
    public Map<String, DeathCry> getCries() {
        return this.cries;
    }
    
    public void reload() {
        this.cries.clear();
        registerDefaultCries();
    }
    
    private void registerDefaultCries() {
        registerCry("default", new DeathCry("Default", 0, false) {
            @Override
            public void play(Player player) {
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_DEATH, 1.0F, 1.0F);
            }
        });
    }
    
    public DeathCry getPlayerCry(Player player) {
        HData data = plugin.getPlayerData(player);
        String cryName = data.getSelectedDeathCry();
        DeathCry cry = getCry(cryName);
        return cry != null ? cry : getCry("default");
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\deathcries\CryManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */