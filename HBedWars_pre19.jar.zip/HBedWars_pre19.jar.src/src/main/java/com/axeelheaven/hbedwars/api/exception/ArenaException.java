package com.axeelheaven.hbedwars.api.exception;

public class ArenaException extends Exception {
  public ArenaException(long lllllllllllllllllIlIlIIlIlIlIIIl) {
    super(lllllllllllllllllIlIlIIlIlIlIIIl);
  }
  
  public ArenaException(int lllllllllllllllllIlIlIIlIlIIIllI, String lllllllllllllllllIlIlIIlIlIIlIlI) {
    super(lllllllllllllllllIlIlIIlIlIIIllI, (Throwable)lllllllllllllllllIlIlIIlIlIIlIlI);
  }
  
  static {
  
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\exception\ArenaException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */