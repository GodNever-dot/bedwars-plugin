package com.axeelheaven.hbedwars.database.economy.types;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.database.economy.Economy;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public class EconomyVault implements Economy {
  private static String lIIlIllllllll(boolean lllllllllllllllIlllllIlIIIIIlIII, double lllllllllllllllIlllllIlIIIIIIllI) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   40: iconst_0
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   58: iconst_0
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic lIIllIIlllIIl : (II)Z
    //   69: ifeq -> 140
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: bipush #28
    //   114: bipush #115
    //   116: iadd
    //   117: bipush #-4
    //   119: isub
    //   120: bipush #52
    //   122: iadd
    //   123: bipush #18
    //   125: bipush #66
    //   127: iadd
    //   128: bipush #-35
    //   130: isub
    //   131: bipush #75
    //   133: iadd
    //   134: ixor
    //   135: ifne -> 62
    //   138: aconst_null
    //   139: areturn
    //   140: aload_2
    //   141: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   144: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   44	101	4	lllllllllllllllIlllllIlIIIIIlIlI	I
    //   32	113	2	lllllllllllllllIlllllIlIIIIIllIl	Ljava/lang/StringBuilder;
    //   0	145	8	lllllllllllllllIlllllIIllllllIIl	B
    //   0	145	1	lllllllllllllllIlllllIlIIIIIllll	Ljava/lang/String;
    //   79	24	8	lllllllllllllllIlllllIlIIIIlIIlI	C
    //   0	145	1	lllllllllllllllIlllllIlIIIIIIllI	D
    //   0	145	7	lllllllllllllllIlllllIIllllllIlI	J
    //   0	145	0	lllllllllllllllIlllllIlIIIIlIIIl	Ljava/lang/String;
    //   0	145	5	lllllllllllllllIlllllIIllllllllI	J
    //   37	108	3	lllllllllllllllIlllllIlIIIIIlIll	[C
    //   0	145	4	lllllllllllllllIlllllIlIIIIIIIII	I
    //   0	145	0	lllllllllllllllIlllllIlIIIIIlIII	Z
    //   0	145	2	lllllllllllllllIlllllIlIIIIIIlII	Ljava/lang/String;
    //   0	145	3	lllllllllllllllIlllllIlIIIIIIIlI	Z
    //   0	145	6	lllllllllllllllIlllllIIlllllllII	I
  }
  
  private static String lIIllIIIIIlIl(boolean lllllllllllllllIlllllIIlllIlllIl, float lllllllllllllllIlllllIIlllIllIlI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   22: bipush #8
    //   24: iaload
    //   25: invokestatic copyOf : ([BI)[B
    //   28: ldc 'DES'
    //   30: invokespecial <init> : ([BLjava/lang/String;)V
    //   33: astore_2
    //   34: ldc 'DES'
    //   36: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   39: astore_3
    //   40: aload_3
    //   41: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   44: iconst_2
    //   45: iaload
    //   46: aload_2
    //   47: invokevirtual init : (ILjava/security/Key;)V
    //   50: new java/lang/String
    //   53: dup
    //   54: aload_3
    //   55: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   58: aload_0
    //   59: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   62: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   65: invokevirtual decode : ([B)[B
    //   68: invokevirtual doFinal : ([B)[B
    //   71: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   74: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   77: areturn
    //   78: astore_2
    //   79: aload_2
    //   80: invokevirtual printStackTrace : ()V
    //   83: aconst_null
    //   84: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	85	3	lllllllllllllllIlllllIIlllIlIlIl	B
    //   79	4	2	lllllllllllllllIlllllIIllllIIllI	Ljava/lang/Exception;
    //   0	85	1	lllllllllllllllIlllllIIllllIIIII	Ljava/lang/String;
    //   34	44	2	lllllllllllllllIlllllIIllllIlIll	Ljavax/crypto/spec/SecretKeySpec;
    //   0	85	0	lllllllllllllllIlllllIIllllIIIll	Ljava/lang/String;
    //   40	38	3	lllllllllllllllIlllllIIllllIlIIl	Ljavax/crypto/Cipher;
    //   0	85	0	lllllllllllllllIlllllIIlllIlllIl	Z
    //   0	85	2	lllllllllllllllIlllllIIlllIllIII	D
    //   0	85	1	lllllllllllllllIlllllIIlllIllIlI	F
    // Exception table:
    //   from	to	target	type
    //   0	77	78	java/lang/Exception
  }
  
  public void addPoints(Player lllllllllllllllIlllllIlIIIllllll, long lllllllllllllllIlllllIlIIIllIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: getfield economy : Lnet/milkbowl/vault/economy/Economy;
    //   4: aload_1
    //   5: dload_2
    //   6: invokeinterface depositPlayer : (Lorg/bukkit/OfflinePlayer;D)Lnet/milkbowl/vault/economy/EconomyResponse;
    //   11: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllIlI : [Ljava/lang/String;
    //   14: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   17: bipush #6
    //   19: iaload
    //   20: aaload
    //   21: invokevirtual length : ()I
    //   24: pop2
    //   25: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	26	0	lllllllllllllllIlllllIlIIlIIIlll	Lcom/axeelheaven/hbedwars/database/economy/types/EconomyVault;
    //   0	26	0	lllllllllllllllIlllllIlIIIlllIll	S
    //   0	26	1	lllllllllllllllIlllllIlIIIllIlll	I
    //   0	26	2	lllllllllllllllIlllllIlIIlIIIIIl	I
    //   0	26	1	lllllllllllllllIlllllIlIIIllllll	Lorg/bukkit/entity/Player;
    //   0	26	2	lllllllllllllllIlllllIlIIIllIlIl	J
    //   0	26	2	lllllllllllllllIlllllIlIIlIIIlII	D
    //   0	26	0	lllllllllllllllIlllllIlIIIlllIII	Ljava/lang/String;
    //   0	26	1	lllllllllllllllIlllllIlIIIllllIl	F
  }
  
  private static String lIIlIlllIllII(short lllllllllllllllIlllllIIllIlllIII, Exception lllllllllllllllIlllllIIllIllIllI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc 'Blowfish'
    //   21: invokespecial <init> : ([BLjava/lang/String;)V
    //   24: astore_2
    //   25: ldc 'Blowfish'
    //   27: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   30: astore_3
    //   31: aload_3
    //   32: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   35: iconst_2
    //   36: iaload
    //   37: aload_2
    //   38: invokevirtual init : (ILjava/security/Key;)V
    //   41: new java/lang/String
    //   44: dup
    //   45: aload_3
    //   46: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   49: aload_0
    //   50: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   53: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   56: invokevirtual decode : ([B)[B
    //   59: invokevirtual doFinal : ([B)[B
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   68: areturn
    //   69: astore_2
    //   70: aload_2
    //   71: invokevirtual printStackTrace : ()V
    //   74: aconst_null
    //   75: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	76	0	lllllllllllllllIlllllIIllIllllII	Ljava/lang/String;
    //   0	76	1	lllllllllllllllIlllllIIllIlllIlI	Ljava/lang/String;
    //   0	76	3	lllllllllllllllIlllllIIllIllIIlI	Ljava/lang/Exception;
    //   70	4	2	lllllllllllllllIlllllIIllIlllllI	Ljava/lang/Exception;
    //   0	76	1	lllllllllllllllIlllllIIllIllIllI	Ljava/lang/Exception;
    //   25	44	2	lllllllllllllllIlllllIIlllIIIIlI	Ljavax/crypto/spec/SecretKeySpec;
    //   0	76	2	lllllllllllllllIlllllIIllIllIlII	S
    //   31	38	3	lllllllllllllllIlllllIIlllIIIIII	Ljavax/crypto/Cipher;
    //   0	76	0	lllllllllllllllIlllllIIllIlllIII	S
    // Exception table:
    //   from	to	target	type
    //   0	68	69	java/lang/Exception
  }
  
  public void setPoints(float lllllllllllllllIlllllIlIIlllIIlI, long lllllllllllllllIlllllIlIIlllIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: getfield economy : Lnet/milkbowl/vault/economy/Economy;
    //   4: aload_1
    //   5: aload_0
    //   6: getfield economy : Lnet/milkbowl/vault/economy/Economy;
    //   9: aload_1
    //   10: invokeinterface getBalance : (Lorg/bukkit/OfflinePlayer;)D
    //   15: invokeinterface withdrawPlayer : (Lorg/bukkit/OfflinePlayer;D)Lnet/milkbowl/vault/economy/EconomyResponse;
    //   20: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllIlI : [Ljava/lang/String;
    //   23: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   26: iconst_4
    //   27: iaload
    //   28: aaload
    //   29: invokevirtual length : ()I
    //   32: pop2
    //   33: aload_0
    //   34: getfield economy : Lnet/milkbowl/vault/economy/Economy;
    //   37: aload_1
    //   38: dload_2
    //   39: invokeinterface depositPlayer : (Lorg/bukkit/OfflinePlayer;D)Lnet/milkbowl/vault/economy/EconomyResponse;
    //   44: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllIlI : [Ljava/lang/String;
    //   47: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   50: iconst_5
    //   51: iaload
    //   52: aaload
    //   53: invokevirtual length : ()I
    //   56: pop2
    //   57: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	58	2	lllllllllllllllIlllllIlIIllIIlll	B
    //   0	58	2	lllllllllllllllIlllllIlIIlllIIIl	J
    //   0	58	2	lllllllllllllllIlllllIlIIllIlllI	D
    //   0	58	0	lllllllllllllllIlllllIlIIllIllIl	Lcom/axeelheaven/hbedwars/database/economy/types/EconomyVault;
    //   0	58	1	lllllllllllllllIlllllIlIIlllIIII	Lorg/bukkit/entity/Player;
    //   0	58	1	lllllllllllllllIlllllIlIIlllIIlI	F
    //   0	58	1	lllllllllllllllIlllllIlIIllIlIII	S
    //   0	58	0	lllllllllllllllIlllllIlIIllIlIIl	D
    //   0	58	0	lllllllllllllllIlllllIlIIllIlIll	Ljava/lang/Exception;
  }
  
  private static void lllIIlIIlll() {
    lIIIllIlII = new String[lIIIllIlIl[lIIlIlllllI[1]]];
    lIIIllIlII[lIIIllIlIl[lIIlIlllllI[0]]] = lllIIlIIllI(lIIlIlllIlI[lIIlIlllllI[7]], lIIlIlllIlI[lIIlIlllllI[8]]);
  }
  
  public EconomyVault(BedWars lllllllllllllllIlllllIlIlIlllIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: invokevirtual getServer : ()Lorg/bukkit/Server;
    //   9: invokeinterface getServicesManager : ()Lorg/bukkit/plugin/ServicesManager;
    //   14: ldc net/milkbowl/vault/economy/Economy
    //   16: invokeinterface getRegistration : (Ljava/lang/Class;)Lorg/bukkit/plugin/RegisteredServiceProvider;
    //   21: invokevirtual getProvider : ()Ljava/lang/Object;
    //   24: checkcast net/milkbowl/vault/economy/Economy
    //   27: putfield economy : Lnet/milkbowl/vault/economy/Economy;
    //   30: aload_1
    //   31: invokevirtual getLogger : ()Ljava/util/logging/Logger;
    //   34: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIIllIlII : [Ljava/lang/String;
    //   37: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIIllIlIl : [I
    //   40: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   43: iconst_0
    //   44: iaload
    //   45: iaload
    //   46: aaload
    //   47: invokevirtual info : (Ljava/lang/String;)V
    //   50: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	51	1	lllllllllllllllIlllllIlIlIllllII	C
    //   0	51	0	lllllllllllllllIlllllIlIlIllIllI	I
    //   0	51	1	lllllllllllllllIlllllIlIlIlllIIl	Lcom/axeelheaven/hbedwars/BedWars;
    //   0	51	1	lllllllllllllllIlllllIlIlIllIlII	Ljava/lang/String;
    //   0	51	0	lllllllllllllllIlllllIlIlIlllIll	S
    //   0	51	0	lllllllllllllllIlllllIlIlIllIlll	Lcom/axeelheaven/hbedwars/database/economy/types/EconomyVault;
  }
  
  private static void lIIllIIllIlll() {
    lIIlIlllllI = new int[16];
    lIIlIlllllI[0] = (0x27 ^ 0x6E) & (0xE5 ^ 0xAC ^ 0xFFFFFFFF);
    lIIlIlllllI[1] = " ".length();
    lIIlIlllllI[2] = "  ".length();
    lIIlIlllllI[3] = "   ".length();
    lIIlIlllllI[4] = 0xC2 ^ 0xC6;
    lIIlIlllllI[5] = 1 + 121 - 93 + 120 ^ 54 + 96 - 92 + 86;
    lIIlIlllllI[6] = 0xA ^ 0x13 ^ 0x7E ^ 0x61;
    lIIlIlllllI[7] = 0x89 ^ 0x8E;
    lIIlIlllllI[8] = 0x89 ^ 0x81;
    lIIlIlllllI[9] = 0x5C ^ 0x10;
    lIIlIlllllI[10] = (0x60 ^ 0x58) + (0xA2 ^ 0x84) - (0xEE ^ 0xBA) + 118 + 45 - -31 + 5;
    lIIlIlllllI[11] = 96 + 11 - 60 + 102;
    lIIlIlllllI[12] = -" ".length();
    lIIlIlllllI[13] = 8 + 115 - 39 + 122 ^ 42 + 120 - 82 + 119;
    lIIlIlllllI[14] = 0x76 ^ 0x7C;
    lIIlIlllllI[15] = 0x69 ^ 0x62;
  }
  
  private static void lIIllIIIIllll() {
    lIIlIlllIlI = new String[lIIlIlllllI[15]];
    lIIlIlllIlI[lIIlIlllllI[0]] = lIIlIlllIllII("slf58Im2unQ=", "ApUGd");
    lIIlIlllIlI[lIIlIlllllI[1]] = lIIlIllllllll("ISACOQcKPwU=", "cLmNa");
    lIIlIlllIlI[lIIlIlllllI[2]] = lIIlIlllIllII("zfXZkJgo5mArHl8dtUNzOA==", "Budvx");
    lIIlIlllIlI[lIIlIlllllI[3]] = lIIllIIIIIlIl("na2xSE21wKY=", "cFfix");
    lIIlIlllIlI[lIIlIlllllI[4]] = lIIlIllllllll("", "oyjhq");
    lIIlIlllIlI[lIIlIlllllI[5]] = lIIlIlllIllII("2PnSBTIrtJ4=", "OTOiP");
    lIIlIlllIlI[lIIlIlllllI[6]] = lIIlIlllIllII("EVtfSK7Ry84=", "IhJQa");
    lIIlIlllIlI[lIIlIlllllI[7]] = lIIlIllllllll("Gz4JLh86AS4wZn46OwMTeyQgOR8JFRpPLik+Ox0qH0EIDgwFIx8MKyhFNUs=", "KwxvI");
    lIIlIlllIlI[lIIlIlllllI[8]] = lIIlIllllllll("KRoxHSw=", "aXYSD");
    lIIlIlllIlI[lIIlIlllllI[13]] = lIIlIllllllll("ZA==", "Dxlfj");
    lIIlIlllIlI[lIIlIlllllI[14]] = lIIlIlllIllII("W/CVAJ2JgFw=", "HPbSd");
  }
  
  static {
    lIIllIIllIlll();
    lIIllIIIIllll();
    lllIIlIlIII();
    lllIIlIIlll();
  }
  
  private static boolean lIIllIIlllIIl(byte lllllllllllllllIlllllIIllIIlllll, double lllllllllllllllIlllllIIllIIllllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public double getPoints(Player lllllllllllllllIlllllIlIIlIlllll) {
    return ((EconomyVault)super).economy.getBalance((OfflinePlayer)lllllllllllllllIlllllIlIIlIlllll);
  }
  
  public void removePoints(short lllllllllllllllIlllllIlIlIIIIllI, double lllllllllllllllIlllllIlIlIIIIIII) {
    // Byte code:
    //   0: aload_0
    //   1: getfield economy : Lnet/milkbowl/vault/economy/Economy;
    //   4: aload_1
    //   5: dload_2
    //   6: invokeinterface withdrawPlayer : (Lorg/bukkit/OfflinePlayer;D)Lnet/milkbowl/vault/economy/EconomyResponse;
    //   11: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllIlI : [Ljava/lang/String;
    //   14: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   17: iconst_3
    //   18: iaload
    //   19: aaload
    //   20: invokevirtual length : ()I
    //   23: pop2
    //   24: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	25	2	lllllllllllllllIlllllIlIIllllIlI	I
    //   0	25	0	lllllllllllllllIlllllIlIlIIIIIlI	Lcom/axeelheaven/hbedwars/database/economy/types/EconomyVault;
    //   0	25	0	lllllllllllllllIlllllIlIlIIIIlII	I
    //   0	25	2	lllllllllllllllIlllllIlIlIIIIIII	D
    //   0	25	2	lllllllllllllllIlllllIlIlIIIlIlI	J
    //   0	25	1	lllllllllllllllIlllllIlIlIIIlIII	Lorg/bukkit/entity/Player;
    //   0	25	1	lllllllllllllllIlllllIlIlIIIIllI	S
    //   0	25	0	lllllllllllllllIlllllIlIIllllllI	S
    //   0	25	1	lllllllllllllllIlllllIlIIlllllII	I
  }
  
  private static String lllIIlIIllI(String lllllllllllllllIlllllIlIlIIllIll, boolean lllllllllllllllIlllllIlIlIIlllll) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllIlI : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   10: iconst_0
    //   11: iaload
    //   12: aaload
    //   13: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   16: aload_1
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   23: invokevirtual digest : ([B)[B
    //   26: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllIlI : [Ljava/lang/String;
    //   29: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   32: iconst_1
    //   33: iaload
    //   34: aaload
    //   35: invokespecial <init> : ([BLjava/lang/String;)V
    //   38: astore_2
    //   39: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllIlI : [Ljava/lang/String;
    //   42: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   45: iconst_2
    //   46: iaload
    //   47: aaload
    //   48: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   51: astore_3
    //   52: aload_3
    //   53: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIIllIlIl : [I
    //   56: getstatic com/axeelheaven/hbedwars/database/economy/types/EconomyVault.lIIlIlllllI : [I
    //   59: iconst_2
    //   60: iaload
    //   61: iaload
    //   62: aload_2
    //   63: invokevirtual init : (ILjava/security/Key;)V
    //   66: new java/lang/String
    //   69: dup
    //   70: aload_3
    //   71: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   74: aload_0
    //   75: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   78: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   81: invokevirtual decode : ([B)[B
    //   84: invokevirtual doFinal : ([B)[B
    //   87: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   90: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   93: areturn
    //   94: astore_2
    //   95: aload_2
    //   96: invokevirtual printStackTrace : ()V
    //   99: aconst_null
    //   100: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	101	3	lllllllllllllllIlllllIlIlIIlIlII	C
    //   0	101	3	lllllllllllllllIlllllIlIlIlIIIlI	C
    //   0	101	1	lllllllllllllllIlllllIlIlIlIIlIl	Ljava/lang/String;
    //   39	55	2	lllllllllllllllIlllllIlIlIlIIllI	Ljavax/crypto/spec/SecretKeySpec;
    //   0	101	2	lllllllllllllllIlllllIlIlIlIIIIl	Ljava/lang/String;
    //   0	101	0	lllllllllllllllIlllllIlIlIIllIlI	S
    //   0	101	0	lllllllllllllllIlllllIlIlIIllIll	Ljava/lang/String;
    //   52	42	3	lllllllllllllllIlllllIlIlIlIIIll	Ljavax/crypto/Cipher;
    //   0	101	2	lllllllllllllllIlllllIlIlIIlIllI	Ljava/lang/Exception;
    //   0	101	0	lllllllllllllllIlllllIlIlIlIIlII	Ljava/lang/String;
    //   0	101	1	lllllllllllllllIlllllIlIlIIlllll	Z
    //   95	4	2	lllllllllllllllIlllllIlIlIIlllIl	Ljava/lang/Exception;
    //   0	101	1	lllllllllllllllIlllllIlIlIIllIII	J
    // Exception table:
    //   from	to	target	type
    //   0	93	94	java/lang/Exception
  }
  
  private static void lllIIlIlIII() {
    lIIIllIlIl = new int[lIIlIlllllI[3]];
    lIIIllIlIl[lIIlIlllllI[0]] = (lIIlIlllllI[8] ^ lIIlIlllllI[9]) & (lIIlIlllllI[10] ^ lIIlIlllllI[11] ^ lIIlIlllllI[12]);
    lIIIllIlIl[lIIlIlllllI[1]] = lIIlIlllIlI[lIIlIlllllI[13]].length();
    lIIIllIlIl[lIIlIlllllI[2]] = lIIlIlllIlI[lIIlIlllllI[14]].length();
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\database\economy\types\EconomyVault.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */