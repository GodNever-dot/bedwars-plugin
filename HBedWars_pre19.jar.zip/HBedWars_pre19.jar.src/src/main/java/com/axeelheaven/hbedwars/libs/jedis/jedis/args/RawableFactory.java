/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.args;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ 
/*    */ public final class RawableFactory
/*    */ {
/*    */   public static Rawable from(int i) {
/*  9 */     return from(Protocol.toByteArray(i));
/*    */   }
/*    */   
/*    */   public static Rawable from(double d) {
/* 13 */     return from(Protocol.toByteArray(d));
/*    */   }
/*    */   
/*    */   public static Rawable from(byte[] binary) {
/* 17 */     return new Raw(binary);
/*    */   }
/*    */   
/*    */   public static Rawable from(String string) {
/* 21 */     return new RawString(string);
/*    */   }
/*    */   
/*    */   public static class Raw
/*    */     implements Rawable {
/*    */     private final byte[] raw;
/*    */     
/*    */     public Raw(byte[] raw) {
/* 29 */       this.raw = raw;
/*    */     }
/*    */ 
/*    */     
/*    */     public byte[] getRaw() {
/* 34 */       return this.raw;
/*    */     }
/*    */   }
/*    */   
/*    */   public static class RawString
/*    */     extends Raw {
/*    */     public RawString(String str) {
/* 41 */       super(SafeEncoder.encode(str));
/*    */     }
/*    */   }
/*    */   
/*    */   private RawableFactory() {
/* 46 */     throw new InstantiationError();
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\args\RawableFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */