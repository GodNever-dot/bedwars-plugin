package com.axeelheaven.hbedwars.cosmetics.deathcries;

import org.bukkit.entity.Player;

public abstract class DeathCry {
    private final String name;
    private final int cost;
    private final boolean purchasable;
    private final String id;
    
    public DeathCry(String name, int cost, boolean purchasable) {
        this.name = name;
        this.cost = cost;
        this.purchasable = purchasable;
        this.id = name.toLowerCase().replace(" ", "_");
    }
    
    public String getName() {
        return name;
    }
    
    public int getCost() {
        return cost;
    }
    
    public boolean isPurchasable() {
        return purchasable;
    }
    
    public String getId() {
        return id;
    }
    
    public abstract void play(Player player);
} 