package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.AccessControlLogEntry;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.AccessControlUser;
import java.util.List;

public interface AccessControlLogCommands {
  String aclWhoAmI();
  
  String aclGenPass();
  
  String aclGenPass(int paramInt);
  
  List<String> aclList();
  
  List<String> aclUsers();
  
  AccessControlUser aclGetUser(String paramString);
  
  String aclSetUser(String paramString);
  
  String aclSetUser(String paramString, String... paramVarArgs);
  
  long aclDelUser(String paramString);
  
  long aclDelUser(String paramString, String... paramVarArgs);
  
  List<String> aclCat();
  
  List<String> aclCat(String paramString);
  
  List<AccessControlLogEntry> aclLog();
  
  List<AccessControlLogEntry> aclLog(int paramInt);
  
  String aclLogReset();
  
  String aclLoad();
  
  String aclSave();
  
  String aclDryRun(String paramString1, String paramString2, String... paramVarArgs);
  
  String aclDryRun(String paramString, CommandArguments paramCommandArguments);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\AccessControlLogCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */