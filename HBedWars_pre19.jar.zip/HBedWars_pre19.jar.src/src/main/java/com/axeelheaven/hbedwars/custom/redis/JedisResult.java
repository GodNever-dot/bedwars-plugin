package com.axeelheaven.hbedwars.custom.redis;

public interface JedisResult {
    void onSuccess();
    void onFailure(Exception e);
} 