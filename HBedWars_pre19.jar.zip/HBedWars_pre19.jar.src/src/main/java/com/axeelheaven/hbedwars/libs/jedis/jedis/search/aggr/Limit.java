/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.search.aggr;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Limit
/*    */ {
/* 12 */   public static final Limit NO_LIMIT = new Limit(0, 0);
/*    */   
/*    */   private final int offset;
/*    */   private final int count;
/*    */   
/*    */   public Limit(int offset, int count) {
/* 18 */     this.offset = offset;
/* 19 */     this.count = count;
/*    */   }
/*    */   
/*    */   public void addArgs(List<String> args) {
/* 23 */     if (this.count == 0) {
/*    */       return;
/*    */     }
/* 26 */     args.add("LIMIT");
/* 27 */     args.add(Integer.toString(this.offset));
/* 28 */     args.add(Integer.toString(this.count));
/*    */   }
/*    */   
/*    */   public List<String> getArgs() {
/* 32 */     if (this.count == 0) {
/* 33 */       return Collections.emptyList();
/*    */     }
/* 35 */     List<String> ll = new ArrayList<>(3);
/* 36 */     addArgs(ll);
/* 37 */     return ll;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\search\aggr\Limit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */