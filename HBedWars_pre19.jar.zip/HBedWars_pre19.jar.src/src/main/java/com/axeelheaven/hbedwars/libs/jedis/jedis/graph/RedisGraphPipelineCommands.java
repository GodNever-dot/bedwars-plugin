package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import java.util.Map;

public interface RedisGraphPipelineCommands {
  Response<ResultSet> graphQuery(String paramString1, String paramString2);
  
  Response<ResultSet> graphReadonlyQuery(String paramString1, String paramString2);
  
  Response<ResultSet> graphQuery(String paramString1, String paramString2, long paramLong);
  
  Response<ResultSet> graphReadonlyQuery(String paramString1, String paramString2, long paramLong);
  
  Response<ResultSet> graphQuery(String paramString1, String paramString2, Map<String, Object> paramMap);
  
  Response<ResultSet> graphReadonlyQuery(String paramString1, String paramString2, Map<String, Object> paramMap);
  
  Response<ResultSet> graphQuery(String paramString1, String paramString2, Map<String, Object> paramMap, long paramLong);
  
  Response<ResultSet> graphReadonlyQuery(String paramString1, String paramString2, Map<String, Object> paramMap, long paramLong);
  
  Response<String> graphDelete(String paramString);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\RedisGraphPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */