/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ public class JedisNoScriptException
/*    */   extends JedisDataException {
/*    */   private static final long serialVersionUID = 4674378093072060731L;
/*    */   
/*    */   public JedisNoScriptException(String message) {
/*  8 */     super(message);
/*    */   }
/*    */   
/*    */   public JedisNoScriptException(Throwable cause) {
/* 12 */     super(cause);
/*    */   }
/*    */   
/*    */   public JedisNoScriptException(String message, Throwable cause) {
/* 16 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\JedisNoScriptException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */