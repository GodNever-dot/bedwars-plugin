/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetParams
/*     */   extends Params
/*     */   implements IParams
/*     */ {
/*     */   private static final String XX = "xx";
/*     */   private static final String NX = "nx";
/*     */   private static final String PX = "px";
/*     */   private static final String EX = "ex";
/*     */   private static final String EXAT = "exat";
/*     */   private static final String PXAT = "pxat";
/*     */   private static final String KEEPTTL = "keepttl";
/*     */   private static final String GET = "get";
/*     */   
/*     */   public static SetParams setParams() {
/*  22 */     return new SetParams();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetParams ex(long secondsToExpire) {
/*  31 */     addParam("ex", Long.valueOf(secondsToExpire));
/*  32 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetParams px(long millisecondsToExpire) {
/*  41 */     addParam("px", Long.valueOf(millisecondsToExpire));
/*  42 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetParams nx() {
/*  50 */     addParam("nx");
/*  51 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetParams xx() {
/*  59 */     addParam("xx");
/*  60 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetParams exAt(long seconds) {
/*  69 */     addParam("exat", Long.valueOf(seconds));
/*  70 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetParams pxAt(long milliseconds) {
/*  79 */     addParam("pxat", Long.valueOf(milliseconds));
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetParams keepttl() {
/*  88 */     addParam("keepttl");
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetParams get() {
/*  97 */     addParam("get");
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addParams(CommandArguments args) {
/* 103 */     if (contains("nx")) {
/* 104 */       args.add(Protocol.Keyword.NX);
/*     */     }
/* 106 */     if (contains("xx")) {
/* 107 */       args.add(Protocol.Keyword.XX);
/*     */     }
/*     */     
/* 110 */     if (contains("ex")) {
/* 111 */       args.add(Protocol.Keyword.EX);
/* 112 */       args.add(Protocol.toByteArray(((Long)getParam("ex")).longValue()));
/*     */     } 
/* 114 */     if (contains("px")) {
/* 115 */       args.add(Protocol.Keyword.PX);
/* 116 */       args.add(Protocol.toByteArray(((Long)getParam("px")).longValue()));
/*     */     } 
/* 118 */     if (contains("exat")) {
/* 119 */       args.add(Protocol.Keyword.EXAT);
/* 120 */       args.add(Protocol.toByteArray(((Long)getParam("exat")).longValue()));
/*     */     } 
/* 122 */     if (contains("pxat")) {
/* 123 */       args.add(Protocol.Keyword.PXAT);
/* 124 */       args.add(Protocol.toByteArray(((Long)getParam("pxat")).longValue()));
/*     */     } 
/* 126 */     if (contains("keepttl")) {
/* 127 */       args.add(Protocol.Keyword.KEEPTTL);
/*     */     }
/*     */     
/* 130 */     if (contains("get"))
/* 131 */       args.add(Protocol.Keyword.GET); 
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\SetParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */