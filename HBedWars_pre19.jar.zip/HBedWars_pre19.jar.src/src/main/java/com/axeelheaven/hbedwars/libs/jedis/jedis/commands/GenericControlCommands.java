package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Module;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.FailoverParams;
import java.util.List;

public interface GenericControlCommands extends ConfigCommands, ScriptingControlCommands, SlowlogCommands {
  String failover();
  
  String failover(FailoverParams paramFailoverParams);
  
  String failoverAbort();
  
  List<Module> moduleList();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\GenericControlCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */