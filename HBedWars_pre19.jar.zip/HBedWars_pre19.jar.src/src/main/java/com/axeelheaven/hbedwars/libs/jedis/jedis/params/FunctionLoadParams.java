/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionLoadParams
/*    */   implements IParams
/*    */ {
/*    */   private boolean replace = false;
/*    */   private String description;
/*    */   
/*    */   public FunctionLoadParams replace() {
/* 18 */     this.replace = true;
/* 19 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FunctionLoadParams libraryDescription(String desc) {
/* 26 */     this.description = desc;
/* 27 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 32 */     if (this.replace) {
/* 33 */       args.add(Protocol.Keyword.REPLACE);
/*    */     }
/*    */     
/* 36 */     if (this.description != null) {
/* 37 */       args.add(Protocol.Keyword.DESCRIPTION);
/* 38 */       args.add(this.description);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\FunctionLoadParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */