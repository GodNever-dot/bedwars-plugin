package com.axeelheaven.hbedwars.custom.version;

import org.bukkit.Location;
import org.bukkit.entity.Player;

public interface VersionSupport {
    void displayParticle(Location location, String particleName, float offsetX, float offsetY, float offsetZ, float speed, int count, double range);
    void sendTitle(Player player, String title, String subtitle, int fadeIn, int stay, int fadeOut);
    void sendActionBar(Player player, String message);
    void sendTabList(Player player, String header, String footer);
} 