package com.axeelheaven.hbedwars.custom.items;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.custom.config.HConfiguration;
import java.util.HashMap;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ItemJoin {
    private final BedWars plugin;
    private final String section;
    private final HashMap<String, String> actions;
    private Material material;
    private byte data;
    private int amount;
    private int slot;
    private Sound sound;
    
    public ItemJoin(BedWars plugin, String section) {
        this.plugin = plugin;
        this.section = section;
        this.actions = new HashMap<>();
        
        HConfiguration config = plugin.getItems();
        config.getStringList(section + ".actions").forEach(action -> {
            String[] parts = action.split(":");
            if (parts[0].equalsIgnoreCase("command")) {
                this.actions.put("command", parts[1]);
            } else if (parts[0].equalsIgnoreCase("message")) {
                this.actions.put("message", parts[1]); 
            }
        });
        
        this.material = Material.valueOf(config.getString(section + ".material"));
        this.data = (byte)config.getInt(section + ".data");
        this.amount = config.getInt(section + ".amount", 1);
        this.slot = config.getInt(section + ".slot");
        
        String soundName = config.getString(section + ".sound");
        if (soundName != null && !soundName.isEmpty()) {
            try {
                this.sound = Sound.valueOf(soundName.toUpperCase());
            } catch (IllegalArgumentException e) {
                // Invalid sound name
            }
        }
    }
    
    public Material getMaterial() {
        return this.material;
    }
    
    public byte getData() {
        return this.data;
    }
    
    public int getAmount() {
        return this.amount;
    }
    
    public int getSlot() {
        return this.slot;
    }
    
    public String getSection() {
        return this.section;
    }
    
    public ItemStack build(Player player) {
        ItemStack item = new ItemStack(this.material, this.amount, this.data);
        // Add meta data if needed
        return item;
    }
    
    public void execute(Player player) {
        if (this.sound != null) {
            player.playSound(player.getLocation(), this.sound, 1.0F, 1.0F);
        }
        
        String cmd = this.actions.get("command");
        if (cmd != null) {
            player.performCommand(cmd);
        }
        
        String msg = this.actions.get("message");
        if (msg != null) {
            player.sendMessage(msg);
        }
    }
    
    private boolean isSound(String name) {
        try {
            Sound.valueOf(name.toUpperCase());
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\items\ItemJoin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */