/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph.entities;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Edge
/*    */   extends GraphEntity
/*    */ {
/*    */   private String relationshipType;
/*    */   private long source;
/*    */   private long destination;
/*    */   
/*    */   public String getRelationshipType() {
/* 23 */     return this.relationshipType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRelationshipType(String relationshipType) {
/* 30 */     this.relationshipType = relationshipType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getSource() {
/* 38 */     return this.source;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSource(long source) {
/* 45 */     this.source = source;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getDestination() {
/* 53 */     return this.destination;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDestination(long destination) {
/* 61 */     this.destination = destination;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 67 */     if (this == o) return true; 
/* 68 */     if (!(o instanceof Edge)) return false; 
/* 69 */     if (!super.equals(o)) return false; 
/* 70 */     Edge edge = (Edge)o;
/* 71 */     return (this.source == edge.source && this.destination == edge.destination && 
/*    */       
/* 73 */       Objects.equals(this.relationshipType, edge.relationshipType));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 78 */     return Objects.hash(new Object[] { Integer.valueOf(super.hashCode()), this.relationshipType, Long.valueOf(this.source), Long.valueOf(this.destination) });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 83 */     StringBuilder sb = new StringBuilder("Edge{");
/* 84 */     sb.append("relationshipType='").append(this.relationshipType).append('\'');
/* 85 */     sb.append(", source=").append(this.source);
/* 86 */     sb.append(", destination=").append(this.destination);
/* 87 */     sb.append(", id=").append(this.id);
/* 88 */     sb.append(", propertyMap=").append(this.propertyMap);
/* 89 */     sb.append('}');
/* 90 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\entities\Edge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */