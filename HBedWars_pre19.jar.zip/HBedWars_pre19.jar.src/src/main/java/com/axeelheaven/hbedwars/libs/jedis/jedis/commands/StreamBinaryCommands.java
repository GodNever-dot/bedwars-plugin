/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XAddParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XAutoClaimParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XClaimParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XTrimParams;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public interface StreamBinaryCommands {
/*    */   default byte[] xadd(byte[] key, Map<byte[], byte[]> hash, XAddParams params) {
/* 11 */     return xadd(key, params, hash);
/*    */   }
/*    */   
/*    */   byte[] xadd(byte[] paramArrayOfbyte, XAddParams paramXAddParams, Map<byte[], byte[]> paramMap);
/*    */   
/*    */   long xlen(byte[] paramArrayOfbyte);
/*    */   
/*    */   List<byte[]> xrange(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
/*    */   
/*    */   List<byte[]> xrange(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, int paramInt);
/*    */   
/*    */   List<byte[]> xrevrange(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
/*    */   
/*    */   List<byte[]> xrevrange(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, int paramInt);
/*    */   
/*    */   long xack(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[]... paramVarArgs);
/*    */   
/*    */   String xgroupCreate(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, boolean paramBoolean);
/*    */   
/*    */   String xgroupSetID(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
/*    */   
/*    */   long xgroupDestroy(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
/*    */   
/*    */   boolean xgroupCreateConsumer(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
/*    */   
/*    */   long xgroupDelConsumer(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
/*    */   
/*    */   long xdel(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
/*    */   
/*    */   long xtrim(byte[] paramArrayOfbyte, long paramLong, boolean paramBoolean);
/*    */   
/*    */   long xtrim(byte[] paramArrayOfbyte, XTrimParams paramXTrimParams);
/*    */   
/*    */   Object xpending(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
/*    */   
/*    */   @Deprecated
/*    */   List<Object> xpending(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4, int paramInt, byte[] paramArrayOfbyte5);
/*    */   
/*    */   List<Object> xpending(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, XPendingParams paramXPendingParams);
/*    */   
/*    */   List<byte[]> xclaim(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, long paramLong, XClaimParams paramXClaimParams, byte[]... paramVarArgs);
/*    */   
/*    */   List<byte[]> xclaimJustId(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, long paramLong, XClaimParams paramXClaimParams, byte[]... paramVarArgs);
/*    */   
/*    */   List<Object> xautoclaim(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, long paramLong, byte[] paramArrayOfbyte4, XAutoClaimParams paramXAutoClaimParams);
/*    */   
/*    */   List<Object> xautoclaimJustId(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, long paramLong, byte[] paramArrayOfbyte4, XAutoClaimParams paramXAutoClaimParams);
/*    */   
/*    */   Object xinfoStream(byte[] paramArrayOfbyte);
/*    */   
/*    */   Object xinfoStreamFull(byte[] paramArrayOfbyte);
/*    */   
/*    */   Object xinfoStreamFull(byte[] paramArrayOfbyte, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   List<Object> xinfoGroup(byte[] paramArrayOfbyte);
/*    */   
/*    */   List<Object> xinfoGroups(byte[] paramArrayOfbyte);
/*    */   
/*    */   List<Object> xinfoConsumers(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
/*    */   
/*    */   List<byte[]> xread(XReadParams paramXReadParams, Map.Entry<byte[], byte[]>... paramVarArgs);
/*    */   
/*    */   List<byte[]> xreadGroup(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, XReadGroupParams paramXReadGroupParams, Map.Entry<byte[], byte[]>... paramVarArgs);
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\StreamBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */