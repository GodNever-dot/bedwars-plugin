package com.axeelheaven.hbedwars.custom.menus.interfaces;

public interface Callback<T> {
    void done(T result);
} 