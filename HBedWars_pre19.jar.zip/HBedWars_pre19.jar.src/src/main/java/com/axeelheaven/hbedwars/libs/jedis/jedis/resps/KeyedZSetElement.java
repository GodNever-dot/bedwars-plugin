/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyedZSetElement
/*    */   extends Tuple
/*    */ {
/*    */   private final String key;
/*    */   
/*    */   public KeyedZSetElement(byte[] key, byte[] element, Double score) {
/* 13 */     super(element, score);
/* 14 */     this.key = SafeEncoder.encode(key);
/*    */   }
/*    */   
/*    */   public KeyedZSetElement(String key, String element, Double score) {
/* 18 */     super(element, score);
/* 19 */     this.key = key;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 23 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 28 */     if (this == o) return true; 
/* 29 */     if (!(o instanceof KeyedZSetElement)) return false;
/*    */     
/* 31 */     if (!this.key.equals(((KeyedZSetElement)o).key)) return false; 
/* 32 */     return super.equals(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 37 */     return 31 * this.key.hashCode() + super.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 42 */     return "KeyedZSetElement{key=" + this.key + ", element='" + getElement() + "', score=" + 
/* 43 */       getScore() + "} ";
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\KeyedZSetElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */