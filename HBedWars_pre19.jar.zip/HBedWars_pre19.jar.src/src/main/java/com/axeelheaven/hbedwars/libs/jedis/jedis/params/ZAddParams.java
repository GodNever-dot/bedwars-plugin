/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ 
/*    */ 
/*    */ public class ZAddParams
/*    */   extends Params
/*    */   implements IParams
/*    */ {
/*    */   private static final String XX = "xx";
/*    */   private static final String NX = "nx";
/*    */   private static final String CH = "ch";
/*    */   private static final String LT = "lt";
/*    */   private static final String GT = "gt";
/*    */   
/*    */   public static ZAddParams zAddParams() {
/* 17 */     return new ZAddParams();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ZAddParams nx() {
/* 25 */     addParam("nx");
/* 26 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ZAddParams xx() {
/* 34 */     addParam("xx");
/* 35 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ZAddParams ch() {
/* 44 */     addParam("ch");
/* 45 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ZAddParams gt() {
/* 53 */     addParam("gt");
/* 54 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ZAddParams lt() {
/* 62 */     addParam("lt");
/* 63 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 68 */     if (contains("nx")) {
/* 69 */       args.add("nx");
/*    */     }
/* 71 */     if (contains("xx")) {
/* 72 */       args.add("xx");
/*    */     }
/* 74 */     if (contains("ch")) {
/* 75 */       args.add("ch");
/*    */     }
/* 77 */     if (contains("lt")) {
/* 78 */       args.add("lt");
/*    */     }
/* 80 */     if (contains("gt"))
/* 81 */       args.add("gt"); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\ZAddParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */