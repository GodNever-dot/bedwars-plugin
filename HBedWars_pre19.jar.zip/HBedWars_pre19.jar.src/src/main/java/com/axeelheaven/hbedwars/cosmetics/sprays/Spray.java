package com.axeelheaven.hbedwars.cosmetics.sprays;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.map.MapView;
import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class Spray {
  private final BedWars plugin;
  private final String id;
  private final Material material;
  private final byte data;
  
  public Spray(BedWars plugin, String id, Material material, byte data) {
    this.plugin = plugin;
    this.id = id;
    this.material = material;
    this.data = data;
  }
  
  public void spray(Player player, Location location) {
    Block block = location.getBlock();
    block.setType(material);
    block.setData(data);
  }
  
  public String getId() {
    return id;
  }
  
  public Material getMaterial() {
    return material;
  }
  
  public byte getData() {
    return data;
  }
  
  public void draw(short llllllllllllllllllIIllllIllllIlI) {
    this.mapView.setScale(MapView.Scale.CLOSEST);
    ItemStack llllllllllllllllllIIlllllIIIIIll = new ItemStack(Material.MAP);
    llllllllllllllllllIIlllllIIIIIll.setDurability(this.mapView.getId());
    llllllllllllllllllIIllllIllllIlI.setItem(llllllllllllllllllIIlllllIIIIIll);
  }
  
  private static void lIIlIIlllllI() {
    lIllIIllIl = new String[lIllIIllll[21]];
    lIllIIllIl[lIllIIllll[1]] = lIIlIIllllII("G1datJY5PBI=", "nMpfy");
    lIllIIllIl[lIllIIllll[2]] = lIIlIIllllII("fglvOhWqeaw=", "BfvmJ");
    lIllIIllIl[lIllIIllll[0]] = lIIlIIllllII("zviyiQIF5TY=", "JbOIt");
    lIllIIllIl[lIllIIllll[20]] = lIIlIIllllIl("9K9Wi50/pVs=", "uhQjo");
  }
  
  private static void lIIlIlIIlIIl() {
    lIllIIllll = new int[23];
    lIllIIllll[0] = "  ".length();
    lIllIIllll[1] = (0x7C ^ 0x79 ^ 0xCE ^ 0xC6) & (100 + 48 - 53 + 52 ^ 128 + 10 - 100 + 120 ^ -" ".length());
    lIllIIllll[2] = " ".length();
    lIllIIllll[3] = 0x33 ^ 0x46;
    lIllIIllll[4] = 0xD0 ^ 0xB1 ^ 0xA0 ^ 0x90;
    lIllIIllll[5] = 131 + 81 - 56 + 3;
    lIllIIllll[6] = 30 + 76 - -44 + 8 + (0x63 ^ 0xD) - 58 + 87 - 77 + 70 + (0x3A ^ 0x3);
    lIllIIllll[7] = -" ".length();
    lIllIIllll[8] = 83 + 123 - 145 + 126 ^ 57 + 150 - 178 + 129;
    lIllIIllll[9] = 0xD0 ^ 0xB0;
    lIllIIllll[10] = 0x73 ^ 0x9 ^ 0x1E ^ 0x15;
    lIllIIllll[11] = 117 + 92 - 159 + 86 ^ 14 + 53 - -104 + 13;
    lIllIIllll[12] = (0x8E ^ 0x8B) + (0x71 ^ 0x1E) - (0xB9 ^ 0x94) + (0x2B ^ 0x6C);
    lIllIIllll[13] = 14 + 13 - -6 + 164;
    lIllIIllll[14] = 213 + 127 - 268 + 174;
    lIllIIllll[15] = 17 + 85 - -49 + 4;
    lIllIIllll[16] = 0x87 ^ 0x93;
    lIllIIllll[17] = 0x74 ^ 0x4A;
    lIllIIllll[18] = 110 + 130 - 91 + 1;
    lIllIIllll[19] = 89 + 51 - 64 + 52 + (0xC2 ^ 0xA0) - 140 + 83 - 66 + 23 + (0x2C ^ 0x40);
    lIllIIllll[20] = "   ".length();
    lIllIIllll[21] = 75 + 38 - 46 + 131 ^ 190 + 112 - 213 + 105;
    lIllIIllll[22] = 0x26 ^ 0x2E;
  }
  
  public boolean isPermission() {
    // Byte code:
    //   0: aload_0
    //   1: getfield permission : Z
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	llllllllllllllllllIIlllllIlIlIIl	Lcom/axeelheaven/hbedwars/cosmetics/sprays/Spray;
    //   0	5	0	llllllllllllllllllIIlllllIlIIlll	I
    //   0	5	0	llllllllllllllllllIIlllllIlIlIII	S
  }
  
  private static boolean lIIlIlIIlIlI(byte llllllllllllllllllIIllllIIIllIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static void lllIlllI() {
    lIIlIll = new int[lIllIIllll[0]];
    lIIlIll[lIllIIllll[1]] = lIllIIllIl[lIllIIllll[1]].length();
    lIIlIll[lIllIIllll[2]] = (lIllIIllll[3] ^ lIllIIllll[4]) & (lIllIIllll[5] ^ lIllIIllll[6] ^ lIllIIllll[7]);
  }
  
  public int getPrice() {
    // Byte code:
    //   0: aload_0
    //   1: getfield price : I
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	llllllllllllllllllIIllllllIllIIl	Z
    //   0	5	0	llllllllllllllllllIIllllllIllIll	B
    //   0	5	0	llllllllllllllllllIIllllllIlllIl	Lcom/axeelheaven/hbedwars/cosmetics/sprays/Spray;
  }
  
  static {
    lIIlIlIIlIIl();
    lIIlIIlllllI();
    lllIlllI();
  }
  
  private static String lIIlIIllllII(double llllllllllllllllllIIllllIlIlllII, String llllllllllllllllllIIllllIlIllIlI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc 'Blowfish'
    //   21: invokespecial <init> : ([BLjava/lang/String;)V
    //   24: astore_2
    //   25: ldc 'Blowfish'
    //   27: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   30: astore_3
    //   31: aload_3
    //   32: getstatic com/axeelheaven/hbedwars/cosmetics/sprays/Spray.lIllIIllll : [I
    //   35: iconst_0
    //   36: iaload
    //   37: aload_2
    //   38: invokevirtual init : (ILjava/security/Key;)V
    //   41: new java/lang/String
    //   44: dup
    //   45: aload_3
    //   46: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   49: aload_0
    //   50: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   53: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   56: invokevirtual decode : ([B)[B
    //   59: invokevirtual doFinal : ([B)[B
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   68: areturn
    //   69: astore_2
    //   70: aload_2
    //   71: invokevirtual printStackTrace : ()V
    //   74: aconst_null
    //   75: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	76	0	llllllllllllllllllIIllllIlIllllI	Ljava/lang/String;
    //   0	76	3	llllllllllllllllllIIllllIlIllIIl	I
    //   70	4	2	llllllllllllllllllIIllllIlIlllll	Ljava/lang/Exception;
    //   0	76	1	llllllllllllllllllIIllllIlIllIll	Z
    //   0	76	2	llllllllllllllllllIIllllIlIllIlI	Ljava/lang/String;
    //   31	38	3	llllllllllllllllllIIllllIllIIIII	Ljavax/crypto/Cipher;
    //   25	44	2	llllllllllllllllllIIllllIllIIIlI	Ljavax/crypto/spec/SecretKeySpec;
    //   0	76	1	llllllllllllllllllIIllllIlIlllIl	Ljava/lang/String;
    //   0	76	0	llllllllllllllllllIIllllIlIlllII	D
    // Exception table:
    //   from	to	target	type
    //   0	68	69	java/lang/Exception
  }
  
  private static boolean lllIllll(char llllllllllllllllllIIlllllIIIlIlI, short llllllllllllllllllIIlllllIIIlIIl) {
    if (lIIlIlIIllIl(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (-(0xE ^ 0x45 ^ 0x5 ^ 0x4A) >= 0)
        return (0x54 ^ 0x42 ^ 0x76 ^ 0x39) & (99 + 57 - -85 + 12 ^ 46 + 155 - 197 + 160 ^ -" ".length()); 
    } else {
    
    } 
    return lIllIIllll[1];
  }
  
  private static boolean lIIlIlIIllII(float llllllllllllllllllIIllllIIlIIlll, int llllllllllllllllllIIllllIIlIIllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public MapView getMapView() {
    return this.mapView;
  }
  
  private static String lIIlIIllllIl(String llllllllllllllllllIIllllIlIIllIl, String llllllllllllllllllIIllllIlIIlIll) {
    try {
      SecretKeySpec llllllllllllllllllIIllllIlIlIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIllllIlIIlIll.getBytes(StandardCharsets.UTF_8)), lIllIIllll[22]), "DES");
      Cipher llllllllllllllllllIIllllIlIlIIII = Cipher.getInstance("DES");
      llllllllllllllllllIIllllIlIlIIII.init(lIllIIllll[0], llllllllllllllllllIIllllIlIlIIlI);
      return new String(llllllllllllllllllIIllllIlIlIIII.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIllllIlIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception llllllllllllllllllIIllllIlIIllll) {
      llllllllllllllllllIIllllIlIIllll.printStackTrace();
      return null;
    } 
  }
  
  public boolean isFree() {
    if (lIIlIlIIlIlI(lllIllll(this.price, lIIlIll[lIllIIllll[1]]))) {
      "".length();
      if (lIIlIlIIllII(-lIllIIllIl[lIllIIllll[0]].length(), lIllIIllll[8] ^ lIllIIllll[9] ^ lIllIIllll[10] ^ lIllIIllll[11]))
        return (lIllIIllll[12] ^ lIllIIllll[13] ^ lIllIIllll[14] ^ lIllIIllll[15]) & (lIllIIllll[16] ^ lIllIIllll[17] ^ lIllIIllll[18] ^ lIllIIllll[19] ^ -lIllIIllIl[lIllIIllll[20]].length()); 
    } else {
    
    } 
    return lIIlIll[lIllIIllll[2]];
  }
  
  private static boolean lIIlIlIIllIl(byte llllllllllllllllllIIllllIIlIIIlI, boolean llllllllllllllllllIIllllIIlIIIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\sprays\Spray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */