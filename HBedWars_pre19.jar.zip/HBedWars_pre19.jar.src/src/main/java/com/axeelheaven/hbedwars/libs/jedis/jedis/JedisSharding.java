/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.providers.ShardedConnectionProvider;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.Hashing;
/*    */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*    */ import java.util.List;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ public class JedisSharding
/*    */   extends UnifiedJedis {
/* 11 */   public static final Pattern DEFAULT_KEY_TAG_PATTERN = Pattern.compile("\\{(.+?)\\}");
/*    */   
/*    */   public JedisSharding(List<HostAndPort> shards) {
/* 14 */     this(new ShardedConnectionProvider(shards));
/*    */   }
/*    */   
/*    */   public JedisSharding(List<HostAndPort> shards, JedisClientConfig clientConfig) {
/* 18 */     this(new ShardedConnectionProvider(shards, clientConfig));
/*    */   }
/*    */ 
/*    */   
/*    */   public JedisSharding(List<HostAndPort> shards, JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig) {
/* 23 */     this(new ShardedConnectionProvider(shards, clientConfig, poolConfig));
/*    */   }
/*    */   
/*    */   public JedisSharding(List<HostAndPort> shards, JedisClientConfig clientConfig, Hashing algo) {
/* 27 */     this(new ShardedConnectionProvider(shards, clientConfig, algo));
/*    */   }
/*    */ 
/*    */   
/*    */   public JedisSharding(List<HostAndPort> shards, JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig, Hashing algo) {
/* 32 */     this(new ShardedConnectionProvider(shards, clientConfig, poolConfig, algo));
/*    */   }
/*    */   
/*    */   public JedisSharding(ShardedConnectionProvider provider) {
/* 36 */     super(provider);
/*    */   }
/*    */   
/*    */   public JedisSharding(ShardedConnectionProvider provider, Pattern tagPattern) {
/* 40 */     super(provider, tagPattern);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\JedisSharding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */