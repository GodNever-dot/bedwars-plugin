/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.HostAndPort;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FailoverParams
/*    */   implements IParams
/*    */ {
/*    */   private HostAndPort to;
/*    */   private boolean force;
/*    */   private Long timeout;
/*    */   
/*    */   public static FailoverParams failoverParams() {
/* 20 */     return new FailoverParams();
/*    */   }
/*    */   
/*    */   public FailoverParams to(String host, int port) {
/* 24 */     return to(new HostAndPort(host, port));
/*    */   }
/*    */   
/*    */   public FailoverParams to(HostAndPort to) {
/* 28 */     this.to = to;
/* 29 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FailoverParams force() {
/* 36 */     this.force = true;
/* 37 */     return this;
/*    */   }
/*    */   
/*    */   public FailoverParams timeout(long timeout) {
/* 41 */     this.timeout = Long.valueOf(timeout);
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 48 */     if (this.to != null) {
/* 49 */       args.add(Protocol.Keyword.TO);
/* 50 */       args.add(this.to.getHost()).add(Protocol.toByteArray(this.to.getPort()));
/*    */     } 
/*    */     
/* 53 */     if (this.force) {
/* 54 */       if (this.to == null || this.timeout == null) {
/* 55 */         throw new IllegalStateException("ERR FAILOVER with force option requires both a timeout and target HOST and IP.");
/*    */       }
/* 57 */       args.add(Protocol.Keyword.FORCE);
/*    */     } 
/*    */     
/* 60 */     if (this.timeout != null)
/* 61 */       args.add(Protocol.Keyword.TIMEOUT).add(Protocol.toByteArray(this.timeout.longValue())); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\FailoverParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */