package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.bloom.RedisBloomCommands;
import com.axeelheaven.hbedwars.libs.jedis.jedis.graph.RedisGraphCommands;
import com.axeelheaven.hbedwars.libs.jedis.jedis.json.RedisJsonCommands;
import com.axeelheaven.hbedwars.libs.jedis.jedis.search.RediSearchCommands;
import com.axeelheaven.hbedwars.libs.jedis.jedis.timeseries.RedisTimeSeriesCommands;

public interface RedisModuleCommands extends RediSearchCommands, RedisJsonCommands, RedisTimeSeriesCommands, RedisBloomCommands, RedisGraphCommands {}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\RedisModuleCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */