/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.executors;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandObject;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Connection;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.IOUtils;
/*    */ 
/*    */ public class SimpleCommandExecutor
/*    */   implements CommandExecutor {
/*    */   protected final Connection connection;
/*    */   
/*    */   public SimpleCommandExecutor(Connection connection) {
/* 12 */     this.connection = connection;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 17 */     IOUtils.closeQuietly((AutoCloseable)this.connection);
/*    */   }
/*    */ 
/*    */   
/*    */   public final <T> T executeCommand(CommandObject<T> commandObject) {
/* 22 */     return (T)this.connection.executeCommand(commandObject);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\executors\SimpleCommandExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */