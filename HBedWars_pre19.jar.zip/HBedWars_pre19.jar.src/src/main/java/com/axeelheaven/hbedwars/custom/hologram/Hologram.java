package com.axeelheaven.hbedwars.custom.hologram;

import org.bukkit.Location;
import org.bukkit.entity.Player;

public interface Hologram {
    void spawn(Location location);
    void destroy();
    void show(Player player);
    void hide(Player player);
    void setLine(int index, String text);
    String getLine(int index);
    Location getLocation();
    boolean isSpawned();
} 