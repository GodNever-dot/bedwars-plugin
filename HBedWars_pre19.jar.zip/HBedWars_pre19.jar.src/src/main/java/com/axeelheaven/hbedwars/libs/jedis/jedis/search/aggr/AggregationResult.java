/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.search.aggr;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisDataException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AggregationResult
/*    */ {
/*    */   public final long totalResults;
/* 17 */   private long cursorId = -1L;
/* 18 */   private final List<Map<String, Object>> results = new ArrayList<>();
/*    */   
/*    */   public AggregationResult(Object resp, long cursorId) {
/* 21 */     this(resp);
/* 22 */     this.cursorId = cursorId;
/*    */   }
/*    */   
/*    */   public AggregationResult(Object resp) {
/* 26 */     List<Object> list = (List<Object>)resp;
/*    */     
/* 28 */     this.totalResults = ((Long)list.get(0)).longValue();
/*    */     
/* 30 */     for (int i = 1; i < list.size(); i++) {
/* 31 */       List<Object> raw = (List<Object>)list.get(i);
/* 32 */       Map<String, Object> cur = new HashMap<>();
/* 33 */       for (int j = 0; j < raw.size(); j += 2) {
/* 34 */         Object r = raw.get(j);
/* 35 */         if (r instanceof JedisDataException) {
/* 36 */           throw (JedisDataException)r;
/*    */         }
/* 38 */         cur.put(new String((byte[])r), raw.get(j + 1));
/*    */       } 
/* 40 */       this.results.add(cur);
/*    */     } 
/*    */   }
/*    */   
/*    */   public List<Map<String, Object>> getResults() {
/* 45 */     return this.results;
/*    */   }
/*    */   
/*    */   public Row getRow(int index) {
/* 49 */     if (index >= this.results.size()) {
/* 50 */       return null;
/*    */     }
/* 52 */     return new Row(this.results.get(index));
/*    */   }
/*    */   
/*    */   public long getCursorId() {
/* 56 */     return this.cursorId;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\search\aggr\AggregationResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */