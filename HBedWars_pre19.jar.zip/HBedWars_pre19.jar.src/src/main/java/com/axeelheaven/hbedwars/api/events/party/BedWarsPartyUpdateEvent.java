/*    */ package com.axeelheaven.hbedwars.api.events.party;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.custom.party.Party;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsPartyUpdateEvent
/*    */   extends Event {
/*    */   private final Party party;
/* 10 */   private static final HandlerList handlerList = new HandlerList();
/*    */   public Party getParty() {
/* 12 */     return this.party;
/*    */   }
/*    */   public BedWarsPartyUpdateEvent(Party party) {
/* 15 */     this.party = party;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 20 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 24 */     return handlerList;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 30 */   public static String USER = "99852";
/* 31 */   public static String USERNAME = "%%__USERNAME__%%";
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\party\BedWarsPartyUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */