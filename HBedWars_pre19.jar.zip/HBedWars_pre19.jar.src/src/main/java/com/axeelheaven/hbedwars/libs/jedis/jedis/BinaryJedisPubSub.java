/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BinaryJedisPubSub
/*     */ {
/*  12 */   private int subscribedChannels = 0;
/*     */   
/*     */   private Connection client;
/*     */ 
/*     */   
/*     */   public void onMessage(byte[] channel, byte[] message) {}
/*     */ 
/*     */   
/*     */   public void onPMessage(byte[] pattern, byte[] channel, byte[] message) {}
/*     */ 
/*     */   
/*     */   public void onSubscribe(byte[] channel, int subscribedChannels) {}
/*     */ 
/*     */   
/*     */   public void onUnsubscribe(byte[] channel, int subscribedChannels) {}
/*     */ 
/*     */   
/*     */   public void onPUnsubscribe(byte[] pattern, int subscribedChannels) {}
/*     */ 
/*     */   
/*     */   public void onPSubscribe(byte[] pattern, int subscribedChannels) {}
/*     */   
/*     */   public void onPong(byte[] pattern) {}
/*     */   
/*     */   public void unsubscribe() {
/*  37 */     this.client.sendCommand(Protocol.Command.UNSUBSCRIBE);
/*  38 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void unsubscribe(byte[]... channels) {
/*  42 */     this.client.sendCommand(Protocol.Command.UNSUBSCRIBE, channels);
/*  43 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void subscribe(byte[]... channels) {
/*  47 */     this.client.sendCommand(Protocol.Command.SUBSCRIBE, channels);
/*  48 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void psubscribe(byte[]... patterns) {
/*  52 */     this.client.sendCommand(Protocol.Command.PSUBSCRIBE, patterns);
/*  53 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void punsubscribe() {
/*  57 */     this.client.sendCommand(Protocol.Command.PUNSUBSCRIBE);
/*  58 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void punsubscribe(byte[]... patterns) {
/*  62 */     this.client.sendCommand(Protocol.Command.PUNSUBSCRIBE, patterns);
/*  63 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void ping() {
/*  67 */     this.client.sendCommand(Protocol.Command.PING);
/*  68 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void ping(byte[] argument) {
/*  72 */     this.client.sendCommand(Protocol.Command.PING, new byte[][] { argument });
/*  73 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public boolean isSubscribed() {
/*  77 */     return (this.subscribedChannels > 0);
/*     */   }
/*     */   
/*     */   public void proceedWithPatterns(Connection client, byte[]... patterns) {
/*  81 */     this.client = client;
/*  82 */     this.client.setTimeoutInfinite();
/*     */     try {
/*  84 */       psubscribe(patterns);
/*  85 */       process();
/*     */     } finally {
/*  87 */       this.client.rollbackTimeout();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void proceed(Connection client, byte[]... channels) {
/*  92 */     this.client = client;
/*  93 */     this.client.setTimeoutInfinite();
/*     */     try {
/*  95 */       subscribe(channels);
/*  96 */       process();
/*     */     } finally {
/*  98 */       this.client.rollbackTimeout();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void process() {
/*     */     do {
/* 104 */       List<Object> reply = this.client.getUnflushedObjectMultiBulkReply();
/* 105 */       Object firstObj = reply.get(0);
/* 106 */       if (!(firstObj instanceof byte[])) {
/* 107 */         throw new JedisException("Unknown message type: " + firstObj);
/*     */       }
/* 109 */       byte[] resp = (byte[])firstObj;
/* 110 */       if (Arrays.equals(Protocol.ResponseKeyword.SUBSCRIBE.getRaw(), resp)) {
/* 111 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 112 */         byte[] bchannel = (byte[])reply.get(1);
/* 113 */         onSubscribe(bchannel, this.subscribedChannels);
/* 114 */       } else if (Arrays.equals(Protocol.ResponseKeyword.UNSUBSCRIBE.getRaw(), resp)) {
/* 115 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 116 */         byte[] bchannel = (byte[])reply.get(1);
/* 117 */         onUnsubscribe(bchannel, this.subscribedChannels);
/* 118 */       } else if (Arrays.equals(Protocol.ResponseKeyword.MESSAGE.getRaw(), resp)) {
/* 119 */         byte[] bchannel = (byte[])reply.get(1);
/* 120 */         byte[] bmesg = (byte[])reply.get(2);
/* 121 */         onMessage(bchannel, bmesg);
/* 122 */       } else if (Arrays.equals(Protocol.ResponseKeyword.PMESSAGE.getRaw(), resp)) {
/* 123 */         byte[] bpattern = (byte[])reply.get(1);
/* 124 */         byte[] bchannel = (byte[])reply.get(2);
/* 125 */         byte[] bmesg = (byte[])reply.get(3);
/* 126 */         onPMessage(bpattern, bchannel, bmesg);
/* 127 */       } else if (Arrays.equals(Protocol.ResponseKeyword.PSUBSCRIBE.getRaw(), resp)) {
/* 128 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 129 */         byte[] bpattern = (byte[])reply.get(1);
/* 130 */         onPSubscribe(bpattern, this.subscribedChannels);
/* 131 */       } else if (Arrays.equals(Protocol.ResponseKeyword.PUNSUBSCRIBE.getRaw(), resp)) {
/* 132 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 133 */         byte[] bpattern = (byte[])reply.get(1);
/* 134 */         onPUnsubscribe(bpattern, this.subscribedChannels);
/* 135 */       } else if (Arrays.equals(Protocol.ResponseKeyword.PONG.getRaw(), resp)) {
/* 136 */         byte[] bpattern = (byte[])reply.get(1);
/* 137 */         onPong(bpattern);
/*     */       } else {
/* 139 */         throw new JedisException("Unknown message type: " + firstObj);
/*     */       } 
/* 141 */     } while (isSubscribed());
/*     */   }
/*     */   
/*     */   public int getSubscribedChannels() {
/* 145 */     return this.subscribedChannels;
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\BinaryJedisPubSub.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */