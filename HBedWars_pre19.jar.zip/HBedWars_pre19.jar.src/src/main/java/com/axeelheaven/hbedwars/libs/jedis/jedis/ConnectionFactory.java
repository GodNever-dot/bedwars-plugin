/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.PooledObject;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.PooledObjectFactory;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.impl.DefaultPooledObject;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.Logger;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionFactory
/*     */   implements PooledObjectFactory<Connection>
/*     */ {
/*  17 */   private static final Logger logger = LoggerFactory.getLogger(ConnectionFactory.class);
/*     */   
/*     */   private final JedisSocketFactory jedisSocketFactory;
/*     */   
/*     */   private final JedisClientConfig clientConfig;
/*     */   
/*     */   public ConnectionFactory(HostAndPort hostAndPort) {
/*  24 */     this.clientConfig = DefaultJedisClientConfig.builder().build();
/*  25 */     this.jedisSocketFactory = new DefaultJedisSocketFactory(hostAndPort);
/*     */   }
/*     */   
/*     */   public ConnectionFactory(HostAndPort hostAndPort, JedisClientConfig clientConfig) {
/*  29 */     this.clientConfig = DefaultJedisClientConfig.copyConfig(clientConfig);
/*  30 */     this.jedisSocketFactory = new DefaultJedisSocketFactory(hostAndPort, this.clientConfig);
/*     */   }
/*     */   
/*     */   public ConnectionFactory(JedisSocketFactory jedisSocketFactory, JedisClientConfig clientConfig) {
/*  34 */     this.clientConfig = DefaultJedisClientConfig.copyConfig(clientConfig);
/*  35 */     this.jedisSocketFactory = jedisSocketFactory;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  39 */     this.clientConfig.updatePassword(password);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void activateObject(PooledObject<Connection> pooledConnection) throws Exception {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroyObject(PooledObject<Connection> pooledConnection) throws Exception {
/*  49 */     Connection jedis = (Connection)pooledConnection.getObject();
/*  50 */     if (jedis.isConnected()) {
/*     */       
/*     */       try {
/*  53 */         if (!jedis.isBroken()) {
/*  54 */           jedis.quit();
/*     */         }
/*  56 */       } catch (RuntimeException e) {
/*  57 */         logger.warn("Error while QUIT", e);
/*     */       } 
/*     */       try {
/*  60 */         jedis.close();
/*  61 */       } catch (RuntimeException e) {
/*  62 */         logger.warn("Error while close", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PooledObject<Connection> makeObject() throws Exception {
/*  69 */     Connection jedis = null;
/*     */     try {
/*  71 */       jedis = new Connection(this.jedisSocketFactory, this.clientConfig);
/*  72 */       jedis.connect();
/*  73 */       return (PooledObject<Connection>)new DefaultPooledObject(jedis);
/*  74 */     } catch (JedisException je) {
/*  75 */       if (jedis != null) {
/*     */         try {
/*  77 */           jedis.quit();
/*  78 */         } catch (RuntimeException e) {
/*  79 */           logger.warn("Error while QUIT", e);
/*     */         } 
/*     */         try {
/*  82 */           jedis.close();
/*  83 */         } catch (RuntimeException e) {
/*  84 */           logger.warn("Error while close", e);
/*     */         } 
/*     */       } 
/*  87 */       throw je;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void passivateObject(PooledObject<Connection> pooledConnection) throws Exception {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean validateObject(PooledObject<Connection> pooledConnection) {
/*  98 */     Connection jedis = (Connection)pooledConnection.getObject();
/*     */     
/*     */     try {
/* 101 */       return (jedis.isConnected() && jedis.ping());
/* 102 */     } catch (Exception e) {
/* 103 */       logger.error("Error while validating pooled Connection object.", e);
/* 104 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\ConnectionFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */