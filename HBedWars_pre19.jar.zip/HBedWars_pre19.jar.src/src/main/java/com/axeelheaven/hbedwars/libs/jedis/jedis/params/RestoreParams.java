/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RestoreParams
/*    */   implements IParams
/*    */ {
/*    */   private boolean replace;
/*    */   private boolean absTtl;
/*    */   private Long idleTime;
/*    */   private Long frequency;
/*    */   
/*    */   public static RestoreParams restoreParams() {
/* 22 */     return new RestoreParams();
/*    */   }
/*    */   
/*    */   public RestoreParams replace() {
/* 26 */     this.replace = true;
/* 27 */     return this;
/*    */   }
/*    */   
/*    */   public RestoreParams absTtl() {
/* 31 */     this.absTtl = true;
/* 32 */     return this;
/*    */   }
/*    */   
/*    */   public RestoreParams idleTime(long idleTime) {
/* 36 */     this.idleTime = Long.valueOf(idleTime);
/* 37 */     return this;
/*    */   }
/*    */   
/*    */   public RestoreParams frequency(long frequency) {
/* 41 */     this.frequency = Long.valueOf(frequency);
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 47 */     if (this.replace) {
/* 48 */       args.add(Protocol.Keyword.REPLACE.getRaw());
/*    */     }
/*    */     
/* 51 */     if (this.absTtl) {
/* 52 */       args.add(Protocol.Keyword.ABSTTL.getRaw());
/*    */     }
/*    */     
/* 55 */     if (this.idleTime != null) {
/* 56 */       args.add(Protocol.Keyword.IDLETIME.getRaw());
/* 57 */       args.add(Protocol.toByteArray(this.idleTime.longValue()));
/*    */     } 
/*    */     
/* 60 */     if (this.frequency != null) {
/* 61 */       args.add(Protocol.Keyword.FREQ.getRaw());
/* 62 */       args.add(Protocol.toByteArray(this.frequency.longValue()));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\RestoreParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */