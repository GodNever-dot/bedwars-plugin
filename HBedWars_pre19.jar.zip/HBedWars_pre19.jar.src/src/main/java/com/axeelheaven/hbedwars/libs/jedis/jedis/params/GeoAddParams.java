/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeoAddParams
/*    */   implements IParams
/*    */ {
/*    */   private boolean nx = false;
/*    */   private boolean xx = false;
/*    */   private boolean ch = false;
/*    */   
/*    */   public static GeoAddParams geoAddParams() {
/* 19 */     return new GeoAddParams();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GeoAddParams nx() {
/* 27 */     this.nx = true;
/* 28 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GeoAddParams xx() {
/* 36 */     this.xx = true;
/* 37 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GeoAddParams ch() {
/* 46 */     this.ch = true;
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 52 */     if (this.nx) {
/* 53 */       args.add(Protocol.Keyword.NX);
/* 54 */     } else if (this.xx) {
/* 55 */       args.add(Protocol.Keyword.XX);
/*    */     } 
/*    */     
/* 58 */     if (this.ch)
/* 59 */       args.add(Protocol.Keyword.CH); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\GeoAddParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */