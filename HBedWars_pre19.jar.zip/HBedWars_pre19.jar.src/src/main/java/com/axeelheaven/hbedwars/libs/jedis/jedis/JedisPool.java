/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.Pool;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.PooledObjectFactory;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.Logger;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.LoggerFactory;
/*     */ import java.net.URI;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLParameters;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JedisPool
/*     */   extends Pool<Jedis>
/*     */ {
/*  19 */   private static final Logger log = LoggerFactory.getLogger(JedisPool.class);
/*     */   
/*     */   public JedisPool() {
/*  22 */     this("127.0.0.1", 6379);
/*     */   }
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String url) {
/*  26 */     this(poolConfig, URI.create(url));
/*     */   }
/*     */   
/*     */   public JedisPool(String host, int port) {
/*  30 */     this(new GenericObjectPoolConfig(), host, port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(String url) {
/*  43 */     this(URI.create(url));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(String url, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  61 */     this(new GenericObjectPoolConfig(), new JedisFactory(URI.create(url), 2000, 2000, null, sslSocketFactory, sslParameters, hostnameVerifier));
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(URI uri) {
/*  66 */     this(new GenericObjectPoolConfig(), uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(URI uri, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  71 */     this(new GenericObjectPoolConfig(), uri, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(URI uri, int timeout) {
/*  76 */     this(new GenericObjectPoolConfig(), uri, timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(URI uri, int timeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  81 */     this(new GenericObjectPoolConfig(), uri, timeout, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String password) {
/*  87 */     this(poolConfig, host, port, timeout, password, 0);
/*     */   }
/*     */   
/*     */   public JedisPool(String host, int port, String user, String password) {
/*  91 */     this(new GenericObjectPoolConfig(), host, port, user, password);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, String user, String password) {
/*  96 */     this(poolConfig, host, port, 2000, user, password, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String user, String password) {
/* 102 */     this(poolConfig, host, port, timeout, user, password, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String password, boolean ssl) {
/* 107 */     this(poolConfig, host, port, timeout, password, 0, ssl);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String user, String password, boolean ssl) {
/* 112 */     this(poolConfig, host, port, timeout, user, password, 0, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String password, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 119 */     this(poolConfig, host, port, timeout, password, 0, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port) {
/* 125 */     this(poolConfig, host, port, 2000);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, boolean ssl) {
/* 130 */     this(poolConfig, host, port, 2000, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 136 */     this(poolConfig, host, port, 2000, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout) {
/* 142 */     this(poolConfig, host, port, timeout, (String)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, boolean ssl) {
/* 147 */     this(poolConfig, host, port, timeout, (String)null, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 154 */     this(poolConfig, host, port, timeout, (String)null, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String password, int database) {
/* 160 */     this(poolConfig, host, port, timeout, password, database, (String)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String user, String password, int database) {
/* 165 */     this(poolConfig, host, port, timeout, user, password, database, (String)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String password, int database, boolean ssl) {
/* 170 */     this(poolConfig, host, port, timeout, password, database, (String)null, ssl);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String user, String password, int database, boolean ssl) {
/* 175 */     this(poolConfig, host, port, timeout, user, password, database, (String)null, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String password, int database, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 182 */     this(poolConfig, host, port, timeout, password, database, null, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String password, int database, String clientName) {
/* 188 */     this(poolConfig, host, port, timeout, timeout, password, database, clientName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String user, String password, int database, String clientName) {
/* 194 */     this(poolConfig, host, port, timeout, timeout, user, password, database, clientName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String password, int database, String clientName, boolean ssl) {
/* 200 */     this(poolConfig, host, port, timeout, timeout, password, database, clientName, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String user, String password, int database, String clientName, boolean ssl) {
/* 206 */     this(poolConfig, host, port, timeout, timeout, user, password, database, clientName, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int timeout, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 213 */     this(poolConfig, host, port, timeout, timeout, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 221 */     this(poolConfig, new JedisFactory(host, port, connectionTimeout, soTimeout, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 230 */     this(poolConfig, host, port, connectionTimeout, soTimeout, infiniteSoTimeout, null, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String user, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 239 */     this(poolConfig, host, port, connectionTimeout, soTimeout, 0, user, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String user, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 248 */     this(poolConfig, new JedisFactory(host, port, connectionTimeout, soTimeout, infiniteSoTimeout, user, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(HostAndPort hostAndPort, JedisClientConfig clientConfig) {
/* 254 */     this(new GenericObjectPoolConfig(), hostAndPort, clientConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, HostAndPort hostAndPort, JedisClientConfig clientConfig) {
/* 259 */     this(poolConfig, new JedisFactory(hostAndPort, clientConfig));
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, JedisSocketFactory jedisSocketFactory, JedisClientConfig clientConfig) {
/* 264 */     this(poolConfig, new JedisFactory(jedisSocketFactory, clientConfig));
/*     */   }
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig) {
/* 268 */     this(poolConfig, "127.0.0.1", 6379);
/*     */   }
/*     */   
/*     */   public JedisPool(String host, int port, boolean ssl) {
/* 272 */     this(new GenericObjectPoolConfig(), host, port, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String password, int database, String clientName) {
/* 278 */     this(poolConfig, new JedisFactory(host, port, connectionTimeout, soTimeout, password, database, clientName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String user, String password, int database, String clientName) {
/* 285 */     this(poolConfig, new JedisFactory(host, port, connectionTimeout, soTimeout, user, password, database, clientName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String user, String password, int database, String clientName) {
/* 292 */     this(poolConfig, new JedisFactory(host, port, connectionTimeout, soTimeout, infiniteSoTimeout, user, password, database, clientName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(String host, int port, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 299 */     this(new GenericObjectPoolConfig(), host, port, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String password, int database, String clientName, boolean ssl) {
/* 306 */     this(poolConfig, host, port, connectionTimeout, soTimeout, password, database, clientName, ssl, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String user, String password, int database, String clientName, boolean ssl) {
/* 313 */     this(poolConfig, host, port, connectionTimeout, soTimeout, user, password, database, clientName, ssl, (SSLSocketFactory)null, (SSLParameters)null, (HostnameVerifier)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, URI uri) {
/* 318 */     this(poolConfig, uri, 2000);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, URI uri, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 324 */     this(poolConfig, uri, 2000, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, URI uri, int timeout) {
/* 329 */     this(poolConfig, uri, timeout, timeout);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, URI uri, int timeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 335 */     this(poolConfig, uri, timeout, timeout, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, URI uri, int connectionTimeout, int soTimeout) {
/* 340 */     this(poolConfig, uri, connectionTimeout, soTimeout, (SSLSocketFactory)null, (SSLParameters)null, (HostnameVerifier)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, URI uri, int connectionTimeout, int soTimeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 346 */     this(poolConfig, new JedisFactory(uri, connectionTimeout, soTimeout, null, sslSocketFactory, sslParameters, hostnameVerifier));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, URI uri, int connectionTimeout, int soTimeout, int infiniteSoTimeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 354 */     this(poolConfig, new JedisFactory(uri, connectionTimeout, soTimeout, infiniteSoTimeout, null, sslSocketFactory, sslParameters, hostnameVerifier));
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPool(GenericObjectPoolConfig<Jedis> poolConfig, PooledObjectFactory<Jedis> factory) {
/* 359 */     super(poolConfig, factory);
/*     */   }
/*     */ 
/*     */   
/*     */   public Jedis getResource() {
/* 364 */     Jedis jedis = (Jedis)super.getResource();
/* 365 */     jedis.setDataSource(this);
/* 366 */     return jedis;
/*     */   }
/*     */ 
/*     */   
/*     */   public void returnResource(Jedis resource) {
/* 371 */     if (resource != null)
/*     */       try {
/* 373 */         resource.resetState();
/* 374 */         super.returnResource(resource);
/* 375 */       } catch (RuntimeException e) {
/* 376 */         returnBrokenResource(resource);
/* 377 */         log.warn("Resource is returned to the pool as broken", e);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\JedisPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */