/*    */ package com.axeelheaven.hbedwars.api.arena;
/*    */ import com.axeelheaven.hbedwars.libs.xseries.XMaterial;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Color;
/*    */ 
/*    */ public enum ArenaColor {
/*    */   RED(ChatColor.RED),
/*    */   BLUE(ChatColor.BLUE),
/*    */   GREEN(ChatColor.GREEN),
/*    */   YELLOW(ChatColor.YELLOW),
/*    */   AQUA(ChatColor.AQUA),
/*    */   WHITE(ChatColor.WHITE),
/*    */   PINK(ChatColor.LIGHT_PURPLE),
/*    */   GRAY(ChatColor.GRAY);
/*    */   
/*    */   private final ChatColor color;
/*    */   
/*    */   ArenaColor(ChatColor color) {
/*    */     this.color = color;
/*    */   }
/*    */   
/*    */   public ChatColor getColor() {
/*    */     return color;
/*    */   }
/*    */   
/*    */   public String toString() {
/*    */     return color.toString();
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\arena\ArenaColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */