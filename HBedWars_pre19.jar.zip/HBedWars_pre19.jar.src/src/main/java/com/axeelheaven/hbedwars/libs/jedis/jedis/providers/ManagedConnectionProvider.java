/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.providers;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Connection;
/*    */ 
/*    */ public class ManagedConnectionProvider
/*    */   implements ConnectionProvider {
/*    */   private Connection connection;
/*    */   
/*    */   public final void setConnection(Connection connection) {
/* 11 */     this.connection = connection;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void close() {}
/*    */ 
/*    */   
/*    */   public final Connection getConnection() {
/* 20 */     return this.connection;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Connection getConnection(CommandArguments args) {
/* 25 */     return this.connection;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\providers\ManagedConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */