package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.GeoCoordinate;
import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.GeoUnit;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoAddParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoRadiusParam;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoRadiusStoreParam;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoSearchParam;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.GeoRadiusResponse;
import java.util.List;
import java.util.Map;

public interface GeoPipelineBinaryCommands {
  Response<Long> geoadd(byte[] paramArrayOfbyte1, double paramDouble1, double paramDouble2, byte[] paramArrayOfbyte2);
  
  Response<Long> geoadd(byte[] paramArrayOfbyte, Map<byte[], GeoCoordinate> paramMap);
  
  Response<Long> geoadd(byte[] paramArrayOfbyte, GeoAddParams paramGeoAddParams, Map<byte[], GeoCoordinate> paramMap);
  
  Response<Double> geodist(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
  
  Response<Double> geodist(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, GeoUnit paramGeoUnit);
  
  Response<List<byte[]>> geohash(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  Response<List<GeoCoordinate>> geopos(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  Response<List<GeoRadiusResponse>> georadius(byte[] paramArrayOfbyte, double paramDouble1, double paramDouble2, double paramDouble3, GeoUnit paramGeoUnit);
  
  Response<List<GeoRadiusResponse>> georadiusReadonly(byte[] paramArrayOfbyte, double paramDouble1, double paramDouble2, double paramDouble3, GeoUnit paramGeoUnit);
  
  Response<List<GeoRadiusResponse>> georadius(byte[] paramArrayOfbyte, double paramDouble1, double paramDouble2, double paramDouble3, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam);
  
  Response<List<GeoRadiusResponse>> georadiusReadonly(byte[] paramArrayOfbyte, double paramDouble1, double paramDouble2, double paramDouble3, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam);
  
  Response<List<GeoRadiusResponse>> georadiusByMember(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, double paramDouble, GeoUnit paramGeoUnit);
  
  Response<List<GeoRadiusResponse>> georadiusByMemberReadonly(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, double paramDouble, GeoUnit paramGeoUnit);
  
  Response<List<GeoRadiusResponse>> georadiusByMember(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, double paramDouble, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam);
  
  Response<List<GeoRadiusResponse>> georadiusByMemberReadonly(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, double paramDouble, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam);
  
  Response<Long> georadiusStore(byte[] paramArrayOfbyte, double paramDouble1, double paramDouble2, double paramDouble3, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam, GeoRadiusStoreParam paramGeoRadiusStoreParam);
  
  Response<Long> georadiusByMemberStore(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, double paramDouble, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam, GeoRadiusStoreParam paramGeoRadiusStoreParam);
  
  Response<List<GeoRadiusResponse>> geosearch(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, double paramDouble, GeoUnit paramGeoUnit);
  
  Response<List<GeoRadiusResponse>> geosearch(byte[] paramArrayOfbyte, GeoCoordinate paramGeoCoordinate, double paramDouble, GeoUnit paramGeoUnit);
  
  Response<List<GeoRadiusResponse>> geosearch(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, double paramDouble1, double paramDouble2, GeoUnit paramGeoUnit);
  
  Response<List<GeoRadiusResponse>> geosearch(byte[] paramArrayOfbyte, GeoCoordinate paramGeoCoordinate, double paramDouble1, double paramDouble2, GeoUnit paramGeoUnit);
  
  Response<List<GeoRadiusResponse>> geosearch(byte[] paramArrayOfbyte, GeoSearchParam paramGeoSearchParam);
  
  Response<Long> geosearchStore(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, double paramDouble, GeoUnit paramGeoUnit);
  
  Response<Long> geosearchStore(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, GeoCoordinate paramGeoCoordinate, double paramDouble, GeoUnit paramGeoUnit);
  
  Response<Long> geosearchStore(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, double paramDouble1, double paramDouble2, GeoUnit paramGeoUnit);
  
  Response<Long> geosearchStore(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, GeoCoordinate paramGeoCoordinate, double paramDouble1, double paramDouble2, GeoUnit paramGeoUnit);
  
  Response<Long> geosearchStore(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, GeoSearchParam paramGeoSearchParam);
  
  Response<Long> geosearchStoreStoreDist(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, GeoSearchParam paramGeoSearchParam);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\GeoPipelineBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */