/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MigrateParams
/*    */   implements IParams
/*    */ {
/*    */   private boolean copy = false;
/*    */   private boolean replace = false;
/* 14 */   private String username = null;
/* 15 */   private String passowrd = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static MigrateParams migrateParams() {
/* 21 */     return new MigrateParams();
/*    */   }
/*    */   
/*    */   public MigrateParams copy() {
/* 25 */     this.copy = true;
/* 26 */     return this;
/*    */   }
/*    */   
/*    */   public MigrateParams replace() {
/* 30 */     this.replace = true;
/* 31 */     return this;
/*    */   }
/*    */   
/*    */   public MigrateParams auth(String password) {
/* 35 */     this.passowrd = password;
/* 36 */     return this;
/*    */   }
/*    */   
/*    */   public MigrateParams auth2(String username, String password) {
/* 40 */     this.username = username;
/* 41 */     this.passowrd = password;
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 47 */     if (this.copy) {
/* 48 */       args.add(Protocol.Keyword.COPY);
/*    */     }
/* 50 */     if (this.replace) {
/* 51 */       args.add(Protocol.Keyword.REPLACE);
/*    */     }
/* 53 */     if (this.username != null) {
/* 54 */       args.add(Protocol.Keyword.AUTH2).add(this.username).add(this.passowrd);
/* 55 */     } else if (this.passowrd != null) {
/* 56 */       args.add(Protocol.Keyword.AUTH).add(this.passowrd);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\MigrateParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */