/*    */ package com.axeelheaven.hbedwars.api.events.holograms;
/*    */ import com.axeelheaven.hbedwars.custom.holograms.Hologram;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsHologramInteractEvent extends Event {
/*    */   private final Player player;
/*    */   private final Hologram hologram;
/*    */   private final Click clickType;
/* 11 */   private static final HandlerList handlerList = new HandlerList(); public Player getPlayer() {
/* 12 */     return this.player; }
/* 13 */   public Hologram getHologram() { return this.hologram; } public Click getClickType() {
/* 14 */     return this.clickType;
/*    */   }
/*    */   public BedWarsHologramInteractEvent(Player player, Hologram hologram, Click clickType) {
/* 17 */     this.player = player;
/* 18 */     this.hologram = hologram;
/* 19 */     this.clickType = clickType;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 24 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 28 */     return handlerList;
/*    */   }
/*    */   
/*    */   public enum Click {
/* 32 */     LEFT, RIGHT;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\holograms\BedWarsHologramInteractEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */