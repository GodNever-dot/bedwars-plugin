package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.bloom.RedisBloomPipelineCommands;
import com.axeelheaven.hbedwars.libs.jedis.jedis.graph.RedisGraphPipelineCommands;
import com.axeelheaven.hbedwars.libs.jedis.jedis.json.RedisJsonPipelineCommands;
import com.axeelheaven.hbedwars.libs.jedis.jedis.search.RediSearchPipelineCommands;
import com.axeelheaven.hbedwars.libs.jedis.jedis.timeseries.RedisTimeSeriesPipelineCommands;

public interface RedisModulePipelineCommands extends RediSearchPipelineCommands, RedisJsonPipelineCommands, RedisTimeSeriesPipelineCommands, RedisBloomPipelineCommands, RedisGraphPipelineCommands {}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\RedisModulePipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */