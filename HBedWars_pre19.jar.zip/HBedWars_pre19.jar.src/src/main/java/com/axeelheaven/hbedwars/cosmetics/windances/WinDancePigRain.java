package com.axeelheaven.hbedwars.cosmetics.windances;

import com.axeelheaven.hbedwars.BedWars;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.entity.Player;

public class WinDancePigRain extends WinDance {
  private static void lIllIIIllIl() {
    lllIIIllI = new int[lIIIlIIlllI[0]];
    lllIIIllI[lIIIlIIlllI[1]] = (lIIIlIIlllI[2] ^ lIIIlIIlllI[3]) & (lIIIlIIlllI[4] ^ lIIIlIIlllI[5] ^ lIIIlIIlllI[6]);
    lllIIIllI[lIIIlIIlllI[7]] = lIIIlIIlIlI[lIIIlIIlllI[1]].length();
    lllIIIllI[lIIIlIIlllI[8]] = lIIIlIIlllI[9] + lIIIlIIlllI[10] - lIIIlIIlllI[11] + lIIIlIIlllI[12] ^ lIIIlIIlllI[13] + lIIIlIIlllI[14] - lIIIlIIlllI[15] + lIIIlIIlllI[16];
    lllIIIllI[lIIIlIIlllI[4]] = lIIIlIIlIlI[lIIIlIIlllI[7]].length();
    lllIIIllI[lIIIlIIlllI[17]] = lIIIlIIlIlI[lIIIlIIlllI[8]].length();
    lllIIIllI[lIIIlIIlllI[18]] = lIIIlIIlllI[19] ^ lIIIlIIlllI[20] ^ lIIIlIIlllI[21] ^ lIIIlIIlllI[22];
    lllIIIllI[lIIIlIIlllI[23]] = lIIIlIIlllI[24] ^ lIIIlIIlllI[25];
    lllIIIllI[lIIIlIIlllI[26]] = -lIIIlIIlIlI[lIIIlIIlllI[4]].length() & lIIIlIIlllI[6] & lIIIlIIlllI[27];
    lllIIIllI[lIIIlIIlllI[28]] = lIIIlIIlllI[29] + lIIIlIIlllI[5] - lIIIlIIlllI[30] + lIIIlIIlllI[31] ^ lIIIlIIlllI[32] + lIIIlIIlllI[33] - lIIIlIIlllI[23] + lIIIlIIlllI[34];
    lllIIIllI[lIIIlIIlllI[35]] = lIIIlIIlllI[36] ^ lIIIlIIlllI[37];
  }
  
  private static String lIllIIIlIll(short llllllllllllllllIIlllIIIIllIIIII, boolean llllllllllllllllIIlllIIIIlIlllll) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lllIIIllI : [I
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   43: iconst_1
    //   44: iaload
    //   45: iaload
    //   46: istore #4
    //   48: aload_0
    //   49: invokevirtual toCharArray : ()[C
    //   52: astore #5
    //   54: aload #5
    //   56: arraylength
    //   57: istore #6
    //   59: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lllIIIllI : [I
    //   62: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   65: iconst_1
    //   66: iaload
    //   67: iaload
    //   68: istore #7
    //   70: iload #7
    //   72: iload #6
    //   74: invokestatic lIllIIlIIIl : (II)Z
    //   77: invokestatic lIIIIlIlIIlIl : (I)Z
    //   80: ifeq -> 166
    //   83: aload #5
    //   85: iload #7
    //   87: caload
    //   88: istore #8
    //   90: aload_2
    //   91: iload #8
    //   93: aload_3
    //   94: iload #4
    //   96: aload_3
    //   97: arraylength
    //   98: irem
    //   99: caload
    //   100: ixor
    //   101: i2c
    //   102: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   105: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlIlI : [Ljava/lang/String;
    //   108: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   111: bipush #17
    //   113: iaload
    //   114: aaload
    //   115: invokevirtual length : ()I
    //   118: pop2
    //   119: iinc #4, 1
    //   122: iinc #7, 1
    //   125: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlIlI : [Ljava/lang/String;
    //   128: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   131: bipush #18
    //   133: iaload
    //   134: aaload
    //   135: invokevirtual length : ()I
    //   138: ldc ''
    //   140: invokevirtual length : ()I
    //   143: pop2
    //   144: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlIlI : [Ljava/lang/String;
    //   147: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   150: bipush #23
    //   152: iaload
    //   153: aaload
    //   154: invokevirtual length : ()I
    //   157: ineg
    //   158: invokestatic lIIIIlIlIIllI : (I)Z
    //   161: ifeq -> 70
    //   164: aconst_null
    //   165: areturn
    //   166: aload_2
    //   167: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   170: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	171	4	llllllllllllllllIIlllIIIIlIlllII	C
    //   48	123	4	llllllllllllllllIIlllIIIIllIllIl	I
    //   0	171	1	llllllllllllllllIIlllIIIIllIlIlI	F
    //   0	171	8	llllllllllllllllIIlllIIIIllIllll	F
    //   0	171	4	llllllllllllllllIIlllIIIIllIIIlI	C
    //   0	171	5	llllllllllllllllIIlllIIIIlIllIll	Ljava/lang/String;
    //   0	171	6	llllllllllllllllIIlllIIIIllIlIll	F
    //   32	139	2	llllllllllllllllIIlllIIIIllIlIII	Ljava/lang/StringBuilder;
    //   0	171	0	llllllllllllllllIIlllIIIIllIlIIl	J
    //   37	134	3	llllllllllllllllIIlllIIIIllIIlll	[C
    //   0	171	0	llllllllllllllllIIlllIIIIllIIIII	S
    //   0	171	3	llllllllllllllllIIlllIIIIllIllII	Ljava/lang/String;
    //   0	171	7	llllllllllllllllIIlllIIIIlIllIIl	B
    //   0	171	8	llllllllllllllllIIlllIIIIlIllIII	C
    //   0	171	2	llllllllllllllllIIlllIIIIllIIIll	D
    //   0	171	3	llllllllllllllllIIlllIIIIlIlllIl	F
    //   0	171	2	llllllllllllllllIIlllIIIIlIllllI	C
    //   90	32	8	llllllllllllllllIIlllIIIIllIlllI	C
    //   0	171	5	llllllllllllllllIIlllIIIIllIIIIl	C
    //   0	171	0	llllllllllllllllIIlllIIIIllIIllI	Ljava/lang/String;
    //   0	171	1	llllllllllllllllIIlllIIIIlIlllll	Z
    //   0	171	6	llllllllllllllllIIlllIIIIlIllIlI	I
    //   0	171	7	llllllllllllllllIIlllIIIIllIIlIl	D
    //   0	171	1	llllllllllllllllIIlllIIIIllIIlII	Ljava/lang/String;
  }
  
  private static String lIIIIlIIIlIIl(char llllllllllllllllIIllIllllllIIIll, String llllllllllllllllIIllIllllllIIlII) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: ldc_w 'Blowfish'
    //   23: invokespecial <init> : ([BLjava/lang/String;)V
    //   26: astore_2
    //   27: ldc_w 'Blowfish'
    //   30: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   33: astore_3
    //   34: aload_3
    //   35: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   38: bipush #8
    //   40: iaload
    //   41: aload_2
    //   42: invokevirtual init : (ILjava/security/Key;)V
    //   45: new java/lang/String
    //   48: dup
    //   49: aload_3
    //   50: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   53: aload_0
    //   54: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   57: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   60: invokevirtual decode : ([B)[B
    //   63: invokevirtual doFinal : ([B)[B
    //   66: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   69: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   72: areturn
    //   73: astore_2
    //   74: aload_2
    //   75: invokevirtual printStackTrace : ()V
    //   78: aconst_null
    //   79: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   34	39	3	llllllllllllllllIIllIllllllIIlll	Ljavax/crypto/Cipher;
    //   0	80	0	llllllllllllllllIIllIllllllIIlIl	Ljava/lang/String;
    //   27	46	2	llllllllllllllllIIllIllllllIlIII	Ljavax/crypto/spec/SecretKeySpec;
    //   0	80	1	llllllllllllllllIIllIllllllIIIlI	D
    //   74	4	2	llllllllllllllllIIllIllllllIIllI	Ljava/lang/Exception;
    //   0	80	3	llllllllllllllllIIllIllllllIIIII	B
    //   0	80	1	llllllllllllllllIIllIllllllIIlII	Ljava/lang/String;
    //   0	80	0	llllllllllllllllIIllIllllllIIIll	C
    //   0	80	2	llllllllllllllllIIllIllllllIIIIl	S
    // Exception table:
    //   from	to	target	type
    //   0	72	73	java/lang/Exception
  }
  
  public void execute(short llllllllllllllllIIlllIIIIIlIIlIl, boolean llllllllllllllllIIlllIIIIIlIIlII) {
    // Byte code:
    //   0: new java/util/concurrent/atomic/AtomicInteger
    //   3: dup
    //   4: aload_2
    //   5: invokevirtual getArenaTask : ()Lcom/axeelheaven/hbedwars/arena/task/ArenaTask;
    //   8: invokevirtual getEndSeconds : ()I
    //   11: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lllIIIllI : [I
    //   14: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   17: bipush #23
    //   19: iaload
    //   20: iaload
    //   21: imul
    //   22: invokespecial <init> : (I)V
    //   25: astore_3
    //   26: aload_0
    //   27: getfield runnable : Ljava/util/HashMap;
    //   30: aload_1
    //   31: aload_0
    //   32: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   35: invokevirtual getServer : ()Lorg/bukkit/Server;
    //   38: invokeinterface getScheduler : ()Lorg/bukkit/scheduler/BukkitScheduler;
    //   43: aload_0
    //   44: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   47: aload_0
    //   48: aload_3
    //   49: aload_1
    //   50: aload_2
    //   51: <illegal opcode> run : (Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain;Ljava/util/concurrent/atomic/AtomicInteger;Lorg/bukkit/entity/Player;Lcom/axeelheaven/hbedwars/api/arena/Arena;)Ljava/lang/Runnable;
    //   56: ldc2_w 5
    //   59: ldc2_w 5
    //   62: invokeinterface scheduleSyncRepeatingTask : (Lorg/bukkit/plugin/Plugin;Ljava/lang/Runnable;JJ)I
    //   67: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   70: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   73: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlIlI : [Ljava/lang/String;
    //   76: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   79: bipush #40
    //   81: iaload
    //   82: aaload
    //   83: invokevirtual length : ()I
    //   86: pop2
    //   87: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	88	3	llllllllllllllllIIlllIIIIIlIlIII	Ljava/lang/String;
    //   0	88	1	llllllllllllllllIIlllIIIIIlIlIll	Lorg/bukkit/entity/Player;
    //   0	88	0	llllllllllllllllIIlllIIIIIlIlIIl	Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain;
    //   26	62	3	llllllllllllllllIIlllIIIIIlIIlll	Ljava/util/concurrent/atomic/AtomicInteger;
    //   0	88	2	llllllllllllllllIIlllIIIIIlIlllI	S
    //   0	88	1	llllllllllllllllIIlllIIIIIlIIlIl	S
    //   0	88	2	llllllllllllllllIIlllIIIIIlIIlII	Z
    //   0	88	2	llllllllllllllllIIlllIIIIIlIllII	Lcom/axeelheaven/hbedwars/api/arena/Arena;
    //   0	88	0	llllllllllllllllIIlllIIIIIlIllIl	Z
    //   0	88	0	llllllllllllllllIIlllIIIIIlIIllI	F
    //   0	88	3	llllllllllllllllIIlllIIIIIlIIIll	Z
    //   0	88	1	llllllllllllllllIIlllIIIIIlIlIlI	B
  }
  
  private static boolean lIIIIlIlIIlIl(String llllllllllllllllIIllIllllIllIIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static String lIIIIlIIIlIll(String llllllllllllllllIIllIlllllIIIIII, String llllllllllllllllIIllIllllIllllll) {
    try {
      SecretKeySpec llllllllllllllllIIllIlllllIIIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIllIllllIllllll.getBytes(StandardCharsets.UTF_8)), lIIIlIIlllI[28]), "DES");
      Cipher llllllllllllllllIIllIlllllIIIIlI = Cipher.getInstance("DES");
      llllllllllllllllIIllIlllllIIIIlI.init(lIIIlIIlllI[8], llllllllllllllllIIllIlllllIIIIll);
      return new String(llllllllllllllllIIllIlllllIIIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllIIllIlllllIIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception llllllllllllllllIIllIlllllIIIIIl) {
      llllllllllllllllIIllIlllllIIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIllIIIlIIl(float llllllllllllllllIIlllIIIIIllIllI, char llllllllllllllllIIlllIIIIIlllIIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlIlI : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   10: iconst_0
    //   11: iaload
    //   12: aaload
    //   13: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   16: aload_1
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   23: invokevirtual digest : ([B)[B
    //   26: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlIlI : [Ljava/lang/String;
    //   29: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   32: bipush #38
    //   34: iaload
    //   35: aaload
    //   36: invokespecial <init> : ([BLjava/lang/String;)V
    //   39: astore_2
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlIlI : [Ljava/lang/String;
    //   43: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   46: bipush #39
    //   48: iaload
    //   49: aaload
    //   50: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   53: astore_3
    //   54: aload_3
    //   55: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lllIIIllI : [I
    //   58: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   61: iconst_4
    //   62: iaload
    //   63: iaload
    //   64: aload_2
    //   65: invokevirtual init : (ILjava/security/Key;)V
    //   68: new java/lang/String
    //   71: dup
    //   72: aload_3
    //   73: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   76: aload_0
    //   77: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   80: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   83: invokevirtual decode : ([B)[B
    //   86: invokevirtual doFinal : ([B)[B
    //   89: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   92: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   95: areturn
    //   96: astore_2
    //   97: aload_2
    //   98: invokevirtual printStackTrace : ()V
    //   101: aconst_null
    //   102: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	103	3	llllllllllllllllIIlllIIIIIllIlll	I
    //   0	103	2	llllllllllllllllIIlllIIIIIllIlII	Ljava/lang/Exception;
    //   0	103	2	llllllllllllllllIIlllIIIIIlllIlI	I
    //   0	103	1	llllllllllllllllIIlllIIIIIllIlIl	S
    //   54	42	3	llllllllllllllllIIlllIIIIIlllIII	Ljavax/crypto/Cipher;
    //   0	103	1	llllllllllllllllIIlllIIIIIlllIIl	C
    //   0	103	0	llllllllllllllllIIlllIIIIIllllll	Ljava/lang/String;
    //   0	103	1	llllllllllllllllIIlllIIIIIllllII	Ljava/lang/String;
    //   0	103	0	llllllllllllllllIIlllIIIIIllIllI	F
    //   97	4	2	llllllllllllllllIIlllIIIIIlllllI	Ljava/lang/Exception;
    //   0	103	3	llllllllllllllllIIlllIIIIIllIIll	S
    //   0	103	0	llllllllllllllllIIlllIIIIIllllIl	J
    //   40	56	2	llllllllllllllllIIlllIIIIIlllIll	Ljavax/crypto/spec/SecretKeySpec;
    // Exception table:
    //   from	to	target	type
    //   0	95	96	java/lang/Exception
  }
  
  static {
    lIIIIlIlIIIlI();
    lIIIIlIIllIIl();
    lIllIIIllIl();
    lIllIIIllII();
  }
  
  private static boolean lIIIIlIlIIlll(boolean llllllllllllllllIIllIllllIllIlII, long llllllllllllllllIIllIllllIllIIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIllIIlIIIl(float llllllllllllllllIIlllIIIIIIIIllI, int llllllllllllllllIIlllIIIIIIIIlIl) {
    if (lIIIIlIlIIlll(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if ("   ".length() != "   ".length())
        return (0x4 ^ 0x48) & (0x1F ^ 0x53 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIIIlIIlllI[1];
  }
  
  private static boolean lIIIIlIlIIlII(char llllllllllllllllIIllIllllIlllIII, char llllllllllllllllIIllIllllIllIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIIIIlIlIIIll(double llllllllllllllllIIllIllllIlIllll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static void lIIIIlIIllIIl() {
    lIIIlIIlIlI = new String[lIIIlIIlllI[20]];
    lIIIlIIlIlI[lIIIlIIlllI[1]] = lIIIIlIIIlIIl("WLuv8MGn8X8=", "ajztM");
    lIIIlIIlIlI[lIIIlIIlllI[7]] = lIIIIlIIIlIIl("0qB/pIg3DOA=", "LSAiV");
    lIIIlIIlIlI[lIIIlIIlllI[8]] = lIIIIlIIIlIlI("RmRE", "fDdPY");
    lIIIlIIlIlI[lIIIlIIlllI[4]] = lIIIIlIIIlIIl("eBzA2l2WyH0=", "OoIOc");
    lIIIlIIlIlI[lIIIlIIlllI[17]] = lIIIIlIIIlIlI("", "hmjXj");
    lIIIlIIlIlI[lIIIlIIlllI[18]] = lIIIIlIIIlIIl("wpjIhCwH+mA=", "EEaQm");
    lIIIlIIlIlI[lIIIlIIlllI[23]] = lIIIIlIIIlIll("zV0n4aYm2Gw=", "gGDGR");
    lIIIlIIlIlI[lIIIlIIlllI[26]] = lIIIIlIIIlIlI("HTJA", "Pvumx");
    lIIIlIIlIlI[lIIIlIIlllI[28]] = lIIIIlIIIlIll("nzjfZiuSMpw=", "RvJYD");
    lIIIlIIlIlI[lIIIlIIlllI[35]] = lIIIIlIIIlIIl("/eIkG6Lh/b4=", "zgOOg");
    lIIIlIIlIlI[lIIIlIIlllI[0]] = lIIIIlIIIlIll("l4cDf/oZZ/s=", "NpJHy");
    lIIIlIIlIlI[lIIIlIIlllI[38]] = lIIIIlIIIlIll("39seu1DhA8vIELMLvlnz6A==", "EJBGG");
    lIIIlIIlIlI[lIIIlIIlllI[39]] = lIIIIlIIIlIIl("67mQxnzjgiqgcDhQtWpQwQ==", "DhUrf");
    lIIIlIIlIlI[lIIIlIIlllI[40]] = lIIIIlIIIlIll("ToKD+jvvnQs=", "VmXzx");
    lIIIlIIlIlI[lIIIlIIlllI[34]] = lIIIIlIIIlIll("NTnxaOsplWfPlKwiLjpN4Q==", "TBSYT");
    lIIIlIIlIlI[lIIIlIIlllI[41]] = lIIIIlIIIlIll("DYzYi8uejEY=", "qouDF");
    lIIIlIIlIlI[lIIIlIIlllI[42]] = lIIIIlIIIlIlI("OSkyKBAqFVs0L0IZWgUuJSggEQVVJlV+", "mQhCi");
    lIIIlIIlIlI[lIIIlIIlllI[43]] = lIIIIlIIIlIll("/Au0oWjlZTA=", "cAcRe");
    lIIIlIIlIlI[lIIIlIIlllI[44]] = lIIIIlIIIlIll("ox7iZZAO3iOWFZZ/FrvnPA==", "Shezo");
    lIIIlIIlIlI[lIIIlIIlllI[45]] = lIIIIlIIIlIIl("6IVwG44skkg=", "RVjNr");
    lIIIlIIlIlI[lIIIlIIlllI[46]] = lIIIIlIIIlIll("GscTsCk96H6vQRuYjafbgA==", "ifGAt");
    lIIIlIIlIlI[lIIIlIIlllI[47]] = lIIIIlIIIlIlI("OjonIBo=", "wxmFQ");
    lIIIlIIlIlI[lIIIlIIlllI[2]] = lIIIIlIIIlIlI("EnpuHAsKACZ/HBMmdjcrcR4wfyolGnh7", "DKEFY");
    lIIIlIIlIlI[lIIIlIIlllI[48]] = lIIIIlIIIlIll("IV5CHKUNqRU=", "dSaIK");
    lIIIlIIlIlI[lIIIlIIlllI[49]] = lIIIIlIIIlIIl("bDw8HG4mtR4=", "LUSTH");
    lIIIlIIlIlI[lIIIlIIlllI[25]] = lIIIIlIIIlIll("RaqttuJoMRY=", "vxVYy");
    lIIIlIIlIlI[lIIIlIIlllI[30]] = lIIIIlIIIlIll("b9prbNMXcjw=", "qjFSo");
    lIIIlIIlIlI[lIIIlIIlllI[55]] = lIIIIlIIIlIll("C8LztTSYp5w=", "MVMtb");
    lIIIlIIlIlI[lIIIlIIlllI[56]] = lIIIIlIIIlIIl("tQlar9ZMaXI=", "atTYm");
    lIIIlIIlIlI[lIIIlIIlllI[24]] = lIIIIlIIIlIll("u881K/o7xKI=", "gOeRf");
    lIIIlIIlIlI[lIIIlIIlllI[57]] = lIIIIlIIIlIlI("", "NWTZQ");
  }
  
  private static boolean lIllIIlIIII(boolean llllllllllllllllIIlllIIIIlllllll) {
    if (lIIIIlIlIIIll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (-" ".length() >= (0x64 ^ 0x60))
        return (0x54 ^ 0x5E) & (0x42 ^ 0x48 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIIIlIIlllI[1];
  }
  
  public WinDancePigRain(BedWars llllllllllllllllIIlllIIIIIIllIlI, String llllllllllllllllIIlllIIIIIIllIII, int llllllllllllllllIIlllIIIIIIlIllI, Exception llllllllllllllllIIlllIIIIIIlIIll, long llllllllllllllllIIlllIIIIIIllIll) {
    super(llllllllllllllllIIlllIIIIIIlIllI, llllllllllllllllIIlllIIIIIIlIIll, llllllllllllllllIIlllIIIIIIllIll);
    this.plugin = llllllllllllllllIIlllIIIIIIllIlI;
    this.runnable = new HashMap<>();
    this.perTask = this.plugin.getWindances().getInt(String.valueOf((new StringBuilder()).append(lllIIIlIl[lllIIIllI[lIIIlIIlllI[1]]]).append(llllllllllllllllIIlllIIIIIIllIII).append(lllIIIlIl[lllIIIllI[lIIIlIIlllI[7]]])), lllIIIllI[lIIIlIIlllI[8]]);
    this.size = this.plugin.getWindances().getInt(String.valueOf((new StringBuilder()).append(lllIIIlIl[lllIIIllI[lIIIlIIlllI[4]]]).append(llllllllllllllllIIlllIIIIIIllIII).append(lllIIIlIl[lllIIIllI[lIIIlIIlllI[17]]])), lllIIIllI[lIIIlIIlllI[18]]);
  }
  
  private static String lIllIIIlIlI(float llllllllllllllllIIlllIIIIlIIlIlI, String llllllllllllllllIIlllIIIIlIlIIll) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlIlI : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   10: bipush #26
    //   12: iaload
    //   13: aaload
    //   14: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   17: aload_1
    //   18: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   21: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   24: invokevirtual digest : ([B)[B
    //   27: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lllIIIllI : [I
    //   30: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   33: bipush #35
    //   35: iaload
    //   36: iaload
    //   37: invokestatic copyOf : ([BI)[B
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlIlI : [Ljava/lang/String;
    //   43: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   46: bipush #28
    //   48: iaload
    //   49: aaload
    //   50: invokespecial <init> : ([BLjava/lang/String;)V
    //   53: astore_2
    //   54: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlIlI : [Ljava/lang/String;
    //   57: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   60: bipush #35
    //   62: iaload
    //   63: aaload
    //   64: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   67: astore_3
    //   68: aload_3
    //   69: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lllIIIllI : [I
    //   72: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   75: iconst_4
    //   76: iaload
    //   77: iaload
    //   78: aload_2
    //   79: invokevirtual init : (ILjava/security/Key;)V
    //   82: new java/lang/String
    //   85: dup
    //   86: aload_3
    //   87: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   90: aload_0
    //   91: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   94: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   97: invokevirtual decode : ([B)[B
    //   100: invokevirtual doFinal : ([B)[B
    //   103: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   106: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   109: areturn
    //   110: astore_2
    //   111: aload_2
    //   112: invokevirtual printStackTrace : ()V
    //   115: aconst_null
    //   116: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   54	56	2	llllllllllllllllIIlllIIIIlIIllII	Ljavax/crypto/spec/SecretKeySpec;
    //   0	117	2	llllllllllllllllIIlllIIIIlIIlllI	F
    //   68	42	3	llllllllllllllllIIlllIIIIlIlIIII	Ljavax/crypto/Cipher;
    //   0	117	1	llllllllllllllllIIlllIIIIlIIlIIl	Z
    //   0	117	1	llllllllllllllllIIlllIIIIlIlIIll	Ljava/lang/String;
    //   0	117	0	llllllllllllllllIIlllIIIIlIlIIlI	Ljava/lang/Exception;
    //   0	117	0	llllllllllllllllIIlllIIIIlIIlIlI	F
    //   0	117	0	llllllllllllllllIIlllIIIIlIIllIl	Ljava/lang/String;
    //   0	117	3	llllllllllllllllIIlllIIIIlIIIlll	B
    //   0	117	2	llllllllllllllllIIlllIIIIlIIlIII	J
    //   0	117	1	llllllllllllllllIIlllIIIIlIIlIll	C
    //   0	117	3	llllllllllllllllIIlllIIIIlIlIIIl	S
    //   111	4	2	llllllllllllllllIIlllIIIIlIIllll	Ljava/lang/Exception;
    // Exception table:
    //   from	to	target	type
    //   0	109	110	java/lang/Exception
  }
  
  private static void lIllIIIllII() {
    lllIIIlIl = new String[lllIIIllI[lIIIlIIlllI[28]]];
    lllIIIlIl[lllIIIllI[lIIIlIIlllI[1]]] = lIllIIIlIIl(lIIIlIIlIlI[lIIIlIIlllI[34]], lIIIlIIlIlI[lIIIlIIlllI[41]]);
    lllIIIlIl[lllIIIllI[lIIIlIIlllI[7]]] = lIllIIIlIlI(lIIIlIIlIlI[lIIIlIIlllI[42]], lIIIlIIlIlI[lIIIlIIlllI[43]]);
    lllIIIlIl[lllIIIllI[lIIIlIIlllI[4]]] = lIllIIIlIIl(lIIIlIIlIlI[lIIIlIIlllI[44]], lIIIlIIlIlI[lIIIlIIlllI[45]]);
    lllIIIlIl[lllIIIllI[lIIIlIIlllI[17]]] = lIllIIIlIll(lIIIlIIlIlI[lIIIlIIlllI[46]], lIIIlIIlIlI[lIIIlIIlllI[47]]);
    lllIIIlIl[lllIIIllI[lIIIlIIlllI[23]]] = lIllIIIlIlI(lIIIlIIlIlI[lIIIlIIlllI[2]], lIIIlIIlIlI[lIIIlIIlllI[48]]);
  }
  
  private static String lIIIIlIIIlIlI(long llllllllllllllllIIllIlllllIlIIII, int llllllllllllllllIIllIlllllIIlllI) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   40: iconst_1
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDancePigRain.lIIIlIIlllI : [I
    //   58: iconst_1
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic lIIIIlIlIIlll : (II)Z
    //   69: ifeq -> 132
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: bipush #79
    //   114: bipush #80
    //   116: ixor
    //   117: sipush #168
    //   120: sipush #183
    //   123: ixor
    //   124: iconst_m1
    //   125: ixor
    //   126: iand
    //   127: ifeq -> 62
    //   130: aconst_null
    //   131: areturn
    //   132: aload_2
    //   133: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   136: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   37	100	3	llllllllllllllllIIllIlllllIlIIlI	[C
    //   0	137	5	llllllllllllllllIIllIlllllIIlIll	Ljava/lang/Exception;
    //   44	93	4	llllllllllllllllIIllIlllllIlIIIl	I
    //   0	137	4	llllllllllllllllIIllIlllllIIllII	J
    //   32	105	2	llllllllllllllllIIllIlllllIlIIll	Ljava/lang/StringBuilder;
    //   0	137	6	llllllllllllllllIIllIlllllIIlIlI	F
    //   0	137	8	llllllllllllllllIIllIlllllIIlIII	S
    //   0	137	1	llllllllllllllllIIllIlllllIIllll	Ljava/lang/String;
    //   0	137	0	llllllllllllllllIIllIlllllIlIlIl	Ljava/lang/String;
    //   0	137	1	llllllllllllllllIIllIlllllIlIlII	Ljava/lang/String;
    //   0	137	3	llllllllllllllllIIllIlllllIIllIl	B
    //   0	137	7	llllllllllllllllIIllIlllllIIlIIl	D
    //   79	24	8	llllllllllllllllIIllIlllllIlIllI	C
    //   0	137	2	llllllllllllllllIIllIlllllIIlllI	I
    //   0	137	0	llllllllllllllllIIllIlllllIlIIII	J
  }
  
  private static boolean lIllIIIlllI(char llllllllllllllllIIlllIIIIllllIlI, char llllllllllllllllIIlllIIIIlllllII) {
    if (lIIIIlIlIIlII(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (" ".length() <= 0)
        return (0x7C ^ 0xC ^ 0x6 ^ 0x30) & (0 + 68 - -117 + 39 ^ 129 + 126 - 143 + 54 ^ -" ".length()); 
    } else {
    
    } 
    return lIIIlIIlllI[1];
  }
  
  private static void lIIIIlIlIIIlI() {
    lIIIlIIlllI = new int[58];
    lIIIlIIlllI[0] = 0x84 ^ 0x8E;
    lIIIlIIlllI[1] = " ".length() & (" ".length() ^ 0xFFFFFFFF);
    lIIIlIIlllI[2] = 42 + 175 - 142 + 133 ^ 170 + 20 - 123 + 131;
    lIIIlIIlllI[3] = 0x15 ^ 0x56 ^ 0xDC ^ 0xB6;
    lIIIlIIlllI[4] = "   ".length();
    lIIIlIIlllI[5] = 0x90 ^ 0xAC;
    lIIIlIIlllI[6] = -" ".length();
    lIIIlIIlllI[7] = " ".length();
    lIIIlIIlllI[8] = "  ".length();
    lIIIlIIlllI[9] = 0xB8 ^ 0x8A ^ 0x6F ^ 0x34;
    lIIIlIIlllI[10] = 0xA ^ 0x61;
    lIIIlIIlllI[11] = (0xA4 ^ 0xB4) + (0x38 ^ 0x75) - -(0xE3 ^ 0xC6) + (0x71 ^ 0x4D);
    lIIIlIIlllI[12] = 0x54 ^ 0x23;
    lIIIlIIlllI[13] = 0x30 ^ 0x5A;
    lIIIlIIlllI[14] = 166 + 73 - 65 + 61 ^ 84 + 14 - -69 + 26;
    lIIIlIIlllI[15] = 0xF7 ^ 0x93;
    lIIIlIIlllI[16] = 0x5B ^ 0x74 ^ 0xE5 ^ 0x9D;
    lIIIlIIlllI[17] = 0xA7 ^ 0xA3;
    lIIIlIIlllI[18] = 141 + 47 - 51 + 57 ^ 37 + 98 - 2 + 66;
    lIIIlIIlllI[19] = 0xF ^ 0x45;
    lIIIlIIlllI[20] = 0x5D ^ 0x6B ^ 0x8B ^ 0xA2;
    lIIIlIIlllI[21] = 222 + 33 - 94 + 69 + (0xC2 ^ 0x96) - (0x70 ^ 0x3F) + (0xC0 ^ 0xC4);
    lIIIlIIlllI[22] = (0x83 ^ 0xC5) + (0xBC ^ 0xB6) - (0x86 ^ 0xBF) + (0x6C ^ 0x1D);
    lIIIlIIlllI[23] = 0xB3 ^ 0xB5;
    lIIIlIIlllI[24] = 136 + 50 - 102 + 73 ^ 33 + 114 - 77 + 58;
    lIIIlIIlllI[25] = 0x24 ^ 0x79 ^ 0x71 ^ 0x35;
    lIIIlIIlllI[26] = 56 + 27 - 25 + 108 ^ 39 + 89 - 110 + 143;
    lIIIlIIlllI[27] = -" ".length() & 0xFFFFFFFF & Integer.MAX_VALUE;
    lIIIlIIlllI[28] = 0x3A ^ 0x64 ^ 0x28 ^ 0x7E;
    lIIIlIIlllI[29] = 0x36 ^ 0x14;
    lIIIlIIlllI[30] = 0x0 ^ 0x59 ^ 0xFA ^ 0xB9;
    lIIIlIIlllI[31] = 0x69 ^ 0x24;
    lIIIlIIlllI[32] = 0x78 ^ 0x33;
    lIIIlIIlllI[33] = 0x47 ^ 0x6;
    lIIIlIIlllI[34] = 0x1C ^ 0x12;
    lIIIlIIlllI[35] = 71 + 90 - -1 + 19 ^ 158 + 0 - 107 + 137;
    lIIIlIIlllI[36] = 0x41 ^ 0x8 ^ 0x56 ^ 0x61;
    lIIIlIIlllI[37] = 0x6D ^ 0x42 ^ 0xDC ^ 0x85;
    lIIIlIIlllI[38] = 0x54 ^ 0x5F;
    lIIIlIIlllI[39] = 52 + 8 - 37 + 104 ^ 0xFA ^ 0x89;
    lIIIlIIlllI[40] = 0x3E ^ 0x5F ^ 0xF4 ^ 0x98;
    lIIIlIIlllI[41] = 57 + 83 - 82 + 80 ^ 84 + 131 - 205 + 123;
    lIIIlIIlllI[42] = 0x67 ^ 0x77;
    lIIIlIIlllI[43] = 0x13 ^ 0x2;
    lIIIlIIlllI[44] = 0xAC ^ 0xBE;
    lIIIlIIlllI[45] = 0x7B ^ 0x59 ^ 0xB8 ^ 0x89;
    lIIIlIIlllI[46] = 0xD5 ^ 0xC1;
    lIIIlIIlllI[47] = 0xD6 ^ 0xC3;
    lIIIlIIlllI[48] = 0xD4 ^ 0xC1 ^ "  ".length();
    lIIIlIIlllI[49] = 82 + 107 - 68 + 8 ^ 58 + 43 - 66 + 118;
    lIIIlIIlllI[50] = 0x56 ^ 0x4D ^ 0xA ^ 0x49;
    lIIIlIIlllI[51] = 0x69 ^ 0x12;
    lIIIlIIlllI[52] = 0xBC ^ 0x92;
    lIIIlIIlllI[53] = 0x13 ^ 0x45;
    lIIIlIIlllI[54] = 0x50 ^ 0x60;
    lIIIlIIlllI[55] = 0xAA ^ 0xB1;
    lIIIlIIlllI[56] = 0xDB ^ 0xC7;
    lIIIlIIlllI[57] = 0x10 ^ 0x4A ^ 0x6B ^ 0x2F;
  }
  
  private static boolean lIIIIlIlIlIII(float llllllllllllllllIIllIllllIlIlIlI, double llllllllllllllllIIllIllllIlIlIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIIIIlIlIIllI(short llllllllllllllllIIllIllllIlIllIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > null);
  }
  
  private static boolean lIllIIIllll(boolean llllllllllllllllIIlllIIIIlIIIlIl) {
    if (lIIIIlIlIIlIl(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return (0x7 ^ 0x69 ^ 0x4 ^ 0x4F) & (91 + 125 - 137 + 85 ^ 86 + 76 - 154 + 121 ^ -" ".length()); 
    } else {
    
    } 
    return lIIIlIIlllI[1];
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\windances\WinDancePigRain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */