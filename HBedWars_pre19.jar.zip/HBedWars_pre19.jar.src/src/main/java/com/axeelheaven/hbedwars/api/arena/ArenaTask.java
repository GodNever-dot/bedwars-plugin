package com.axeelheaven.hbedwars.api.arena;

import org.bukkit.scheduler.BukkitRunnable;

public class ArenaTask extends BukkitRunnable {
    private int endSeconds;
    private boolean running;
    
    public ArenaTask() {
        this.endSeconds = 0;
        this.running = false;
    }
    
    @Override
    public void run() {
        if (!running) return;
        endSeconds++;
    }
    
    public void start() {
        this.running = true;
    }
    
    public void stop() {
        this.running = false;
    }
    
    public int getEndSeconds() {
        return endSeconds;
    }
    
    public boolean isRunning() {
        return running;
    }
} 