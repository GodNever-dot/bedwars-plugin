package com.axeelheaven.hbedwars.custom.sounds;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.configuration.HConfiguration;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SoundManager {
    private final BedWars plugin;
    private final Map<String, HSound> sounds;

    public SoundManager(BedWars plugin) {
        this.plugin = plugin;
        this.sounds = new HashMap<>();
        reload();
    }

    public void reload() {
        this.sounds.clear();
        HConfiguration config = this.plugin.getSounds();
        Iterator<String> iterator = config.getConfigurationSection("sounds").getKeys(false).iterator();
        while (iterator.hasNext()) {
            String key = iterator.next();
            String sound = config.getString("sounds." + key + ".sound");
            if (!this.plugin.getNmsInterface().isSound(sound)) {
                this.plugin.getUtil().console(ChatColor.RED + "Sound '" + key + "' with value '" + sound + "' is not valid!");
                continue;
            }
            float volume = (float)config.getDouble("sounds." + key + ".volume", 1.0D);
            float pitch = (float)config.getDouble("sounds." + key + ".pitch", 1.0D);
            this.sounds.put(key, new HSound(sound, volume, pitch));
        }
    }

    public void play(Player player, String name) {
        HSound sound = this.sounds.get(name);
        if (sound != null) {
            sound.play(player);
        }
    }

    public void play(Player player, String name, float volume, float pitch) {
        HSound sound = this.sounds.get(name);
        if (sound != null) {
            sound.play(player, volume, pitch);
        }
    }

    public Map<String, HSound> getSounds() {
        return this.sounds;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\sounds\SoundManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */