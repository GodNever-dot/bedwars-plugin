package com.axeelheaven.hbedwars.cosmetics.killeffects;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.libs.xseries.XMaterial;
import com.axeelheaven.hbedwars.libs.xseries.XSound;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.Effect;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;

public class KillEffectGhost extends KillEffect {
  public void execute(byte lllllllllllllllllIIlllIIlllIlIlI, Player lllllllllllllllllIIlllIIlllIllII) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface getLocation : ()Lorg/bukkit/Location;
    //   6: invokevirtual clone : ()Lorg/bukkit/Location;
    //   9: astore_3
    //   10: aload_3
    //   11: invokevirtual getWorld : ()Lorg/bukkit/World;
    //   14: aload_3
    //   15: invokevirtual clone : ()Lorg/bukkit/Location;
    //   18: dconst_0
    //   19: dconst_1
    //   20: dconst_0
    //   21: invokevirtual add : (DDD)Lorg/bukkit/Location;
    //   24: ldc org/bukkit/entity/ArmorStand
    //   26: invokeinterface spawn : (Lorg/bukkit/Location;Ljava/lang/Class;)Lorg/bukkit/entity/Entity;
    //   31: checkcast org/bukkit/entity/ArmorStand
    //   34: astore #4
    //   36: aload #4
    //   38: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIII : [Ljava/lang/String;
    //   41: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   44: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   47: iconst_0
    //   48: iaload
    //   49: iaload
    //   50: aaload
    //   51: new org/bukkit/metadata/FixedMetadataValue
    //   54: dup
    //   55: aload_0
    //   56: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   59: aload_0
    //   60: invokevirtual getId : ()Ljava/lang/String;
    //   63: invokespecial <init> : (Lorg/bukkit/plugin/Plugin;Ljava/lang/Object;)V
    //   66: invokeinterface setMetadata : (Ljava/lang/String;Lorg/bukkit/metadata/MetadataValue;)V
    //   71: aload #4
    //   73: invokeinterface getEquipment : ()Lorg/bukkit/inventory/EntityEquipment;
    //   78: aload_0
    //   79: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   82: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   85: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIII : [Ljava/lang/String;
    //   88: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   91: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   94: iconst_1
    //   95: iaload
    //   96: iaload
    //   97: aaload
    //   98: aload_1
    //   99: invokeinterface getName : ()Ljava/lang/String;
    //   104: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   107: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   110: iconst_1
    //   111: iaload
    //   112: iaload
    //   113: aload_1
    //   114: invokeinterface getName : ()Ljava/lang/String;
    //   119: invokevirtual getCustomHead : (Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Lorg/bukkit/inventory/ItemStack;
    //   122: invokeinterface setHelmet : (Lorg/bukkit/inventory/ItemStack;)V
    //   127: aload #4
    //   129: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   132: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   135: iconst_0
    //   136: iaload
    //   137: iaload
    //   138: invokeinterface setBasePlate : (Z)V
    //   143: aload #4
    //   145: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   148: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   151: iconst_1
    //   152: iaload
    //   153: iaload
    //   154: invokeinterface setCustomNameVisible : (Z)V
    //   159: aload #4
    //   161: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   164: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   167: iconst_0
    //   168: iaload
    //   169: iaload
    //   170: invokeinterface setGravity : (Z)V
    //   175: aload #4
    //   177: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   180: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   183: iconst_0
    //   184: iaload
    //   185: iaload
    //   186: invokeinterface setCanPickupItems : (Z)V
    //   191: aload #4
    //   193: new java/lang/StringBuilder
    //   196: dup
    //   197: invokespecial <init> : ()V
    //   200: getstatic org/bukkit/ChatColor.RED : Lorg/bukkit/ChatColor;
    //   203: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   206: aload_1
    //   207: invokeinterface getName : ()Ljava/lang/String;
    //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   215: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   218: invokeinterface setCustomName : (Ljava/lang/String;)V
    //   223: aload #4
    //   225: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   228: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   231: iconst_1
    //   232: iaload
    //   233: iaload
    //   234: invokeinterface setSmall : (Z)V
    //   239: aload #4
    //   241: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   244: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   247: iconst_0
    //   248: iaload
    //   249: iaload
    //   250: invokeinterface setVisible : (Z)V
    //   255: aload #4
    //   257: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   260: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   263: iconst_1
    //   264: iaload
    //   265: iaload
    //   266: invokeinterface setMarker : (Z)V
    //   271: aload #4
    //   273: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIIIl : [I
    //   276: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   279: iconst_2
    //   280: iaload
    //   281: iaload
    //   282: invokeinterface setNoDamageTicks : (I)V
    //   287: aload_0
    //   288: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   291: invokevirtual getServer : ()Lorg/bukkit/Server;
    //   294: invokeinterface getScheduler : ()Lorg/bukkit/scheduler/BukkitScheduler;
    //   299: aload_0
    //   300: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   303: aload #4
    //   305: <illegal opcode> run : (Lorg/bukkit/entity/ArmorStand;)Ljava/lang/Runnable;
    //   310: ldc2_w 100
    //   313: invokeinterface scheduleSyncDelayedTask : (Lorg/bukkit/plugin/Plugin;Ljava/lang/Runnable;J)I
    //   318: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIllIll : [Ljava/lang/String;
    //   321: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   324: iconst_4
    //   325: iaload
    //   326: aaload
    //   327: invokevirtual length : ()I
    //   330: pop2
    //   331: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   10	322	3	lllllllllllllllllIIlllIIllllIIll	Lorg/bukkit/Location;
    //   36	296	4	lllllllllllllllllIIlllIIlllIllIl	Lorg/bukkit/entity/ArmorStand;
    //   0	332	3	lllllllllllllllllIIlllIIllllIIlI	C
    //   0	332	3	lllllllllllllllllIIlllIIlllIlIIl	F
    //   0	332	1	lllllllllllllllllIIlllIIllllIIIl	Ljava/lang/String;
    //   0	332	2	lllllllllllllllllIIlllIIlllIllII	Lorg/bukkit/entity/Player;
    //   0	332	4	lllllllllllllllllIIlllIIlllIlIII	D
    //   0	332	0	lllllllllllllllllIIlllIIllllIIII	Lcom/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost;
    //   0	332	1	lllllllllllllllllIIlllIIlllIlIlI	B
    //   0	332	0	lllllllllllllllllIIlllIIlllIlIll	I
    //   0	332	0	lllllllllllllllllIIlllIIllllIlII	J
    //   0	332	1	lllllllllllllllllIIlllIIlllIllll	Lorg/bukkit/entity/Player;
    //   0	332	4	lllllllllllllllllIIlllIIlllIlllI	J
  }
  
  private static String lIIlllIIlI(String lllllllllllllllllIIlllIlIIlIIIIl, Exception lllllllllllllllllIIlllIlIIIllIlI) {
    String str = new String(Base64.getDecoder().decode(lllllllllllllllllIIlllIlIIlIIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIlllIlIIlIIlII = new StringBuilder();
    char[] lllllllllllllllllIIlllIlIIlIIIII = lllllllllllllllllIIlllIlIIIllIlI.toCharArray();
    int lllllllllllllllllIIlllIlIIIlllIl = llIlIIIl[llIlIlllII[0]];
    char[] arrayOfChar1 = str.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIlIIIl[llIlIlllII[0]];
    while (lIlllIllllII(lIIlllIlIl(j, i))) {
      char lllllllllllllllllIIlllIlIIlIlIIl = arrayOfChar1[j];
      llIlIllIll[llIlIlllII[0]].length();
      lllllllllllllllllIIlllIlIIIlllIl++;
      j++;
      "".length();
      if (lIlllIllllIl(llIlIllIll[llIlIlllII[2]].length(), llIlIlllII[3] ^ llIlIlllII[1]))
        return null; 
    } 
    return String.valueOf(lllllllllllllllllIIlllIlIIlIIlII);
  }
  
  private static void lIIlllIlII() {
    llIlIIIl = new int[llIlIlllII[3]];
    llIlIIIl[llIlIlllII[0]] = (llIlIlllII[8] + llIlIlllII[9] - llIlIlllII[10] + llIlIlllII[11] ^ llIlIlllII[3] + llIlIlllII[12] - llIlIlllII[13] + llIlIlllII[14]) & (llIlIlllII[15] ^ llIlIlllII[16] ^ llIlIlllII[17] ^ llIlIlllII[18] ^ -llIlIllIll[llIlIlllII[19]].length());
    llIlIIIl[llIlIlllII[1]] = llIlIllIll[llIlIlllII[20]].length();
    llIlIIIl[llIlIlllII[2]] = -llIlIllIll[llIlIlllII[21]].length() & llIlIlllII[22] & llIlIlllII[23];
    llIlIIIl[llIlIlllII[4]] = llIlIlllII[24] ^ llIlIlllII[25];
    llIlIIIl[llIlIlllII[5]] = llIlIllIll[llIlIlllII[26]].length();
  }
  
  public KillEffectGhost(BedWars lllllllllllllllllIIlllIlIIIIlIIl, String lllllllllllllllllIIlllIlIIIIIlII, boolean lllllllllllllllllIIlllIlIIIIIIII, byte lllllllllllllllllIIlllIIllllllll) {
    super(lllllllllllllllllIIlllIlIIIIIlII, lllllllllllllllllIIlllIlIIIIIIII, lllllllllllllllllIIlllIIllllllll);
    this.plugin = lllllllllllllllllIIlllIlIIIIlIIl;
  }
  
  private static String lIlllIlllIIl(String lllllllllllllllllIIlllIIllIllIIl, String lllllllllllllllllIIlllIIllIllIII) {
    String str = new String(Base64.getDecoder().decode(lllllllllllllllllIIlllIIllIllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIlllIIllIlIlll = new StringBuilder();
    char[] lllllllllllllllllIIlllIIllIlIllI = lllllllllllllllllIIlllIIllIllIII.toCharArray();
    int lllllllllllllllllIIlllIIllIlIlIl = llIlIlllII[0];
    char[] arrayOfChar1 = str.toCharArray();
    int i = arrayOfChar1.length;
    lllllllllllllllllIIlllIIllIIllIl = llIlIlllII[0];
    while (lIlllIlllllI(lllllllllllllllllIIlllIIllIIllIl, i)) {
      char lllllllllllllllllIIlllIIllIllIlI = arrayOfChar1[lllllllllllllllllIIlllIIllIIllIl];
      "".length();
      lllllllllllllllllIIlllIIllIlIlIl++;
      lllllllllllllllllIIlllIIllIIllIl++;
      "".length();
      if (((0x2 ^ 0x5E) & (0x67 ^ 0x3B ^ 0xFFFFFFFF)) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllllIIlllIIllIlIlll);
  }
  
  private static boolean lIIlllIlIl(char lllllllllllllllllIIlllIIllllllII, Exception lllllllllllllllllIIlllIIlllllIIl) {
    if (lIlllIlllllI(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (((0x59 ^ 0x6) & (0x46 ^ 0x19 ^ 0xFFFFFFFF)) < ((0x16 ^ 0x4A) & (0x69 ^ 0x35 ^ 0xFFFFFFFF)))
        return (0x6F ^ 0x2A) & (0xFB ^ 0xBE ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIlIlllII[0];
  }
  
  private static boolean lIlllIlllllI(char lllllllllllllllllIIlllIIlIlIlIll, char lllllllllllllllllIIlllIIlIlIlIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  static {
    lIlllIlllIll();
    lIlllIlllIlI();
    lIIlllIlII();
    lIIlllIIll();
  }
  
  private static void lIlllIlllIlI() {
    llIlIllIll = new String[llIlIlllII[27]];
    llIlIllIll[llIlIlllII[0]] = lIlllIllIlll("reVr3Qlb5Fo=", "fXZab");
    llIlIllIll[llIlIlllII[1]] = lIlllIlllIII("9x2aC8cR4F8=", "JSRvY");
    llIlIllIll[llIlIlllII[2]] = lIlllIllIlll("ry+XrK2RfqM=", "GLkFI");
    llIlIllIll[llIlIlllII[4]] = lIlllIlllIII("EGMKEhJz4o8=", "FqqDo");
    llIlIllIll[llIlIlllII[5]] = lIlllIlllIII("JTx2pw2yPStNwDUwkGSa4XNzsCBgdE7B", "trzed");
    llIlIllIll[llIlIlllII[3]] = lIlllIllIlll("0jRu/RzJI6c=", "RgkTn");
    llIlIllIll[llIlIlllII[6]] = lIlllIlllIII("XbrPEvo565ineBCIZCwvyQ==", "Pradw");
    llIlIllIll[llIlIlllII[7]] = lIlllIlllIII("QW2VwLgxpDo=", "FASqX");
    llIlIllIll[llIlIlllII[19]] = lIlllIlllIII("JgsEgpkrZGk=", "oxzue");
    llIlIllIll[llIlIlllII[20]] = lIlllIllIlll("nbA0+CLFtTk=", "QUaba");
    llIlIllIll[llIlIlllII[21]] = lIlllIlllIIl("Zg==", "FYHIp");
    llIlIllIll[llIlIlllII[26]] = lIlllIllIlll("xEVx0eaCxcU=", "LuzEW");
  }
  
  private static String lIlllIlllIII(String lllllllllllllllllIIlllIIlIllIlll, String lllllllllllllllllIIlllIIlIllIllI) {
    try {
      SecretKeySpec lllllllllllllllllIIlllIIlIlllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIlllIIlIllIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIIlllIIlIlllIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllllIIlllIIlIlllIIl.init(llIlIlllII[2], lllllllllllllllllIIlllIIlIlllIlI);
      return new String(lllllllllllllllllIIlllIIlIlllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIlllIIlIllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIIlllIIlIlllIII) {
      lllllllllllllllllIIlllIIlIlllIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIlllIlllIll() {
    llIlIlllII = new int[28];
    llIlIlllII[0] = (0x62 ^ 0x69) & (0x7F ^ 0x74 ^ 0xFFFFFFFF);
    llIlIlllII[1] = " ".length();
    llIlIlllII[2] = "  ".length();
    llIlIlllII[3] = 0x54 ^ 0x51;
    llIlIlllII[4] = "   ".length();
    llIlIlllII[5] = 0x13 ^ 0xC ^ 0xDC ^ 0xC7;
    llIlIlllII[6] = 0xBA ^ 0xBC;
    llIlIlllII[7] = 27 + 9 - -32 + 89 ^ 130 + 43 - 34 + 15;
    llIlIlllII[8] = 0x4E ^ 0xE ^ 0x1A ^ 0x4F;
    llIlIlllII[9] = 0x78 ^ 0x5A;
    llIlIlllII[10] = -(0x81 ^ 0xC7 ^ 0x6B ^ 0x56);
    llIlIlllII[11] = 0x7F ^ 0x4A;
    llIlIlllII[12] = 94 + 115 - 6 + 33 ^ 23 + 56 - 12 + 61;
    llIlIlllII[13] = -(0x75 ^ 0x2 ^ 0xE ^ 0x70);
    llIlIlllII[14] = 0x7E ^ 0x41 ^ 0x42 ^ 0x3C;
    llIlIlllII[15] = 0x15 ^ 0x39;
    llIlIlllII[16] = 0x7C ^ 0x36;
    llIlIlllII[17] = 0xF ^ 0x7A ^ 0x51 ^ 0x38;
    llIlIlllII[18] = 58 + 84 - 37 + 25 ^ 5 + 65 - -40 + 54;
    llIlIlllII[19] = 0x9B ^ 0x8C ^ 0xA8 ^ 0xB7;
    llIlIlllII[20] = 0x71 ^ 0x78;
    llIlIlllII[21] = 0x98 ^ 0x92;
    llIlIlllII[22] = -" ".length();
    llIlIlllII[23] = -" ".length() & 0xFFFFFFFF & Integer.MAX_VALUE;
    llIlIlllII[24] = (0x62 ^ 0x56) + (0x6D ^ 0x1B) - (0x8D ^ 0xB6) + (0xD5 ^ 0x8A);
    llIlIlllII[25] = (0x1B ^ 0x22) + (0xF ^ 0x43) - (0x4E ^ 0xE) + 101 + 39 - 124 + 111;
    llIlIlllII[26] = 0x2F ^ 0x30 ^ 0x2D ^ 0x39;
    llIlIlllII[27] = 167 + 170 - 208 + 47 ^ 143 + 137 - 185 + 93;
  }
  
  private static void lIIlllIIll() {
    llIlIIII = new String[llIlIIIl[llIlIlllII[5]]];
    llIlIIII[llIlIIIl[llIlIlllII[0]]] = lIIlllIIlI(llIlIllIll[llIlIlllII[5]], llIlIllIll[llIlIlllII[3]]);
    llIlIIII[llIlIIIl[llIlIlllII[1]]] = lIIlllIIlI(llIlIllIll[llIlIlllII[6]], llIlIllIll[llIlIlllII[7]]);
  }
  
  private static String lIlllIllIlll(String lllllllllllllllllIIlllIIllIIIIlI, long lllllllllllllllllIIlllIIllIIIIIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   23: bipush #19
    //   25: iaload
    //   26: invokestatic copyOf : ([BI)[B
    //   29: ldc_w 'DES'
    //   32: invokespecial <init> : ([BLjava/lang/String;)V
    //   35: astore_2
    //   36: ldc_w 'DES'
    //   39: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   42: astore_3
    //   43: aload_3
    //   44: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectGhost.llIlIlllII : [I
    //   47: iconst_2
    //   48: iaload
    //   49: aload_2
    //   50: invokevirtual init : (ILjava/security/Key;)V
    //   53: new java/lang/String
    //   56: dup
    //   57: aload_3
    //   58: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   61: aload_0
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   68: invokevirtual decode : ([B)[B
    //   71: invokevirtual doFinal : ([B)[B
    //   74: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   77: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   80: areturn
    //   81: astore_2
    //   82: aload_2
    //   83: invokevirtual printStackTrace : ()V
    //   86: aconst_null
    //   87: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   43	38	3	lllllllllllllllllIIlllIIllIIIllI	Ljavax/crypto/Cipher;
    //   0	88	0	lllllllllllllllllIIlllIIllIIIlII	Ljava/lang/String;
    //   0	88	0	lllllllllllllllllIIlllIIllIIIIlI	Ljava/lang/String;
    //   0	88	2	lllllllllllllllllIIlllIIllIIIIII	I
    //   0	88	3	lllllllllllllllllIIlllIIlIllllll	C
    //   36	45	2	lllllllllllllllllIIlllIIllIIIlll	Ljavax/crypto/spec/SecretKeySpec;
    //   0	88	1	lllllllllllllllllIIlllIIllIIIIll	Ljava/lang/String;
    //   0	88	1	lllllllllllllllllIIlllIIllIIIIIl	J
    //   82	4	2	lllllllllllllllllIIlllIIllIIIlIl	Ljava/lang/Exception;
    // Exception table:
    //   from	to	target	type
    //   0	80	81	java/lang/Exception
  }
  
  private static boolean lIlllIllllIl(boolean lllllllllllllllllIIlllIIlIlIllll, double lllllllllllllllllIIlllIIlIlIlllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIlllIllllII(char lllllllllllllllllIIlllIIlIlIlIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\killeffects\KillEffectGhost.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */