package com.axeelheaven.hbedwars.cosmetics.shopkeeper;

import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.Map;

public class ShopKeeperManager {
    private final BedWars plugin;
    private final Map<String, ShopKeeper> shopKeepers;
    
    public ShopKeeperManager(BedWars plugin) {
        this.plugin = plugin;
        this.shopKeepers = new HashMap<>();
    }
    
    public void registerShopKeeper(String id, ShopKeeper shopKeeper) {
        this.shopKeepers.put(id, shopKeeper);
    }
    
    public ShopKeeper getShopKeeper(String id) {
        return this.shopKeepers.get(id);
    }
    
    public void spawnShopKeeper(Location location, String id) {
        ShopKeeper shopKeeper = getShopKeeper(id);
        if (shopKeeper != null) {
            Entity entity = location.getWorld().spawnEntity(location, EntityType.VILLAGER);
            shopKeeper.apply(entity);
        }
    }
    
    public Map<String, ShopKeeper> getShopKeepers() {
        return this.shopKeepers;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\shopkeeper\ShopKeeperManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */