/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LCSParams
/*    */   implements IParams
/*    */ {
/*    */   private boolean len = false;
/*    */   private boolean idx = false;
/*    */   private Long minMatchLen;
/*    */   private boolean withMatchLen = false;
/*    */   
/*    */   public static LCSParams LCSParams() {
/* 17 */     return new LCSParams();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LCSParams len() {
/* 24 */     this.len = true;
/* 25 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LCSParams idx() {
/* 35 */     this.idx = true;
/* 36 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LCSParams minMatchLen(long minMatchLen) {
/* 44 */     this.minMatchLen = Long.valueOf(minMatchLen);
/* 45 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LCSParams withMatchLen() {
/* 53 */     this.withMatchLen = true;
/* 54 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 59 */     if (this.len) {
/* 60 */       args.add(Protocol.Keyword.LEN);
/*    */     }
/* 62 */     if (this.idx) {
/* 63 */       args.add(Protocol.Keyword.IDX);
/*    */     }
/* 65 */     if (this.minMatchLen != null) {
/* 66 */       args.add(Protocol.Keyword.MINMATCHLEN).add(this.minMatchLen);
/*    */     }
/* 68 */     if (this.withMatchLen)
/* 69 */       args.add(Protocol.Keyword.WITHMATCHLEN); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\LCSParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */