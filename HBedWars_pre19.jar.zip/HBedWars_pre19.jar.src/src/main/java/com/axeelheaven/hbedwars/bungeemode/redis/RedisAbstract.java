package com.axeelheaven.hbedwars.bungeemode.redis;

import com.axeelheaven.hbedwars.libs.jedis.jedis.JedisPubSub;

public abstract class RedisAbstract extends JedisPubSub {
  public abstract void onMessage(String paramString1, String paramString2);
  
  static {
  
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\bungeemode\redis\RedisAbstract.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */