/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.executors;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandObject;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Connection;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisConnectionException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.providers.ConnectionProvider;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.IOUtils;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.Logger;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.LoggerFactory;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class RetryableCommandExecutor
/*     */   implements CommandExecutor
/*     */ {
/*  18 */   private final Logger log = LoggerFactory.getLogger(getClass());
/*     */   
/*     */   protected final ConnectionProvider provider;
/*     */   
/*     */   protected final int maxAttempts;
/*     */   protected final Duration maxTotalRetriesDuration;
/*     */   
/*     */   public RetryableCommandExecutor(ConnectionProvider provider, int maxAttempts, Duration maxTotalRetriesDuration) {
/*  26 */     this.provider = provider;
/*  27 */     this.maxAttempts = maxAttempts;
/*  28 */     this.maxTotalRetriesDuration = maxTotalRetriesDuration;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  33 */     IOUtils.closeQuietly((AutoCloseable)this.provider);
/*     */   }
/*     */ 
/*     */   
/*     */   public final <T> T executeCommand(CommandObject<T> commandObject) {
/*     */     JedisConnectionException jedisConnectionException;
/*  39 */     Instant deadline = Instant.now().plus(this.maxTotalRetriesDuration);
/*     */     
/*  41 */     int consecutiveConnectionFailures = 0;
/*  42 */     JedisException lastException = null;
/*  43 */     for (int attemptsLeft = this.maxAttempts; attemptsLeft > 0; attemptsLeft--) {
/*  44 */       Connection connection = null;
/*     */       try {
/*  46 */         connection = this.provider.getConnection(commandObject.getArguments());
/*     */         
/*  48 */         return (T)connection.executeCommand(commandObject);
/*     */       }
/*  50 */       catch (JedisConnectionException jce) {
/*  51 */         jedisConnectionException = jce;
/*  52 */         consecutiveConnectionFailures++;
/*  53 */         this.log.debug("Failed connecting to Redis: {}", connection, jce);
/*     */         
/*  55 */         boolean reset = handleConnectionProblem(attemptsLeft - 1, consecutiveConnectionFailures, deadline);
/*  56 */         if (reset) {
/*  57 */           consecutiveConnectionFailures = 0;
/*     */         }
/*     */       } finally {
/*  60 */         if (connection != null) {
/*  61 */           connection.close();
/*     */         }
/*     */       } 
/*  64 */       if (Instant.now().isAfter(deadline)) {
/*  65 */         throw new JedisException("Cluster retry deadline exceeded.");
/*     */       }
/*     */     } 
/*     */     
/*  69 */     JedisException maxAttemptsException = new JedisException("No more cluster attempts left.");
/*  70 */     maxAttemptsException.addSuppressed((Throwable)jedisConnectionException);
/*  71 */     throw maxAttemptsException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean handleConnectionProblem(int attemptsLeft, int consecutiveConnectionFailures, Instant doneDeadline) {
/*  85 */     if (consecutiveConnectionFailures < 2) {
/*  86 */       return false;
/*     */     }
/*     */     
/*  89 */     sleep(getBackoffSleepMillis(attemptsLeft, doneDeadline));
/*  90 */     return true;
/*     */   }
/*     */   
/*     */   private static long getBackoffSleepMillis(int attemptsLeft, Instant deadline) {
/*  94 */     if (attemptsLeft <= 0) {
/*  95 */       return 0L;
/*     */     }
/*     */     
/*  98 */     long millisLeft = Duration.between(Instant.now(), deadline).toMillis();
/*  99 */     if (millisLeft < 0L) {
/* 100 */       throw new JedisException("Cluster retry deadline exceeded.");
/*     */     }
/*     */     
/* 103 */     return millisLeft / (attemptsLeft * (attemptsLeft + 1));
/*     */   }
/*     */   
/*     */   protected void sleep(long sleepMillis) {
/*     */     try {
/* 108 */       TimeUnit.MILLISECONDS.sleep(sleepMillis);
/* 109 */     } catch (InterruptedException e) {
/* 110 */       throw new JedisException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\executors\RetryableCommandExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */