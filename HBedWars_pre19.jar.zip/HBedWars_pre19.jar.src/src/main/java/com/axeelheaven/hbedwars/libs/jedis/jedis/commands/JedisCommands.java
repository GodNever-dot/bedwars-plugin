package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

public interface JedisCommands extends KeyCommands, StringCommands, ListCommands, HashCommands, SetCommands, SortedSetCommands, GeoCommands, HyperLogLogCommands, StreamCommands, ScriptingKeyCommands, FunctionCommands {}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\JedisCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */