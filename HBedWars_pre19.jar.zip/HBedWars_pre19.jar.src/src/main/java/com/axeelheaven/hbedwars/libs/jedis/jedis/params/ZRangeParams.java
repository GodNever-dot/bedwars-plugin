/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.Rawable;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.RawableFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZRangeParams
/*     */   implements IParams
/*     */ {
/*     */   private final Protocol.Keyword by;
/*     */   private final Rawable min;
/*     */   private final Rawable max;
/*     */   private boolean rev = false;
/*     */   private boolean limit = false;
/*     */   private int offset;
/*     */   private int count;
/*     */   
/*     */   private ZRangeParams() {
/*  25 */     throw new InstantiationError("Empty constructor must not be called.");
/*     */   }
/*     */   
/*     */   public ZRangeParams(int min, int max) {
/*  29 */     this.by = null;
/*  30 */     this.min = RawableFactory.from(min);
/*  31 */     this.max = RawableFactory.from(max);
/*     */   }
/*     */   
/*     */   public static ZRangeParams zrangeParams(int min, int max) {
/*  35 */     return new ZRangeParams(min, max);
/*     */   }
/*     */   
/*     */   public ZRangeParams(double min, double max) {
/*  39 */     this.by = Protocol.Keyword.BYSCORE;
/*  40 */     this.min = RawableFactory.from(min);
/*  41 */     this.max = RawableFactory.from(max);
/*     */   }
/*     */   
/*     */   public static ZRangeParams zrangeByScoreParams(double min, double max) {
/*  45 */     return new ZRangeParams(min, max);
/*     */   }
/*     */   
/*     */   private ZRangeParams(Protocol.Keyword by, Rawable min, Rawable max) {
/*  49 */     if (by == null || by == Protocol.Keyword.BYSCORE || by == Protocol.Keyword.BYLEX) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  54 */       this.by = by;
/*  55 */       this.min = min;
/*  56 */       this.max = max;
/*     */       return;
/*     */     } 
/*     */     throw new IllegalArgumentException(by.name() + " is not a valid ZRANGE type argument."); } public ZRangeParams(Protocol.Keyword by, String min, String max) {
/*  60 */     this(by, RawableFactory.from(min), RawableFactory.from(max));
/*     */   }
/*     */   
/*     */   public ZRangeParams(Protocol.Keyword by, byte[] min, byte[] max) {
/*  64 */     this(by, RawableFactory.from(min), RawableFactory.from(max));
/*     */   }
/*     */   
/*     */   public static ZRangeParams zrangeByLexParams(String min, String max) {
/*  68 */     return new ZRangeParams(Protocol.Keyword.BYLEX, min, max);
/*     */   }
/*     */   
/*     */   public static ZRangeParams zrangeByLexParams(byte[] min, byte[] max) {
/*  72 */     return new ZRangeParams(Protocol.Keyword.BYLEX, min, max);
/*     */   }
/*     */   
/*     */   public ZRangeParams rev() {
/*  76 */     this.rev = true;
/*  77 */     return this;
/*     */   }
/*     */   
/*     */   public ZRangeParams limit(int offset, int count) {
/*  81 */     this.limit = true;
/*  82 */     this.offset = offset;
/*  83 */     this.count = count;
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParams(CommandArguments args) {
/*  90 */     args.add(this.min).add(this.max);
/*  91 */     if (this.by != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  97 */       args.add(this.by);
/*     */     }
/*     */     
/* 100 */     if (this.rev) {
/* 101 */       args.add(Protocol.Keyword.REV);
/*     */     }
/*     */     
/* 104 */     if (this.limit)
/* 105 */       args.add(Protocol.Keyword.LIMIT).add(Integer.valueOf(this.offset)).add(Integer.valueOf(this.count)); 
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\ZRangeParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */