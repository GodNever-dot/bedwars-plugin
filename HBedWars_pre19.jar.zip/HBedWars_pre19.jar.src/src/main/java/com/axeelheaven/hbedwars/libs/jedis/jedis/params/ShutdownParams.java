/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.SaveMode;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ 
/*    */ public class ShutdownParams
/*    */   implements IParams {
/*    */   private SaveMode saveMode;
/*    */   private boolean now;
/*    */   private boolean force;
/*    */   
/*    */   public static ShutdownParams shutdownParams() {
/* 15 */     return new ShutdownParams();
/*    */   }
/*    */   
/*    */   public ShutdownParams saveMode(SaveMode saveMode) {
/* 19 */     this.saveMode = saveMode;
/* 20 */     return this;
/*    */   }
/*    */   
/*    */   public ShutdownParams nosave() {
/* 24 */     return saveMode(SaveMode.NOSAVE);
/*    */   }
/*    */   
/*    */   public ShutdownParams save() {
/* 28 */     return saveMode(SaveMode.SAVE);
/*    */   }
/*    */   
/*    */   public ShutdownParams now() {
/* 32 */     this.now = true;
/* 33 */     return this;
/*    */   }
/*    */   
/*    */   public ShutdownParams force() {
/* 37 */     this.force = true;
/* 38 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 44 */     if (this.saveMode != null) {
/* 45 */       args.add(SafeEncoder.encode(this.saveMode.getRaw()));
/*    */     }
/*    */     
/* 48 */     if (this.now) {
/* 49 */       args.add(Protocol.Keyword.NOW.getRaw());
/*    */     }
/*    */     
/* 52 */     if (this.force)
/* 53 */       args.add(Protocol.Keyword.FORCE.getRaw()); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\ShutdownParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */