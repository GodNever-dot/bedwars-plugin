package com.axeelheaven.hbedwars.custom.npc;

import com.mojang.authlib.GameProfile;
import java.util.HashMap;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public interface NPC {
  void spawn(Location location);
  
  void destroy();
  
  void show(Player player);
  
  void hide(Player player);
  
  void setName(String name);
  
  String getName();
  
  Location getLocation();
  
  boolean isSpawned();
  
  int getId();
  
  void delete(Player paramPlayer);
  
  void display(Player paramPlayer, GameProfile paramGameProfile);
  
  List<Player> getRender();
  
  void setLocation(Location paramLocation);
  
  void display(Player paramPlayer);
  
  boolean isLookPlayer();
  
  void lookAt(Player paramPlayer);
  
  HashMap<String, Object> getData();
  
  void despawn();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\npc\NPC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */