package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.BitCountOption;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.BitOP;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.BitPosParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GetExParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.LCSParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.SetParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.StrAlgoLCSParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LCSMatchResult;
import java.util.List;

public interface StringPipelineBinaryCommands {
  Response<String> set(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  Response<String> set(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, SetParams paramSetParams);
  
  Response<byte[]> get(byte[] paramArrayOfbyte);
  
  Response<byte[]> getDel(byte[] paramArrayOfbyte);
  
  Response<byte[]> getEx(byte[] paramArrayOfbyte, GetExParams paramGetExParams);
  
  Response<Boolean> setbit(byte[] paramArrayOfbyte, long paramLong, boolean paramBoolean);
  
  Response<Boolean> getbit(byte[] paramArrayOfbyte, long paramLong);
  
  Response<Long> setrange(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2);
  
  Response<byte[]> getrange(byte[] paramArrayOfbyte, long paramLong1, long paramLong2);
  
  Response<byte[]> getSet(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  Response<Long> setnx(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  Response<String> setex(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2);
  
  Response<String> psetex(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2);
  
  Response<List<byte[]>> mget(byte[]... paramVarArgs);
  
  Response<String> mset(byte[]... paramVarArgs);
  
  Response<Long> msetnx(byte[]... paramVarArgs);
  
  Response<Long> incr(byte[] paramArrayOfbyte);
  
  Response<Long> incrBy(byte[] paramArrayOfbyte, long paramLong);
  
  Response<Double> incrByFloat(byte[] paramArrayOfbyte, double paramDouble);
  
  Response<Long> decr(byte[] paramArrayOfbyte);
  
  Response<Long> decrBy(byte[] paramArrayOfbyte, long paramLong);
  
  Response<Long> append(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  Response<byte[]> substr(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  Response<Long> strlen(byte[] paramArrayOfbyte);
  
  Response<Long> bitcount(byte[] paramArrayOfbyte);
  
  Response<Long> bitcount(byte[] paramArrayOfbyte, long paramLong1, long paramLong2);
  
  Response<Long> bitcount(byte[] paramArrayOfbyte, long paramLong1, long paramLong2, BitCountOption paramBitCountOption);
  
  Response<Long> bitpos(byte[] paramArrayOfbyte, boolean paramBoolean);
  
  Response<Long> bitpos(byte[] paramArrayOfbyte, boolean paramBoolean, BitPosParams paramBitPosParams);
  
  Response<List<Long>> bitfield(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  Response<List<Long>> bitfieldReadonly(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  Response<Long> bitop(BitOP paramBitOP, byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  @Deprecated
  Response<LCSMatchResult> strAlgoLCSKeys(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, StrAlgoLCSParams paramStrAlgoLCSParams);
  
  Response<LCSMatchResult> lcs(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, LCSParams paramLCSParams);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\StringPipelineBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */