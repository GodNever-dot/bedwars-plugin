package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import java.util.List;

public interface SampleKeyedPipelineCommands {
  Response<Long> waitReplicas(String paramString, int paramInt, long paramLong);
  
  Response<Object> eval(String paramString1, String paramString2);
  
  Response<Object> evalsha(String paramString1, String paramString2);
  
  Response<List<Boolean>> scriptExists(String paramString, String... paramVarArgs);
  
  Response<String> scriptLoad(String paramString1, String paramString2);
  
  Response<String> scriptFlush(String paramString);
  
  Response<String> scriptFlush(String paramString, FlushMode paramFlushMode);
  
  Response<String> scriptKill(String paramString);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\SampleKeyedPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */