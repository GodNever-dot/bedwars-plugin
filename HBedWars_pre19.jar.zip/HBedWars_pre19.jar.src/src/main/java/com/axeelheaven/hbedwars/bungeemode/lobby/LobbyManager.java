package com.axeelheaven.hbedwars.bungeemode.lobby;

import com.axeelheaven.hbedwars.api.arena.GameState;
import com.axeelheaven.hbedwars.bungeemode.redis.RedisMessenger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.Location;

public class LobbyManager {
  private static boolean lIIIIIllIIll(Exception lllllllllllllllIllIlIllllIIIIlII) {
    if (lIlIIlIlIIlll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ("   ".length() < " ".length())
        return (0xC0 ^ 0x96) & (0x7E ^ 0x28 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIlIIIIllIl[1];
  }
  
  private static boolean lIIIIIllIIIl(String lllllllllllllllIllIlIllllllllllI, Exception lllllllllllllllIllIlIllllllllIll) {
    if (lIlIIlIlIIIIl(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (((0x5A ^ 0x2C ^ 0x51 ^ 0x72) & (51 + 49 - 72 + 122 ^ 41 + 130 - 67 + 91 ^ -" ".length())) >= "   ".length())
        return (0x3F ^ 0x70 ^ 0xC9 ^ 0x8B) & (93 + 74 - 143 + 106 ^ 27 + 70 - 30 + 76 ^ -" ".length()); 
    } else {
    
    } 
    return lIlIIIIllIl[1];
  }
  
  private static void lIlIIlIIllllI() {
    lIlIIIIllIl = new int[101];
    lIlIIIIllIl[0] = " ".length();
    lIlIIIIllIl[1] = (63 + 107 - 49 + 68 ^ 125 + 83 - 195 + 125) & (0x41 ^ 0x6 ^ 0xEF ^ 0x9F ^ -" ".length());
    lIlIIIIllIl[2] = 0x1C ^ 0x74;
    lIlIIIIllIl[3] = 40 + 40 - -25 + 40;
    lIlIIIIllIl[4] = 0x45 ^ 0x12;
    lIlIIIIllIl[5] = 0x7D ^ 0x26 ^ 0xDD ^ 0xA1;
    lIlIIIIllIl[6] = 0x73 ^ 0x7 ^ 0x3 ^ 0x44;
    lIlIIIIllIl[7] = 0xD4 ^ 0xBA ^ 0xD6 ^ 0xBE;
    lIlIIIIllIl[8] = -(0xB4 ^ 0x91 ^ 119 + 38 - 60 + 30);
    lIlIIIIllIl[9] = 0xAA ^ 0x91;
    lIlIIIIllIl[10] = 0x27 ^ 0x28 ^ 0x23 ^ 0xC;
    lIlIIIIllIl[11] = -(46 + 27 - 70 + 137 ^ 44 + 73 - 13 + 67);
    lIlIIIIllIl[12] = 0xE6 ^ 0x8F ^ 0x6 ^ 0x28;
    lIlIIIIllIl[13] = 0x11 ^ 0x1C ^ 0x4 ^ 0x40;
    lIlIIIIllIl[14] = 0xFD ^ 0x8F;
    lIlIIIIllIl[15] = (0xB9 ^ 0x96) + (0x4D ^ 0x47) - -(0xFF ^ 0xBC) + (0x28 ^ 0x1C);
    lIlIIIIllIl[16] = 92 + 118 - 128 + 55;
    lIlIIIIllIl[17] = "  ".length();
    lIlIIIIllIl[18] = 0x2A ^ 0x24;
    lIlIIIIllIl[19] = 0x5E ^ 0x10 ^ 0x3C ^ 0x6F;
    lIlIIIIllIl[20] = 0xE6 ^ 0x90;
    lIlIIIIllIl[21] = 215 + 142 - 197 + 71 ^ 102 + 95 - 47 + 43;
    lIlIIIIllIl[22] = 0xC7 ^ 0xBE ^ 0xA6 ^ 0x9C;
    lIlIIIIllIl[23] = 0x5D ^ 0x1F;
    lIlIIIIllIl[24] = 155 + 168 - 190 + 45;
    lIlIIIIllIl[25] = (0x49 ^ 0x11) + (0xE4 ^ 0x96) - (0x15 ^ 0x48) + (0x93 ^ 0x89);
    lIlIIIIllIl[26] = 0x98 ^ 0x8B;
    lIlIIIIllIl[27] = 65 + 22 - 47 + 91 + (0x6B ^ 0x7C) - (0x2C ^ 0x6) + (0xDE ^ 0xC4);
    lIlIIIIllIl[28] = 111 + 131 - 110 + 17;
    lIlIIIIllIl[29] = "   ".length();
    lIlIIIIllIl[30] = 96 + 101 - 190 + 163 ^ 169 + 140 - 259 + 124;
    lIlIIIIllIl[31] = 0x8B ^ 0x8E;
    lIlIIIIllIl[32] = 56 + 81 - 109 + 122 ^ 69 + 82 - 145 + 169;
    lIlIIIIllIl[33] = 0x60 ^ 0x7E;
    lIlIIIIllIl[34] = 0xBF ^ 0x8F ^ 0x68 ^ 0x67;
    lIlIIIIllIl[35] = 0x10 ^ 0xC;
    lIlIIIIllIl[36] = 132 + 27 - 88 + 81;
    lIlIIIIllIl[37] = (0x25 ^ 0x5F) + (0x9B ^ 0x8C) - 42 + 93 - 97 + 97 + (0xF5 ^ 0x82);
    lIlIIIIllIl[38] = (0x2C ^ 0x39) + (0x23 ^ 0x73) - (0xC7 ^ 0x9C) + 96 + 8 - -45 + 8;
    lIlIIIIllIl[39] = 0x2A ^ 0x67 ^ 0x94 ^ 0xAE;
    lIlIIIIllIl[40] = (0x6B ^ 0x42) + 159 + 12 - 170 + 177 - (0xB ^ 0x79) + (0xD1 ^ 0x9B);
    lIlIIIIllIl[41] = 140 + 102 - 133 + 60 ^ 119 + 18 - 72 + 109;
    lIlIIIIllIl[42] = 0xA5 ^ 0x98 ^ 0x58 ^ 0x2;
    lIlIIIIllIl[43] = 194 + 37 - 29 + 39 ^ 22 + 47 - 61 + 129;
    lIlIIIIllIl[44] = 0xCA ^ 0x95;
    lIlIIIIllIl[45] = 0xDC ^ 0xA6;
    lIlIIIIllIl[46] = 94 + 116 - 132 + 50;
    lIlIIIIllIl[47] = 0x8C ^ 0xB2;
    lIlIIIIllIl[48] = 95 + 205 - 227 + 137 ^ 52 + 68 - -19 + 7;
    lIlIIIIllIl[49] = 29 + 101 - 19 + 43 ^ 6 + 74 - 76 + 164;
    lIlIIIIllIl[50] = 198 + 31 - 121 + 104 ^ 92 + 169 - 256 + 190;
    lIlIIIIllIl[51] = 0x1A ^ 0x5;
    lIlIIIIllIl[52] = 0x6D ^ 0x67;
    lIlIIIIllIl[53] = -(0xE4 ^ 0x8D);
    lIlIIIIllIl[54] = 0x5A ^ 0x4F;
    lIlIIIIllIl[55] = 0x6E ^ 0x2 ^ 0xE3 ^ 0x87;
    lIlIIIIllIl[56] = 0x71 ^ 0x61 ^ 0x8D ^ 0x94;
    lIlIIIIllIl[57] = 0xCC ^ 0xC7;
    lIlIIIIllIl[58] = 0xB7 ^ 0xBB;
    lIlIIIIllIl[59] = " ".length() ^ 0x49 ^ 0x3B;
    lIlIIIIllIl[60] = 0x39 ^ 0x27 ^ 0x29 ^ 0x65;
    lIlIIIIllIl[61] = 82 + 123 - 92 + 117;
    lIlIIIIllIl[62] = 112 + 82 - 36 + 41;
    lIlIIIIllIl[63] = -" ".length();
    lIlIIIIllIl[64] = 0x49 ^ 0x1C ^ 0xF9 ^ 0xA1;
    lIlIIIIllIl[65] = 0x28 ^ 0x27;
    lIlIIIIllIl[66] = 0x2C ^ 0x2A ^ 0xB9 ^ 0xAF;
    lIlIIIIllIl[67] = 0x8A ^ 0x9C ^ 0x64 ^ 0x63;
    lIlIIIIllIl[68] = 0x28 ^ 0x3A;
    lIlIIIIllIl[69] = 0x3D ^ 0x61;
    lIlIIIIllIl[70] = 0x46 ^ 0x64;
    lIlIIIIllIl[71] = 204 + 43 - 136 + 130;
    lIlIIIIllIl[72] = 0x47 ^ 0x1C;
    lIlIIIIllIl[73] = (0xE ^ 0x46) + 66 + 143 - 145 + 80 - 42 + 26 - 54 + 160 + 85 + 85 - 166 + 126;
    lIlIIIIllIl[74] = (0x7E ^ 0x50) + 99 + 49 - 6 + 24 - (0x6C ^ 0x1C) + (0xF1 ^ 0xB8);
    lIlIIIIllIl[75] = 50 + 88 - 85 + 80 + 69 + 96 - 149 + 128 - (0xFFFFB50F & 0x4BFD) + 94 + 68 - 115 + 96;
    lIlIIIIllIl[76] = 0x5E ^ 0x3A;
    lIlIIIIllIl[77] = 0xBB ^ 0x9F;
    lIlIIIIllIl[78] = 0x43 ^ 0x3 ^ 0x34 ^ 0x60;
    lIlIIIIllIl[79] = 0x74 ^ 0x3 ^ 0x9 ^ 0x66;
    lIlIIIIllIl[80] = 17 + 71 - -46 + 34;
    lIlIIIIllIl[81] = (0x5B ^ 0x69) + (0x48 ^ 0x2F) - -(0x2C ^ 0x3E) + "   ".length();
    lIlIIIIllIl[82] = 130 + 143 - 142 + 27;
    lIlIIIIllIl[83] = 9 + 47 - -21 + 86;
    lIlIIIIllIl[84] = 120 + 3 - -29 + 82;
    lIlIIIIllIl[85] = (0x78 ^ 0x42) + (0x69 ^ 0x7) - (0x73 ^ 0x9) + (0xD2 ^ 0x83);
    lIlIIIIllIl[86] = 0x85 ^ 0xB2;
    lIlIIIIllIl[87] = 0xFE ^ 0xBA;
    lIlIIIIllIl[88] = 0x75 ^ 0x2D;
    lIlIIIIllIl[89] = 0x88 ^ 0xA6 ^ 0x16 ^ 0x2E;
    lIlIIIIllIl[90] = 0x8 ^ 0x17 ^ 0xA7 ^ 0x97;
    lIlIIIIllIl[91] = 0x37 ^ 0x79;
    lIlIIIIllIl[92] = 0x67 ^ 0x6;
    lIlIIIIllIl[93] = 107 + 82 - 108 + 73;
    lIlIIIIllIl[94] = 0x21 ^ 0x5A;
    lIlIIIIllIl[95] = 0x12 ^ 0x38 ^ 0xB9 ^ 0xA9;
    lIlIIIIllIl[96] = 12 + 114 - -1 + 32 ^ 29 + 61 - -16 + 28;
    lIlIIIIllIl[97] = 114 + 127 - 167 + 56 ^ 4 + 121 - 103 + 130;
    lIlIIIIllIl[98] = 0x3E ^ 0x1D ^ 0x46 ^ 0x7E;
    lIlIIIIllIl[99] = 9 + 9 - -70 + 67 ^ 168 + 30 - 23 + 2;
    lIlIIIIllIl[100] = 69 + 154 - 218 + 232 ^ 9 + 11 - 9 + 125;
  }
  
  private final HashMap<String, LServer> servers;
  private final RedisMessenger redisMessenger;
  
  public LobbyManager(BedWars plugin) {
    this.servers = new HashMap<>();
    this.redisMessenger = new RedisMessenger(plugin);
  }
  
  public HashMap<String, LServer> getServers() {
    return this.servers;
  }
  
  public RedisMessenger getRedisMessenger() {
    return this.redisMessenger;
  }
  
  public LArena getRandom() {
    List<LArena> arenas = new ArrayList<>();
    this.servers.values().forEach(server -> server.getArenas().forEach(arenas::add));
    Collections.shuffle(arenas);
    
    LArena bestArena = null;
    int maxPlayers = 0;
    
    for (LArena arena : arenas) {
      if (isAvailable(arena) && arena.getPlayers() > maxPlayers) {
        maxPlayers = arena.getPlayers();
        bestArena = arena;
      }
    }
    
    if (bestArena == null) {
      for (LArena arena : arenas) {
        if (isAvailable(arena)) {
          bestArena = arena;
          break;
        }
      }
    }
    
    return bestArena;
  }
  
  public LArena getRandom(String group) {
    List<LArena> arenas = new ArrayList<>();
    this.servers.values().forEach(server -> server.getArenas().stream()
      .filter(arena -> arena.getGroup().getName().equals(group))
      .forEach(arenas::add));
      
    Collections.shuffle(arenas);
    
    LArena bestArena = null;
    int maxPlayers = 0;
    
    for (LArena arena : arenas) {
      if (isAvailable(arena) && arena.getPlayers() > maxPlayers) {
        maxPlayers = arena.getPlayers();
        bestArena = arena;
      }
    }
    
    if (bestArena == null) {
      for (LArena arena : arenas) {
        if (isAvailable(arena)) {
          bestArena = arena;
          break;
        }
      }
    }
    
    return bestArena;
  }
  
  private boolean isAvailable(LArena arena) {
    return (arena.isGameState(GameState.WAITING) || arena.isGameState(GameState.STARTING)) 
      && arena.getPlayers() < arena.getTeams() * arena.getGroup().getTeamSize();
  }
  
  private static boolean lIlIIlIlIlIIl(char lllllllllllllllIllIlIlllIIIlIlIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > null);
  }
  
  private static boolean lIlIIlIlIIIll(double lllllllllllllllIllIlIlllIIIlllll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean lIlIIlIlIIlll(short lllllllllllllllIllIlIlllIIIllIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static boolean lIlIIlIlIIlIl(short lllllllllllllllIllIlIlllIIlIIllI, float lllllllllllllllIllIlIlllIIlIIlIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 <= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIlIIlIIlllll(float lllllllllllllllIllIlIlllIIIllIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean lIlIIlIlIIIIl(short lllllllllllllllIllIlIlllIIlIIIlI, double lllllllllllllllIllIlIlllIIlIIIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIlIIlIlIIllI(int lllllllllllllllIllIlIlllIIIlIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 <= null);
  }
  
  private static boolean lIIIIIllIIlI(String lllllllllllllllIllIlIllllllllIII) {
    if (lIlIIlIlIIIlI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (-"   ".length() > 0)
        return (0xE1 ^ 0xB6 ^ 0x78 ^ 0x74) & (0x2B ^ 0x6E ^ 0x6B ^ 0x75 ^ -" ".length()); 
    } else {
    
    } 
    return lIlIIIIllIl[1];
  }
  
  private static void lIlIIlIIIlIIl() {
    lIlIIIIIlIl = new String[lIlIIIIllIl[10]];
    lIlIIIIIlIl[lIlIIIIllIl[1]] = lIlIIIlllIIIl("", "hRzNI");
    lIlIIIIIlIl[lIlIIIIllIl[0]] = lIlIIIlllIIIl("eUw=", "YlyvK");
    lIlIIIIIlIl[lIlIIIIllIl[17]] = lIlIIIlllIIIl("Zw==", "GpLMG");
    lIlIIIIIlIl[lIlIIIIllIl[29]] = lIlIIIlllIIlI("AbynTdC9ylE=", "ggtdj");
    lIlIIIIIlIl[lIlIIIIllIl[30]] = lIlIIIlllIIll("21akcvtaI34=", "zOSkT");
    lIlIIIIIlIl[lIlIIIIllIl[31]] = lIlIIIlllIIll("yzKM2lYiKS4=", "jYOSN");
    lIlIIIIIlIl[lIlIIIIllIl[7]] = lIlIIIlllIIll("ir5WRs7aTO8=", "upCCX");
    lIlIIIIIlIl[lIlIIIIllIl[41]] = lIlIIIlllIIIl("aQ==", "IcpaJ");
    lIlIIIIIlIl[lIlIIIIllIl[55]] = lIlIIIlllIIll("SEZH1jwSjz0=", "Cnqkh");
    lIlIIIIIlIl[lIlIIIIllIl[56]] = lIlIIIlllIIll("e9aERv4g9Bw=", "jcuir");
    lIlIIIIIlIl[lIlIIIIllIl[52]] = lIlIIIlllIIlI("oH1e619y320=", "AipfS");
    lIlIIIIIlIl[lIlIIIIllIl[57]] = lIlIIIlllIIll("g9jMUPW1xZM=", "zzids");
    lIlIIIIIlIl[lIlIIIIllIl[58]] = lIlIIIlllIIlI("jPONQVD6x+I=", "eTpOa");
    lIlIIIIIlIl[lIlIIIIllIl[64]] = lIlIIIlllIIlI("dDT764+kctU=", "NcbvJ");
    lIlIIIIIlIl[lIlIIIIllIl[18]] = lIlIIIlllIIIl("", "ALZQp");
    lIlIIIIIlIl[lIlIIIIllIl[65]] = lIlIIIlllIIll("LskHKHLlhSY=", "paVoH");
    lIlIIIIIlIl[lIlIIIIllIl[66]] = lIlIIIlllIIll("mvz4Z8qai9o=", "lMmuF");
    lIlIIIIIlIl[lIlIIIIllIl[67]] = lIlIIIlllIIlI("Px8I0B3sqws=", "jqAcs");
    lIlIIIIIlIl[lIlIIIIllIl[68]] = lIlIIIlllIIlI("mGvbCVnifMs=", "WAdCO");
    lIlIIIIIlIl[lIlIIIIllIl[26]] = lIlIIIlllIIll("WhipIjrjTBE=", "AAiYS");
    lIlIIIIIlIl[lIlIIIIllIl[78]] = lIlIIIlllIIll("7REQNaeQ+N8=", "VFpCU");
    lIlIIIIIlIl[lIlIIIIllIl[54]] = lIlIIIlllIIIl("", "gHfkX");
    lIlIIIIIlIl[lIlIIIIllIl[89]] = lIlIIIlllIIIl("ag==", "JdCfi");
    lIlIIIIIlIl[lIlIIIIllIl[50]] = lIlIIIlllIIIl("SA==", "hLLpt");
    lIlIIIIIlIl[lIlIIIIllIl[79]] = lIlIIIlllIIIl("", "jdMOB");
    lIlIIIIIlIl[lIlIIIIllIl[96]] = lIlIIIlllIIIl("", "vygPY");
    lIlIIIIIlIl[lIlIIIIllIl[97]] = lIlIIIlllIIIl("ZA==", "DRSKZ");
    lIlIIIIIlIl[lIlIIIIllIl[98]] = lIlIIIlllIIIl("", "KhLEF");
    lIlIIIIIlIl[lIlIIIIllIl[35]] = lIlIIIlllIIll("eKIuN1JmxFw=", "SMmgF");
    lIlIIIIIlIl[lIlIIIIllIl[19]] = lIlIIIlllIIll("Y/UN0zI1zYg=", "eESYn");
    lIlIIIIIlIl[lIlIIIIllIl[33]] = lIlIIIlllIIlI("jwSZCw0nmYc=", "NwvqY");
    lIlIIIIIlIl[lIlIIIIllIl[51]] = lIlIIIlllIIIl("dW4=", "UNxLU");
  }
  
  private static boolean lIlIIlIlIlIII(float lllllllllllllllIllIlIlllIIlIlIlI, byte lllllllllllllllIllIlIlllIIlIlIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static String lIlIIIlllIIll(char lllllllllllllllIllIlIlllIlIlllIl, String lllllllllllllllIllIlIlllIlIllllI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlllIIllllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlllIlIllllI.getBytes(StandardCharsets.UTF_8)), lIlIIIIllIl[55]), "DES");
      Cipher lllllllllllllllIllIlIlllIIllllII = Cipher.getInstance("DES");
      lllllllllllllllIllIlIlllIIllllII.init(lIlIIIIllIl[17], lllllllllllllllIllIlIlllIIllllIl);
      return new String(lllllllllllllllIllIlIlllIIllllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIlIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlllIIlllIll) {
      lllllllllllllllIllIlIlllIIlllIll.printStackTrace();
      return null;
    } 
  }
  
  private static boolean lIlIIlIlIIIlI(Exception lllllllllllllllIllIlIlllIIIlllIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static String lIlIIIlllIIIl(String lllllllllllllllIllIlIlllIlIIllll, String lllllllllllllllIllIlIlllIlIIlllI) {
    String str = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIlIIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIlllIlIIllIl = new StringBuilder();
    char[] lllllllllllllllIllIlIlllIlIIllII = lllllllllllllllIllIlIlllIlIIlllI.toCharArray();
    int lllllllllllllllIllIlIlllIlIIlIll = lIlIIIIllIl[1];
    char[] arrayOfChar1 = str.toCharArray();
    int i = arrayOfChar1.length;
    lllllllllllllllIllIlIlllIlIIIIll = lIlIIIIllIl[1];
    while (lIlIIlIlIlIII(lllllllllllllllIllIlIlllIlIIIIll, i)) {
      char lllllllllllllllIllIlIlllIlIlIIII = arrayOfChar1[lllllllllllllllIllIlIlllIlIIIIll];
      "".length();
      lllllllllllllllIllIlIlllIlIIlIll++;
      lllllllllllllllIllIlIlllIlIIIIll++;
      "".length();
      if (((0xBB ^ 0x9B) & (0x7D ^ 0x5D ^ 0xFFFFFFFF)) >= "  ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIlllIlIIllIl);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\bungeemode\lobby\LobbyManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */