/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisDataException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandListFilterByParams
/*    */   implements IParams
/*    */ {
/*    */   private String moduleName;
/*    */   private String category;
/*    */   private String pattern;
/*    */   
/*    */   public static CommandListFilterByParams commandListFilterByParams() {
/* 17 */     return new CommandListFilterByParams();
/*    */   }
/*    */   
/*    */   public CommandListFilterByParams filterByModule(String moduleName) {
/* 21 */     this.moduleName = moduleName;
/* 22 */     return this;
/*    */   }
/*    */   
/*    */   public CommandListFilterByParams filterByAclCat(String category) {
/* 26 */     this.category = category;
/* 27 */     return this;
/*    */   }
/*    */   
/*    */   public CommandListFilterByParams filterByPattern(String pattern) {
/* 31 */     this.pattern = pattern;
/* 32 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 37 */     args.add(Protocol.Keyword.FILTERBY);
/*    */     
/* 39 */     if (this.moduleName != null && this.category == null && this.pattern == null) {
/* 40 */       args.add(Protocol.Keyword.MODULE);
/* 41 */       args.add(this.moduleName);
/* 42 */     } else if (this.moduleName == null && this.category != null && this.pattern == null) {
/* 43 */       args.add(Protocol.Keyword.ACLCAT);
/* 44 */       args.add(this.category);
/* 45 */     } else if (this.moduleName == null && this.category == null && this.pattern != null) {
/* 46 */       args.add(Protocol.Keyword.PATTERN);
/* 47 */       args.add(this.pattern);
/*    */     } else {
/* 49 */       throw new JedisDataException("Must choose exactly one filter");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\CommandListFilterByParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */