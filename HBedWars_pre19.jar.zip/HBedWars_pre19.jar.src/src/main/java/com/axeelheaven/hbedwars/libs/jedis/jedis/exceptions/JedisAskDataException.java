/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.HostAndPort;
/*    */ 
/*    */ public class JedisAskDataException
/*    */   extends JedisRedirectionException {
/*    */   private static final long serialVersionUID = 3878126572474819403L;
/*    */   
/*    */   public JedisAskDataException(Throwable cause, HostAndPort targetHost, int slot) {
/* 10 */     super(cause, targetHost, slot);
/*    */   }
/*    */   
/*    */   public JedisAskDataException(String message, Throwable cause, HostAndPort targetHost, int slot) {
/* 14 */     super(message, cause, targetHost, slot);
/*    */   }
/*    */   
/*    */   public JedisAskDataException(String message, HostAndPort targetHost, int slot) {
/* 18 */     super(message, targetHost, slot);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\JedisAskDataException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */