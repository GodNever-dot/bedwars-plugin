/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessControlLogEntry
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   public static final String COUNT = "count";
/*    */   public static final String REASON = "reason";
/*    */   public static final String CONTEXT = "context";
/*    */   public static final String OBJECT = "object";
/*    */   public static final String USERNAME = "username";
/*    */   public static final String AGE_SECONDS = "age-seconds";
/*    */   public static final String CLIENT_INFO = "client-info";
/*    */   private long count;
/*    */   private final String reason;
/*    */   private final String context;
/*    */   private final String object;
/*    */   private final String username;
/*    */   private final String ageSeconds;
/*    */   private final Map<String, String> clientInfo;
/*    */   private final Map<String, Object> logEntry;
/*    */   
/*    */   public AccessControlLogEntry(Map<String, Object> map) {
/* 33 */     this.count = ((Long)map.get("count")).longValue();
/* 34 */     this.reason = (String)map.get("reason");
/* 35 */     this.context = (String)map.get("context");
/* 36 */     this.object = (String)map.get("object");
/* 37 */     this.username = (String)map.get("username");
/* 38 */     this.ageSeconds = (String)map.get("age-seconds");
/* 39 */     this.clientInfo = getMapFromRawClientInfo((String)map.get("client-info"));
/* 40 */     this.logEntry = map;
/*    */   }
/*    */   
/*    */   public long getCount() {
/* 44 */     return this.count;
/*    */   }
/*    */   
/*    */   public String getReason() {
/* 48 */     return this.reason;
/*    */   }
/*    */   
/*    */   public String getContext() {
/* 52 */     return this.context;
/*    */   }
/*    */   
/*    */   public String getObject() {
/* 56 */     return this.object;
/*    */   }
/*    */   
/*    */   public String getUsername() {
/* 60 */     return this.username;
/*    */   }
/*    */   
/*    */   public String getAgeSeconds() {
/* 64 */     return this.ageSeconds;
/*    */   }
/*    */   
/*    */   public Map<String, String> getClientInfo() {
/* 68 */     return this.clientInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Object> getlogEntry() {
/* 75 */     return this.logEntry;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Map<String, String> getMapFromRawClientInfo(String clientInfo) {
/* 85 */     String[] entries = clientInfo.split(" ");
/* 86 */     Map<String, String> clientInfoMap = new LinkedHashMap<>(entries.length);
/* 87 */     for (String entry : entries) {
/* 88 */       String[] kvArray = entry.split("=");
/* 89 */       clientInfoMap.put(kvArray[0], (kvArray.length == 2) ? kvArray[1] : "");
/*    */     } 
/* 91 */     return clientInfoMap;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 96 */     return "AccessControlLogEntry{count=" + this.count + ", reason='" + this.reason + '\'' + ", context='" + this.context + '\'' + ", object='" + this.object + '\'' + ", username='" + this.username + '\'' + ", ageSeconds='" + this.ageSeconds + '\'' + ", clientInfo=" + this.clientInfo + '}';
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\AccessControlLogEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */