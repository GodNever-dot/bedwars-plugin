/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XTrimParams
/*    */   implements IParams
/*    */ {
/*    */   private Long maxLen;
/*    */   private boolean approximateTrimming;
/*    */   private boolean exactTrimming;
/*    */   private String minId;
/*    */   private Long limit;
/*    */   
/*    */   public static XTrimParams xTrimParams() {
/* 24 */     return new XTrimParams();
/*    */   }
/*    */ 
/*    */   
/*    */   public XTrimParams maxLen(long maxLen) {
/* 29 */     this.maxLen = Long.valueOf(maxLen);
/* 30 */     return this;
/*    */   }
/*    */   
/*    */   public XTrimParams minId(String minId) {
/* 34 */     this.minId = minId;
/* 35 */     return this;
/*    */   }
/*    */   
/*    */   public XTrimParams approximateTrimming() {
/* 39 */     this.approximateTrimming = true;
/* 40 */     return this;
/*    */   }
/*    */   
/*    */   public XTrimParams exactTrimming() {
/* 44 */     this.exactTrimming = true;
/* 45 */     return this;
/*    */   }
/*    */   
/*    */   public XTrimParams limit(long limit) {
/* 49 */     this.limit = Long.valueOf(limit);
/* 50 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 55 */     if (this.maxLen != null) {
/* 56 */       args.add(Protocol.Keyword.MAXLEN.getRaw());
/*    */       
/* 58 */       if (this.approximateTrimming) {
/* 59 */         args.add(Protocol.BYTES_TILDE);
/* 60 */       } else if (this.exactTrimming) {
/* 61 */         args.add(Protocol.BYTES_EQUAL);
/*    */       } 
/*    */       
/* 64 */       args.add(Protocol.toByteArray(this.maxLen.longValue()));
/* 65 */     } else if (this.minId != null) {
/* 66 */       args.add(Protocol.Keyword.MINID.getRaw());
/*    */       
/* 68 */       if (this.approximateTrimming) {
/* 69 */         args.add(Protocol.BYTES_TILDE);
/* 70 */       } else if (this.exactTrimming) {
/* 71 */         args.add(Protocol.BYTES_EQUAL);
/*    */       } 
/*    */       
/* 74 */       args.add(SafeEncoder.encode(this.minId));
/*    */     } 
/*    */     
/* 77 */     if (this.limit != null) {
/* 78 */       args.add(Protocol.Keyword.LIMIT.getRaw());
/* 79 */       args.add(Protocol.toByteArray(this.limit.longValue()));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\XTrimParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */