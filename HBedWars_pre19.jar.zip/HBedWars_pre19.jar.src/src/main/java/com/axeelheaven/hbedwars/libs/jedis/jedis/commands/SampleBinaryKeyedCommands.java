package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import java.util.List;

public interface SampleBinaryKeyedCommands {
  long waitReplicas(byte[] paramArrayOfbyte, int paramInt, long paramLong);
  
  Object eval(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  Object evalsha(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  Boolean scriptExists(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  List<Boolean> scriptExists(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  byte[] scriptLoad(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  String scriptFlush(byte[] paramArrayOfbyte);
  
  String scriptFlush(byte[] paramArrayOfbyte, FlushMode paramFlushMode);
  
  String scriptKill(byte[] paramArrayOfbyte);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\SampleBinaryKeyedCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */