/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.providers;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Connection;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.ConnectionPool;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.DefaultJedisClientConfig;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.HostAndPort;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.JedisClientConfig;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.ShardedCommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.Hashing;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public class ShardedConnectionProvider
/*     */   implements ConnectionProvider
/*     */ {
/*  24 */   private final TreeMap<Long, HostAndPort> nodes = new TreeMap<>();
/*  25 */   private final Map<String, ConnectionPool> resources = new HashMap<>();
/*     */   private final JedisClientConfig clientConfig;
/*     */   private final GenericObjectPoolConfig<Connection> poolConfig;
/*     */   private final Hashing algo;
/*     */   
/*     */   public ShardedConnectionProvider(List<HostAndPort> shards) {
/*  31 */     this(shards, (JedisClientConfig)DefaultJedisClientConfig.builder().build());
/*     */   }
/*     */   
/*     */   public ShardedConnectionProvider(List<HostAndPort> shards, JedisClientConfig clientConfig) {
/*  35 */     this(shards, clientConfig, new GenericObjectPoolConfig());
/*     */   }
/*     */ 
/*     */   
/*     */   public ShardedConnectionProvider(List<HostAndPort> shards, JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig) {
/*  40 */     this(shards, clientConfig, poolConfig, Hashing.MURMUR_HASH);
/*     */   }
/*     */ 
/*     */   
/*     */   public ShardedConnectionProvider(List<HostAndPort> shards, JedisClientConfig clientConfig, Hashing algo) {
/*  45 */     this(shards, clientConfig, new GenericObjectPoolConfig(), algo);
/*     */   }
/*     */ 
/*     */   
/*     */   public ShardedConnectionProvider(List<HostAndPort> shards, JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig, Hashing algo) {
/*  50 */     this.clientConfig = clientConfig;
/*  51 */     this.poolConfig = poolConfig;
/*  52 */     this.algo = algo;
/*  53 */     initialize(shards);
/*     */   }
/*     */   
/*     */   private void initialize(List<HostAndPort> shards) {
/*  57 */     for (int i = 0; i < shards.size(); i++) {
/*  58 */       HostAndPort shard = shards.get(i);
/*  59 */       for (int n = 0; n < 160; n++) {
/*  60 */         Long hash = Long.valueOf(this.algo.hash("SHARD-" + i + "-NODE-" + n));
/*  61 */         this.nodes.put(hash, shard);
/*  62 */         setupNodeIfNotExist(shard);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private ConnectionPool setupNodeIfNotExist(HostAndPort node) {
/*  68 */     String nodeKey = node.toString();
/*  69 */     ConnectionPool existingPool = this.resources.get(nodeKey);
/*  70 */     if (existingPool != null) return existingPool;
/*     */     
/*  72 */     ConnectionPool nodePool = new ConnectionPool(node, this.clientConfig, this.poolConfig);
/*  73 */     this.resources.put(nodeKey, nodePool);
/*  74 */     return nodePool;
/*     */   }
/*     */   
/*     */   public Hashing getHashingAlgo() {
/*  78 */     return this.algo;
/*     */   }
/*     */   
/*     */   private void reset() {
/*  82 */     for (ConnectionPool pool : this.resources.values()) {
/*     */       try {
/*  84 */         if (pool != null) {
/*  85 */           pool.destroy();
/*     */         }
/*  87 */       } catch (RuntimeException runtimeException) {}
/*     */     } 
/*     */ 
/*     */     
/*  91 */     this.resources.clear();
/*  92 */     this.nodes.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  97 */     reset();
/*     */   }
/*     */   
/*     */   public HostAndPort getNode(Long hash) {
/* 101 */     return (hash != null) ? getNodeFromHash(hash) : null;
/*     */   }
/*     */   
/*     */   public Connection getConnection(HostAndPort node) {
/* 105 */     return (node != null) ? setupNodeIfNotExist(node).getResource() : getConnection();
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection getConnection(CommandArguments args) {
/* 110 */     Long hash = ((ShardedCommandArguments)args).getKeyHash();
/* 111 */     return (hash != null) ? getConnection(getNodeFromHash(hash)) : getConnection();
/*     */   }
/*     */   
/*     */   private List<ConnectionPool> getShuffledNodesPool() {
/* 115 */     List<ConnectionPool> pools = new ArrayList<>(this.resources.values());
/* 116 */     Collections.shuffle(pools);
/* 117 */     return pools;
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection getConnection() {
/* 122 */     List<ConnectionPool> pools = getShuffledNodesPool();
/*     */     
/* 124 */     JedisException suppressed = null;
/* 125 */     for (ConnectionPool pool : pools) {
/* 126 */       Connection jedis = null;
/*     */       try {
/* 128 */         jedis = pool.getResource();
/* 129 */         if (jedis == null) {
/*     */           continue;
/*     */         }
/*     */         
/* 133 */         jedis.ping();
/* 134 */         return jedis;
/*     */       }
/* 136 */       catch (JedisException ex) {
/* 137 */         if (suppressed == null) {
/* 138 */           suppressed = ex;
/*     */         }
/* 140 */         if (jedis != null) {
/* 141 */           jedis.close();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 146 */     JedisException noReachableNode = new JedisException("No reachable shard.");
/* 147 */     if (suppressed != null) {
/* 148 */       noReachableNode.addSuppressed((Throwable)suppressed);
/*     */     }
/* 150 */     throw noReachableNode;
/*     */   }
/*     */   
/*     */   private HostAndPort getNodeFromHash(Long hash) {
/* 154 */     SortedMap<Long, HostAndPort> tail = this.nodes.tailMap(hash);
/* 155 */     if (tail.isEmpty()) {
/* 156 */       return this.nodes.get(this.nodes.firstKey());
/*     */     }
/* 158 */     return tail.get(tail.firstKey());
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\providers\ShardedConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */