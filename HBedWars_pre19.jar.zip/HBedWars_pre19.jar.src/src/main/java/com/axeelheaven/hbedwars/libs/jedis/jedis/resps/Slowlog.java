/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.HostAndPort;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Slowlog
/*    */ {
/*    */   private final long id;
/*    */   private final long timeStamp;
/*    */   private final long executionTime;
/*    */   private final List<String> args;
/*    */   private HostAndPort clientIpPort;
/*    */   private String clientName;
/*    */   private static final String COMMA = ",";
/*    */   
/*    */   private Slowlog(List<Object> properties) {
/* 23 */     this.id = ((Long)properties.get(0)).longValue();
/* 24 */     this.timeStamp = ((Long)properties.get(1)).longValue();
/* 25 */     this.executionTime = ((Long)properties.get(2)).longValue();
/*    */     
/* 27 */     List<byte[]> bargs = (List<byte[]>)properties.get(3);
/* 28 */     this.args = new ArrayList<>(bargs.size());
/*    */     
/* 30 */     for (byte[] barg : bargs) {
/* 31 */       this.args.add(SafeEncoder.encode(barg));
/*    */     }
/* 33 */     if (properties.size() == 4)
/*    */       return; 
/* 35 */     this.clientIpPort = HostAndPort.from(SafeEncoder.encode((byte[])properties.get(4)));
/* 36 */     this.clientName = SafeEncoder.encode((byte[])properties.get(5));
/*    */   }
/*    */ 
/*    */   
/*    */   public static List<Slowlog> from(List<Object> nestedMultiBulkReply) {
/* 41 */     List<Slowlog> logs = new ArrayList<>(nestedMultiBulkReply.size());
/* 42 */     for (Object obj : nestedMultiBulkReply) {
/* 43 */       List<Object> properties = (List<Object>)obj;
/* 44 */       logs.add(new Slowlog(properties));
/*    */     } 
/*    */     
/* 47 */     return logs;
/*    */   }
/*    */   
/*    */   public long getId() {
/* 51 */     return this.id;
/*    */   }
/*    */   
/*    */   public long getTimeStamp() {
/* 55 */     return this.timeStamp;
/*    */   }
/*    */   
/*    */   public long getExecutionTime() {
/* 59 */     return this.executionTime;
/*    */   }
/*    */   
/*    */   public List<String> getArgs() {
/* 63 */     return this.args;
/*    */   }
/*    */   
/*    */   public HostAndPort getClientIpPort() {
/* 67 */     return this.clientIpPort;
/*    */   }
/*    */   
/*    */   public String getClientName() {
/* 71 */     return this.clientName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return this.id + "," + this.timeStamp + "," + this.executionTime + 
/* 77 */       "," + this.args;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\Slowlog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */