package com.axeelheaven.hbedwars.bungeemode.server;

public class SRemote {
  public SRemote(short llllllllllllllllIlIIIIIllIlllIIl) {
    this.server = llllllllllllllllIlIIIIIllIlllIIl;
  }
  
  public String getServer() {
    // Byte code:
    //   0: aload_0
    //   1: getfield server : Ljava/lang/String;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	llllllllllllllllIlIIIIIllIllllII	F
    //   0	5	0	llllllllllllllllIlIIIIIllIllllIl	I
    //   0	5	0	llllllllllllllllIlIIIIIllIlllllI	Lcom/axeelheaven/hbedwars/bungeemode/server/SRemote;
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\bungeemode\server\SRemote.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */