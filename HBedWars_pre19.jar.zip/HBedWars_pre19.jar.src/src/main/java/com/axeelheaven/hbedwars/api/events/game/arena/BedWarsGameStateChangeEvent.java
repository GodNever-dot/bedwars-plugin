/*    */ package com.axeelheaven.hbedwars.api.events.game.arena;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.api.arena.Arena;
/*    */ import com.axeelheaven.hbedwars.api.arena.GameState;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsGameStateChangeEvent extends Event {
/*    */   private final Arena arena;
/*    */   private final GameState gameState;
/* 11 */   private static final HandlerList handlerList = new HandlerList(); public Arena getArena() {
/* 12 */     return this.arena; } public GameState getGameState() {
/* 13 */     return this.gameState;
/*    */   }
/*    */   public BedWarsGameStateChangeEvent(Arena arena, GameState gameState) {
/* 16 */     this.arena = arena;
/* 17 */     this.gameState = gameState;
/*    */   }
/*    */   
/*    */   public boolean isGameState(GameState gameState) {
/* 21 */     return (this.gameState == gameState);
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 26 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 30 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\game\arena\BedWarsGameStateChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */