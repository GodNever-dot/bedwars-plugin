/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.executors.ClusterCommandExecutor;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*     */ import java.time.Duration;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JedisCluster
/*     */   extends UnifiedJedis
/*     */ {
/*     */   public static final int DEFAULT_TIMEOUT = 2000;
/*     */   public static final int DEFAULT_MAX_ATTEMPTS = 5;
/*     */   
/*     */   public JedisCluster(HostAndPort node) {
/*  19 */     this(Collections.singleton(node));
/*     */   }
/*     */   
/*     */   public JedisCluster(HostAndPort node, int timeout) {
/*  23 */     this(Collections.singleton(node), timeout);
/*     */   }
/*     */   
/*     */   public JedisCluster(HostAndPort node, int timeout, int maxAttempts) {
/*  27 */     this(Collections.singleton(node), timeout, maxAttempts);
/*     */   }
/*     */   
/*     */   public JedisCluster(HostAndPort node, GenericObjectPoolConfig<Connection> poolConfig) {
/*  31 */     this(Collections.singleton(node), poolConfig);
/*     */   }
/*     */   
/*     */   public JedisCluster(HostAndPort node, int timeout, GenericObjectPoolConfig<Connection> poolConfig) {
/*  35 */     this(Collections.singleton(node), timeout, poolConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisCluster(HostAndPort node, int timeout, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
/*  40 */     this(Collections.singleton(node), timeout, maxAttempts, poolConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
/*  45 */     this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, poolConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, String password, GenericObjectPoolConfig<Connection> poolConfig) {
/*  50 */     this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, password, poolConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig) {
/*  56 */     this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, password, clientName, poolConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, String user, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig) {
/*  63 */     this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, user, password, clientName, poolConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig, boolean ssl) {
/*  70 */     this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, password, clientName, poolConfig, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(HostAndPort node, int connectionTimeout, int soTimeout, int maxAttempts, String user, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig, boolean ssl) {
/*  77 */     this(Collections.singleton(node), connectionTimeout, soTimeout, maxAttempts, user, password, clientName, poolConfig, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(HostAndPort node, JedisClientConfig clientConfig, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
/*  83 */     this(Collections.singleton(node), clientConfig, maxAttempts, poolConfig);
/*     */   }
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> nodes) {
/*  87 */     this(nodes, 2000);
/*     */   }
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> nodes, int timeout) {
/*  91 */     this(nodes, DefaultJedisClientConfig.builder().timeoutMillis(timeout).build());
/*     */   }
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> nodes, int timeout, int maxAttempts) {
/*  95 */     this(nodes, DefaultJedisClientConfig.builder().timeoutMillis(timeout).build(), maxAttempts);
/*     */   }
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> nodes, String user, String password) {
/*  99 */     this(nodes, DefaultJedisClientConfig.builder().user(user).password(password).build());
/*     */   }
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> nodes, GenericObjectPoolConfig<Connection> poolConfig) {
/* 103 */     this(nodes, 2000, 5, poolConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> nodes, int timeout, GenericObjectPoolConfig<Connection> poolConfig) {
/* 108 */     this(nodes, timeout, 5, poolConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, int timeout, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
/* 113 */     this(clusterNodes, timeout, timeout, maxAttempts, poolConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
/* 118 */     this(clusterNodes, connectionTimeout, soTimeout, maxAttempts, (String)null, poolConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, String password, GenericObjectPoolConfig<Connection> poolConfig) {
/* 123 */     this(clusterNodes, connectionTimeout, soTimeout, maxAttempts, password, (String)null, poolConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig) {
/* 129 */     this(clusterNodes, connectionTimeout, soTimeout, maxAttempts, (String)null, password, clientName, poolConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, String user, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig) {
/* 136 */     this(clusterNodes, DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout)
/* 137 */         .socketTimeoutMillis(soTimeout).user(user).password(password).clientName(clientName).build(), maxAttempts, poolConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int infiniteSoTimeout, int maxAttempts, String user, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig) {
/* 144 */     this(clusterNodes, DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout)
/* 145 */         .socketTimeoutMillis(soTimeout).blockingSocketTimeoutMillis(infiniteSoTimeout)
/* 146 */         .user(user).password(password).clientName(clientName).build(), maxAttempts, poolConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig, boolean ssl) {
/* 152 */     this(clusterNodes, connectionTimeout, soTimeout, maxAttempts, (String)null, password, clientName, poolConfig, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, int connectionTimeout, int soTimeout, int maxAttempts, String user, String password, String clientName, GenericObjectPoolConfig<Connection> poolConfig, boolean ssl) {
/* 159 */     this(clusterNodes, DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout)
/* 160 */         .socketTimeoutMillis(soTimeout).user(user).password(password).clientName(clientName).ssl(ssl).build(), maxAttempts, poolConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, int maxAttempts, GenericObjectPoolConfig<Connection> poolConfig) {
/* 166 */     this(clusterNodes, clientConfig, maxAttempts, 
/* 167 */         Duration.ofMillis(clientConfig.getSocketTimeoutMillis() * maxAttempts), poolConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, int maxAttempts, Duration maxTotalRetriesDuration, GenericObjectPoolConfig<Connection> poolConfig) {
/* 172 */     super(clusterNodes, clientConfig, poolConfig, maxAttempts, maxTotalRetriesDuration);
/*     */   }
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig) {
/* 176 */     this(clusterNodes, clientConfig, 5);
/*     */   }
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, int maxAttempts) {
/* 180 */     super(clusterNodes, clientConfig, maxAttempts);
/*     */   }
/*     */   
/*     */   public JedisCluster(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, int maxAttempts, Duration maxTotalRetriesDuration) {
/* 184 */     super(clusterNodes, clientConfig, maxAttempts, maxTotalRetriesDuration);
/*     */   }
/*     */   
/*     */   public Map<String, ConnectionPool> getClusterNodes() {
/* 188 */     return ((ClusterCommandExecutor)this.executor).provider.getNodes();
/*     */   }
/*     */   
/*     */   public Connection getConnectionFromSlot(int slot) {
/* 192 */     return ((ClusterCommandExecutor)this.executor).provider.getConnectionFromSlot(slot);
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\JedisCluster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */