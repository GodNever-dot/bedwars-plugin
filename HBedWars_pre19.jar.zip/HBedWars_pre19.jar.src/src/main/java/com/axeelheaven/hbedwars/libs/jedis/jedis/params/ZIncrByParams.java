/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZIncrByParams
/*    */   extends Params
/*    */   implements IParams
/*    */ {
/*    */   private static final String XX = "xx";
/*    */   private static final String NX = "nx";
/*    */   private static final String INCR = "incr";
/*    */   
/*    */   public static ZIncrByParams zIncrByParams() {
/* 29 */     return new ZIncrByParams();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ZIncrByParams nx() {
/* 37 */     addParam("nx");
/* 38 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ZIncrByParams xx() {
/* 46 */     addParam("xx");
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 52 */     if (contains("nx")) {
/* 53 */       args.add("nx");
/*    */     }
/* 55 */     if (contains("xx")) {
/* 56 */       args.add("xx");
/*    */     }
/*    */     
/* 59 */     args.add("incr");
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\ZIncrByParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */