/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.providers;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Connection;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.ConnectionFactory;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.ConnectionPool;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.HostAndPort;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.JedisClientConfig;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.Pool;
/*    */ import com.axeelheaven.hbedwars.libs.pool2.PooledObjectFactory;
/*    */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*    */ 
/*    */ public class PooledConnectionProvider
/*    */   implements ConnectionProvider
/*    */ {
/*    */   private final Pool<Connection> pool;
/*    */   
/*    */   public PooledConnectionProvider(HostAndPort hostAndPort) {
/* 19 */     this((PooledObjectFactory<Connection>)new ConnectionFactory(hostAndPort));
/*    */   }
/*    */   
/*    */   public PooledConnectionProvider(HostAndPort hostAndPort, JedisClientConfig clientConfig) {
/* 23 */     this((PooledObjectFactory<Connection>)new ConnectionFactory(hostAndPort, clientConfig));
/*    */   }
/*    */   
/*    */   public PooledConnectionProvider(PooledObjectFactory<Connection> factory) {
/* 27 */     this(factory, new GenericObjectPoolConfig());
/*    */   }
/*    */   
/*    */   public PooledConnectionProvider(PooledObjectFactory<Connection> factory, GenericObjectPoolConfig<Connection> poolConfig) {
/* 31 */     this((Pool<Connection>)new ConnectionPool(factory, poolConfig));
/*    */   }
/*    */   
/*    */   private PooledConnectionProvider(Pool<Connection> pool) {
/* 35 */     this.pool = pool;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 40 */     this.pool.close();
/*    */   }
/*    */   
/*    */   public final Pool<Connection> getPool() {
/* 44 */     return this.pool;
/*    */   }
/*    */ 
/*    */   
/*    */   public Connection getConnection() {
/* 49 */     return (Connection)this.pool.getResource();
/*    */   }
/*    */ 
/*    */   
/*    */   public Connection getConnection(CommandArguments args) {
/* 54 */     return (Connection)this.pool.getResource();
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\providers\PooledConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */