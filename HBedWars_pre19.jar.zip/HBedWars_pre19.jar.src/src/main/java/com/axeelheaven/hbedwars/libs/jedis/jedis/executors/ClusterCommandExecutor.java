/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.executors;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandObject;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Connection;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.commands.ProtocolCommand;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisClusterOperationException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisConnectionException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisRedirectionException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.providers.ClusterConnectionProvider;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.IOUtils;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.Logger;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.LoggerFactory;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class ClusterCommandExecutor implements CommandExecutor {
/*  19 */   private final Logger log = LoggerFactory.getLogger(getClass());
/*     */   
/*     */   public final ClusterConnectionProvider provider;
/*     */   
/*     */   protected final int maxAttempts;
/*     */   protected final Duration maxTotalRetriesDuration;
/*     */   
/*     */   public ClusterCommandExecutor(ClusterConnectionProvider provider, int maxAttempts, Duration maxTotalRetriesDuration) {
/*  27 */     this.provider = provider;
/*  28 */     this.maxAttempts = maxAttempts;
/*  29 */     this.maxTotalRetriesDuration = maxTotalRetriesDuration;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  34 */     this.provider.close();
/*     */   }
/*     */   
/*     */   public final <T> T executeCommand(CommandObject<T> commandObject) {
/*     */     JedisRedirectionException jedisRedirectionException1;
/*  39 */     Instant deadline = Instant.now().plus(this.maxTotalRetriesDuration);
/*     */     
/*  41 */     JedisRedirectionException redirect = null;
/*  42 */     int consecutiveConnectionFailures = 0;
/*  43 */     Exception lastException = null;
/*  44 */     for (int attemptsLeft = this.maxAttempts; attemptsLeft > 0; attemptsLeft--) {
/*  45 */       JedisConnectionException jedisConnectionException; Connection connection = null;
/*     */       try {
/*  47 */         if (redirect != null) {
/*  48 */           connection = this.provider.getConnection(redirect.getTargetNode());
/*  49 */           if (redirect instanceof com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisAskDataException)
/*     */           {
/*  51 */             connection.executeCommand((ProtocolCommand)Protocol.Command.ASKING);
/*     */           }
/*     */         } else {
/*  54 */           connection = this.provider.getConnection(commandObject.getArguments());
/*     */         } 
/*     */         
/*  57 */         return (T)connection.executeCommand(commandObject);
/*     */       }
/*  59 */       catch (JedisClusterOperationException jnrcne) {
/*  60 */         throw jnrcne;
/*  61 */       } catch (JedisConnectionException jce) {
/*  62 */         jedisConnectionException = jce;
/*  63 */         consecutiveConnectionFailures++;
/*  64 */         this.log.debug("Failed connecting to Redis: {}", connection, jce);
/*     */         
/*  66 */         boolean reset = handleConnectionProblem(attemptsLeft - 1, consecutiveConnectionFailures, deadline);
/*  67 */         if (reset) {
/*  68 */           consecutiveConnectionFailures = 0;
/*  69 */           redirect = null;
/*     */         } 
/*  71 */       } catch (JedisRedirectionException jre) {
/*     */         
/*  73 */         if (jedisConnectionException == null || jedisConnectionException instanceof JedisRedirectionException) {
/*  74 */           jedisRedirectionException1 = jre;
/*     */         }
/*  76 */         this.log.debug("Redirected by server to {}", jre.getTargetNode());
/*  77 */         consecutiveConnectionFailures = 0;
/*  78 */         redirect = jre;
/*     */         
/*  80 */         if (jre instanceof com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisMovedDataException)
/*     */         {
/*  82 */           this.provider.renewSlotCache(connection);
/*     */         }
/*     */       } finally {
/*  85 */         IOUtils.closeQuietly((AutoCloseable)connection);
/*     */       } 
/*  87 */       if (Instant.now().isAfter(deadline)) {
/*  88 */         throw new JedisClusterOperationException("Cluster retry deadline exceeded.");
/*     */       }
/*     */     } 
/*     */     
/*  92 */     JedisClusterOperationException maxAttemptsException = new JedisClusterOperationException("No more cluster attempts left.");
/*     */     
/*  94 */     maxAttemptsException.addSuppressed((Throwable)jedisRedirectionException1);
/*  95 */     throw maxAttemptsException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean handleConnectionProblem(int attemptsLeft, int consecutiveConnectionFailures, Instant doneDeadline) {
/* 108 */     if (this.maxAttempts < 3) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       if (attemptsLeft == 0) {
/* 115 */         this.provider.renewSlotCache();
/* 116 */         return true;
/*     */       } 
/* 118 */       return false;
/*     */     } 
/*     */     
/* 121 */     if (consecutiveConnectionFailures < 2) {
/* 122 */       return false;
/*     */     }
/*     */     
/* 125 */     sleep(getBackoffSleepMillis(attemptsLeft, doneDeadline));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     this.provider.renewSlotCache();
/* 131 */     return true;
/*     */   }
/*     */   
/*     */   private static long getBackoffSleepMillis(int attemptsLeft, Instant deadline) {
/* 135 */     if (attemptsLeft <= 0) {
/* 136 */       return 0L;
/*     */     }
/*     */     
/* 139 */     long millisLeft = Duration.between(Instant.now(), deadline).toMillis();
/* 140 */     if (millisLeft < 0L) {
/* 141 */       throw new JedisClusterOperationException("Cluster retry deadline exceeded.");
/*     */     }
/*     */     
/* 144 */     return millisLeft / (attemptsLeft * (attemptsLeft + 1));
/*     */   }
/*     */   
/*     */   protected void sleep(long sleepMillis) {
/*     */     try {
/* 149 */       TimeUnit.MILLISECONDS.sleep(sleepMillis);
/* 150 */     } catch (InterruptedException e) {
/* 151 */       throw new JedisClusterOperationException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\executors\ClusterCommandExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */