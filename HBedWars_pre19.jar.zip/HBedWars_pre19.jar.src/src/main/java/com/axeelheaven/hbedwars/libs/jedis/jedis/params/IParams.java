package com.axeelheaven.hbedwars.libs.jedis.jedis.params;

import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;

public interface IParams {
  void addParams(CommandArguments paramCommandArguments);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\IParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */