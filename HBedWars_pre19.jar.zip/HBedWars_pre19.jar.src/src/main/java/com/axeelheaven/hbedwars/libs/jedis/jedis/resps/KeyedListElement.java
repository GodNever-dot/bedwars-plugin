/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.KeyValue;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class KeyedListElement
/*    */   extends KeyValue<String, String>
/*    */ {
/*    */   public KeyedListElement(byte[] key, byte[] element) {
/* 14 */     this(SafeEncoder.encode(key), SafeEncoder.encode(element));
/*    */   }
/*    */   
/*    */   public KeyedListElement(String key, String element) {
/* 18 */     super(key, element);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public String getElement() {
/* 26 */     return (String)getValue();
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\KeyedListElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */