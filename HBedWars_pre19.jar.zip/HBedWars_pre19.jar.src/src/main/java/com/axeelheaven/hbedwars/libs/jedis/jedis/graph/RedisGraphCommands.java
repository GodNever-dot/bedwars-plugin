package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;

import java.util.Map;

public interface RedisGraphCommands {
  ResultSet graphQuery(String paramString1, String paramString2);
  
  ResultSet graphReadonlyQuery(String paramString1, String paramString2);
  
  ResultSet graphQuery(String paramString1, String paramString2, long paramLong);
  
  ResultSet graphReadonlyQuery(String paramString1, String paramString2, long paramLong);
  
  ResultSet graphQuery(String paramString1, String paramString2, Map<String, Object> paramMap);
  
  ResultSet graphReadonlyQuery(String paramString1, String paramString2, Map<String, Object> paramMap);
  
  ResultSet graphQuery(String paramString1, String paramString2, Map<String, Object> paramMap, long paramLong);
  
  ResultSet graphReadonlyQuery(String paramString1, String paramString2, Map<String, Object> paramMap, long paramLong);
  
  String graphDelete(String paramString);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\RedisGraphCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */