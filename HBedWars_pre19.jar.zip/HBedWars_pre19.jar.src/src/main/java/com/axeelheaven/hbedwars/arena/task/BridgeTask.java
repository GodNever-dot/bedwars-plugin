package com.axeelheaven.hbedwars.arena.task;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.api.arena.Arena;
import com.axeelheaven.hbedwars.database.profile.HData;
import com.axeelheaven.hbedwars.utils.Cuboid;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class BridgeTask extends BukkitRunnable {
    private final BedWars plugin;
    private final Player player;
    private final Projectile projectile;
    private final HData data;
    private final Arena arena;
    private final int length;
    private boolean running;
    private BukkitTask bukkitTask;

    public BridgeTask(BedWars plugin, Player player, Projectile projectile) {
        this.plugin = plugin;
        this.player = player;
        this.projectile = projectile;
        this.data = plugin.getGameManager().getData(player.getUniqueId());
        this.arena = this.data.getArena();
        this.length = plugin.getSettings().getInt("bridge.length", 0);
    }

    private boolean isProtected(Location location) {
        for (Cuboid region : this.arena.getRegions()) {
            if (region.contains(location)) {
                return true;
            }
        }
        return false;
    }

    public BukkitTask getBukkitTask() {
        return this.bukkitTask;
    }

    public boolean isRunning() {
        return this.running;
    }

    public void setRunning(boolean running) {
        this.running = running;
    }

    public BridgeTask start() {
        this.running = true;
        this.bukkitTask = runTaskTimer(this.plugin, 0L, 1L);
        return this;
    }

    @Override
    public void run() {
        if (!this.running || this.projectile.isDead() || this.projectile.isOnGround()) {
            cancel();
            return;
        }
        
        Location location = this.projectile.getLocation();
        if (this.isProtected(location)) {
            cancel();
            return;
        }
        
        Block block = location.getBlock();
        if (block.getType() == Material.AIR) {
            block.setType(Material.STAINED_CLAY);
            block.setData((byte)this.data.getTeam().getColor().getWoolData());
        }
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\arena\task\BridgeTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */