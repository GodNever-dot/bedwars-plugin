/*      */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.BitCountOption;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ExpiryOption;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.GeoUnit;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ListDirection;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.SortedSetOption;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.graph.ResultSet;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.json.JsonSetParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.json.Path;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.json.Path2;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoAddParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoRadiusParam;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoRadiusStoreParam;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoSearchParam;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.LPosParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.MigrateParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ScanParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.SortingParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.StrAlgoLCSParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XAutoClaimParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XClaimParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XPendingParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XReadGroupParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XTrimParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ZAddParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ZParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ZRangeParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.GeoRadiusResponse;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LCSMatchResult;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.ScanResult;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamEntry;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.Tuple;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.search.Query;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.timeseries.TSElement;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.timeseries.TSKeyedElements;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.timeseries.TSRangeParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.KeyValue;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ public class Pipeline extends Queable implements PipelineCommands, PipelineBinaryCommands, DatabasePipelineCommands, RedisModulePipelineCommands, Closeable {
/*      */   protected final Connection connection;
/*      */   
/*      */   public Pipeline(Connection connection) {
/*   47 */     this.connection = connection;
/*      */     
/*   49 */     this.commandObjects = new CommandObjects();
/*   50 */     this.graphCommandObjects = new GraphCommandObjects(this.connection);
/*      */   }
/*      */   private final CommandObjects commandObjects; private final GraphCommandObjects graphCommandObjects;
/*      */   
/*      */   public Pipeline(Jedis jedis) {
/*   55 */     this.connection = jedis.getConnection();
/*      */     
/*   57 */     this.commandObjects = new CommandObjects();
/*   58 */     this.graphCommandObjects = new GraphCommandObjects(this.connection);
/*      */   }
/*      */   
/*      */   public final <T> Response<T> appendCommand(CommandObject<T> commandObject) {
/*   62 */     this.connection.sendCommand(commandObject.getArguments());
/*   63 */     return enqueResponse(commandObject.getBuilder());
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() {
/*   68 */     sync();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sync() {
/*   77 */     if (!hasPipelinedResponse())
/*   78 */       return;  List<Object> unformatted = this.connection.getMany(getPipelinedResponseLength());
/*   79 */     for (Object o : unformatted) {
/*   80 */       generateResponse(o);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Object> syncAndReturnAll() {
/*   91 */     if (hasPipelinedResponse()) {
/*   92 */       List<Object> unformatted = this.connection.getMany(getPipelinedResponseLength());
/*   93 */       List<Object> formatted = new ArrayList();
/*   94 */       for (Object o : unformatted) {
/*      */         try {
/*   96 */           formatted.add(generateResponse(o).get());
/*   97 */         } catch (JedisDataException e) {
/*   98 */           formatted.add(e);
/*      */         } 
/*      */       } 
/*  101 */       return formatted;
/*      */     } 
/*  103 */     return Collections.emptyList();
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean hasPipelinedResponse() {
/*  108 */     return (getPipelinedResponseLength() > 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> exists(String key) {
/*  113 */     return appendCommand(this.commandObjects.exists(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> exists(String... keys) {
/*  118 */     return appendCommand(this.commandObjects.exists(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> persist(String key) {
/*  123 */     return appendCommand(this.commandObjects.persist(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> type(String key) {
/*  128 */     return appendCommand(this.commandObjects.type(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> dump(String key) {
/*  133 */     return (Response)appendCommand((CommandObject)this.commandObjects.dump(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> restore(String key, long ttl, byte[] serializedValue) {
/*  138 */     return appendCommand(this.commandObjects.restore(key, ttl, serializedValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> restore(String key, long ttl, byte[] serializedValue, RestoreParams params) {
/*  143 */     return appendCommand(this.commandObjects.restore(key, ttl, serializedValue, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> expire(String key, long seconds) {
/*  148 */     return appendCommand(this.commandObjects.expire(key, seconds));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> expire(String key, long seconds, ExpiryOption expiryOption) {
/*  153 */     return appendCommand(this.commandObjects.expire(key, seconds, expiryOption));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pexpire(String key, long milliseconds) {
/*  158 */     return appendCommand(this.commandObjects.pexpire(key, milliseconds));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pexpire(String key, long milliseconds, ExpiryOption expiryOption) {
/*  163 */     return appendCommand(this.commandObjects.pexpire(key, milliseconds, expiryOption));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> expireTime(String key) {
/*  168 */     return appendCommand(this.commandObjects.expireTime(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pexpireTime(String key) {
/*  173 */     return appendCommand(this.commandObjects.pexpireTime(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> expireAt(String key, long unixTime) {
/*  178 */     return appendCommand(this.commandObjects.expireAt(key, unixTime));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> expireAt(String key, long unixTime, ExpiryOption expiryOption) {
/*  183 */     return appendCommand(this.commandObjects.expireAt(key, unixTime, expiryOption));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pexpireAt(String key, long millisecondsTimestamp) {
/*  188 */     return appendCommand(this.commandObjects.pexpireAt(key, millisecondsTimestamp));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pexpireAt(String key, long millisecondsTimestamp, ExpiryOption expiryOption) {
/*  193 */     return appendCommand(this.commandObjects.pexpireAt(key, millisecondsTimestamp, expiryOption));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> ttl(String key) {
/*  198 */     return appendCommand(this.commandObjects.ttl(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pttl(String key) {
/*  203 */     return appendCommand(this.commandObjects.pttl(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> touch(String key) {
/*  208 */     return appendCommand(this.commandObjects.touch(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> touch(String... keys) {
/*  213 */     return appendCommand(this.commandObjects.touch(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> sort(String key) {
/*  218 */     return appendCommand(this.commandObjects.sort(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sort(String key, String dstKey) {
/*  223 */     return appendCommand(this.commandObjects.sort(key, dstKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> sort(String key, SortingParams sortingParams) {
/*  228 */     return appendCommand(this.commandObjects.sort(key, sortingParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sort(String key, SortingParams sortingParams, String dstKey) {
/*  233 */     return appendCommand(this.commandObjects.sort(key, sortingParams, dstKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> sortReadonly(String key, SortingParams sortingParams) {
/*  238 */     return appendCommand(this.commandObjects.sortReadonly(key, sortingParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> del(String key) {
/*  243 */     return appendCommand(this.commandObjects.del(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> del(String... keys) {
/*  248 */     return appendCommand(this.commandObjects.del(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> unlink(String key) {
/*  253 */     return appendCommand(this.commandObjects.unlink(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> unlink(String... keys) {
/*  258 */     return appendCommand(this.commandObjects.unlink(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> copy(String srcKey, String dstKey, boolean replace) {
/*  263 */     return appendCommand(this.commandObjects.copy(srcKey, dstKey, replace));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> rename(String oldkey, String newkey) {
/*  268 */     return appendCommand(this.commandObjects.rename(oldkey, newkey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> renamenx(String oldkey, String newkey) {
/*  273 */     return appendCommand(this.commandObjects.renamenx(oldkey, newkey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> memoryUsage(String key) {
/*  278 */     return appendCommand(this.commandObjects.memoryUsage(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> memoryUsage(String key, int samples) {
/*  283 */     return appendCommand(this.commandObjects.memoryUsage(key, samples));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> objectRefcount(String key) {
/*  288 */     return appendCommand(this.commandObjects.objectRefcount(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> objectEncoding(String key) {
/*  293 */     return appendCommand(this.commandObjects.objectEncoding(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> objectIdletime(String key) {
/*  298 */     return appendCommand(this.commandObjects.objectIdletime(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> objectFreq(String key) {
/*  303 */     return appendCommand(this.commandObjects.objectFreq(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> migrate(String host, int port, String key, int timeout) {
/*  308 */     return appendCommand(this.commandObjects.migrate(host, port, key, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> migrate(String host, int port, int timeout, MigrateParams params, String... keys) {
/*  313 */     return appendCommand(this.commandObjects.migrate(host, port, timeout, params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<String>> keys(String pattern) {
/*  318 */     return appendCommand(this.commandObjects.keys(pattern));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<String>> scan(String cursor) {
/*  323 */     return appendCommand(this.commandObjects.scan(cursor));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<String>> scan(String cursor, ScanParams params) {
/*  328 */     return appendCommand(this.commandObjects.scan(cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<String>> scan(String cursor, ScanParams params, String type) {
/*  333 */     return appendCommand(this.commandObjects.scan(cursor, params, type));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> randomKey() {
/*  338 */     return appendCommand(this.commandObjects.randomKey());
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> get(String key) {
/*  343 */     return appendCommand(this.commandObjects.get(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> getDel(String key) {
/*  348 */     return appendCommand(this.commandObjects.getDel(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> getEx(String key, GetExParams params) {
/*  353 */     return appendCommand(this.commandObjects.getEx(key, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> setbit(String key, long offset, boolean value) {
/*  358 */     return appendCommand(this.commandObjects.setbit(key, offset, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> getbit(String key, long offset) {
/*  363 */     return appendCommand(this.commandObjects.getbit(key, offset));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> setrange(String key, long offset, String value) {
/*  368 */     return appendCommand(this.commandObjects.setrange(key, offset, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> getrange(String key, long startOffset, long endOffset) {
/*  373 */     return appendCommand(this.commandObjects.getrange(key, startOffset, endOffset));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> getSet(String key, String value) {
/*  378 */     return appendCommand(this.commandObjects.getSet(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> setnx(String key, String value) {
/*  383 */     return appendCommand(this.commandObjects.setnx(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> setex(String key, long seconds, String value) {
/*  388 */     return appendCommand(this.commandObjects.setex(key, seconds, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> psetex(String key, long milliseconds, String value) {
/*  393 */     return appendCommand(this.commandObjects.psetex(key, milliseconds, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> mget(String... keys) {
/*  398 */     return appendCommand(this.commandObjects.mget(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> mset(String... keysvalues) {
/*  403 */     return appendCommand(this.commandObjects.mset(keysvalues));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> msetnx(String... keysvalues) {
/*  408 */     return appendCommand(this.commandObjects.msetnx(keysvalues));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> incr(String key) {
/*  413 */     return appendCommand(this.commandObjects.incr(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> incrBy(String key, long increment) {
/*  418 */     return appendCommand(this.commandObjects.incrBy(key, increment));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> incrByFloat(String key, double increment) {
/*  423 */     return appendCommand(this.commandObjects.incrByFloat(key, increment));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> decr(String key) {
/*  428 */     return appendCommand(this.commandObjects.decr(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> decrBy(String key, long decrement) {
/*  433 */     return appendCommand(this.commandObjects.decrBy(key, decrement));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> append(String key, String value) {
/*  438 */     return appendCommand(this.commandObjects.append(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> substr(String key, int start, int end) {
/*  443 */     return appendCommand(this.commandObjects.substr(key, start, end));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> strlen(String key) {
/*  448 */     return appendCommand(this.commandObjects.strlen(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitcount(String key) {
/*  453 */     return appendCommand(this.commandObjects.bitcount(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitcount(String key, long start, long end) {
/*  458 */     return appendCommand(this.commandObjects.bitcount(key, start, end));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitcount(String key, long start, long end, BitCountOption option) {
/*  463 */     return appendCommand(this.commandObjects.bitcount(key, start, end, option));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitpos(String key, boolean value) {
/*  468 */     return appendCommand(this.commandObjects.bitpos(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitpos(String key, boolean value, BitPosParams params) {
/*  473 */     return appendCommand(this.commandObjects.bitpos(key, value, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> bitfield(String key, String... arguments) {
/*  478 */     return appendCommand(this.commandObjects.bitfield(key, arguments));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> bitfieldReadonly(String key, String... arguments) {
/*  483 */     return appendCommand(this.commandObjects.bitfieldReadonly(key, arguments));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitop(BitOP op, String destKey, String... srcKeys) {
/*  488 */     return appendCommand(this.commandObjects.bitop(op, destKey, srcKeys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<LCSMatchResult> strAlgoLCSKeys(String keyA, String keyB, StrAlgoLCSParams params) {
/*  493 */     return appendCommand(this.commandObjects.strAlgoLCSKeys(keyA, keyB, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<LCSMatchResult> lcs(String keyA, String keyB, LCSParams params) {
/*  498 */     return appendCommand(this.commandObjects.lcs(keyA, keyB, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> set(String key, String value) {
/*  503 */     return appendCommand(this.commandObjects.set(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> set(String key, String value, SetParams params) {
/*  508 */     return appendCommand(this.commandObjects.set(key, value, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> rpush(String key, String... string) {
/*  513 */     return appendCommand(this.commandObjects.rpush(key, string));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Response<Long> lpush(String key, String... string) {
/*  519 */     return appendCommand(this.commandObjects.lpush(key, string));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> llen(String key) {
/*  524 */     return appendCommand(this.commandObjects.llen(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> lrange(String key, long start, long stop) {
/*  529 */     return appendCommand(this.commandObjects.lrange(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ltrim(String key, long start, long stop) {
/*  534 */     return appendCommand(this.commandObjects.ltrim(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> lindex(String key, long index) {
/*  539 */     return appendCommand(this.commandObjects.lindex(key, index));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> lset(String key, long index, String value) {
/*  544 */     return appendCommand(this.commandObjects.lset(key, index, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> lrem(String key, long count, String value) {
/*  549 */     return appendCommand(this.commandObjects.lrem(key, count, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> lpop(String key) {
/*  554 */     return appendCommand(this.commandObjects.lpop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> lpop(String key, int count) {
/*  559 */     return appendCommand(this.commandObjects.lpop(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> lpos(String key, String element) {
/*  564 */     return appendCommand(this.commandObjects.lpos(key, element));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> lpos(String key, String element, LPosParams params) {
/*  569 */     return appendCommand(this.commandObjects.lpos(key, element, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> lpos(String key, String element, LPosParams params, long count) {
/*  574 */     return appendCommand(this.commandObjects.lpos(key, element, params, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> rpop(String key) {
/*  579 */     return appendCommand(this.commandObjects.rpop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> rpop(String key, int count) {
/*  584 */     return appendCommand(this.commandObjects.rpop(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> linsert(String key, ListPosition where, String pivot, String value) {
/*  589 */     return appendCommand(this.commandObjects.linsert(key, where, pivot, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> lpushx(String key, String... strings) {
/*  594 */     return appendCommand(this.commandObjects.lpushx(key, strings));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> rpushx(String key, String... strings) {
/*  599 */     return appendCommand(this.commandObjects.rpushx(key, strings));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> blpop(int timeout, String key) {
/*  604 */     return appendCommand(this.commandObjects.blpop(timeout, key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyedListElement> blpop(double timeout, String key) {
/*  609 */     return appendCommand(this.commandObjects.blpop(timeout, key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> brpop(int timeout, String key) {
/*  614 */     return appendCommand(this.commandObjects.brpop(timeout, key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyedListElement> brpop(double timeout, String key) {
/*  619 */     return appendCommand(this.commandObjects.brpop(timeout, key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> blpop(int timeout, String... keys) {
/*  624 */     return appendCommand(this.commandObjects.blpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyedListElement> blpop(double timeout, String... keys) {
/*  629 */     return appendCommand(this.commandObjects.blpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> brpop(int timeout, String... keys) {
/*  634 */     return appendCommand(this.commandObjects.brpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyedListElement> brpop(double timeout, String... keys) {
/*  639 */     return appendCommand(this.commandObjects.brpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> rpoplpush(String srcKey, String dstKey) {
/*  644 */     return appendCommand(this.commandObjects.rpoplpush(srcKey, dstKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> brpoplpush(String source, String destination, int timeout) {
/*  649 */     return appendCommand(this.commandObjects.brpoplpush(source, destination, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> lmove(String srcKey, String dstKey, ListDirection from, ListDirection to) {
/*  654 */     return appendCommand(this.commandObjects.lmove(srcKey, dstKey, from, to));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> blmove(String srcKey, String dstKey, ListDirection from, ListDirection to, double timeout) {
/*  659 */     return appendCommand(this.commandObjects.blmove(srcKey, dstKey, from, to, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<String, List<String>>> lmpop(ListDirection direction, String... keys) {
/*  664 */     return appendCommand(this.commandObjects.lmpop(direction, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<String, List<String>>> lmpop(ListDirection direction, int count, String... keys) {
/*  669 */     return appendCommand(this.commandObjects.lmpop(direction, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<String, List<String>>> blmpop(long timeout, ListDirection direction, String... keys) {
/*  674 */     return appendCommand(this.commandObjects.blmpop(timeout, direction, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<String, List<String>>> blmpop(long timeout, ListDirection direction, int count, String... keys) {
/*  679 */     return appendCommand(this.commandObjects.blmpop(timeout, direction, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hset(String key, String field, String value) {
/*  684 */     return appendCommand(this.commandObjects.hset(key, field, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hset(String key, Map<String, String> hash) {
/*  689 */     return appendCommand(this.commandObjects.hset(key, hash));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> hget(String key, String field) {
/*  694 */     return appendCommand(this.commandObjects.hget(key, field));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hsetnx(String key, String field, String value) {
/*  699 */     return appendCommand(this.commandObjects.hsetnx(key, field, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> hmset(String key, Map<String, String> hash) {
/*  704 */     return appendCommand(this.commandObjects.hmset(key, hash));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> hmget(String key, String... fields) {
/*  709 */     return appendCommand(this.commandObjects.hmget(key, fields));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hincrBy(String key, String field, long value) {
/*  714 */     return appendCommand(this.commandObjects.hincrBy(key, field, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> hincrByFloat(String key, String field, double value) {
/*  719 */     return appendCommand(this.commandObjects.hincrByFloat(key, field, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> hexists(String key, String field) {
/*  724 */     return appendCommand(this.commandObjects.hexists(key, field));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hdel(String key, String... field) {
/*  729 */     return appendCommand(this.commandObjects.hdel(key, field));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hlen(String key) {
/*  734 */     return appendCommand(this.commandObjects.hlen(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<String>> hkeys(String key) {
/*  739 */     return appendCommand(this.commandObjects.hkeys(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> hvals(String key) {
/*  744 */     return appendCommand(this.commandObjects.hvals(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<String, String>> hgetAll(String key) {
/*  749 */     return appendCommand(this.commandObjects.hgetAll(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> hrandfield(String key) {
/*  754 */     return appendCommand(this.commandObjects.hrandfield(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> hrandfield(String key, long count) {
/*  759 */     return appendCommand(this.commandObjects.hrandfield(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<String, String>> hrandfieldWithValues(String key, long count) {
/*  764 */     return appendCommand(this.commandObjects.hrandfieldWithValues(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<Map.Entry<String, String>>> hscan(String key, String cursor, ScanParams params) {
/*  769 */     return appendCommand(this.commandObjects.hscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hstrlen(String key, String field) {
/*  774 */     return appendCommand(this.commandObjects.hstrlen(key, field));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sadd(String key, String... members) {
/*  779 */     return appendCommand(this.commandObjects.sadd(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<String>> smembers(String key) {
/*  784 */     return appendCommand(this.commandObjects.smembers(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> srem(String key, String... members) {
/*  789 */     return appendCommand(this.commandObjects.srem(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> spop(String key) {
/*  794 */     return appendCommand(this.commandObjects.spop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<String>> spop(String key, long count) {
/*  799 */     return appendCommand(this.commandObjects.spop(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> scard(String key) {
/*  804 */     return appendCommand(this.commandObjects.scard(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> sismember(String key, String member) {
/*  809 */     return appendCommand(this.commandObjects.sismember(key, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> smismember(String key, String... members) {
/*  814 */     return appendCommand(this.commandObjects.smismember(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> srandmember(String key) {
/*  819 */     return appendCommand(this.commandObjects.srandmember(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> srandmember(String key, int count) {
/*  824 */     return appendCommand(this.commandObjects.srandmember(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<String>> sscan(String key, String cursor, ScanParams params) {
/*  829 */     return appendCommand(this.commandObjects.sscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<String>> sdiff(String... keys) {
/*  834 */     return appendCommand(this.commandObjects.sdiff(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sdiffstore(String dstKey, String... keys) {
/*  839 */     return appendCommand(this.commandObjects.sdiffstore(dstKey, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<String>> sinter(String... keys) {
/*  844 */     return appendCommand(this.commandObjects.sinter(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sinterstore(String dstKey, String... keys) {
/*  849 */     return appendCommand(this.commandObjects.sinterstore(dstKey, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sintercard(String... keys) {
/*  854 */     return appendCommand(this.commandObjects.sintercard(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sintercard(int limit, String... keys) {
/*  859 */     return appendCommand(this.commandObjects.sintercard(limit, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<String>> sunion(String... keys) {
/*  864 */     return appendCommand(this.commandObjects.sunion(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sunionstore(String dstKey, String... keys) {
/*  869 */     return appendCommand(this.commandObjects.sunionstore(dstKey, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> smove(String srcKey, String dstKey, String member) {
/*  874 */     return appendCommand(this.commandObjects.smove(srcKey, dstKey, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zadd(String key, double score, String member) {
/*  879 */     return appendCommand(this.commandObjects.zadd(key, score, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zadd(String key, double score, String member, ZAddParams params) {
/*  884 */     return appendCommand(this.commandObjects.zadd(key, score, member, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zadd(String key, Map<String, Double> scoreMembers) {
/*  889 */     return appendCommand(this.commandObjects.zadd(key, scoreMembers));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zadd(String key, Map<String, Double> scoreMembers, ZAddParams params) {
/*  894 */     return appendCommand(this.commandObjects.zadd(key, scoreMembers, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> zaddIncr(String key, double score, String member, ZAddParams params) {
/*  899 */     return appendCommand(this.commandObjects.zaddIncr(key, score, member, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zrem(String key, String... members) {
/*  904 */     return appendCommand(this.commandObjects.zrem(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> zincrby(String key, double increment, String member) {
/*  909 */     return appendCommand(this.commandObjects.zincrby(key, increment, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> zincrby(String key, double increment, String member, ZIncrByParams params) {
/*  914 */     return appendCommand(this.commandObjects.zincrby(key, increment, member, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zrank(String key, String member) {
/*  919 */     return appendCommand(this.commandObjects.zrank(key, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zrevrank(String key, String member) {
/*  924 */     return appendCommand(this.commandObjects.zrevrank(key, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrange(String key, long start, long stop) {
/*  929 */     return appendCommand(this.commandObjects.zrange(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrevrange(String key, long start, long stop) {
/*  934 */     return appendCommand(this.commandObjects.zrevrange(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeWithScores(String key, long start, long stop) {
/*  939 */     return appendCommand(this.commandObjects.zrangeWithScores(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrevrangeWithScores(String key, long start, long stop) {
/*  944 */     return appendCommand(this.commandObjects.zrevrangeWithScores(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> zrandmember(String key) {
/*  949 */     return appendCommand(this.commandObjects.zrandmember(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrandmember(String key, long count) {
/*  954 */     return appendCommand(this.commandObjects.zrandmember(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrandmemberWithScores(String key, long count) {
/*  959 */     return appendCommand(this.commandObjects.zrandmemberWithScores(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zcard(String key) {
/*  964 */     return appendCommand(this.commandObjects.zcard(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> zscore(String key, String member) {
/*  969 */     return appendCommand(this.commandObjects.zscore(key, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Double>> zmscore(String key, String... members) {
/*  974 */     return appendCommand(this.commandObjects.zmscore(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Tuple> zpopmax(String key) {
/*  979 */     return appendCommand(this.commandObjects.zpopmax(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zpopmax(String key, int count) {
/*  984 */     return appendCommand(this.commandObjects.zpopmax(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Tuple> zpopmin(String key) {
/*  989 */     return appendCommand(this.commandObjects.zpopmin(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zpopmin(String key, int count) {
/*  994 */     return appendCommand(this.commandObjects.zpopmin(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zcount(String key, double min, double max) {
/*  999 */     return appendCommand(this.commandObjects.zcount(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zcount(String key, String min, String max) {
/* 1004 */     return appendCommand(this.commandObjects.zcount(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrangeByScore(String key, double min, double max) {
/* 1009 */     return appendCommand(this.commandObjects.zrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrangeByScore(String key, String min, String max) {
/* 1014 */     return appendCommand(this.commandObjects.zrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrevrangeByScore(String key, double max, double min) {
/* 1019 */     return appendCommand(this.commandObjects.zrevrangeByScore(key, max, min));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrangeByScore(String key, double min, double max, int offset, int count) {
/* 1025 */     return appendCommand(this.commandObjects.zrangeByScore(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrevrangeByScore(String key, String max, String min) {
/* 1030 */     return appendCommand(this.commandObjects.zrevrangeByScore(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrangeByScore(String key, String min, String max, int offset, int count) {
/* 1035 */     return appendCommand(this.commandObjects.zrangeByScore(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrevrangeByScore(String key, double max, double min, int offset, int count) {
/* 1040 */     return appendCommand(this.commandObjects.zrevrangeByScore(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeByScoreWithScores(String key, double min, double max) {
/* 1045 */     return appendCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrevrangeByScoreWithScores(String key, double max, double min) {
/* 1050 */     return appendCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeByScoreWithScores(String key, double min, double max, int offset, int count) {
/* 1055 */     return appendCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrevrangeByScore(String key, String max, String min, int offset, int count) {
/* 1060 */     return appendCommand(this.commandObjects.zrevrangeByScore(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeByScoreWithScores(String key, String min, String max) {
/* 1065 */     return appendCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrevrangeByScoreWithScores(String key, String max, String min) {
/* 1070 */     return appendCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeByScoreWithScores(String key, String min, String max, int offset, int count) {
/* 1075 */     return appendCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrevrangeByScoreWithScores(String key, double max, double min, int offset, int count) {
/* 1080 */     return appendCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrevrangeByScoreWithScores(String key, String max, String min, int offset, int count) {
/* 1085 */     return appendCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrange(String key, ZRangeParams zRangeParams) {
/* 1090 */     return appendCommand(this.commandObjects.zrange(key, zRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeWithScores(String key, ZRangeParams zRangeParams) {
/* 1095 */     return appendCommand(this.commandObjects.zrangeWithScores(key, zRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zrangestore(String dest, String src, ZRangeParams zRangeParams) {
/* 1100 */     return appendCommand(this.commandObjects.zrangestore(dest, src, zRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zremrangeByRank(String key, long start, long stop) {
/* 1105 */     return appendCommand(this.commandObjects.zremrangeByRank(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zremrangeByScore(String key, double min, double max) {
/* 1110 */     return appendCommand(this.commandObjects.zremrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zremrangeByScore(String key, String min, String max) {
/* 1115 */     return appendCommand(this.commandObjects.zremrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zlexcount(String key, String min, String max) {
/* 1120 */     return appendCommand(this.commandObjects.zlexcount(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrangeByLex(String key, String min, String max) {
/* 1125 */     return appendCommand(this.commandObjects.zrangeByLex(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrangeByLex(String key, String min, String max, int offset, int count) {
/* 1130 */     return appendCommand(this.commandObjects.zrangeByLex(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrevrangeByLex(String key, String max, String min) {
/* 1135 */     return appendCommand(this.commandObjects.zrevrangeByLex(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> zrevrangeByLex(String key, String max, String min, int offset, int count) {
/* 1140 */     return appendCommand(this.commandObjects.zrevrangeByLex(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zremrangeByLex(String key, String min, String max) {
/* 1145 */     return appendCommand(this.commandObjects.zremrangeByLex(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<Tuple>> zscan(String key, String cursor, ScanParams params) {
/* 1150 */     return appendCommand(this.commandObjects.zscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyedZSetElement> bzpopmax(double timeout, String... keys) {
/* 1155 */     return appendCommand(this.commandObjects.bzpopmax(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyedZSetElement> bzpopmin(double timeout, String... keys) {
/* 1160 */     return appendCommand(this.commandObjects.bzpopmin(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<String, List<Tuple>>> zmpop(SortedSetOption option, String... keys) {
/* 1165 */     return appendCommand(this.commandObjects.zmpop(option, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<String, List<Tuple>>> zmpop(SortedSetOption option, int count, String... keys) {
/* 1170 */     return appendCommand(this.commandObjects.zmpop(option, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<String, List<Tuple>>> bzmpop(long timeout, SortedSetOption option, String... keys) {
/* 1175 */     return appendCommand(this.commandObjects.bzmpop(timeout, option, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<String, List<Tuple>>> bzmpop(long timeout, SortedSetOption option, int count, String... keys) {
/* 1180 */     return appendCommand(this.commandObjects.bzmpop(timeout, option, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<String>> zdiff(String... keys) {
/* 1185 */     return appendCommand(this.commandObjects.zdiff(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<Tuple>> zdiffWithScores(String... keys) {
/* 1190 */     return appendCommand(this.commandObjects.zdiffWithScores(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zdiffStore(String dstKey, String... keys) {
/* 1195 */     return appendCommand(this.commandObjects.zdiffStore(dstKey, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zinterstore(String dstKey, String... sets) {
/* 1200 */     return appendCommand(this.commandObjects.zinterstore(dstKey, sets));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zinterstore(String dstKey, ZParams params, String... sets) {
/* 1205 */     return appendCommand(this.commandObjects.zinterstore(dstKey, params, sets));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<String>> zinter(ZParams params, String... keys) {
/* 1210 */     return appendCommand(this.commandObjects.zinter(params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<Tuple>> zinterWithScores(ZParams params, String... keys) {
/* 1215 */     return appendCommand(this.commandObjects.zinterWithScores(params, keys));
/*      */   }
/*      */   
/*      */   public Response<Long> zintercard(String... keys) {
/* 1219 */     return appendCommand(this.commandObjects.zintercard(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zintercard(long limit, String... keys) {
/* 1224 */     return appendCommand(this.commandObjects.zintercard(limit, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<String>> zunion(ZParams params, String... keys) {
/* 1229 */     return appendCommand(this.commandObjects.zunion(params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<Tuple>> zunionWithScores(ZParams params, String... keys) {
/* 1234 */     return appendCommand(this.commandObjects.zunionWithScores(params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zunionstore(String dstKey, String... sets) {
/* 1239 */     return appendCommand(this.commandObjects.zunionstore(dstKey, sets));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zunionstore(String dstKey, ZParams params, String... sets) {
/* 1244 */     return appendCommand(this.commandObjects.zunionstore(dstKey, params, sets));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geoadd(String key, double longitude, double latitude, String member) {
/* 1249 */     return appendCommand(this.commandObjects.geoadd(key, longitude, latitude, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geoadd(String key, Map<String, GeoCoordinate> memberCoordinateMap) {
/* 1254 */     return appendCommand(this.commandObjects.geoadd(key, memberCoordinateMap));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geoadd(String key, GeoAddParams params, Map<String, GeoCoordinate> memberCoordinateMap) {
/* 1259 */     return appendCommand(this.commandObjects.geoadd(key, params, memberCoordinateMap));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> geodist(String key, String member1, String member2) {
/* 1264 */     return appendCommand(this.commandObjects.geodist(key, member1, member2));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> geodist(String key, String member1, String member2, GeoUnit unit) {
/* 1269 */     return appendCommand(this.commandObjects.geodist(key, member1, member2, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> geohash(String key, String... members) {
/* 1274 */     return appendCommand(this.commandObjects.geohash(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoCoordinate>> geopos(String key, String... members) {
/* 1279 */     return appendCommand(this.commandObjects.geopos(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadius(String key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 1284 */     return appendCommand(this.commandObjects.georadius(key, longitude, latitude, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusReadonly(String key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 1289 */     return appendCommand(this.commandObjects.georadiusReadonly(key, longitude, latitude, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadius(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 1294 */     return appendCommand(this.commandObjects.georadius(key, longitude, latitude, radius, unit, param));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusReadonly(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 1299 */     return appendCommand(this.commandObjects.georadiusReadonly(key, longitude, latitude, radius, unit, param));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusByMember(String key, String member, double radius, GeoUnit unit) {
/* 1304 */     return appendCommand(this.commandObjects.georadiusByMember(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusByMemberReadonly(String key, String member, double radius, GeoUnit unit) {
/* 1309 */     return appendCommand(this.commandObjects.georadiusByMemberReadonly(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusByMember(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 1314 */     return appendCommand(this.commandObjects.georadiusByMember(key, member, radius, unit, param));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusByMemberReadonly(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 1319 */     return appendCommand(this.commandObjects.georadiusByMemberReadonly(key, member, radius, unit, param));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> georadiusStore(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 1324 */     return appendCommand(this.commandObjects.georadiusStore(key, longitude, latitude, radius, unit, param, storeParam));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> georadiusByMemberStore(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 1329 */     return appendCommand(this.commandObjects.georadiusByMemberStore(key, member, radius, unit, param, storeParam));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> geosearch(String key, String member, double radius, GeoUnit unit) {
/* 1334 */     return appendCommand(this.commandObjects.geosearch(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> geosearch(String key, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 1339 */     return appendCommand(this.commandObjects.geosearch(key, coord, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> geosearch(String key, String member, double width, double height, GeoUnit unit) {
/* 1344 */     return appendCommand(this.commandObjects.geosearch(key, member, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> geosearch(String key, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 1349 */     return appendCommand(this.commandObjects.geosearch(key, coord, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> geosearch(String key, GeoSearchParam params) {
/* 1354 */     return appendCommand(this.commandObjects.geosearch(key, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStore(String dest, String src, String member, double radius, GeoUnit unit) {
/* 1359 */     return appendCommand(this.commandObjects.geosearchStore(dest, src, member, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStore(String dest, String src, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 1364 */     return appendCommand(this.commandObjects.geosearchStore(dest, src, coord, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStore(String dest, String src, String member, double width, double height, GeoUnit unit) {
/* 1369 */     return appendCommand(this.commandObjects.geosearchStore(dest, src, member, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStore(String dest, String src, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 1374 */     return appendCommand(this.commandObjects.geosearchStore(dest, src, coord, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStore(String dest, String src, GeoSearchParam params) {
/* 1379 */     return appendCommand(this.commandObjects.geosearchStore(dest, src, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStoreStoreDist(String dest, String src, GeoSearchParam params) {
/* 1384 */     return appendCommand(this.commandObjects.geosearchStoreStoreDist(dest, src, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pfadd(String key, String... elements) {
/* 1389 */     return appendCommand(this.commandObjects.pfadd(key, elements));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> pfmerge(String destkey, String... sourcekeys) {
/* 1394 */     return appendCommand(this.commandObjects.pfmerge(destkey, sourcekeys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pfcount(String key) {
/* 1399 */     return appendCommand(this.commandObjects.pfcount(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pfcount(String... keys) {
/* 1404 */     return appendCommand(this.commandObjects.pfcount(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<StreamEntryID> xadd(String key, StreamEntryID id, Map<String, String> hash) {
/* 1409 */     return appendCommand(this.commandObjects.xadd(key, id, hash));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<StreamEntryID> xadd(String key, XAddParams params, Map<String, String> hash) {
/* 1414 */     return appendCommand(this.commandObjects.xadd(key, params, hash));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xlen(String key) {
/* 1419 */     return appendCommand(this.commandObjects.xlen(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamEntry>> xrange(String key, StreamEntryID start, StreamEntryID end) {
/* 1424 */     return appendCommand(this.commandObjects.xrange(key, start, end));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamEntry>> xrange(String key, StreamEntryID start, StreamEntryID end, int count) {
/* 1429 */     return appendCommand(this.commandObjects.xrange(key, start, end, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamEntry>> xrevrange(String key, StreamEntryID end, StreamEntryID start) {
/* 1434 */     return appendCommand(this.commandObjects.xrevrange(key, end, start));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamEntry>> xrevrange(String key, StreamEntryID end, StreamEntryID start, int count) {
/* 1439 */     return appendCommand(this.commandObjects.xrevrange(key, end, start, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamEntry>> xrange(String key, String start, String end) {
/* 1444 */     return appendCommand(this.commandObjects.xrange(key, start, end));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamEntry>> xrange(String key, String start, String end, int count) {
/* 1449 */     return appendCommand(this.commandObjects.xrange(key, start, end, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamEntry>> xrevrange(String key, String end, String start) {
/* 1454 */     return appendCommand(this.commandObjects.xrevrange(key, end, start));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamEntry>> xrevrange(String key, String end, String start, int count) {
/* 1459 */     return appendCommand(this.commandObjects.xrevrange(key, end, start, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xack(String key, String group, StreamEntryID... ids) {
/* 1464 */     return appendCommand(this.commandObjects.xack(key, group, ids));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> xgroupCreate(String key, String groupName, StreamEntryID id, boolean makeStream) {
/* 1469 */     return appendCommand(this.commandObjects.xgroupCreate(key, groupName, id, makeStream));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> xgroupSetID(String key, String groupName, StreamEntryID id) {
/* 1474 */     return appendCommand(this.commandObjects.xgroupSetID(key, groupName, id));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xgroupDestroy(String key, String groupName) {
/* 1479 */     return appendCommand(this.commandObjects.xgroupDestroy(key, groupName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> xgroupCreateConsumer(String key, String groupName, String consumerName) {
/* 1484 */     return appendCommand(this.commandObjects.xgroupCreateConsumer(key, groupName, consumerName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xgroupDelConsumer(String key, String groupName, String consumerName) {
/* 1489 */     return appendCommand(this.commandObjects.xgroupDelConsumer(key, groupName, consumerName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<StreamPendingSummary> xpending(String key, String groupName) {
/* 1494 */     return appendCommand(this.commandObjects.xpending(key, groupName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamPendingEntry>> xpending(String key, String groupName, StreamEntryID start, StreamEntryID end, int count, String consumerName) {
/* 1499 */     return appendCommand(this.commandObjects.xpending(key, groupName, start, end, count, consumerName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamPendingEntry>> xpending(String key, String groupName, XPendingParams params) {
/* 1504 */     return appendCommand(this.commandObjects.xpending(key, groupName, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xdel(String key, StreamEntryID... ids) {
/* 1509 */     return appendCommand(this.commandObjects.xdel(key, ids));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xtrim(String key, long maxLen, boolean approximate) {
/* 1514 */     return appendCommand(this.commandObjects.xtrim(key, maxLen, approximate));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xtrim(String key, XTrimParams params) {
/* 1519 */     return appendCommand(this.commandObjects.xtrim(key, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamEntry>> xclaim(String key, String group, String consumerName, long minIdleTime, XClaimParams params, StreamEntryID... ids) {
/* 1524 */     return appendCommand(this.commandObjects.xclaim(key, group, consumerName, minIdleTime, params, ids));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamEntryID>> xclaimJustId(String key, String group, String consumerName, long minIdleTime, XClaimParams params, StreamEntryID... ids) {
/* 1529 */     return appendCommand(this.commandObjects.xclaimJustId(key, group, consumerName, minIdleTime, params, ids));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map.Entry<StreamEntryID, List<StreamEntry>>> xautoclaim(String key, String group, String consumerName, long minIdleTime, StreamEntryID start, XAutoClaimParams params) {
/* 1534 */     return appendCommand(this.commandObjects.xautoclaim(key, group, consumerName, minIdleTime, start, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map.Entry<StreamEntryID, List<StreamEntryID>>> xautoclaimJustId(String key, String group, String consumerName, long minIdleTime, StreamEntryID start, XAutoClaimParams params) {
/* 1539 */     return appendCommand(this.commandObjects.xautoclaimJustId(key, group, consumerName, minIdleTime, start, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<StreamInfo> xinfoStream(String key) {
/* 1544 */     return appendCommand(this.commandObjects.xinfoStream(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<StreamFullInfo> xinfoStreamFull(String key) {
/* 1549 */     return appendCommand(this.commandObjects.xinfoStreamFull(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<StreamFullInfo> xinfoStreamFull(String key, int count) {
/* 1554 */     return appendCommand(this.commandObjects.xinfoStreamFull(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Response<List<StreamGroupInfo>> xinfoGroup(String key) {
/* 1560 */     return appendCommand(this.commandObjects.xinfoGroup(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamGroupInfo>> xinfoGroups(String key) {
/* 1565 */     return appendCommand(this.commandObjects.xinfoGroups(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<StreamConsumersInfo>> xinfoConsumers(String key, String group) {
/* 1570 */     return appendCommand(this.commandObjects.xinfoConsumers(key, group));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Map.Entry<String, List<StreamEntry>>>> xread(XReadParams xReadParams, Map<String, StreamEntryID> streams) {
/* 1575 */     return appendCommand(this.commandObjects.xread(xReadParams, streams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Map.Entry<String, List<StreamEntry>>>> xreadGroup(String groupName, String consumer, XReadGroupParams xReadGroupParams, Map<String, StreamEntryID> streams) {
/* 1580 */     return appendCommand(this.commandObjects.xreadGroup(groupName, consumer, xReadGroupParams, streams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> eval(String script) {
/* 1585 */     return appendCommand(this.commandObjects.eval(script));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> eval(String script, int keyCount, String... params) {
/* 1590 */     return appendCommand(this.commandObjects.eval(script, keyCount, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> eval(String script, List<String> keys, List<String> args) {
/* 1595 */     return appendCommand(this.commandObjects.eval(script, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalReadonly(String script, List<String> keys, List<String> args) {
/* 1600 */     return appendCommand(this.commandObjects.evalReadonly(script, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalsha(String sha1) {
/* 1605 */     return appendCommand(this.commandObjects.evalsha(sha1));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalsha(String sha1, int keyCount, String... params) {
/* 1610 */     return appendCommand(this.commandObjects.evalsha(sha1, keyCount, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalsha(String sha1, List<String> keys, List<String> args) {
/* 1615 */     return appendCommand(this.commandObjects.evalsha(sha1, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalshaReadonly(String sha1, List<String> keys, List<String> args) {
/* 1620 */     return appendCommand(this.commandObjects.evalshaReadonly(sha1, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> waitReplicas(String sampleKey, int replicas, long timeout) {
/* 1625 */     return appendCommand(this.commandObjects.waitReplicas(sampleKey, replicas, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> eval(String script, String sampleKey) {
/* 1630 */     return appendCommand(this.commandObjects.eval(script, sampleKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalsha(String sha1, String sampleKey) {
/* 1635 */     return appendCommand(this.commandObjects.evalsha(sha1, sampleKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> scriptExists(String sampleKey, String... sha1) {
/* 1640 */     return appendCommand(this.commandObjects.scriptExists(sampleKey, sha1));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> scriptLoad(String script, String sampleKey) {
/* 1645 */     return appendCommand(this.commandObjects.scriptLoad(script, sampleKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> scriptFlush(String sampleKey) {
/* 1650 */     return appendCommand(this.commandObjects.scriptFlush(sampleKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> scriptFlush(String sampleKey, FlushMode flushMode) {
/* 1655 */     return appendCommand(this.commandObjects.scriptFlush(sampleKey, flushMode));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> scriptKill(String sampleKey) {
/* 1660 */     return appendCommand(this.commandObjects.scriptKill(sampleKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> fcall(byte[] name, List<byte[]> keys, List<byte[]> args) {
/* 1665 */     return appendCommand(this.commandObjects.fcall(name, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> fcall(String name, List<String> keys, List<String> args) {
/* 1670 */     return appendCommand(this.commandObjects.fcall(name, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> fcallReadonly(byte[] name, List<byte[]> keys, List<byte[]> args) {
/* 1675 */     return appendCommand(this.commandObjects.fcallReadonly(name, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> fcallReadonly(String name, List<String> keys, List<String> args) {
/* 1680 */     return appendCommand(this.commandObjects.fcallReadonly(name, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionDelete(byte[] libraryName) {
/* 1685 */     return appendCommand(this.commandObjects.functionDelete(libraryName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionDelete(String libraryName) {
/* 1690 */     return appendCommand(this.commandObjects.functionDelete(libraryName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> functionDump() {
/* 1695 */     return (Response)appendCommand((CommandObject)this.commandObjects.functionDump());
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<LibraryInfo>> functionList(String libraryNamePattern) {
/* 1700 */     return appendCommand(this.commandObjects.functionList(libraryNamePattern));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<LibraryInfo>> functionList() {
/* 1705 */     return appendCommand(this.commandObjects.functionList());
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<LibraryInfo>> functionListWithCode(String libraryNamePattern) {
/* 1710 */     return appendCommand(this.commandObjects.functionListWithCode(libraryNamePattern));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<LibraryInfo>> functionListWithCode() {
/* 1715 */     return appendCommand(this.commandObjects.functionListWithCode());
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> functionListBinary() {
/* 1720 */     return appendCommand(this.commandObjects.functionListBinary());
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> functionList(byte[] libraryNamePattern) {
/* 1725 */     return appendCommand(this.commandObjects.functionList(libraryNamePattern));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> functionListWithCodeBinary() {
/* 1730 */     return appendCommand(this.commandObjects.functionListWithCodeBinary());
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> functionListWithCode(byte[] libraryNamePattern) {
/* 1735 */     return appendCommand(this.commandObjects.functionListWithCode(libraryNamePattern));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionLoad(byte[] engineName, byte[] libraryName, byte[] functionCode) {
/* 1740 */     return appendCommand(this.commandObjects.functionLoad(engineName, libraryName, functionCode));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionLoad(String engineName, String libraryName, String functionCode) {
/* 1745 */     return appendCommand(this.commandObjects.functionLoad(engineName, libraryName, functionCode));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionLoad(byte[] engineName, byte[] libraryName, FunctionLoadParams params, byte[] functionCode) {
/* 1750 */     return appendCommand(this.commandObjects.functionLoad(engineName, libraryName, params, functionCode));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionLoad(String engineName, String libraryName, FunctionLoadParams params, String functionCode) {
/* 1755 */     return appendCommand(this.commandObjects.functionLoad(engineName, libraryName, params, functionCode));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionRestore(byte[] serializedValue) {
/* 1760 */     return appendCommand(this.commandObjects.functionRestore(serializedValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionRestore(byte[] serializedValue, FunctionRestorePolicy policy) {
/* 1765 */     return appendCommand(this.commandObjects.functionRestore(serializedValue, policy));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionFlush() {
/* 1770 */     return appendCommand(this.commandObjects.functionFlush());
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionFlush(FlushMode mode) {
/* 1775 */     return appendCommand(this.commandObjects.functionFlush(mode));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> functionKill() {
/* 1780 */     return appendCommand(this.commandObjects.functionKill());
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<FunctionStats> functionStats() {
/* 1785 */     return appendCommand(this.commandObjects.functionStats());
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> functionStatsBinary() {
/* 1790 */     return appendCommand(this.commandObjects.functionStatsBinary());
/*      */   }
/*      */   
/*      */   public Response<Long> publish(String channel, String message) {
/* 1794 */     return appendCommand(this.commandObjects.publish(channel, message));
/*      */   }
/*      */   
/*      */   public Response<LCSMatchResult> strAlgoLCSStrings(String strA, String strB, StrAlgoLCSParams params) {
/* 1798 */     return appendCommand(this.commandObjects.strAlgoLCSStrings(strA, strB, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geoadd(byte[] key, double longitude, double latitude, byte[] member) {
/* 1803 */     return appendCommand(this.commandObjects.geoadd(key, longitude, latitude, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geoadd(byte[] key, Map<byte[], GeoCoordinate> memberCoordinateMap) {
/* 1808 */     return appendCommand(this.commandObjects.geoadd(key, memberCoordinateMap));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geoadd(byte[] key, GeoAddParams params, Map<byte[], GeoCoordinate> memberCoordinateMap) {
/* 1813 */     return appendCommand(this.commandObjects.geoadd(key, params, memberCoordinateMap));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> geodist(byte[] key, byte[] member1, byte[] member2) {
/* 1818 */     return appendCommand(this.commandObjects.geodist(key, member1, member2));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> geodist(byte[] key, byte[] member1, byte[] member2, GeoUnit unit) {
/* 1823 */     return appendCommand(this.commandObjects.geodist(key, member1, member2, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> geohash(byte[] key, byte[]... members) {
/* 1828 */     return appendCommand(this.commandObjects.geohash(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoCoordinate>> geopos(byte[] key, byte[]... members) {
/* 1833 */     return appendCommand(this.commandObjects.geopos(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadius(byte[] key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 1838 */     return appendCommand(this.commandObjects.georadius(key, longitude, latitude, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusReadonly(byte[] key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 1843 */     return appendCommand(this.commandObjects.georadiusReadonly(key, longitude, latitude, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadius(byte[] key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 1848 */     return appendCommand(this.commandObjects.georadius(key, longitude, latitude, radius, unit, param));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusReadonly(byte[] key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 1853 */     return appendCommand(this.commandObjects.georadiusReadonly(key, longitude, latitude, radius, unit, param));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusByMember(byte[] key, byte[] member, double radius, GeoUnit unit) {
/* 1858 */     return appendCommand(this.commandObjects.georadiusByMember(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusByMemberReadonly(byte[] key, byte[] member, double radius, GeoUnit unit) {
/* 1863 */     return appendCommand(this.commandObjects.georadiusByMemberReadonly(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusByMember(byte[] key, byte[] member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 1868 */     return appendCommand(this.commandObjects.georadiusByMember(key, member, radius, unit, param));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> georadiusByMemberReadonly(byte[] key, byte[] member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 1873 */     return appendCommand(this.commandObjects.georadiusByMemberReadonly(key, member, radius, unit, param));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> georadiusStore(byte[] key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 1878 */     return appendCommand(this.commandObjects.georadiusStore(key, longitude, latitude, radius, unit, param, storeParam));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> georadiusByMemberStore(byte[] key, byte[] member, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 1883 */     return appendCommand(this.commandObjects.georadiusByMemberStore(key, member, radius, unit, param, storeParam));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> geosearch(byte[] key, byte[] member, double radius, GeoUnit unit) {
/* 1888 */     return appendCommand(this.commandObjects.geosearch(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> geosearch(byte[] key, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 1893 */     return appendCommand(this.commandObjects.geosearch(key, coord, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> geosearch(byte[] key, byte[] member, double width, double height, GeoUnit unit) {
/* 1898 */     return appendCommand(this.commandObjects.geosearch(key, member, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> geosearch(byte[] key, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 1903 */     return appendCommand(this.commandObjects.geosearch(key, coord, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<GeoRadiusResponse>> geosearch(byte[] key, GeoSearchParam params) {
/* 1908 */     return appendCommand(this.commandObjects.geosearch(key, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStore(byte[] dest, byte[] src, byte[] member, double radius, GeoUnit unit) {
/* 1913 */     return appendCommand(this.commandObjects.geosearchStore(dest, src, member, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStore(byte[] dest, byte[] src, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 1918 */     return appendCommand(this.commandObjects.geosearchStore(dest, src, coord, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStore(byte[] dest, byte[] src, byte[] member, double width, double height, GeoUnit unit) {
/* 1923 */     return appendCommand(this.commandObjects.geosearchStore(dest, src, member, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStore(byte[] dest, byte[] src, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 1928 */     return appendCommand(this.commandObjects.geosearchStore(dest, src, coord, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStore(byte[] dest, byte[] src, GeoSearchParam params) {
/* 1933 */     return appendCommand(this.commandObjects.geosearchStore(dest, src, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> geosearchStoreStoreDist(byte[] dest, byte[] src, GeoSearchParam params) {
/* 1938 */     return appendCommand(this.commandObjects.geosearchStoreStoreDist(dest, src, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hset(byte[] key, byte[] field, byte[] value) {
/* 1943 */     return appendCommand(this.commandObjects.hset(key, field, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hset(byte[] key, Map<byte[], byte[]> hash) {
/* 1948 */     return appendCommand(this.commandObjects.hset(key, hash));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> hget(byte[] key, byte[] field) {
/* 1953 */     return (Response)appendCommand((CommandObject)this.commandObjects.hget(key, field));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hsetnx(byte[] key, byte[] field, byte[] value) {
/* 1958 */     return appendCommand(this.commandObjects.hsetnx(key, field, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> hmset(byte[] key, Map<byte[], byte[]> hash) {
/* 1963 */     return appendCommand(this.commandObjects.hmset(key, hash));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> hmget(byte[] key, byte[]... fields) {
/* 1968 */     return appendCommand(this.commandObjects.hmget(key, fields));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hincrBy(byte[] key, byte[] field, long value) {
/* 1973 */     return appendCommand(this.commandObjects.hincrBy(key, field, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> hincrByFloat(byte[] key, byte[] field, double value) {
/* 1978 */     return appendCommand(this.commandObjects.hincrByFloat(key, field, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> hexists(byte[] key, byte[] field) {
/* 1983 */     return appendCommand(this.commandObjects.hexists(key, field));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hdel(byte[] key, byte[]... field) {
/* 1988 */     return appendCommand(this.commandObjects.hdel(key, field));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hlen(byte[] key) {
/* 1993 */     return appendCommand(this.commandObjects.hlen(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<byte[]>> hkeys(byte[] key) {
/* 1998 */     return appendCommand(this.commandObjects.hkeys(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> hvals(byte[] key) {
/* 2003 */     return appendCommand(this.commandObjects.hvals(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<byte[], byte[]>> hgetAll(byte[] key) {
/* 2008 */     return appendCommand(this.commandObjects.hgetAll(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> hrandfield(byte[] key) {
/* 2013 */     return (Response)appendCommand((CommandObject)this.commandObjects.hrandfield(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> hrandfield(byte[] key, long count) {
/* 2018 */     return appendCommand(this.commandObjects.hrandfield(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<byte[], byte[]>> hrandfieldWithValues(byte[] key, long count) {
/* 2023 */     return appendCommand(this.commandObjects.hrandfieldWithValues(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<Map.Entry<byte[], byte[]>>> hscan(byte[] key, byte[] cursor, ScanParams params) {
/* 2028 */     return appendCommand(this.commandObjects.hscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> hstrlen(byte[] key, byte[] field) {
/* 2033 */     return appendCommand(this.commandObjects.hstrlen(key, field));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pfadd(byte[] key, byte[]... elements) {
/* 2038 */     return appendCommand(this.commandObjects.pfadd(key, elements));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> pfmerge(byte[] destkey, byte[]... sourcekeys) {
/* 2043 */     return appendCommand(this.commandObjects.pfmerge(destkey, sourcekeys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pfcount(byte[] key) {
/* 2048 */     return appendCommand(this.commandObjects.pfcount(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pfcount(byte[]... keys) {
/* 2053 */     return appendCommand(this.commandObjects.pfcount(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> exists(byte[] key) {
/* 2058 */     return appendCommand(this.commandObjects.exists(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> exists(byte[]... keys) {
/* 2063 */     return appendCommand(this.commandObjects.exists(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> persist(byte[] key) {
/* 2068 */     return appendCommand(this.commandObjects.persist(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> type(byte[] key) {
/* 2073 */     return appendCommand(this.commandObjects.type(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> dump(byte[] key) {
/* 2078 */     return (Response)appendCommand((CommandObject)this.commandObjects.dump(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> restore(byte[] key, long ttl, byte[] serializedValue) {
/* 2083 */     return appendCommand(this.commandObjects.restore(key, ttl, serializedValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> restore(byte[] key, long ttl, byte[] serializedValue, RestoreParams params) {
/* 2088 */     return appendCommand(this.commandObjects.restore(key, ttl, serializedValue, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> expire(byte[] key, long seconds) {
/* 2093 */     return appendCommand(this.commandObjects.expire(key, seconds));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> expire(byte[] key, long seconds, ExpiryOption expiryOption) {
/* 2098 */     return appendCommand(this.commandObjects.expire(key, seconds, expiryOption));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pexpire(byte[] key, long milliseconds) {
/* 2103 */     return appendCommand(this.commandObjects.pexpire(key, milliseconds));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pexpire(byte[] key, long milliseconds, ExpiryOption expiryOption) {
/* 2108 */     return appendCommand(this.commandObjects.pexpire(key, milliseconds, expiryOption));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> expireTime(byte[] key) {
/* 2113 */     return appendCommand(this.commandObjects.expireTime(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pexpireTime(byte[] key) {
/* 2118 */     return appendCommand(this.commandObjects.pexpireTime(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> expireAt(byte[] key, long unixTime) {
/* 2123 */     return appendCommand(this.commandObjects.expireAt(key, unixTime));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> expireAt(byte[] key, long unixTime, ExpiryOption expiryOption) {
/* 2128 */     return appendCommand(this.commandObjects.expireAt(key, unixTime));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pexpireAt(byte[] key, long millisecondsTimestamp) {
/* 2133 */     return appendCommand(this.commandObjects.pexpireAt(key, millisecondsTimestamp));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pexpireAt(byte[] key, long millisecondsTimestamp, ExpiryOption expiryOption) {
/* 2138 */     return appendCommand(this.commandObjects.pexpireAt(key, millisecondsTimestamp, expiryOption));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> ttl(byte[] key) {
/* 2143 */     return appendCommand(this.commandObjects.ttl(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> pttl(byte[] key) {
/* 2148 */     return appendCommand(this.commandObjects.pttl(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> touch(byte[] key) {
/* 2153 */     return appendCommand(this.commandObjects.touch(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> touch(byte[]... keys) {
/* 2158 */     return appendCommand(this.commandObjects.touch(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> sort(byte[] key) {
/* 2163 */     return appendCommand(this.commandObjects.sort(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> sort(byte[] key, SortingParams sortingParams) {
/* 2168 */     return appendCommand(this.commandObjects.sort(key, sortingParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> sortReadonly(byte[] key, SortingParams sortingParams) {
/* 2173 */     return appendCommand(this.commandObjects.sortReadonly(key, sortingParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> del(byte[] key) {
/* 2178 */     return appendCommand(this.commandObjects.del(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> del(byte[]... keys) {
/* 2183 */     return appendCommand(this.commandObjects.del(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> unlink(byte[] key) {
/* 2188 */     return appendCommand(this.commandObjects.unlink(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> unlink(byte[]... keys) {
/* 2193 */     return appendCommand(this.commandObjects.unlink(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> copy(byte[] srcKey, byte[] dstKey, boolean replace) {
/* 2198 */     return appendCommand(this.commandObjects.copy(srcKey, dstKey, replace));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> rename(byte[] oldkey, byte[] newkey) {
/* 2203 */     return appendCommand(this.commandObjects.rename(oldkey, newkey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> renamenx(byte[] oldkey, byte[] newkey) {
/* 2208 */     return appendCommand(this.commandObjects.renamenx(oldkey, newkey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sort(byte[] key, SortingParams sortingParams, byte[] dstkey) {
/* 2213 */     return appendCommand(this.commandObjects.sort(key, sortingParams, dstkey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sort(byte[] key, byte[] dstkey) {
/* 2218 */     return appendCommand(this.commandObjects.sort(key, dstkey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> memoryUsage(byte[] key) {
/* 2223 */     return appendCommand(this.commandObjects.memoryUsage(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> memoryUsage(byte[] key, int samples) {
/* 2228 */     return appendCommand(this.commandObjects.memoryUsage(key, samples));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> objectRefcount(byte[] key) {
/* 2233 */     return appendCommand(this.commandObjects.objectRefcount(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> objectEncoding(byte[] key) {
/* 2238 */     return (Response)appendCommand((CommandObject)this.commandObjects.objectEncoding(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> objectIdletime(byte[] key) {
/* 2243 */     return appendCommand(this.commandObjects.objectIdletime(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> objectFreq(byte[] key) {
/* 2248 */     return appendCommand(this.commandObjects.objectFreq(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> migrate(String host, int port, byte[] key, int timeout) {
/* 2253 */     return appendCommand(this.commandObjects.migrate(host, port, key, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> migrate(String host, int port, int timeout, MigrateParams params, byte[]... keys) {
/* 2258 */     return appendCommand(this.commandObjects.migrate(host, port, timeout, params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<byte[]>> keys(byte[] pattern) {
/* 2263 */     return appendCommand(this.commandObjects.keys(pattern));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<byte[]>> scan(byte[] cursor) {
/* 2268 */     return appendCommand(this.commandObjects.scan(cursor));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<byte[]>> scan(byte[] cursor, ScanParams params) {
/* 2273 */     return appendCommand(this.commandObjects.scan(cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<byte[]>> scan(byte[] cursor, ScanParams params, byte[] type) {
/* 2278 */     return appendCommand(this.commandObjects.scan(cursor, params, type));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> randomBinaryKey() {
/* 2283 */     return (Response)appendCommand((CommandObject)this.commandObjects.randomBinaryKey());
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> rpush(byte[] key, byte[]... args) {
/* 2288 */     return appendCommand(this.commandObjects.rpush(key, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> lpush(byte[] key, byte[]... args) {
/* 2293 */     return appendCommand(this.commandObjects.lpush(key, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> llen(byte[] key) {
/* 2298 */     return appendCommand(this.commandObjects.llen(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> lrange(byte[] key, long start, long stop) {
/* 2303 */     return appendCommand(this.commandObjects.lrange(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ltrim(byte[] key, long start, long stop) {
/* 2308 */     return appendCommand(this.commandObjects.ltrim(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> lindex(byte[] key, long index) {
/* 2313 */     return (Response)appendCommand((CommandObject)this.commandObjects.lindex(key, index));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> lset(byte[] key, long index, byte[] value) {
/* 2318 */     return appendCommand(this.commandObjects.lset(key, index, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> lrem(byte[] key, long count, byte[] value) {
/* 2323 */     return appendCommand(this.commandObjects.lrem(key, count, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> lpop(byte[] key) {
/* 2328 */     return (Response)appendCommand((CommandObject)this.commandObjects.lpop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> lpop(byte[] key, int count) {
/* 2333 */     return appendCommand(this.commandObjects.lpop(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> lpos(byte[] key, byte[] element) {
/* 2338 */     return appendCommand(this.commandObjects.lpos(key, element));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> lpos(byte[] key, byte[] element, LPosParams params) {
/* 2343 */     return appendCommand(this.commandObjects.lpos(key, element, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> lpos(byte[] key, byte[] element, LPosParams params, long count) {
/* 2348 */     return appendCommand(this.commandObjects.lpos(key, element, params, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> rpop(byte[] key) {
/* 2353 */     return (Response)appendCommand((CommandObject)this.commandObjects.rpop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> rpop(byte[] key, int count) {
/* 2358 */     return appendCommand(this.commandObjects.rpop(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> linsert(byte[] key, ListPosition where, byte[] pivot, byte[] value) {
/* 2363 */     return appendCommand(this.commandObjects.linsert(key, where, pivot, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> lpushx(byte[] key, byte[]... args) {
/* 2368 */     return appendCommand(this.commandObjects.lpushx(key, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> rpushx(byte[] key, byte[]... args) {
/* 2373 */     return appendCommand(this.commandObjects.rpushx(key, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> blpop(int timeout, byte[]... keys) {
/* 2378 */     return appendCommand(this.commandObjects.blpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> blpop(double timeout, byte[]... keys) {
/* 2383 */     return appendCommand(this.commandObjects.blpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> brpop(int timeout, byte[]... keys) {
/* 2388 */     return appendCommand(this.commandObjects.brpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> brpop(double timeout, byte[]... keys) {
/* 2393 */     return appendCommand(this.commandObjects.brpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> rpoplpush(byte[] srckey, byte[] dstkey) {
/* 2398 */     return (Response)appendCommand((CommandObject)this.commandObjects.rpoplpush(srckey, dstkey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> brpoplpush(byte[] source, byte[] destination, int timeout) {
/* 2403 */     return (Response)appendCommand((CommandObject)this.commandObjects.brpoplpush(source, destination, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> lmove(byte[] srcKey, byte[] dstKey, ListDirection from, ListDirection to) {
/* 2408 */     return (Response)appendCommand((CommandObject)this.commandObjects.lmove(srcKey, dstKey, from, to));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> blmove(byte[] srcKey, byte[] dstKey, ListDirection from, ListDirection to, double timeout) {
/* 2413 */     return (Response)appendCommand((CommandObject)this.commandObjects.blmove(srcKey, dstKey, from, to, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<byte[], List<byte[]>>> lmpop(ListDirection direction, byte[]... keys) {
/* 2418 */     return appendCommand(this.commandObjects.lmpop(direction, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<byte[], List<byte[]>>> lmpop(ListDirection direction, int count, byte[]... keys) {
/* 2423 */     return appendCommand(this.commandObjects.lmpop(direction, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<byte[], List<byte[]>>> blmpop(long timeout, ListDirection direction, byte[]... keys) {
/* 2428 */     return appendCommand(this.commandObjects.blmpop(timeout, direction, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<byte[], List<byte[]>>> blmpop(long timeout, ListDirection direction, int count, byte[]... keys) {
/* 2433 */     return appendCommand(this.commandObjects.blmpop(timeout, direction, count, keys));
/*      */   }
/*      */   
/*      */   public Response<Long> publish(byte[] channel, byte[] message) {
/* 2437 */     return appendCommand(this.commandObjects.publish(channel, message));
/*      */   }
/*      */   
/*      */   public Response<LCSMatchResult> strAlgoLCSStrings(byte[] strA, byte[] strB, StrAlgoLCSParams params) {
/* 2441 */     return appendCommand(this.commandObjects.strAlgoLCSStrings(strA, strB, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> waitReplicas(byte[] sampleKey, int replicas, long timeout) {
/* 2446 */     return appendCommand(this.commandObjects.waitReplicas(sampleKey, replicas, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> eval(byte[] script, byte[] sampleKey) {
/* 2451 */     return appendCommand(this.commandObjects.eval(script, sampleKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalsha(byte[] sha1, byte[] sampleKey) {
/* 2456 */     return appendCommand(this.commandObjects.evalsha(sha1, sampleKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> scriptExists(byte[] sampleKey, byte[]... sha1s) {
/* 2461 */     return appendCommand(this.commandObjects.scriptExists(sampleKey, sha1s));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> scriptLoad(byte[] script, byte[] sampleKey) {
/* 2466 */     return (Response)appendCommand((CommandObject)this.commandObjects.scriptLoad(script, sampleKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> scriptFlush(byte[] sampleKey) {
/* 2471 */     return appendCommand(this.commandObjects.scriptFlush(sampleKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> scriptFlush(byte[] sampleKey, FlushMode flushMode) {
/* 2476 */     return appendCommand(this.commandObjects.scriptFlush(sampleKey, flushMode));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> scriptKill(byte[] sampleKey) {
/* 2481 */     return appendCommand(this.commandObjects.scriptKill(sampleKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> eval(byte[] script) {
/* 2486 */     return appendCommand(this.commandObjects.eval(script));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> eval(byte[] script, int keyCount, byte[]... params) {
/* 2491 */     return appendCommand(this.commandObjects.eval(script, keyCount, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> eval(byte[] script, List<byte[]> keys, List<byte[]> args) {
/* 2496 */     return appendCommand(this.commandObjects.eval(script, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalReadonly(byte[] script, List<byte[]> keys, List<byte[]> args) {
/* 2501 */     return appendCommand(this.commandObjects.evalReadonly(script, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalsha(byte[] sha1) {
/* 2506 */     return appendCommand(this.commandObjects.evalsha(sha1));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalsha(byte[] sha1, int keyCount, byte[]... params) {
/* 2511 */     return appendCommand(this.commandObjects.evalsha(sha1, keyCount, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalsha(byte[] sha1, List<byte[]> keys, List<byte[]> args) {
/* 2516 */     return appendCommand(this.commandObjects.evalsha(sha1, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> evalshaReadonly(byte[] sha1, List<byte[]> keys, List<byte[]> args) {
/* 2521 */     return appendCommand(this.commandObjects.evalshaReadonly(sha1, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sadd(byte[] key, byte[]... members) {
/* 2526 */     return appendCommand(this.commandObjects.sadd(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<byte[]>> smembers(byte[] key) {
/* 2531 */     return appendCommand(this.commandObjects.smembers(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> srem(byte[] key, byte[]... members) {
/* 2536 */     return appendCommand(this.commandObjects.srem(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> spop(byte[] key) {
/* 2541 */     return (Response)appendCommand((CommandObject)this.commandObjects.spop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<byte[]>> spop(byte[] key, long count) {
/* 2546 */     return appendCommand(this.commandObjects.spop(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> scard(byte[] key) {
/* 2551 */     return appendCommand(this.commandObjects.scard(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> sismember(byte[] key, byte[] member) {
/* 2556 */     return appendCommand(this.commandObjects.sismember(key, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> smismember(byte[] key, byte[]... members) {
/* 2561 */     return appendCommand(this.commandObjects.smismember(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> srandmember(byte[] key) {
/* 2566 */     return (Response)appendCommand((CommandObject)this.commandObjects.srandmember(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> srandmember(byte[] key, int count) {
/* 2571 */     return appendCommand(this.commandObjects.srandmember(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<byte[]>> sscan(byte[] key, byte[] cursor, ScanParams params) {
/* 2576 */     return appendCommand(this.commandObjects.sscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<byte[]>> sdiff(byte[]... keys) {
/* 2581 */     return appendCommand(this.commandObjects.sdiff(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sdiffstore(byte[] dstkey, byte[]... keys) {
/* 2586 */     return appendCommand(this.commandObjects.sdiffstore(dstkey, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<byte[]>> sinter(byte[]... keys) {
/* 2591 */     return appendCommand(this.commandObjects.sinter(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sinterstore(byte[] dstkey, byte[]... keys) {
/* 2596 */     return appendCommand(this.commandObjects.sinterstore(dstkey, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sintercard(byte[]... keys) {
/* 2601 */     return appendCommand(this.commandObjects.sintercard(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sintercard(int limit, byte[]... keys) {
/* 2606 */     return appendCommand(this.commandObjects.sintercard(limit, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<byte[]>> sunion(byte[]... keys) {
/* 2611 */     return appendCommand(this.commandObjects.sunion(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> sunionstore(byte[] dstkey, byte[]... keys) {
/* 2616 */     return appendCommand(this.commandObjects.sunionstore(dstkey, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> smove(byte[] srckey, byte[] dstkey, byte[] member) {
/* 2621 */     return appendCommand(this.commandObjects.smove(srckey, dstkey, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zadd(byte[] key, double score, byte[] member) {
/* 2626 */     return appendCommand(this.commandObjects.zadd(key, score, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zadd(byte[] key, double score, byte[] member, ZAddParams params) {
/* 2631 */     return appendCommand(this.commandObjects.zadd(key, score, member, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zadd(byte[] key, Map<byte[], Double> scoreMembers) {
/* 2636 */     return appendCommand(this.commandObjects.zadd(key, scoreMembers));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zadd(byte[] key, Map<byte[], Double> scoreMembers, ZAddParams params) {
/* 2641 */     return appendCommand(this.commandObjects.zadd(key, scoreMembers, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> zaddIncr(byte[] key, double score, byte[] member, ZAddParams params) {
/* 2646 */     return appendCommand(this.commandObjects.zaddIncr(key, score, member, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zrem(byte[] key, byte[]... members) {
/* 2651 */     return appendCommand(this.commandObjects.zrem(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> zincrby(byte[] key, double increment, byte[] member) {
/* 2656 */     return appendCommand(this.commandObjects.zincrby(key, increment, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> zincrby(byte[] key, double increment, byte[] member, ZIncrByParams params) {
/* 2661 */     return appendCommand(this.commandObjects.zincrby(key, increment, member, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zrank(byte[] key, byte[] member) {
/* 2666 */     return appendCommand(this.commandObjects.zrank(key, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zrevrank(byte[] key, byte[] member) {
/* 2671 */     return appendCommand(this.commandObjects.zrevrank(key, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrange(byte[] key, long start, long stop) {
/* 2676 */     return appendCommand(this.commandObjects.zrange(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrevrange(byte[] key, long start, long stop) {
/* 2681 */     return appendCommand(this.commandObjects.zrevrange(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeWithScores(byte[] key, long start, long stop) {
/* 2686 */     return appendCommand(this.commandObjects.zrangeWithScores(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrevrangeWithScores(byte[] key, long start, long stop) {
/* 2691 */     return appendCommand(this.commandObjects.zrevrangeWithScores(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> zrandmember(byte[] key) {
/* 2696 */     return (Response)appendCommand((CommandObject)this.commandObjects.zrandmember(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrandmember(byte[] key, long count) {
/* 2701 */     return appendCommand(this.commandObjects.zrandmember(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrandmemberWithScores(byte[] key, long count) {
/* 2706 */     return appendCommand(this.commandObjects.zrandmemberWithScores(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zcard(byte[] key) {
/* 2711 */     return appendCommand(this.commandObjects.zcard(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> zscore(byte[] key, byte[] member) {
/* 2716 */     return appendCommand(this.commandObjects.zscore(key, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Double>> zmscore(byte[] key, byte[]... members) {
/* 2721 */     return appendCommand(this.commandObjects.zmscore(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Tuple> zpopmax(byte[] key) {
/* 2726 */     return appendCommand(this.commandObjects.zpopmax(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zpopmax(byte[] key, int count) {
/* 2731 */     return appendCommand(this.commandObjects.zpopmax(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Tuple> zpopmin(byte[] key) {
/* 2736 */     return appendCommand(this.commandObjects.zpopmin(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zpopmin(byte[] key, int count) {
/* 2741 */     return appendCommand(this.commandObjects.zpopmin(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zcount(byte[] key, double min, double max) {
/* 2746 */     return appendCommand(this.commandObjects.zcount(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zcount(byte[] key, byte[] min, byte[] max) {
/* 2751 */     return appendCommand(this.commandObjects.zcount(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrangeByScore(byte[] key, double min, double max) {
/* 2756 */     return appendCommand(this.commandObjects.zrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrangeByScore(byte[] key, byte[] min, byte[] max) {
/* 2761 */     return appendCommand(this.commandObjects.zrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrevrangeByScore(byte[] key, double max, double min) {
/* 2766 */     return appendCommand(this.commandObjects.zrevrangeByScore(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrangeByScore(byte[] key, double min, double max, int offset, int count) {
/* 2771 */     return appendCommand(this.commandObjects.zrangeByScore(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrevrangeByScore(byte[] key, byte[] max, byte[] min) {
/* 2776 */     return appendCommand(this.commandObjects.zrevrangeByScore(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrangeByScore(byte[] key, byte[] min, byte[] max, int offset, int count) {
/* 2781 */     return appendCommand(this.commandObjects.zrangeByScore(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrevrangeByScore(byte[] key, double max, double min, int offset, int count) {
/* 2786 */     return appendCommand(this.commandObjects.zrevrangeByScore(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeByScoreWithScores(byte[] key, double min, double max) {
/* 2791 */     return appendCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrevrangeByScoreWithScores(byte[] key, double max, double min) {
/* 2796 */     return appendCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeByScoreWithScores(byte[] key, double min, double max, int offset, int count) {
/* 2801 */     return appendCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrevrangeByScore(byte[] key, byte[] max, byte[] min, int offset, int count) {
/* 2806 */     return appendCommand(this.commandObjects.zrevrangeByScore(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max) {
/* 2811 */     return appendCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min) {
/* 2816 */     return appendCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max, int offset, int count) {
/* 2821 */     return appendCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrevrangeByScoreWithScores(byte[] key, double max, double min, int offset, int count) {
/* 2826 */     return appendCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min, int offset, int count) {
/* 2831 */     return appendCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zremrangeByRank(byte[] key, long start, long stop) {
/* 2836 */     return appendCommand(this.commandObjects.zremrangeByRank(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zremrangeByScore(byte[] key, double min, double max) {
/* 2841 */     return appendCommand(this.commandObjects.zremrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zremrangeByScore(byte[] key, byte[] min, byte[] max) {
/* 2846 */     return appendCommand(this.commandObjects.zremrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zlexcount(byte[] key, byte[] min, byte[] max) {
/* 2851 */     return appendCommand(this.commandObjects.zlexcount(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrangeByLex(byte[] key, byte[] min, byte[] max) {
/* 2856 */     return appendCommand(this.commandObjects.zrangeByLex(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrangeByLex(byte[] key, byte[] min, byte[] max, int offset, int count) {
/* 2861 */     return appendCommand(this.commandObjects.zrangeByLex(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrevrangeByLex(byte[] key, byte[] max, byte[] min) {
/* 2866 */     return appendCommand(this.commandObjects.zrevrangeByLex(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrevrangeByLex(byte[] key, byte[] max, byte[] min, int offset, int count) {
/* 2871 */     return appendCommand(this.commandObjects.zrevrangeByLex(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> zrange(byte[] key, ZRangeParams zRangeParams) {
/* 2876 */     return appendCommand(this.commandObjects.zrange(key, zRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Tuple>> zrangeWithScores(byte[] key, ZRangeParams zRangeParams) {
/* 2881 */     return appendCommand(this.commandObjects.zrangeWithScores(key, zRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zrangestore(byte[] dest, byte[] src, ZRangeParams zRangeParams) {
/* 2886 */     return appendCommand(this.commandObjects.zrangestore(dest, src, zRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zremrangeByLex(byte[] key, byte[] min, byte[] max) {
/* 2891 */     return appendCommand(this.commandObjects.zremrangeByLex(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ScanResult<Tuple>> zscan(byte[] key, byte[] cursor, ScanParams params) {
/* 2896 */     return appendCommand(this.commandObjects.zscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> bzpopmax(double timeout, byte[]... keys) {
/* 2901 */     return appendCommand(this.commandObjects.bzpopmax(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> bzpopmin(double timeout, byte[]... keys) {
/* 2906 */     return appendCommand(this.commandObjects.bzpopmin(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<byte[], List<Tuple>>> zmpop(SortedSetOption option, byte[]... keys) {
/* 2911 */     return appendCommand(this.commandObjects.zmpop(option, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<byte[], List<Tuple>>> zmpop(SortedSetOption option, int count, byte[]... keys) {
/* 2916 */     return appendCommand(this.commandObjects.zmpop(option, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<byte[], List<Tuple>>> bzmpop(long timeout, SortedSetOption option, byte[]... keys) {
/* 2921 */     return appendCommand(this.commandObjects.bzmpop(timeout, option, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<KeyValue<byte[], List<Tuple>>> bzmpop(long timeout, SortedSetOption option, int count, byte[]... keys) {
/* 2926 */     return appendCommand(this.commandObjects.bzmpop(timeout, option, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<byte[]>> zdiff(byte[]... keys) {
/* 2931 */     return appendCommand(this.commandObjects.zdiff(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<Tuple>> zdiffWithScores(byte[]... keys) {
/* 2936 */     return appendCommand(this.commandObjects.zdiffWithScores(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zdiffStore(byte[] dstkey, byte[]... keys) {
/* 2941 */     return appendCommand(this.commandObjects.zdiffStore(dstkey, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<byte[]>> zinter(ZParams params, byte[]... keys) {
/* 2946 */     return appendCommand(this.commandObjects.zinter(params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<Tuple>> zinterWithScores(ZParams params, byte[]... keys) {
/* 2951 */     return appendCommand(this.commandObjects.zinterWithScores(params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zinterstore(byte[] dstkey, byte[]... sets) {
/* 2956 */     return appendCommand(this.commandObjects.zinterstore(dstkey, sets));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zinterstore(byte[] dstkey, ZParams params, byte[]... sets) {
/* 2961 */     return appendCommand(this.commandObjects.zinterstore(dstkey, params, sets));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zintercard(byte[]... keys) {
/* 2966 */     return appendCommand(this.commandObjects.zintercard(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zintercard(long limit, byte[]... keys) {
/* 2971 */     return appendCommand(this.commandObjects.zintercard(limit, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<byte[]>> zunion(ZParams params, byte[]... keys) {
/* 2976 */     return appendCommand(this.commandObjects.zunion(params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Set<Tuple>> zunionWithScores(ZParams params, byte[]... keys) {
/* 2981 */     return appendCommand(this.commandObjects.zunionWithScores(params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zunionstore(byte[] dstkey, byte[]... sets) {
/* 2986 */     return appendCommand(this.commandObjects.zunionstore(dstkey, sets));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> zunionstore(byte[] dstkey, ZParams params, byte[]... sets) {
/* 2991 */     return appendCommand(this.commandObjects.zunionstore(dstkey, params, sets));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> xadd(byte[] key, XAddParams params, Map<byte[], byte[]> hash) {
/* 2996 */     return (Response)appendCommand((CommandObject)this.commandObjects.xadd(key, params, hash));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xlen(byte[] key) {
/* 3001 */     return appendCommand(this.commandObjects.xlen(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> xrange(byte[] key, byte[] start, byte[] end) {
/* 3006 */     return appendCommand(this.commandObjects.xrange(key, start, end));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> xrange(byte[] key, byte[] start, byte[] end, int count) {
/* 3011 */     return appendCommand(this.commandObjects.xrange(key, start, end, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> xrevrange(byte[] key, byte[] end, byte[] start) {
/* 3016 */     return appendCommand(this.commandObjects.xrevrange(key, end, start));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> xrevrange(byte[] key, byte[] end, byte[] start, int count) {
/* 3021 */     return appendCommand(this.commandObjects.xrevrange(key, end, start, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xack(byte[] key, byte[] group, byte[]... ids) {
/* 3026 */     return appendCommand(this.commandObjects.xack(key, group, ids));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> xgroupCreate(byte[] key, byte[] groupName, byte[] id, boolean makeStream) {
/* 3031 */     return appendCommand(this.commandObjects.xgroupCreate(key, groupName, id, makeStream));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> xgroupSetID(byte[] key, byte[] groupName, byte[] id) {
/* 3036 */     return appendCommand(this.commandObjects.xgroupSetID(key, groupName, id));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xgroupDestroy(byte[] key, byte[] groupName) {
/* 3041 */     return appendCommand(this.commandObjects.xgroupDestroy(key, groupName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> xgroupCreateConsumer(byte[] key, byte[] groupName, byte[] consumerName) {
/* 3046 */     return appendCommand(this.commandObjects.xgroupCreateConsumer(key, groupName, consumerName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xgroupDelConsumer(byte[] key, byte[] groupName, byte[] consumerName) {
/* 3051 */     return appendCommand(this.commandObjects.xgroupDelConsumer(key, groupName, consumerName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xdel(byte[] key, byte[]... ids) {
/* 3056 */     return appendCommand(this.commandObjects.xdel(key, ids));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xtrim(byte[] key, long maxLen, boolean approximateLength) {
/* 3061 */     return appendCommand(this.commandObjects.xtrim(key, maxLen, approximateLength));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> xtrim(byte[] key, XTrimParams params) {
/* 3066 */     return appendCommand(this.commandObjects.xtrim(key, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> xpending(byte[] key, byte[] groupName) {
/* 3071 */     return appendCommand(this.commandObjects.xpending(key, groupName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> xpending(byte[] key, byte[] groupName, byte[] start, byte[] end, int count, byte[] consumerName) {
/* 3076 */     return appendCommand(this.commandObjects.xpending(key, groupName, start, end, count, consumerName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> xpending(byte[] key, byte[] groupName, XPendingParams params) {
/* 3081 */     return appendCommand(this.commandObjects.xpending(key, groupName, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> xclaim(byte[] key, byte[] group, byte[] consumerName, long minIdleTime, XClaimParams params, byte[]... ids) {
/* 3086 */     return appendCommand(this.commandObjects.xclaim(key, group, consumerName, minIdleTime, params, ids));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> xclaimJustId(byte[] key, byte[] group, byte[] consumerName, long minIdleTime, XClaimParams params, byte[]... ids) {
/* 3091 */     return appendCommand(this.commandObjects.xclaimJustId(key, group, consumerName, minIdleTime, params, ids));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> xautoclaim(byte[] key, byte[] groupName, byte[] consumerName, long minIdleTime, byte[] start, XAutoClaimParams params) {
/* 3096 */     return appendCommand(this.commandObjects.xautoclaim(key, groupName, consumerName, minIdleTime, start, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> xautoclaimJustId(byte[] key, byte[] groupName, byte[] consumerName, long minIdleTime, byte[] start, XAutoClaimParams params) {
/* 3101 */     return appendCommand(this.commandObjects.xautoclaimJustId(key, groupName, consumerName, minIdleTime, start, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> xinfoStream(byte[] key) {
/* 3106 */     return appendCommand(this.commandObjects.xinfoStream(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> xinfoStreamFull(byte[] key) {
/* 3111 */     return appendCommand(this.commandObjects.xinfoStreamFull(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> xinfoStreamFull(byte[] key, int count) {
/* 3116 */     return appendCommand(this.commandObjects.xinfoStreamFull(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Response<List<Object>> xinfoGroup(byte[] key) {
/* 3122 */     return appendCommand(this.commandObjects.xinfoGroup(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> xinfoGroups(byte[] key) {
/* 3127 */     return appendCommand(this.commandObjects.xinfoGroups(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> xinfoConsumers(byte[] key, byte[] group) {
/* 3132 */     return appendCommand(this.commandObjects.xinfoConsumers(key, group));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> xread(XReadParams xReadParams, Map.Entry<byte[], byte[]>... streams) {
/* 3137 */     return appendCommand(this.commandObjects.xread(xReadParams, streams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> xreadGroup(byte[] groupName, byte[] consumer, XReadGroupParams xReadGroupParams, Map.Entry<byte[], byte[]>... streams) {
/* 3142 */     return appendCommand(this.commandObjects.xreadGroup(groupName, consumer, xReadGroupParams, streams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> set(byte[] key, byte[] value) {
/* 3147 */     return appendCommand(this.commandObjects.set(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> set(byte[] key, byte[] value, SetParams params) {
/* 3152 */     return appendCommand(this.commandObjects.set(key, value, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> get(byte[] key) {
/* 3157 */     return (Response)appendCommand((CommandObject)this.commandObjects.get(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> getDel(byte[] key) {
/* 3162 */     return (Response)appendCommand((CommandObject)this.commandObjects.getDel(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> getEx(byte[] key, GetExParams params) {
/* 3167 */     return (Response)appendCommand((CommandObject)this.commandObjects.getEx(key, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> setbit(byte[] key, long offset, boolean value) {
/* 3172 */     return appendCommand(this.commandObjects.setbit(key, offset, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> getbit(byte[] key, long offset) {
/* 3177 */     return appendCommand(this.commandObjects.getbit(key, offset));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> setrange(byte[] key, long offset, byte[] value) {
/* 3182 */     return appendCommand(this.commandObjects.setrange(key, offset, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> getrange(byte[] key, long startOffset, long endOffset) {
/* 3187 */     return (Response)appendCommand((CommandObject)this.commandObjects.getrange(key, startOffset, endOffset));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> getSet(byte[] key, byte[] value) {
/* 3192 */     return (Response)appendCommand((CommandObject)this.commandObjects.getSet(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> setnx(byte[] key, byte[] value) {
/* 3197 */     return appendCommand(this.commandObjects.setnx(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> setex(byte[] key, long seconds, byte[] value) {
/* 3202 */     return appendCommand(this.commandObjects.setex(key, seconds, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> psetex(byte[] key, long milliseconds, byte[] value) {
/* 3207 */     return appendCommand(this.commandObjects.psetex(key, milliseconds, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<byte[]>> mget(byte[]... keys) {
/* 3212 */     return appendCommand(this.commandObjects.mget(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> mset(byte[]... keysvalues) {
/* 3217 */     return appendCommand(this.commandObjects.mset(keysvalues));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> msetnx(byte[]... keysvalues) {
/* 3222 */     return appendCommand(this.commandObjects.msetnx(keysvalues));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> incr(byte[] key) {
/* 3227 */     return appendCommand(this.commandObjects.incr(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> incrBy(byte[] key, long increment) {
/* 3232 */     return appendCommand(this.commandObjects.incrBy(key, increment));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Double> incrByFloat(byte[] key, double increment) {
/* 3237 */     return appendCommand(this.commandObjects.incrByFloat(key, increment));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> decr(byte[] key) {
/* 3242 */     return appendCommand(this.commandObjects.decr(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> decrBy(byte[] key, long decrement) {
/* 3247 */     return appendCommand(this.commandObjects.decrBy(key, decrement));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> append(byte[] key, byte[] value) {
/* 3252 */     return appendCommand(this.commandObjects.append(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<byte[]> substr(byte[] key, int start, int end) {
/* 3257 */     return (Response)appendCommand((CommandObject)this.commandObjects.substr(key, start, end));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> strlen(byte[] key) {
/* 3262 */     return appendCommand(this.commandObjects.strlen(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitcount(byte[] key) {
/* 3267 */     return appendCommand(this.commandObjects.bitcount(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitcount(byte[] key, long start, long end) {
/* 3272 */     return appendCommand(this.commandObjects.bitcount(key, start, end));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitcount(byte[] key, long start, long end, BitCountOption option) {
/* 3277 */     return appendCommand(this.commandObjects.bitcount(key, start, end, option));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitpos(byte[] key, boolean value) {
/* 3282 */     return appendCommand(this.commandObjects.bitpos(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitpos(byte[] key, boolean value, BitPosParams params) {
/* 3287 */     return appendCommand(this.commandObjects.bitpos(key, value, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> bitfield(byte[] key, byte[]... arguments) {
/* 3292 */     return appendCommand(this.commandObjects.bitfield(key, arguments));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> bitfieldReadonly(byte[] key, byte[]... arguments) {
/* 3297 */     return appendCommand(this.commandObjects.bitfieldReadonly(key, arguments));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> bitop(BitOP op, byte[] destKey, byte[]... srcKeys) {
/* 3302 */     return appendCommand(this.commandObjects.bitop(op, destKey, srcKeys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<LCSMatchResult> strAlgoLCSKeys(byte[] keyA, byte[] keyB, StrAlgoLCSParams params) {
/* 3307 */     return appendCommand(this.commandObjects.strAlgoLCSKeys(keyA, keyB, params));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Response<String> ftCreate(String indexName, IndexOptions indexOptions, Schema schema) {
/* 3313 */     return appendCommand(this.commandObjects.ftCreate(indexName, indexOptions, schema));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftAlter(String indexName, Schema schema) {
/* 3318 */     return appendCommand(this.commandObjects.ftAlter(indexName, schema));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<SearchResult> ftSearch(String indexName, Query query) {
/* 3323 */     return appendCommand(this.commandObjects.ftSearch(indexName, query));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<SearchResult> ftSearch(byte[] indexName, Query query) {
/* 3328 */     return appendCommand(this.commandObjects.ftSearch(indexName, query));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftExplain(String indexName, Query query) {
/* 3333 */     return appendCommand(this.commandObjects.ftExplain(indexName, query));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> ftExplainCLI(String indexName, Query query) {
/* 3338 */     return appendCommand(this.commandObjects.ftExplainCLI(indexName, query));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<AggregationResult> ftAggregate(String indexName, AggregationBuilder aggr) {
/* 3343 */     return appendCommand(this.commandObjects.ftAggregate(indexName, aggr));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<AggregationResult> ftCursorRead(String indexName, long cursorId, int count) {
/* 3348 */     return appendCommand(this.commandObjects.ftCursorRead(indexName, cursorId, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftCursorDel(String indexName, long cursorId) {
/* 3353 */     return appendCommand(this.commandObjects.ftCursorDel(indexName, cursorId));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftDropIndex(String indexName) {
/* 3358 */     return appendCommand(this.commandObjects.ftDropIndex(indexName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftDropIndexDD(String indexName) {
/* 3363 */     return appendCommand(this.commandObjects.ftDropIndexDD(indexName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftSynUpdate(String indexName, String synonymGroupId, String... terms) {
/* 3368 */     return appendCommand(this.commandObjects.ftSynUpdate(indexName, synonymGroupId, terms));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<String, List<String>>> ftSynDump(String indexName) {
/* 3373 */     return appendCommand(this.commandObjects.ftSynDump(indexName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<String, Object>> ftInfo(String indexName) {
/* 3378 */     return appendCommand(this.commandObjects.ftInfo(indexName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftAliasAdd(String aliasName, String indexName) {
/* 3383 */     return appendCommand(this.commandObjects.ftAliasAdd(aliasName, indexName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftAliasUpdate(String aliasName, String indexName) {
/* 3388 */     return appendCommand(this.commandObjects.ftAliasUpdate(aliasName, indexName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftAliasDel(String aliasName) {
/* 3393 */     return appendCommand(this.commandObjects.ftAliasDel(aliasName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<String, String>> ftConfigGet(String option) {
/* 3398 */     return appendCommand(this.commandObjects.ftConfigGet(option));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<String, String>> ftConfigGet(String indexName, String option) {
/* 3403 */     return appendCommand(this.commandObjects.ftConfigGet(indexName, option));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftConfigSet(String option, String value) {
/* 3408 */     return appendCommand(this.commandObjects.ftConfigSet(option, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> ftConfigSet(String indexName, String option, String value) {
/* 3413 */     return appendCommand(this.commandObjects.ftConfigSet(indexName, option, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Response<LCSMatchResult> lcs(byte[] keyA, byte[] keyB, LCSParams params) {
/* 3420 */     return appendCommand(this.commandObjects.lcs(keyA, keyB, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> jsonSet(String key, Path2 path, Object object) {
/* 3425 */     return appendCommand(this.commandObjects.jsonSet(key, path, object));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> jsonSetWithEscape(String key, Path2 path, Object object) {
/* 3430 */     return appendCommand(this.commandObjects.jsonSetWithEscape(key, path, object));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> jsonSet(String key, Path path, Object object) {
/* 3435 */     return appendCommand(this.commandObjects.jsonSet(key, path, object));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> jsonSet(String key, Path2 path, Object object, JsonSetParams params) {
/* 3440 */     return appendCommand(this.commandObjects.jsonSet(key, path, object, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> jsonSetWithEscape(String key, Path2 path, Object object, JsonSetParams params) {
/* 3445 */     return appendCommand(this.commandObjects.jsonSetWithEscape(key, path, object, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> jsonSet(String key, Path path, Object object, JsonSetParams params) {
/* 3450 */     return appendCommand(this.commandObjects.jsonSet(key, path, object, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> jsonGet(String key) {
/* 3455 */     return appendCommand(this.commandObjects.jsonGet(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Response<T> jsonGet(String key, Class<T> clazz) {
/* 3460 */     return appendCommand(this.commandObjects.jsonGet(key, clazz));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> jsonGet(String key, Path2... paths) {
/* 3465 */     return appendCommand(this.commandObjects.jsonGet(key, paths));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> jsonGet(String key, Path... paths) {
/* 3470 */     return appendCommand(this.commandObjects.jsonGet(key, paths));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Response<T> jsonGet(String key, Class<T> clazz, Path... paths) {
/* 3475 */     return appendCommand(this.commandObjects.jsonGet(key, clazz, paths));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<JSONArray>> jsonMGet(Path2 path, String... keys) {
/* 3480 */     return appendCommand(this.commandObjects.jsonMGet(path, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Response<List<T>> jsonMGet(Path path, Class<T> clazz, String... keys) {
/* 3485 */     return appendCommand(this.commandObjects.jsonMGet(path, clazz, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonDel(String key) {
/* 3490 */     return appendCommand(this.commandObjects.jsonDel(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonDel(String key, Path2 path) {
/* 3495 */     return appendCommand(this.commandObjects.jsonDel(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonDel(String key, Path path) {
/* 3500 */     return appendCommand(this.commandObjects.jsonDel(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonClear(String key) {
/* 3505 */     return appendCommand(this.commandObjects.jsonClear(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonClear(String key, Path2 path) {
/* 3510 */     return appendCommand(this.commandObjects.jsonClear(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonClear(String key, Path path) {
/* 3515 */     return appendCommand(this.commandObjects.jsonClear(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> jsonToggle(String key, Path2 path) {
/* 3520 */     return appendCommand(this.commandObjects.jsonToggle(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> jsonToggle(String key, Path path) {
/* 3525 */     return appendCommand(this.commandObjects.jsonToggle(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Class<?>> jsonType(String key) {
/* 3530 */     return appendCommand(this.commandObjects.jsonType(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Class<?>>> jsonType(String key, Path2 path) {
/* 3535 */     return appendCommand(this.commandObjects.jsonType(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Class<?>> jsonType(String key, Path path) {
/* 3540 */     return appendCommand(this.commandObjects.jsonType(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonStrAppend(String key, Object string) {
/* 3545 */     return appendCommand(this.commandObjects.jsonStrAppend(key, string));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> jsonStrAppend(String key, Path2 path, Object string) {
/* 3550 */     return appendCommand(this.commandObjects.jsonStrAppend(key, path, string));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonStrAppend(String key, Path path, Object string) {
/* 3555 */     return appendCommand(this.commandObjects.jsonStrAppend(key, path, string));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonStrLen(String key) {
/* 3560 */     return appendCommand(this.commandObjects.jsonStrLen(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> jsonStrLen(String key, Path2 path) {
/* 3565 */     return appendCommand(this.commandObjects.jsonStrLen(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonStrLen(String key, Path path) {
/* 3570 */     return appendCommand(this.commandObjects.jsonStrLen(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> jsonArrAppend(String key, Path2 path, Object... objects) {
/* 3575 */     return appendCommand(this.commandObjects.jsonArrAppend(key, path, objects));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> jsonArrAppendWithEscape(String key, Path2 path, Object... objects) {
/* 3580 */     return appendCommand(this.commandObjects.jsonArrAppendWithEscape(key, path, objects));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonArrAppend(String key, Path path, Object... objects) {
/* 3585 */     return appendCommand(this.commandObjects.jsonArrAppend(key, path, objects));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> jsonArrIndex(String key, Path2 path, Object scalar) {
/* 3590 */     return appendCommand(this.commandObjects.jsonArrIndex(key, path, scalar));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> jsonArrIndexWithEscape(String key, Path2 path, Object scalar) {
/* 3595 */     return appendCommand(this.commandObjects.jsonArrIndexWithEscape(key, path, scalar));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonArrIndex(String key, Path path, Object scalar) {
/* 3600 */     return appendCommand(this.commandObjects.jsonArrIndex(key, path, scalar));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> jsonArrInsert(String key, Path2 path, int index, Object... objects) {
/* 3605 */     return appendCommand(this.commandObjects.jsonArrInsert(key, path, index, objects));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> jsonArrInsertWithEscape(String key, Path2 path, int index, Object... objects) {
/* 3610 */     return appendCommand(this.commandObjects.jsonArrInsertWithEscape(key, path, index, objects));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonArrInsert(String key, Path path, int index, Object... pojos) {
/* 3615 */     return appendCommand(this.commandObjects.jsonArrInsert(key, path, index, pojos));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> jsonArrPop(String key) {
/* 3620 */     return appendCommand(this.commandObjects.jsonArrPop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonArrLen(String key, Path path) {
/* 3625 */     return appendCommand(this.commandObjects.jsonArrLen(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> jsonArrTrim(String key, Path2 path, int start, int stop) {
/* 3630 */     return appendCommand(this.commandObjects.jsonArrTrim(key, path, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonArrTrim(String key, Path path, int start, int stop) {
/* 3635 */     return appendCommand(this.commandObjects.jsonArrTrim(key, path, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Response<T> jsonArrPop(String key, Class<T> clazz, Path path) {
/* 3640 */     return appendCommand(this.commandObjects.jsonArrPop(key, clazz, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> jsonArrPop(String key, Path2 path, int index) {
/* 3645 */     return appendCommand(this.commandObjects.jsonArrPop(key, path, index));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> jsonArrPop(String key, Path path, int index) {
/* 3650 */     return appendCommand(this.commandObjects.jsonArrPop(key, path, index));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Response<T> jsonArrPop(String key, Class<T> clazz, Path path, int index) {
/* 3655 */     return appendCommand(this.commandObjects.jsonArrPop(key, clazz, path, index));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> jsonArrLen(String key) {
/* 3660 */     return appendCommand(this.commandObjects.jsonArrLen(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> jsonArrLen(String key, Path2 path) {
/* 3665 */     return appendCommand(this.commandObjects.jsonArrLen(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Response<T> jsonArrPop(String key, Class<T> clazz) {
/* 3670 */     return appendCommand(this.commandObjects.jsonArrPop(key, clazz));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Object>> jsonArrPop(String key, Path2 path) {
/* 3675 */     return appendCommand(this.commandObjects.jsonArrPop(key, path));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Object> jsonArrPop(String key, Path path) {
/* 3680 */     return appendCommand(this.commandObjects.jsonArrPop(key, path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Response<String> tsCreate(String key) {
/* 3687 */     return appendCommand(this.commandObjects.tsCreate(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> tsCreate(String key, TSCreateParams createParams) {
/* 3692 */     return appendCommand(this.commandObjects.tsCreate(key, createParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> tsDel(String key, long fromTimestamp, long toTimestamp) {
/* 3697 */     return appendCommand(this.commandObjects.tsDel(key, fromTimestamp, toTimestamp));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> tsAlter(String key, TSAlterParams alterParams) {
/* 3702 */     return appendCommand(this.commandObjects.tsAlter(key, alterParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> tsAdd(String key, double value) {
/* 3707 */     return appendCommand(this.commandObjects.tsAdd(key, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> tsAdd(String key, long timestamp, double value) {
/* 3712 */     return appendCommand(this.commandObjects.tsAdd(key, timestamp, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> tsAdd(String key, long timestamp, double value, TSCreateParams createParams) {
/* 3717 */     return appendCommand(this.commandObjects.tsAdd(key, timestamp, value, createParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<TSElement>> tsRange(String key, long fromTimestamp, long toTimestamp) {
/* 3722 */     return appendCommand(this.commandObjects.tsRange(key, fromTimestamp, toTimestamp));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<TSElement>> tsRange(String key, TSRangeParams rangeParams) {
/* 3727 */     return appendCommand(this.commandObjects.tsRange(key, rangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<TSElement>> tsRevRange(String key, long fromTimestamp, long toTimestamp) {
/* 3732 */     return appendCommand(this.commandObjects.tsRevRange(key, fromTimestamp, toTimestamp));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<TSElement>> tsRevRange(String key, TSRangeParams rangeParams) {
/* 3737 */     return appendCommand(this.commandObjects.tsRevRange(key, rangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<TSKeyedElements>> tsMRange(long fromTimestamp, long toTimestamp, String... filters) {
/* 3742 */     return appendCommand(this.commandObjects.tsMRange(fromTimestamp, toTimestamp, filters));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<TSKeyedElements>> tsMRange(TSMRangeParams multiRangeParams) {
/* 3747 */     return appendCommand(this.commandObjects.tsMRange(multiRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<TSKeyedElements>> tsMRevRange(long fromTimestamp, long toTimestamp, String... filters) {
/* 3752 */     return appendCommand(this.commandObjects.tsMRevRange(fromTimestamp, toTimestamp, filters));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<TSKeyedElements>> tsMRevRange(TSMRangeParams multiRangeParams) {
/* 3757 */     return appendCommand(this.commandObjects.tsMRevRange(multiRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<TSElement> tsGet(String key) {
/* 3762 */     return appendCommand(this.commandObjects.tsGet(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<TSKeyValue<TSElement>>> tsMGet(TSMGetParams multiGetParams, String... filters) {
/* 3767 */     return appendCommand(this.commandObjects.tsMGet(multiGetParams, filters));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> tsCreateRule(String sourceKey, String destKey, AggregationType aggregationType, long timeBucket) {
/* 3772 */     return appendCommand(this.commandObjects.tsCreateRule(sourceKey, destKey, aggregationType, timeBucket));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> tsDeleteRule(String sourceKey, String destKey) {
/* 3777 */     return appendCommand(this.commandObjects.tsDeleteRule(sourceKey, destKey));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> tsQueryIndex(String... filters) {
/* 3782 */     return appendCommand(this.commandObjects.tsQueryIndex(filters));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Response<String> bfReserve(String key, double errorRate, long capacity) {
/* 3789 */     return appendCommand(this.commandObjects.bfReserve(key, errorRate, capacity));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> bfReserve(String key, double errorRate, long capacity, BFReserveParams reserveParams) {
/* 3794 */     return appendCommand(this.commandObjects.bfReserve(key, errorRate, capacity, reserveParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> bfAdd(String key, String item) {
/* 3799 */     return appendCommand(this.commandObjects.bfAdd(key, item));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> bfMAdd(String key, String... items) {
/* 3804 */     return appendCommand(this.commandObjects.bfMAdd(key, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> bfInsert(String key, String... items) {
/* 3809 */     return appendCommand(this.commandObjects.bfInsert(key, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> bfInsert(String key, BFInsertParams insertParams, String... items) {
/* 3814 */     return appendCommand(this.commandObjects.bfInsert(key, insertParams, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> bfExists(String key, String item) {
/* 3819 */     return appendCommand(this.commandObjects.bfExists(key, item));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> bfMExists(String key, String... items) {
/* 3824 */     return appendCommand(this.commandObjects.bfMExists(key, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<String, Object>> bfInfo(String key) {
/* 3829 */     return appendCommand(this.commandObjects.bfInfo(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> cfReserve(String key, long capacity) {
/* 3834 */     return appendCommand(this.commandObjects.cfReserve(key, capacity));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> cfReserve(String key, long capacity, CFReserveParams reserveParams) {
/* 3839 */     return appendCommand(this.commandObjects.cfReserve(key, capacity, reserveParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> cfAdd(String key, String item) {
/* 3844 */     return appendCommand(this.commandObjects.cfAdd(key, item));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> cfAddNx(String key, String item) {
/* 3849 */     return appendCommand(this.commandObjects.cfAddNx(key, item));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> cfInsert(String key, String... items) {
/* 3854 */     return appendCommand(this.commandObjects.cfInsert(key, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> cfInsert(String key, CFInsertParams insertParams, String... items) {
/* 3859 */     return appendCommand(this.commandObjects.cfInsert(key, insertParams, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> cfInsertNx(String key, String... items) {
/* 3864 */     return appendCommand(this.commandObjects.cfInsertNx(key, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> cfInsertNx(String key, CFInsertParams insertParams, String... items) {
/* 3869 */     return appendCommand(this.commandObjects.cfInsertNx(key, insertParams, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> cfExists(String key, String item) {
/* 3874 */     return appendCommand(this.commandObjects.cfExists(key, item));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> cfDel(String key, String item) {
/* 3879 */     return appendCommand(this.commandObjects.cfDel(key, item));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> cfCount(String key, String item) {
/* 3884 */     return appendCommand(this.commandObjects.cfCount(key, item));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<String, Object>> cfInfo(String key) {
/* 3889 */     return appendCommand(this.commandObjects.cfInfo(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> cmsInitByDim(String key, long width, long depth) {
/* 3894 */     return appendCommand(this.commandObjects.cmsInitByDim(key, width, depth));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> cmsInitByProb(String key, double error, double probability) {
/* 3899 */     return appendCommand(this.commandObjects.cmsInitByProb(key, error, probability));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> cmsIncrBy(String key, Map<String, Long> itemIncrements) {
/* 3904 */     return appendCommand(this.commandObjects.cmsIncrBy(key, itemIncrements));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> cmsQuery(String key, String... items) {
/* 3909 */     return appendCommand(this.commandObjects.cmsQuery(key, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> cmsMerge(String destKey, String... keys) {
/* 3914 */     return appendCommand(this.commandObjects.cmsMerge(destKey, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> cmsMerge(String destKey, Map<String, Long> keysAndWeights) {
/* 3919 */     return appendCommand(this.commandObjects.cmsMerge(destKey, keysAndWeights));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<String, Object>> cmsInfo(String key) {
/* 3924 */     return appendCommand(this.commandObjects.cmsInfo(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> topkReserve(String key, long topk) {
/* 3929 */     return appendCommand(this.commandObjects.topkReserve(key, topk));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> topkReserve(String key, long topk, long width, long depth, double decay) {
/* 3934 */     return appendCommand(this.commandObjects.topkReserve(key, topk, width, depth, decay));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> topkAdd(String key, String... items) {
/* 3939 */     return appendCommand(this.commandObjects.topkAdd(key, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> topkIncrBy(String key, Map<String, Long> itemIncrements) {
/* 3944 */     return appendCommand(this.commandObjects.topkIncrBy(key, itemIncrements));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Boolean>> topkQuery(String key, String... items) {
/* 3949 */     return appendCommand(this.commandObjects.topkQuery(key, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<Long>> topkCount(String key, String... items) {
/* 3954 */     return appendCommand(this.commandObjects.topkCount(key, items));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<List<String>> topkList(String key) {
/* 3959 */     return appendCommand(this.commandObjects.topkList(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Map<String, Object>> topkInfo(String key) {
/* 3964 */     return appendCommand(this.commandObjects.topkInfo(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Response<ResultSet> graphQuery(String name, String query) {
/* 3971 */     return appendCommand(this.graphCommandObjects.graphQuery(name, query));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ResultSet> graphReadonlyQuery(String name, String query) {
/* 3976 */     return appendCommand(this.graphCommandObjects.graphReadonlyQuery(name, query));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ResultSet> graphQuery(String name, String query, long timeout) {
/* 3981 */     return appendCommand(this.graphCommandObjects.graphQuery(name, query, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ResultSet> graphReadonlyQuery(String name, String query, long timeout) {
/* 3986 */     return appendCommand(this.graphCommandObjects.graphReadonlyQuery(name, query, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ResultSet> graphQuery(String name, String query, Map<String, Object> params) {
/* 3991 */     return appendCommand(this.graphCommandObjects.graphQuery(name, query, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ResultSet> graphReadonlyQuery(String name, String query, Map<String, Object> params) {
/* 3996 */     return appendCommand(this.graphCommandObjects.graphReadonlyQuery(name, query, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ResultSet> graphQuery(String name, String query, Map<String, Object> params, long timeout) {
/* 4001 */     return appendCommand(this.graphCommandObjects.graphQuery(name, query, params, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<ResultSet> graphReadonlyQuery(String name, String query, Map<String, Object> params, long timeout) {
/* 4006 */     return appendCommand(this.graphCommandObjects.graphReadonlyQuery(name, query, params, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> graphDelete(String name) {
/* 4011 */     return appendCommand(this.graphCommandObjects.graphDelete(name));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> waitReplicas(int replicas, long timeout) {
/* 4016 */     return appendCommand(this.commandObjects.waitReplicas(replicas, timeout));
/*      */   }
/*      */   
/*      */   public Response<List<String>> time() {
/* 4020 */     return appendCommand(new CommandObject<>(this.commandObjects.commandArguments(Protocol.Command.TIME), BuilderFactory.STRING_LIST));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> select(int index) {
/* 4025 */     return appendCommand(new CommandObject<>(this.commandObjects.commandArguments(Protocol.Command.SELECT), BuilderFactory.STRING));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> dbSize() {
/* 4030 */     return appendCommand(new CommandObject<>(this.commandObjects.commandArguments(Protocol.Command.DBSIZE), BuilderFactory.LONG));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> swapDB(int index1, int index2) {
/* 4035 */     return appendCommand(new CommandObject<>(this.commandObjects.commandArguments(Protocol.Command.SWAPDB)
/* 4036 */           .add(Integer.valueOf(index1)).add(Integer.valueOf(index2)), BuilderFactory.STRING));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> move(String key, int dbIndex) {
/* 4041 */     return appendCommand(new CommandObject<>(this.commandObjects.commandArguments(Protocol.Command.MOVE)
/* 4042 */           .key(key).add(Integer.valueOf(dbIndex)), BuilderFactory.LONG));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Long> move(byte[] key, int dbIndex) {
/* 4047 */     return appendCommand(new CommandObject<>(this.commandObjects.commandArguments(Protocol.Command.MOVE)
/* 4048 */           .key(key).add(Integer.valueOf(dbIndex)), BuilderFactory.LONG));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> copy(String srcKey, String dstKey, int db, boolean replace) {
/* 4053 */     return appendCommand(this.commandObjects.copy(srcKey, dstKey, db, replace));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<Boolean> copy(byte[] srcKey, byte[] dstKey, int db, boolean replace) {
/* 4058 */     return appendCommand(this.commandObjects.copy(srcKey, dstKey, db, replace));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> migrate(String host, int port, byte[] key, int destinationDB, int timeout) {
/* 4063 */     return appendCommand(this.commandObjects.migrate(host, port, key, destinationDB, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> migrate(String host, int port, String key, int destinationDB, int timeout) {
/* 4068 */     return appendCommand(this.commandObjects.migrate(host, port, key, destinationDB, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> migrate(String host, int port, int destinationDB, int timeout, MigrateParams params, byte[]... keys) {
/* 4073 */     return appendCommand(this.commandObjects.migrate(host, port, destinationDB, timeout, params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Response<String> migrate(String host, int port, int destinationDB, int timeout, MigrateParams params, String... keys) {
/* 4078 */     return appendCommand(this.commandObjects.migrate(host, port, destinationDB, timeout, params, keys));
/*      */   }
/*      */   
/*      */   public Response<Object> sendCommand(ProtocolCommand cmd, String... args) {
/* 4082 */     return sendCommand((new CommandArguments(cmd)).addObjects((Object[])args));
/*      */   }
/*      */   
/*      */   public Response<Object> sendCommand(ProtocolCommand cmd, byte[]... args) {
/* 4086 */     return sendCommand((new CommandArguments(cmd)).addObjects((Object[])args));
/*      */   }
/*      */   
/*      */   public Response<Object> sendCommand(CommandArguments args) {
/* 4090 */     return executeCommand(new CommandObject(args, BuilderFactory.RAW_OBJECT));
/*      */   }
/*      */   
/*      */   public <T> Response<T> executeCommand(CommandObject<T> command) {
/* 4094 */     return appendCommand(command);
/*      */   }
/*      */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\Pipeline.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */