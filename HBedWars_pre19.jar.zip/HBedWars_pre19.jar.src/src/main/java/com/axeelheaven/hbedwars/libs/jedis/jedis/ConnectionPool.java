/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.Pool;
/*    */ import com.axeelheaven.hbedwars.libs.pool2.PooledObjectFactory;
/*    */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*    */ 
/*    */ public class ConnectionPool
/*    */   extends Pool<Connection>
/*    */ {
/*    */   public ConnectionPool(HostAndPort hostAndPort, JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig) {
/* 11 */     this(new ConnectionFactory(hostAndPort, clientConfig), poolConfig);
/*    */   }
/*    */   
/*    */   public ConnectionPool(HostAndPort hostAndPort, JedisClientConfig clientConfig) {
/* 15 */     this(new ConnectionFactory(hostAndPort, clientConfig));
/*    */   }
/*    */   
/*    */   public ConnectionPool(PooledObjectFactory<Connection> factory) {
/* 19 */     this(factory, new GenericObjectPoolConfig());
/*    */   }
/*    */   
/*    */   public ConnectionPool(PooledObjectFactory<Connection> factory, GenericObjectPoolConfig<Connection> poolConfig) {
/* 23 */     super(factory, poolConfig);
/*    */   }
/*    */ 
/*    */   
/*    */   public Connection getResource() {
/* 28 */     Connection conn = (Connection)super.getResource();
/* 29 */     conn.setHandlingPool(this);
/* 30 */     return conn;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\ConnectionPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */