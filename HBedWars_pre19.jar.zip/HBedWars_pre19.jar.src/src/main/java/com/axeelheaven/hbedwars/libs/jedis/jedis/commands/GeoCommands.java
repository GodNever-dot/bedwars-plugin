package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.GeoCoordinate;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.GeoUnit;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoAddParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoRadiusParam;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoRadiusStoreParam;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoSearchParam;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.GeoRadiusResponse;
import java.util.List;
import java.util.Map;

public interface GeoCommands {
  long geoadd(String paramString1, double paramDouble1, double paramDouble2, String paramString2);
  
  long geoadd(String paramString, Map<String, GeoCoordinate> paramMap);
  
  long geoadd(String paramString, GeoAddParams paramGeoAddParams, Map<String, GeoCoordinate> paramMap);
  
  Double geodist(String paramString1, String paramString2, String paramString3);
  
  Double geodist(String paramString1, String paramString2, String paramString3, GeoUnit paramGeoUnit);
  
  List<String> geohash(String paramString, String... paramVarArgs);
  
  List<GeoCoordinate> geopos(String paramString, String... paramVarArgs);
  
  List<GeoRadiusResponse> georadius(String paramString, double paramDouble1, double paramDouble2, double paramDouble3, GeoUnit paramGeoUnit);
  
  List<GeoRadiusResponse> georadiusReadonly(String paramString, double paramDouble1, double paramDouble2, double paramDouble3, GeoUnit paramGeoUnit);
  
  List<GeoRadiusResponse> georadius(String paramString, double paramDouble1, double paramDouble2, double paramDouble3, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam);
  
  List<GeoRadiusResponse> georadiusReadonly(String paramString, double paramDouble1, double paramDouble2, double paramDouble3, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam);
  
  List<GeoRadiusResponse> georadiusByMember(String paramString1, String paramString2, double paramDouble, GeoUnit paramGeoUnit);
  
  List<GeoRadiusResponse> georadiusByMemberReadonly(String paramString1, String paramString2, double paramDouble, GeoUnit paramGeoUnit);
  
  List<GeoRadiusResponse> georadiusByMember(String paramString1, String paramString2, double paramDouble, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam);
  
  List<GeoRadiusResponse> georadiusByMemberReadonly(String paramString1, String paramString2, double paramDouble, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam);
  
  long georadiusStore(String paramString, double paramDouble1, double paramDouble2, double paramDouble3, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam, GeoRadiusStoreParam paramGeoRadiusStoreParam);
  
  long georadiusByMemberStore(String paramString1, String paramString2, double paramDouble, GeoUnit paramGeoUnit, GeoRadiusParam paramGeoRadiusParam, GeoRadiusStoreParam paramGeoRadiusStoreParam);
  
  List<GeoRadiusResponse> geosearch(String paramString1, String paramString2, double paramDouble, GeoUnit paramGeoUnit);
  
  List<GeoRadiusResponse> geosearch(String paramString, GeoCoordinate paramGeoCoordinate, double paramDouble, GeoUnit paramGeoUnit);
  
  List<GeoRadiusResponse> geosearch(String paramString1, String paramString2, double paramDouble1, double paramDouble2, GeoUnit paramGeoUnit);
  
  List<GeoRadiusResponse> geosearch(String paramString, GeoCoordinate paramGeoCoordinate, double paramDouble1, double paramDouble2, GeoUnit paramGeoUnit);
  
  List<GeoRadiusResponse> geosearch(String paramString, GeoSearchParam paramGeoSearchParam);
  
  long geosearchStore(String paramString1, String paramString2, String paramString3, double paramDouble, GeoUnit paramGeoUnit);
  
  long geosearchStore(String paramString1, String paramString2, GeoCoordinate paramGeoCoordinate, double paramDouble, GeoUnit paramGeoUnit);
  
  long geosearchStore(String paramString1, String paramString2, String paramString3, double paramDouble1, double paramDouble2, GeoUnit paramGeoUnit);
  
  long geosearchStore(String paramString1, String paramString2, GeoCoordinate paramGeoCoordinate, double paramDouble1, double paramDouble2, GeoUnit paramGeoUnit);
  
  long geosearchStore(String paramString1, String paramString2, GeoSearchParam paramGeoSearchParam);
  
  long geosearchStoreStoreDist(String paramString1, String paramString2, GeoSearchParam paramGeoSearchParam);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\GeoCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */