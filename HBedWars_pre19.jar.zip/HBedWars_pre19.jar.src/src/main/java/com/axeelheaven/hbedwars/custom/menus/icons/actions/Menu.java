package com.axeelheaven.hbedwars.custom.menus.icons.actions;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.custom.menus.interfaces.MenuActionInterface;
import com.axeelheaven.hbedwars.libs.json.simple.JSONObject;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.entity.Player;

public class Menu implements MenuActionInterface {
  private static String lIlIlllIIllI(String lllllllllllllllllIlIllIllIllIlII, String lllllllllllllllllIlIllIllIllIIll) {
    try {
      SecretKeySpec lllllllllllllllllIlIllIllIllIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIllIllIllIIll.getBytes(StandardCharsets.UTF_8)), llIIlIlIlI[8]), "DES");
      Cipher lllllllllllllllllIlIllIllIllIllI = Cipher.getInstance("DES");
      lllllllllllllllllIlIllIllIllIllI.init(llIIlIlIlI[3], lllllllllllllllllIlIllIllIllIlll);
      return new String(lllllllllllllllllIlIllIllIllIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIllIllIllIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIlIllIllIllIlIl) {
      lllllllllllllllllIlIllIllIllIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static boolean lllIlllII(short lllllllllllllllllIlIllIllllIIIIl) {
    if (lIlIllllIIII(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return (0x5E ^ 0x77) & (0x47 ^ 0x6E ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIIlIlIlI[0];
  }
  
  private static void lllIllIll() {
    lIlIIIlI = new int[llIIlIlIlI[4]];
    lIlIIIlI[llIIlIlIlI[0]] = llIIlIlIII[llIIlIlIlI[9]].length();
    lIlIIIlI[llIIlIlIlI[2]] = (llIIlIlIlI[10] ^ llIIlIlIlI[11]) & (llIIlIlIlI[12] ^ llIIlIlIlI[13] ^ llIIlIlIlI[14]);
    lIlIIIlI[llIIlIlIlI[3]] = llIIlIlIII[llIIlIlIlI[15]].length();
    lIlIIIlI[llIIlIlIlI[1]] = llIIlIlIlI[16] ^ llIIlIlIlI[17] ^ llIIlIlIlI[18] ^ llIIlIlIlI[19];
  }
  
  private static String lIlIlllIlIII(String lllllllllllllllllIlIllIlllIllIIl, String lllllllllllllllllIlIllIlllIllIII) {
    try {
      SecretKeySpec lllllllllllllllllIlIllIlllIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIllIlllIllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIlIllIlllIllIll = Cipher.getInstance("Blowfish");
      lllllllllllllllllIlIllIlllIllIll.init(llIIlIlIlI[3], lllllllllllllllllIlIllIlllIlllII);
      return new String(lllllllllllllllllIlIllIlllIllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIllIlllIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIlIllIlllIllIlI) {
      lllllllllllllllllIlIllIlllIllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static boolean lIlIllllIIII(Exception lllllllllllllllllIlIllIllIlIlIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static void lllIllIlI() {
    lIlIIIIl = new String[lIlIIIlI[llIIlIlIlI[3]]];
    lIlIIIIl[lIlIIIlI[llIIlIlIlI[2]]] = lllIllIIl(llIIlIlIII[llIIlIlIlI[5]], llIIlIlIII[llIIlIlIlI[6]]);
    lIlIIIIl[lIlIIIlI[llIIlIlIlI[0]]] = lllIllIIl(llIIlIlIII[llIIlIlIlI[7]], llIIlIlIII[llIIlIlIlI[8]]);
  }
  
  private static void lIlIlllIlllI() {
    llIIlIlIlI = new int[21];
    llIIlIlIlI[0] = (0x93 ^ 0xA2) & (0x56 ^ 0x67 ^ 0xFFFFFFFF);
    llIIlIlIlI[1] = "   ".length();
    llIIlIlIlI[2] = " ".length();
    llIIlIlIlI[3] = "  ".length();
    llIIlIlIlI[4] = 0x5F ^ 0x5B;
    llIIlIlIlI[5] = 0x5B ^ 0x50 ^ 0x7F ^ 0x71;
    llIIlIlIlI[6] = 0xA7 ^ 0xA1;
    llIIlIlIlI[7] = 135 + 99 - 75 + 23 ^ 61 + 43 - -6 + 67;
    llIIlIlIlI[8] = 137 + 7 - 99 + 121 ^ 70 + 64 - 57 + 97;
    llIIlIlIlI[9] = 0xE7 ^ 0x80 ^ 0x5F ^ 0x31;
    llIIlIlIlI[10] = (0x52 ^ 0x66) + (0xB4 ^ 0xB1) - -(0x42 ^ 0x63) + (0x1 ^ 0x2C);
    llIIlIlIlI[11] = (0x99 ^ 0xC3) + (0x20 ^ 0x18) - (0xC9 ^ 0xAC) + (0x77 ^ 0x16);
    llIIlIlIlI[12] = 233 + 26 - 31 + 6 ^ 59 + 106 - 55 + 53;
    llIIlIlIlI[13] = 134 + 108 - 166 + 151 ^ 157 + 138 - 237 + 105;
    llIIlIlIlI[14] = -" ".length();
    llIIlIlIlI[15] = 0x2E ^ 0x24;
    llIIlIlIlI[16] = 123 + 89 - 86 + 8;
    llIIlIlIlI[17] = (0xF9 ^ 0x8D) + (0x39 ^ 0x4A) - 46 + 16 - 14 + 79 + (0x5 ^ 0x3C);
    llIIlIlIlI[18] = 154 + 83 - 181 + 120;
    llIIlIlIlI[19] = (0x77 ^ 0xC) + 83 + 54 - 97 + 116 - 127 + 124 - 94 + 31 + (0x3E ^ 0x7A);
    llIIlIlIlI[20] = 90 + 148 - 225 + 136 ^ 99 + 142 - 108 + 25;
  }
  
  private static String lllIllIIl(int lllllllllllllllllIlIlllIIIIIIlIl, boolean lllllllllllllllllIlIlllIIIIIllIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.llIIlIlIII : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.llIIlIlIlI : [I
    //   10: iconst_0
    //   11: iaload
    //   12: aaload
    //   13: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   16: aload_1
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   23: invokevirtual digest : ([B)[B
    //   26: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.lIlIIIlI : [I
    //   29: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.llIIlIlIlI : [I
    //   32: iconst_1
    //   33: iaload
    //   34: iaload
    //   35: invokestatic copyOf : ([BI)[B
    //   38: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.llIIlIlIII : [Ljava/lang/String;
    //   41: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.llIIlIlIlI : [I
    //   44: iconst_2
    //   45: iaload
    //   46: aaload
    //   47: invokespecial <init> : ([BLjava/lang/String;)V
    //   50: astore_2
    //   51: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.llIIlIlIII : [Ljava/lang/String;
    //   54: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.llIIlIlIlI : [I
    //   57: iconst_3
    //   58: iaload
    //   59: aaload
    //   60: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   63: astore_3
    //   64: aload_3
    //   65: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.lIlIIIlI : [I
    //   68: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.llIIlIlIlI : [I
    //   71: iconst_3
    //   72: iaload
    //   73: iaload
    //   74: aload_2
    //   75: invokevirtual init : (ILjava/security/Key;)V
    //   78: new java/lang/String
    //   81: dup
    //   82: aload_3
    //   83: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   86: aload_0
    //   87: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   90: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   93: invokevirtual decode : ([B)[B
    //   96: invokevirtual doFinal : ([B)[B
    //   99: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   102: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   105: areturn
    //   106: astore_2
    //   107: aload_2
    //   108: invokevirtual printStackTrace : ()V
    //   111: aconst_null
    //   112: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	113	0	lllllllllllllllllIlIlllIIIIIIllI	Ljava/lang/String;
    //   0	113	0	lllllllllllllllllIlIlllIIIIIIlIl	I
    //   0	113	1	lllllllllllllllllIlIlllIIIIIllII	Ljava/lang/String;
    //   51	55	2	lllllllllllllllllIlIlllIIIIIlIII	Ljavax/crypto/spec/SecretKeySpec;
    //   0	113	1	lllllllllllllllllIlIlllIIIIIllIl	Z
    //   0	113	3	lllllllllllllllllIlIlllIIIIIIlll	S
    //   0	113	0	lllllllllllllllllIlIlllIIIIIlllI	F
    //   107	4	2	lllllllllllllllllIlIlllIIIIIlIlI	Ljava/lang/Exception;
    //   0	113	2	lllllllllllllllllIlIlllIIIIIIIll	C
    //   64	42	3	lllllllllllllllllIlIlllIIIIIlIIl	Ljavax/crypto/Cipher;
    //   0	113	3	lllllllllllllllllIlIlllIIIIIIIlI	B
    //   0	113	2	lllllllllllllllllIlIlllIIIIIlIll	C
    //   0	113	1	lllllllllllllllllIlIlllIIIIIIlII	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	105	106	java/lang/Exception
  }
  
  private static boolean lIlIlllIllll(char lllllllllllllllllIlIllIllIlIIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  public String serialize() {
    JSONObject lllllllllllllllllIlIllIlllllIIII = new JSONObject();
    llIIlIlIII[llIIlIlIlI[1]].length();
    llIIlIlIII[llIIlIlIlI[4]].length();
    return lllllllllllllllllIlIllIlllllIIII.toJSONString();
  }
  
  private static boolean lIlIllllIIIl(boolean lllllllllllllllllIlIllIllIlIllII, double lllllllllllllllllIlIllIllIlIlIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public String name(Player lllllllllllllllllIlIlllIIIIlIlIl, byte lllllllllllllllllIlIlllIIIIlIllI) {
    return lllllllllllllllllIlIlllIIIIlIllI;
  }
  
  private static String lIlIlllIIlll(float lllllllllllllllllIlIllIlllIIIlII, char lllllllllllllllllIlIllIlllIIIIll) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.llIIlIlIlI : [I
    //   40: iconst_0
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/custom/menus/icons/actions/Menu.llIIlIlIlI : [I
    //   58: iconst_0
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic lIlIllllIIIl : (II)Z
    //   69: ifeq -> 127
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: bipush #20
    //   114: bipush #16
    //   116: ixor
    //   117: bipush #27
    //   119: bipush #31
    //   121: ixor
    //   122: if_icmpeq -> 62
    //   125: aconst_null
    //   126: areturn
    //   127: aload_2
    //   128: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   131: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	132	8	lllllllllllllllllIlIllIllIllllII	I
    //   79	24	8	lllllllllllllllllIlIllIlllIIlIlI	C
    //   0	132	3	lllllllllllllllllIlIllIlllIIIIIl	S
    //   44	88	4	lllllllllllllllllIlIllIlllIIIlIl	I
    //   0	132	1	lllllllllllllllllIlIllIlllIIlIII	Ljava/lang/String;
    //   37	95	3	lllllllllllllllllIlIllIlllIIIllI	[C
    //   32	100	2	lllllllllllllllllIlIllIlllIIIlll	Ljava/lang/StringBuilder;
    //   0	132	0	lllllllllllllllllIlIllIlllIIlIIl	Ljava/lang/String;
    //   0	132	0	lllllllllllllllllIlIllIlllIIIlII	F
    //   0	132	5	lllllllllllllllllIlIllIllIllllll	J
    //   0	132	2	lllllllllllllllllIlIllIlllIIIIlI	B
    //   0	132	6	lllllllllllllllllIlIllIllIlllllI	D
    //   0	132	7	lllllllllllllllllIlIllIllIllllIl	B
    //   0	132	1	lllllllllllllllllIlIllIlllIIIIll	C
    //   0	132	4	lllllllllllllllllIlIllIlllIIIIII	I
  }
  
  public List<String> lore(Player lllllllllllllllllIlIllIllllIIlIl, long lllllllllllllllllIlIllIllllIIlll) {
    return lllllllllllllllllIlIllIllllIIlll;
  }
  
  public boolean execute(char lllllllllllllllllIlIlllIIIIllIIl) {
    if (lIlIlllIllll(lllIlllII(this.plugin.getMenuManager().getMenu(this.menu))))
      this.plugin.getMenuManager().getMenu(this.menu).open(lllllllllllllllllIlIlllIIIIllIIl); 
    return lIlIIIlI[llIIlIlIlI[0]];
  }
  
  static {
    lIlIlllIlllI();
    lIlIlllIlIIl();
    lllIllIll();
    lllIllIlI();
  }
  
  public Object content() {
    // Byte code:
    //   0: aload_0
    //   1: getfield menu : Ljava/lang/String;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIllIllllIlIll	D
    //   0	5	0	lllllllllllllllllIlIllIllllIlIlI	D
    //   0	5	0	lllllllllllllllllIlIllIllllIllII	Lcom/axeelheaven/hbedwars/custom/menus/icons/actions/Menu;
  }
  
  private static void lIlIlllIlIIl() {
    llIIlIlIII = new String[llIIlIlIlI[20]];
    llIIlIlIII[llIIlIlIlI[0]] = lIlIlllIIllI("rIpuLfRGjKc=", "ctZRB");
    llIIlIlIII[llIIlIlIlI[2]] = lIlIlllIIlll("HhI5", "ZWjcb");
    llIIlIlIII[llIIlIlIlI[3]] = lIlIlllIIlll("Hj8j", "ZzptF");
    llIIlIlIII[llIIlIlIlI[1]] = lIlIlllIIlll("", "hvGpG");
    llIIlIlIII[llIIlIlIlI[4]] = lIlIlllIIllI("DP11iQCRSPA=", "TZiyU");
    llIIlIlIII[llIIlIlIlI[5]] = lIlIlllIlIII("1IydIAN5jzzOExl0Y7zZvg==", "BTiRD");
    llIIlIlIII[llIIlIlIlI[6]] = lIlIlllIIllI("XyV8S0558Lc=", "BNIBx");
    llIIlIlIII[llIIlIlIlI[7]] = lIlIlllIIlll("P1N0fSouGhYkWitf", "fbELb");
    llIIlIlIII[llIIlIlIlI[8]] = lIlIlllIIlll("FS4PHjM=", "DMByF");
    llIIlIlIII[llIIlIlIlI[9]] = lIlIlllIlIII("Nwn696TecRo=", "szRdp");
    llIIlIlIII[llIIlIlIlI[15]] = lIlIlllIIlll("ck4=", "Rnidg");
  }
  
  public Menu(boolean lllllllllllllllllIlIllIllllllllI, int lllllllllllllllllIlIllIlllllIllI) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   9: aload_0
    //   10: aload_2
    //   11: putfield menu : Ljava/lang/String;
    //   14: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	15	2	lllllllllllllllllIlIllIllllllIIl	J
    //   0	15	1	lllllllllllllllllIlIllIlllllIlll	I
    //   0	15	0	lllllllllllllllllIlIllIlllllllIl	Lcom/axeelheaven/hbedwars/custom/menus/icons/actions/Menu;
    //   0	15	2	lllllllllllllllllIlIllIlllllIllI	I
    //   0	15	2	lllllllllllllllllIlIllIllllllIll	Ljava/lang/String;
    //   0	15	0	lllllllllllllllllIlIllIlllllllII	F
    //   0	15	1	lllllllllllllllllIlIllIllllllllI	Z
    //   0	15	0	lllllllllllllllllIlIllIllllllIII	F
    //   0	15	1	lllllllllllllllllIlIllIllllllIlI	Lcom/axeelheaven/hbedwars/BedWars;
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\menus\icons\actions\Menu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */