package com.axeelheaven.hbedwars.cosmetics.windances;

import com.axeelheaven.hbedwars.BedWars;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.entity.Player;

public class WinDanceAnvilRain extends WinDance {
  private static void lIllIIIIIll() {
    lllIIIIll = new String[lllIIIlII[lIIIlIIlIIl[11]]];
    lllIIIIll[lllIIIlII[lIIIlIIlIIl[1]]] = lIllIIIIIIl(lIIIlIIlIII[lIIIlIIlIIl[9]], lIIIlIIlIII[lIIIlIIlIIl[10]]);
    lllIIIIll[lllIIIlII[lIIIlIIlIIl[0]]] = lIllIIIIIIl(lIIIlIIlIII[lIIIlIIlIIl[11]], lIIIlIIlIII[lIIIlIIlIIl[12]]);
    lllIIIIll[lllIIIlII[lIIIlIIlIIl[8]]] = lIllIIIIIIl(lIIIlIIlIII[lIIIlIIlIIl[13]], lIIIlIIlIII[lIIIlIIlIIl[14]]);
    lllIIIIll[lllIIIlII[lIIIlIIlIIl[9]]] = lIllIIIIIlI(lIIIlIIlIII[lIIIlIIlIIl[15]], lIIIlIIlIII[lIIIlIIlIIl[16]]);
  }
  
  private static boolean lIllIIIIlIl(boolean llllllllllllllllIIlllIllllIIIIll, String llllllllllllllllIIlllIllllIIIlIl) {
    if (lIIIIlIIIIIlI(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if ("   ".length() > "   ".length())
        return (0x52 ^ 0x1F) & (0x23 ^ 0x6E ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIIIlIIlIIl[1];
  }
  
  private static String lIIIIIllllIlI(String llllllllllllllllIIlllIllIIllllIl, String llllllllllllllllIIlllIllIIllllII) {
    String str = new String(Base64.getDecoder().decode(llllllllllllllllIIlllIllIIllllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIIlllIllIIlllIlI = new StringBuilder();
    char[] llllllllllllllllIIlllIllIIlllIII = llllllllllllllllIIlllIllIIllllII.toCharArray();
    int llllllllllllllllIIlllIllIIllIllI = lIIIlIIlIIl[1];
    char[] arrayOfChar1 = str.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIIIlIIlIIl[1];
    while (lIIIIlIIIIlIl(j, i)) {
      char llllllllllllllllIIlllIllIIllllll = arrayOfChar1[j];
      "".length();
      llllllllllllllllIIlllIllIIllIllI++;
      j++;
      "".length();
      if ((0xE2 ^ 0x84 ^ 0x5 ^ 0x67) <= 0)
        return null; 
    } 
    return String.valueOf(llllllllllllllllIIlllIllIIlllIlI);
  }
  
  private static boolean lIllIIIlIII(char llllllllllllllllIIlllIllIllIIlIl, long llllllllllllllllIIlllIllIllIIlll) {
    if (lIIIIlIIIIlIl(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (-"   ".length() >= 0)
        return (0xF6 ^ 0xA5 ^ 0xF5 ^ 0x8D) & (0xDF ^ 0x98 ^ 0x34 ^ 0x58 ^ -" ".length()); 
    } else {
    
    } 
    return lIIIlIIlIIl[1];
  }
  
  private static boolean lIIIIIlllllll(String llllllllllllllllIIlllIlIllIIlIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean lIIIIlIIIIIlI(byte llllllllllllllllIIlllIlIlllIIIlI, boolean llllllllllllllllIIlllIlIlllIIIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public void execute(Player llllllllllllllllIIlllIlllIllIIll, int llllllllllllllllIIlllIlllIlIllll) {
    // Byte code:
    //   0: new java/util/concurrent/atomic/AtomicInteger
    //   3: dup
    //   4: aload_2
    //   5: invokevirtual getArenaTask : ()Lcom/axeelheaven/hbedwars/arena/task/ArenaTask;
    //   8: invokevirtual getEndSeconds : ()I
    //   11: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIlII : [I
    //   14: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   17: bipush #11
    //   19: iaload
    //   20: iaload
    //   21: imul
    //   22: invokespecial <init> : (I)V
    //   25: astore_3
    //   26: aload_0
    //   27: getfield runnable : Ljava/util/HashMap;
    //   30: aload_1
    //   31: aload_0
    //   32: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   35: invokevirtual getServer : ()Lorg/bukkit/Server;
    //   38: invokeinterface getScheduler : ()Lorg/bukkit/scheduler/BukkitScheduler;
    //   43: aload_0
    //   44: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   47: aload_0
    //   48: aload_3
    //   49: aload_1
    //   50: aload_2
    //   51: <illegal opcode> run : (Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain;Ljava/util/concurrent/atomic/AtomicInteger;Lorg/bukkit/entity/Player;Lcom/axeelheaven/hbedwars/api/arena/Arena;)Ljava/lang/Runnable;
    //   56: ldc2_w 5
    //   59: ldc2_w 5
    //   62: invokeinterface scheduleSyncRepeatingTask : (Lorg/bukkit/plugin/Plugin;Ljava/lang/Runnable;JJ)I
    //   67: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   70: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   73: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIII : [Ljava/lang/String;
    //   76: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   79: bipush #36
    //   81: iaload
    //   82: aaload
    //   83: invokevirtual length : ()I
    //   86: pop2
    //   87: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	88	1	llllllllllllllllIIlllIlllIllIlIl	B
    //   26	62	3	llllllllllllllllIIlllIlllIllIIIl	Ljava/util/concurrent/atomic/AtomicInteger;
    //   0	88	1	llllllllllllllllIIlllIlllIllIIll	Lorg/bukkit/entity/Player;
    //   0	88	3	llllllllllllllllIIlllIlllIlllIIl	Z
    //   0	88	2	llllllllllllllllIIlllIlllIllIlII	Lcom/axeelheaven/hbedwars/api/arena/Arena;
    //   0	88	0	llllllllllllllllIIlllIlllIlIlIll	S
    //   0	88	0	llllllllllllllllIIlllIlllIlIllIl	Z
    //   0	88	2	llllllllllllllllIIlllIlllIlIllll	I
    //   0	88	0	llllllllllllllllIIlllIlllIllIlll	Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain;
    //   0	88	2	llllllllllllllllIIlllIlllIlIIlll	F
    //   0	88	3	llllllllllllllllIIlllIlllIlIIlIl	S
    //   0	88	1	llllllllllllllllIIlllIlllIlIlIIl	F
  }
  
  private static boolean lIIIIlIIIIIII(float llllllllllllllllIIlllIlIlIllllIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= null);
  }
  
  private static void lIllIIIIlII() {
    lllIIIlII = new int[lIIIlIIlIIl[12]];
    lllIIIlII[lIIIlIIlIIl[1]] = (lIIIlIIlIIl[20] ^ lIIIlIIlIIl[21]) & (lIIIlIIlIIl[22] ^ lIIIlIIlIIl[23] ^ lIIIlIIlIIl[7]);
    lllIIIlII[lIIIlIIlIIl[0]] = lIIIlIIlIII[lIIIlIIlIIl[24]].length();
    lllIIIlII[lIIIlIIlIIl[4]] = lIIIlIIlIIl[25] ^ lIIIlIIlIIl[26] ^ lIIIlIIlIIl[27] ^ lIIIlIIlIIl[28];
    lllIIIlII[lIIIlIIlIIl[8]] = lIIIlIIlIII[lIIIlIIlIIl[23]].length();
    lllIIIlII[lIIIlIIlIIl[9]] = lIIIlIIlIII[lIIIlIIlIIl[29]].length();
    lllIIIlII[lIIIlIIlIIl[10]] = lIIIlIIlIIl[30] ^ lIIIlIIlIIl[31] ^ lIIIlIIlIIl[32] ^ lIIIlIIlIIl[33];
    lllIIIlII[lIIIlIIlIIl[11]] = lIIIlIIlIIl[34] ^ lIIIlIIlIIl[35];
  }
  
  private static String lIllIIIIIlI(boolean llllllllllllllllIIlllIllllIIlIll, String llllllllllllllllIIlllIllllIlIIll) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIII : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   10: bipush #17
    //   12: iaload
    //   13: aaload
    //   14: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   17: aload_1
    //   18: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   21: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   24: invokevirtual digest : ([B)[B
    //   27: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIII : [Ljava/lang/String;
    //   30: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   33: bipush #18
    //   35: iaload
    //   36: aaload
    //   37: invokespecial <init> : ([BLjava/lang/String;)V
    //   40: astore_2
    //   41: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIII : [Ljava/lang/String;
    //   44: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   47: bipush #19
    //   49: iaload
    //   50: aaload
    //   51: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   54: astore_3
    //   55: aload_3
    //   56: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIlII : [I
    //   59: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   62: bipush #8
    //   64: iaload
    //   65: iaload
    //   66: aload_2
    //   67: invokevirtual init : (ILjava/security/Key;)V
    //   70: new java/lang/String
    //   73: dup
    //   74: aload_3
    //   75: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   78: aload_0
    //   79: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   82: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   85: invokevirtual decode : ([B)[B
    //   88: invokevirtual doFinal : ([B)[B
    //   91: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   94: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   97: areturn
    //   98: astore_2
    //   99: aload_2
    //   100: invokevirtual printStackTrace : ()V
    //   103: aconst_null
    //   104: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	105	1	llllllllllllllllIIlllIllllIIlIlI	Z
    //   0	105	2	llllllllllllllllIIlllIllllIIlIIl	Z
    //   0	105	0	llllllllllllllllIIlllIllllIlIIIl	Ljava/lang/String;
    //   0	105	0	llllllllllllllllIIlllIllllIIlIll	Z
    //   0	105	0	llllllllllllllllIIlllIllllIlIIII	J
    //   0	105	1	llllllllllllllllIIlllIllllIlIIll	Ljava/lang/String;
    //   0	105	1	llllllllllllllllIIlllIllllIlIIlI	Ljava/lang/Exception;
    //   0	105	3	llllllllllllllllIIlllIllllIIlIII	B
    //   0	105	2	llllllllllllllllIIlllIllllIIllIl	S
    //   0	105	3	llllllllllllllllIIlllIllllIIlllI	I
    //   55	43	3	llllllllllllllllIIlllIllllIlIlII	Ljavax/crypto/Cipher;
    //   99	4	2	llllllllllllllllIIlllIllllIIllll	Ljava/lang/Exception;
    //   41	57	2	llllllllllllllllIIlllIllllIIllII	Ljavax/crypto/spec/SecretKeySpec;
    // Exception table:
    //   from	to	target	type
    //   0	97	98	java/lang/Exception
  }
  
  private static String lIIIIIlllllII(String llllllllllllllllIIlllIllIIIllIIl, char llllllllllllllllIIlllIllIIIlIlII) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: ldc_w 'Blowfish'
    //   23: invokespecial <init> : ([BLjava/lang/String;)V
    //   26: astore_2
    //   27: ldc_w 'Blowfish'
    //   30: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   33: astore_3
    //   34: aload_3
    //   35: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   38: iconst_4
    //   39: iaload
    //   40: aload_2
    //   41: invokevirtual init : (ILjava/security/Key;)V
    //   44: new java/lang/String
    //   47: dup
    //   48: aload_3
    //   49: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   52: aload_0
    //   53: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   56: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   59: invokevirtual decode : ([B)[B
    //   62: invokevirtual doFinal : ([B)[B
    //   65: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   68: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   71: areturn
    //   72: astore_2
    //   73: aload_2
    //   74: invokevirtual printStackTrace : ()V
    //   77: aconst_null
    //   78: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	79	3	llllllllllllllllIIlllIllIIIlIIIl	F
    //   0	79	1	llllllllllllllllIIlllIllIIIllIII	Ljava/lang/String;
    //   0	79	1	llllllllllllllllIIlllIllIIIlIlII	C
    //   73	4	2	llllllllllllllllIIlllIllIIIllIll	Ljava/lang/Exception;
    //   27	45	2	llllllllllllllllIIlllIllIIIllllI	Ljavax/crypto/spec/SecretKeySpec;
    //   0	79	0	llllllllllllllllIIlllIllIIIlIllI	Ljava/lang/Exception;
    //   0	79	0	llllllllllllllllIIlllIllIIIllIIl	Ljava/lang/String;
    //   0	79	2	llllllllllllllllIIlllIllIIIlIIlI	Z
    //   34	38	3	llllllllllllllllIIlllIllIIIlllII	Ljavax/crypto/Cipher;
    // Exception table:
    //   from	to	target	type
    //   0	71	72	java/lang/Exception
  }
  
  public WinDanceAnvilRain(BedWars llllllllllllllllIIlllIlllllIIlIl, int llllllllllllllllIIlllIlllllIIIlI, String llllllllllllllllIIlllIlllllIlllI, short llllllllllllllllIIlllIlllllIllIl, Exception llllllllllllllllIIlllIlllllIlIII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_3
    //   2: iload #4
    //   4: iload #5
    //   6: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   9: aload_0
    //   10: aload_1
    //   11: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   14: aload_0
    //   15: new java/util/HashMap
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putfield runnable : Ljava/util/HashMap;
    //   25: aload_0
    //   26: aload_0
    //   27: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   30: invokevirtual getWindances : ()Lcom/axeelheaven/hbedwars/custom/config/HConfiguration;
    //   33: new java/lang/StringBuilder
    //   36: dup
    //   37: invokespecial <init> : ()V
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIIll : [Ljava/lang/String;
    //   43: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIlII : [I
    //   46: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   49: iconst_1
    //   50: iaload
    //   51: iaload
    //   52: aaload
    //   53: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: aload_2
    //   57: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIIll : [Ljava/lang/String;
    //   63: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIlII : [I
    //   66: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   69: iconst_0
    //   70: iaload
    //   71: iaload
    //   72: aaload
    //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   79: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIlII : [I
    //   82: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   85: iconst_4
    //   86: iaload
    //   87: iaload
    //   88: invokevirtual getInt : (Ljava/lang/String;I)I
    //   91: putfield perTask : I
    //   94: aload_0
    //   95: aload_0
    //   96: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   99: invokevirtual getWindances : ()Lcom/axeelheaven/hbedwars/custom/config/HConfiguration;
    //   102: new java/lang/StringBuilder
    //   105: dup
    //   106: invokespecial <init> : ()V
    //   109: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIIll : [Ljava/lang/String;
    //   112: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIlII : [I
    //   115: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   118: bipush #8
    //   120: iaload
    //   121: iaload
    //   122: aaload
    //   123: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   126: aload_2
    //   127: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIIll : [Ljava/lang/String;
    //   133: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIlII : [I
    //   136: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   139: bipush #9
    //   141: iaload
    //   142: iaload
    //   143: aaload
    //   144: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   147: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   150: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIlII : [I
    //   153: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   156: bipush #10
    //   158: iaload
    //   159: iaload
    //   160: invokevirtual getInt : (Ljava/lang/String;I)I
    //   163: putfield size : I
    //   166: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	167	1	llllllllllllllllIIlllIlllllIllll	B
    //   0	167	2	llllllllllllllllIIlllIlllllIIllI	Ljava/lang/String;
    //   0	167	4	llllllllllllllllIIlllIlllllIIIII	I
    //   0	167	0	llllllllllllllllIIlllIlllllIlIIl	Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain;
    //   0	167	3	llllllllllllllllIIlllIlllllIIIIl	Ljava/lang/Exception;
    //   0	167	3	llllllllllllllllIIlllIlllllIlllI	Ljava/lang/String;
    //   0	167	5	llllllllllllllllIIlllIllllIlllll	S
    //   0	167	0	llllllllllllllllIIlllIlllllIIlII	B
    //   0	167	4	llllllllllllllllIIlllIlllllIllIl	S
    //   0	167	1	llllllllllllllllIIlllIlllllIIlIl	Lcom/axeelheaven/hbedwars/BedWars;
    //   0	167	2	llllllllllllllllIIlllIlllllIIIlI	I
    //   0	167	0	llllllllllllllllIIlllIlllllIlIlI	I
    //   0	167	4	llllllllllllllllIIlllIlllllIllII	I
    //   0	167	1	llllllllllllllllIIlllIlllllIIIll	Ljava/lang/Exception;
    //   0	167	3	llllllllllllllllIIlllIlllllIIlll	D
    //   0	167	2	llllllllllllllllIIlllIllllllIIII	Ljava/lang/Exception;
    //   0	167	5	llllllllllllllllIIlllIlllllIlIII	Ljava/lang/Exception;
    //   0	167	5	llllllllllllllllIIlllIlllllIlIll	Z
  }
  
  private static String lIllIIIIIIl(String llllllllllllllllIIlllIllIllllIII, byte llllllllllllllllIIlllIlllIIIlIlI) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIlII : [I
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   43: iconst_1
    //   44: iaload
    //   45: iaload
    //   46: istore #4
    //   48: aload_0
    //   49: invokevirtual toCharArray : ()[C
    //   52: astore #5
    //   54: aload #5
    //   56: arraylength
    //   57: istore #6
    //   59: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lllIIIlII : [I
    //   62: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   65: iconst_1
    //   66: iaload
    //   67: iaload
    //   68: istore #7
    //   70: iload #7
    //   72: iload #6
    //   74: invokestatic lIllIIIlIII : (II)Z
    //   77: invokestatic lIIIIIlllllll : (I)Z
    //   80: ifeq -> 153
    //   83: aload #5
    //   85: iload #7
    //   87: caload
    //   88: istore #8
    //   90: aload_2
    //   91: iload #8
    //   93: aload_3
    //   94: iload #4
    //   96: aload_3
    //   97: arraylength
    //   98: irem
    //   99: caload
    //   100: ixor
    //   101: i2c
    //   102: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   105: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIII : [Ljava/lang/String;
    //   108: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   111: bipush #37
    //   113: iaload
    //   114: aaload
    //   115: invokevirtual length : ()I
    //   118: pop2
    //   119: iinc #4, 1
    //   122: iinc #7, 1
    //   125: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIII : [Ljava/lang/String;
    //   128: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceAnvilRain.lIIIlIIlIIl : [I
    //   131: bipush #38
    //   133: iaload
    //   134: aaload
    //   135: invokevirtual length : ()I
    //   138: ldc ''
    //   140: invokevirtual length : ()I
    //   143: pop2
    //   144: aconst_null
    //   145: invokestatic lIIIIlIIIIlII : (Ljava/lang/Object;)Z
    //   148: ifeq -> 70
    //   151: aconst_null
    //   152: areturn
    //   153: aload_2
    //   154: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   157: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	158	3	llllllllllllllllIIlllIlllIIIIlIl	B
    //   0	158	0	llllllllllllllllIIlllIllIlllIllI	C
    //   48	110	4	llllllllllllllllIIlllIlllIIlIIlI	I
    //   0	158	4	llllllllllllllllIIlllIllIlllllII	F
    //   0	158	0	llllllllllllllllIIlllIllIllllIII	Ljava/lang/String;
    //   0	158	1	llllllllllllllllIIlllIlllIIIIllI	Ljava/lang/String;
    //   0	158	2	llllllllllllllllIIlllIlllIIIlIII	Z
    //   0	158	2	llllllllllllllllIIlllIllIlllIIlI	I
    //   0	158	0	llllllllllllllllIIlllIllIllllllI	I
    //   0	158	8	llllllllllllllllIIlllIllIllIllII	J
    //   37	121	3	llllllllllllllllIIlllIlllIIIlllI	[C
    //   32	126	2	llllllllllllllllIIlllIlllIIIIIlI	Ljava/lang/StringBuilder;
    //   0	158	1	llllllllllllllllIIlllIlllIIIlIlI	B
    //   90	32	8	llllllllllllllllIIlllIlllIIlIIII	C
    //   0	158	7	llllllllllllllllIIlllIllIllIllIl	I
    //   0	158	6	llllllllllllllllIIlllIlllIIIllII	B
    //   0	158	5	llllllllllllllllIIlllIlllIIIlIIl	Ljava/lang/String;
    //   0	158	1	llllllllllllllllIIlllIllIlllIlII	D
    //   0	158	3	llllllllllllllllIIlllIllIlllIIIl	S
    //   0	158	6	llllllllllllllllIIlllIllIllIlllI	Ljava/lang/String;
    //   0	158	5	llllllllllllllllIIlllIllIllIllll	Ljava/lang/String;
    //   0	158	4	llllllllllllllllIIlllIllIlllIIII	B
    //   0	158	8	llllllllllllllllIIlllIllIllllIlI	D
    //   0	158	7	llllllllllllllllIIlllIlllIIIIIII	S
  }
  
  private static boolean lIIIIlIIIIIIl(double llllllllllllllllIIlllIlIllIIIIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  static {
    lIIIIIllllllI();
    lIIIIIlllllIl();
    lIllIIIIlII();
    lIllIIIIIll();
  }
  
  private static void lIIIIIllllllI() {
    lIIIlIIlIIl = new int[40];
    lIIIlIIlIIl[0] = " ".length();
    lIIIlIIlIIl[1] = (0x3C ^ 0x21) & (0xA8 ^ 0xB5 ^ 0xFFFFFFFF);
    lIIIlIIlIIl[2] = ((0xCE ^ 0x91) & (0xCE ^ 0x91 ^ 0xFFFFFFFF)) + "  ".length() - -(0xCC ^ 0xC0) + (0x13 ^ 0x65);
    lIIIlIIlIIl[3] = 21 + 31 - 3 + 80;
    lIIIlIIlIIl[4] = "  ".length();
    lIIIlIIlIIl[5] = 0x5 ^ 0x68;
    lIIIlIIlIIl[6] = 0x16 ^ 0x26;
    lIIIlIIlIIl[7] = -" ".length();
    lIIIlIIlIIl[8] = "   ".length();
    lIIIlIIlIIl[9] = 0x3B ^ 0x3F;
    lIIIlIIlIIl[10] = 0xF1 ^ 0xB2 ^ 0x27 ^ 0x61;
    lIIIlIIlIIl[11] = 0x8C ^ 0x8A;
    lIIIlIIlIIl[12] = 0xBE ^ 0xB9;
    lIIIlIIlIIl[13] = 0x31 ^ 0x39;
    lIIIlIIlIIl[14] = 51 + 60 - 12 + 58 ^ 37 + 17 - 33 + 127;
    lIIIlIIlIIl[15] = 0xDF ^ 0xB4 ^ 0x23 ^ 0x42;
    lIIIlIIlIIl[16] = 0x3A ^ 0x69 ^ 0x7F ^ 0x27;
    lIIIlIIlIIl[17] = 29 + 102 - 27 + 85 ^ 6 + 26 - -55 + 90;
    lIIIlIIlIIl[18] = 58 + 151 - 74 + 47 ^ 61 + 105 - 25 + 46;
    lIIIlIIlIIl[19] = 83 + 58 - 59 + 102 ^ 38 + 181 - 218 + 181;
    lIIIlIIlIIl[20] = 61 + 55 - 108 + 128 + 156 + 125 - 246 + 124 - 201 + 45 - 9 + 18 + 65 + 70 - 24 + 60;
    lIIIlIIlIIl[21] = 134 + 33 - 164 + 134;
    lIIIlIIlIIl[22] = 0x87 ^ 0xB6 ^ 0xE8 ^ 0x93;
    lIIIlIIlIIl[23] = 49 + 104 - 38 + 32 ^ 80 + 58 - 110 + 103;
    lIIIlIIlIIl[24] = 51 + 114 - 152 + 178 ^ 57 + 63 - 102 + 158;
    lIIIlIIlIIl[25] = 160 + 120 - 139 + 38 ^ 32 + 80 - 53 + 112;
    lIIIlIIlIIl[26] = 0x64 ^ 0x23 ^ 0xEF ^ 0x83;
    lIIIlIIlIIl[27] = 0xD8 ^ 0xAF ^ 0x63 ^ 0x5D;
    lIIIlIIlIIl[28] = 0xCA ^ 0xBA;
    lIIIlIIlIIl[29] = 176 + 115 - 177 + 76 ^ 66 + 42 - -38 + 29;
    lIIIlIIlIIl[30] = 0x2A ^ 0x48;
    lIIIlIIlIIl[31] = 0xF6 ^ 0x8E;
    lIIIlIIlIIl[32] = (0x83 ^ 0x85) + (0x5C ^ 0x43) - -(0x71 ^ 0xB) + (0x1 ^ 0x14);
    lIIIlIIlIIl[33] = (0xDE ^ 0x8D) + 20 + 143 - 52 + 36 - (0x6A ^ 0x7) + (0x5 ^ 0x26);
    lIIIlIIlIIl[34] = 0x7 ^ 0x26;
    lIIIlIIlIIl[35] = 0xAE ^ 0xA2 ^ 0xC ^ 0x25;
    lIIIlIIlIIl[36] = 0x1 ^ 0x40 ^ 0x57 ^ 0x4;
    lIIIlIIlIIl[37] = 0x2 ^ 0x64 ^ 0xC8 ^ 0xBD;
    lIIIlIIlIIl[38] = 0x9A ^ 0x8E;
    lIIIlIIlIIl[39] = 0x77 ^ 0x62;
  }
  
  private static boolean lIllIIIIllI(double llllllllllllllllIIlllIllllIllIlI) {
    if (lIIIIIlllllll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ((0x94 ^ 0x90) != (0x7C ^ 0x78))
        return (0x58 ^ 0x42) & (0xD8 ^ 0xC2 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIIIlIIlIIl[1];
  }
  
  private static boolean lIllIIIIlll(long llllllllllllllllIIlllIllllIlllII) {
    if (lIIIIlIIIIIIl(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ((42 + 85 - 50 + 52 ^ 79 + 108 - 98 + 44) <= 0)
        return (0x5C ^ 0x70 ^ 0x7F ^ 0x5E) & (0x46 ^ 0x76 ^ 0x5A ^ 0x67 ^ -" ".length()); 
    } else {
    
    } 
    return lIIIlIIlIIl[1];
  }
  
  private static boolean lIIIIlIIIIlII(byte llllllllllllllllIIlllIlIllIlIIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static String lIIIIIllllIll(String llllllllllllllllIIlllIlIllllllll, String llllllllllllllllIIlllIlIllllllIl) {
    try {
      SecretKeySpec llllllllllllllllIIlllIllIIIIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlllIlIllllllIl.getBytes(StandardCharsets.UTF_8)), lIIIlIIlIIl[13]), "DES");
      Cipher llllllllllllllllIIlllIllIIIIIIll = Cipher.getInstance("DES");
      llllllllllllllllIIlllIllIIIIIIll.init(lIIIlIIlIIl[4], llllllllllllllllIIlllIllIIIIIlIl);
      return new String(llllllllllllllllIIlllIllIIIIIIll.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlllIlIllllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception llllllllllllllllIIlllIllIIIIIIIl) {
      llllllllllllllllIIlllIllIIIIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static boolean lIIIIlIIIIlIl(boolean llllllllllllllllIIlllIlIllIllIIl, Exception llllllllllllllllIIlllIlIllIlIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static void lIIIIIlllllIl() {
    lIIIlIIlIII = new String[lIIIlIIlIIl[39]];
    lIIIlIIlIII[lIIIlIIlIIl[1]] = lIIIIIllllIlI("", "EqeAD");
    lIIIlIIlIII[lIIIlIIlIIl[0]] = lIIIIIllllIlI("", "pJtRE");
    lIIIlIIlIII[lIIIlIIlIIl[4]] = lIIIIIllllIlI("", "QVyfm");
    lIIIlIIlIII[lIIIlIIlIIl[8]] = lIIIIIllllIll("uBBg0cS44KQ=", "NJjeg");
    lIIIlIIlIII[lIIIlIIlIIl[9]] = lIIIIIlllllII("Mytqk/VASP58slxBb2z04A==", "OkYAu");
    lIIIlIIlIII[lIIIlIIlIIl[10]] = lIIIIIllllIll("pRla3JcqE+w=", "BFrKK");
    lIIIlIIlIII[lIIIlIIlIIl[11]] = lIIIIIllllIlI("HCUDGywCIS8uPkIr", "zdBkj");
    lIIIlIIlIII[lIIIlIIlIIl[12]] = lIIIIIllllIlI("KyIaDDk=", "yRViw");
    lIIIlIIlIII[lIIIlIIlIIl[13]] = lIIIIIlllllII("KqMHYwNDKPM+H+yh7C4mbQ==", "CFTRx");
    lIIIlIIlIII[lIIIlIIlIIl[14]] = lIIIIIlllllII("kfnXGFOuW8s=", "lMKNI");
    lIIIlIIlIII[lIIIlIIlIIl[15]] = lIIIIIllllIlI("Oj4oLiICJj47DDF6", "tGgjh");
    lIIIlIIlIII[lIIIlIIlIIl[16]] = lIIIIIllllIll("cbJkx5wv2qk=", "cwAJD");
    lIIIlIIlIII[lIIIlIIlIIl[17]] = lIIIIIllllIlI("Ait5", "OoLqH");
    lIIIlIIlIII[lIIIlIIlIIl[18]] = lIIIIIlllllII("OyX+LyRXise/zIqXARakIw==", "vwCQQ");
    lIIIlIIlIII[lIIIlIIlIIl[19]] = lIIIIIllllIlI("BRQ1AywuCzI=", "GxZtJ");
    lIIIlIIlIII[lIIIlIIlIIl[24]] = lIIIIIlllllII("QDXLKDBEgCA=", "nnhWR");
    lIIIlIIlIII[lIIIlIIlIIl[23]] = lIIIIIllllIlI("cWI=", "QBcJM");
    lIIIlIIlIII[lIIIlIIlIIl[29]] = lIIIIIllllIlI("VVdt", "uwMNv");
    lIIIlIIlIII[lIIIlIIlIIl[36]] = lIIIIIlllllII("mUNO3x+ZmAQ=", "KaLBP");
    lIIIlIIlIII[lIIIlIIlIIl[37]] = lIIIIIlllllII("mXHpKdkR99Y=", "uGgBr");
    lIIIlIIlIII[lIIIlIIlIIl[38]] = lIIIIIllllIll("BW8gRSa9R4Q=", "YOOpi");
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\windances\WinDanceAnvilRain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */