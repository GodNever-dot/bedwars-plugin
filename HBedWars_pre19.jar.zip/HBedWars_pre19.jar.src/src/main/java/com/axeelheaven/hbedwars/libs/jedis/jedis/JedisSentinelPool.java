/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisConnectionException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.Pool;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.Logger;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.LoggerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ public class JedisSentinelPool
/*     */   extends Pool<Jedis>
/*     */ {
/*  21 */   private static final Logger LOG = LoggerFactory.getLogger(JedisSentinelPool.class);
/*     */   
/*     */   private final JedisFactory factory;
/*     */   
/*     */   private final JedisClientConfig sentinelClientConfig;
/*     */   
/*  27 */   protected final Collection<MasterListener> masterListeners = new ArrayList<>();
/*     */   
/*     */   private volatile HostAndPort currentHostMaster;
/*     */   
/*  31 */   private final Object initPoolLock = new Object();
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig) {
/*  35 */     this(masterName, sentinels, poolConfig, 2000, null, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels) {
/*  40 */     this(masterName, sentinels, new GenericObjectPoolConfig(), 2000, null, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, String password) {
/*  45 */     this(masterName, sentinels, new GenericObjectPoolConfig(), 2000, password);
/*     */   }
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, String password, String sentinelPassword) {
/*  49 */     this(masterName, sentinels, new GenericObjectPoolConfig(), 2000, 2000, password, 0, null, 2000, 2000, sentinelPassword, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int timeout, String password) {
/*  55 */     this(masterName, sentinels, poolConfig, timeout, password, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int timeout) {
/*  60 */     this(masterName, sentinels, poolConfig, timeout, null, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, String password) {
/*  65 */     this(masterName, sentinels, poolConfig, 2000, password);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int timeout, String password, int database) {
/*  71 */     this(masterName, sentinels, poolConfig, timeout, timeout, (String)null, password, database);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int timeout, String user, String password, int database) {
/*  77 */     this(masterName, sentinels, poolConfig, timeout, timeout, user, password, database);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int timeout, String password, int database, String clientName) {
/*  83 */     this(masterName, sentinels, poolConfig, timeout, timeout, password, database, clientName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int timeout, String user, String password, int database, String clientName) {
/*  89 */     this(masterName, sentinels, poolConfig, timeout, timeout, user, password, database, clientName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int connectionTimeout, int soTimeout, String password, int database) {
/*  95 */     this(masterName, sentinels, poolConfig, connectionTimeout, soTimeout, null, password, database, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int connectionTimeout, int soTimeout, String user, String password, int database) {
/* 101 */     this(masterName, sentinels, poolConfig, connectionTimeout, soTimeout, user, password, database, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int connectionTimeout, int soTimeout, String password, int database, String clientName) {
/* 107 */     this(masterName, sentinels, poolConfig, connectionTimeout, soTimeout, null, password, database, clientName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int connectionTimeout, int soTimeout, String user, String password, int database, String clientName) {
/* 113 */     this(masterName, sentinels, poolConfig, connectionTimeout, soTimeout, user, password, database, clientName, 2000, 2000, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String user, String password, int database, String clientName) {
/* 120 */     this(masterName, sentinels, poolConfig, connectionTimeout, soTimeout, infiniteSoTimeout, user, password, database, clientName, 2000, 2000, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int connectionTimeout, int soTimeout, String password, int database, String clientName, int sentinelConnectionTimeout, int sentinelSoTimeout, String sentinelPassword, String sentinelClientName) {
/* 129 */     this(masterName, sentinels, poolConfig, connectionTimeout, soTimeout, null, password, database, clientName, sentinelConnectionTimeout, sentinelSoTimeout, null, sentinelPassword, sentinelClientName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int connectionTimeout, int soTimeout, String user, String password, int database, String clientName, int sentinelConnectionTimeout, int sentinelSoTimeout, String sentinelUser, String sentinelPassword, String sentinelClientName) {
/* 138 */     this(masterName, sentinels, poolConfig, connectionTimeout, soTimeout, 0, user, password, database, clientName, sentinelConnectionTimeout, sentinelSoTimeout, sentinelUser, sentinelPassword, sentinelClientName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String user, String password, int database, String clientName, int sentinelConnectionTimeout, int sentinelSoTimeout, String sentinelUser, String sentinelPassword, String sentinelClientName) {
/* 148 */     this(masterName, parseHostAndPorts(sentinels), poolConfig, 
/* 149 */         DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout)
/* 150 */         .socketTimeoutMillis(soTimeout).blockingSocketTimeoutMillis(infiniteSoTimeout)
/* 151 */         .user(user).password(password).database(database).clientName(clientName).build(), 
/* 152 */         DefaultJedisClientConfig.builder().connectionTimeoutMillis(sentinelConnectionTimeout)
/* 153 */         .socketTimeoutMillis(sentinelSoTimeout).user(sentinelUser).password(sentinelPassword)
/* 154 */         .clientName(sentinelClientName).build());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<String> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, JedisFactory factory) {
/* 160 */     this(masterName, parseHostAndPorts(sentinels), poolConfig, factory, 
/* 161 */         DefaultJedisClientConfig.builder().build());
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<HostAndPort> sentinels, JedisClientConfig masteClientConfig, JedisClientConfig sentinelClientConfig) {
/* 166 */     this(masterName, sentinels, new GenericObjectPoolConfig(), masteClientConfig, sentinelClientConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<HostAndPort> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, JedisClientConfig masteClientConfig, JedisClientConfig sentinelClientConfig) {
/* 172 */     this(masterName, sentinels, poolConfig, new JedisFactory(masteClientConfig), sentinelClientConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisSentinelPool(String masterName, Set<HostAndPort> sentinels, GenericObjectPoolConfig<Jedis> poolConfig, JedisFactory factory, JedisClientConfig sentinelClientConfig) {
/* 178 */     super(poolConfig, factory);
/*     */     
/* 180 */     this.factory = factory;
/* 181 */     this.sentinelClientConfig = sentinelClientConfig;
/*     */     
/* 183 */     HostAndPort master = initSentinels(sentinels, masterName);
/* 184 */     initMaster(master);
/*     */   }
/*     */   
/*     */   private static Set<HostAndPort> parseHostAndPorts(Set<String> strings) {
/* 188 */     return (Set<HostAndPort>)strings.stream().map(HostAndPort::from).collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 193 */     for (MasterListener m : this.masterListeners) {
/* 194 */       m.shutdown();
/*     */     }
/*     */     
/* 197 */     super.destroy();
/*     */   }
/*     */   
/*     */   public HostAndPort getCurrentHostMaster() {
/* 201 */     return this.currentHostMaster;
/*     */   }
/*     */   
/*     */   private void initMaster(HostAndPort master) {
/* 205 */     synchronized (this.initPoolLock) {
/* 206 */       if (!master.equals(this.currentHostMaster)) {
/* 207 */         this.currentHostMaster = master;
/* 208 */         this.factory.setHostAndPort(this.currentHostMaster);
/*     */ 
/*     */         
/* 211 */         clear();
/*     */         
/* 213 */         LOG.info("Created JedisSentinelPool to master at {}", master);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private HostAndPort initSentinels(Set<HostAndPort> sentinels, String masterName) {
/* 220 */     HostAndPort master = null;
/* 221 */     boolean sentinelAvailable = false;
/*     */     
/* 223 */     LOG.info("Trying to find master from available Sentinels...");
/*     */     
/* 225 */     for (HostAndPort sentinel : sentinels) {
/*     */       
/* 227 */       LOG.debug("Connecting to Sentinel {}", sentinel);
/*     */       
/* 229 */       try { try (Jedis jedis = new Jedis(sentinel, this.sentinelClientConfig))
/*     */         
/* 231 */         { List<String> masterAddr = jedis.sentinelGetMasterAddrByName(masterName);
/*     */ 
/*     */           
/* 234 */           sentinelAvailable = true;
/*     */           
/* 236 */           if (masterAddr == null || masterAddr.size() != 2)
/* 237 */           { LOG.warn("Can not get master addr, master name: {}. Sentinel: {}", masterName, sentinel);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 244 */             if (jedis != null) { if (null != null) { try { jedis.close(); } catch (Throwable throwable) { null.addSuppressed(throwable); }  continue; }  jedis.close(); }  continue; }  master = toHostAndPort(masterAddr); LOG.debug("Found Redis master at {}", master); }  break; } catch (JedisException e)
/*     */       
/*     */       { 
/* 247 */         LOG.warn("Cannot get master address from sentinel running @ {}. Reason: {}. Trying next one.", sentinel, e); }
/*     */     
/*     */     } 
/*     */ 
/*     */     
/* 252 */     if (master == null) {
/* 253 */       if (sentinelAvailable)
/*     */       {
/* 255 */         throw new JedisException("Can connect to sentinel, but " + masterName + " seems to be not monitored...");
/*     */       }
/*     */       
/* 258 */       throw new JedisConnectionException("All sentinels down, cannot determine where is " + masterName + " master is running...");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 263 */     LOG.info("Redis master running at {}, starting Sentinel listeners...", master);
/*     */     
/* 265 */     for (HostAndPort sentinel : sentinels) {
/*     */       
/* 267 */       MasterListener masterListener = new MasterListener(masterName, sentinel.getHost(), sentinel.getPort());
/*     */       
/* 269 */       masterListener.setDaemon(true);
/* 270 */       this.masterListeners.add(masterListener);
/* 271 */       masterListener.start();
/*     */     } 
/*     */     
/* 274 */     return master;
/*     */   }
/*     */   
/*     */   private HostAndPort toHostAndPort(List<String> getMasterAddrByNameResult) {
/* 278 */     String host = getMasterAddrByNameResult.get(0);
/* 279 */     int port = Integer.parseInt(getMasterAddrByNameResult.get(1));
/*     */     
/* 281 */     return new HostAndPort(host, port);
/*     */   }
/*     */ 
/*     */   
/*     */   public Jedis getResource() {
/*     */     while (true) {
/* 287 */       Jedis jedis = (Jedis)super.getResource();
/* 288 */       jedis.setDataSource(this);
/*     */ 
/*     */       
/* 291 */       HostAndPort master = this.currentHostMaster;
/* 292 */       HostAndPort connection = jedis.getClient().getHostAndPort();
/*     */       
/* 294 */       if (master.equals(connection))
/*     */       {
/* 296 */         return jedis;
/*     */       }
/* 298 */       returnBrokenResource(jedis);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void returnResource(Jedis resource) {
/* 305 */     if (resource != null)
/*     */       try {
/* 307 */         resource.resetState();
/* 308 */         super.returnResource(resource);
/* 309 */       } catch (RuntimeException e) {
/* 310 */         returnBrokenResource(resource);
/* 311 */         LOG.debug("Resource is returned to the pool as broken", e);
/*     */       }  
/*     */   }
/*     */   
/*     */   protected class MasterListener
/*     */     extends Thread
/*     */   {
/*     */     protected String masterName;
/*     */     protected String host;
/*     */     protected int port;
/* 321 */     protected long subscribeRetryWaitTimeMillis = 5000L;
/*     */     protected volatile Jedis j;
/* 323 */     protected AtomicBoolean running = new AtomicBoolean(false);
/*     */ 
/*     */     
/*     */     protected MasterListener() {}
/*     */     
/*     */     public MasterListener(String masterName, String host, int port) {
/* 329 */       super(String.format("MasterListener-%s-[%s:%d]", new Object[] { masterName, host, Integer.valueOf(port) }));
/* 330 */       this.masterName = masterName;
/* 331 */       this.host = host;
/* 332 */       this.port = port;
/*     */     }
/*     */ 
/*     */     
/*     */     public MasterListener(String masterName, String host, int port, long subscribeRetryWaitTimeMillis) {
/* 337 */       this(masterName, host, port);
/* 338 */       this.subscribeRetryWaitTimeMillis = subscribeRetryWaitTimeMillis;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 344 */       this.running.set(true);
/*     */       
/* 346 */       while (this.running.get()) {
/*     */ 
/*     */ 
/*     */         
/* 350 */         try { if (!this.running.get())
/*     */           
/*     */           { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 404 */             if (this.j != null)
/* 405 */               this.j.close();  break; }  final HostAndPort hostPort = new HostAndPort(this.host, this.port); this.j = new Jedis(hostPort, JedisSentinelPool.this.sentinelClientConfig); List<String> masterAddr = this.j.sentinelGetMasterAddrByName(this.masterName); if (masterAddr == null || masterAddr.size() != 2) { JedisSentinelPool.LOG.warn("Can not get master addr, master name: {}. Sentinel: {}.", this.masterName, hostPort); } else { JedisSentinelPool.this.initMaster(JedisSentinelPool.this.toHostAndPort(masterAddr)); }  this.j.subscribe(new JedisPubSub() { public void onMessage(String channel, String message) { JedisSentinelPool.LOG.debug("Sentinel {} published: {}.", hostPort, message); String[] switchMasterMsg = message.split(" "); if (switchMasterMsg.length > 3) { if (JedisSentinelPool.MasterListener.this.masterName.equals(switchMasterMsg[0])) { JedisSentinelPool.this.initMaster(JedisSentinelPool.this.toHostAndPort(Arrays.asList(new String[] { switchMasterMsg[3], switchMasterMsg[4] }))); } else { JedisSentinelPool.LOG.debug("Ignoring message on +switch-master for master name {}, our master name is {}", switchMasterMsg[0], JedisSentinelPool.MasterListener.this.masterName); }  } else { JedisSentinelPool.LOG.error("Invalid message received on Sentinel {} on channel +switch-master: {}", hostPort, message); }  } }new String[] { "+switch-master" }); } catch (JedisException e) { if (this.running.get()) { JedisSentinelPool.LOG.error("Lost connection to Sentinel at {}:{}. Sleeping 5000ms and retrying.", new Object[] { this.host, Integer.valueOf(this.port), e }); try { Thread.sleep(this.subscribeRetryWaitTimeMillis); } catch (InterruptedException e1) { JedisSentinelPool.LOG.error("Sleep interrupted: ", e1); }  } else { JedisSentinelPool.LOG.debug("Unsubscribing from Sentinel at {}:{}", this.host, Integer.valueOf(this.port)); }  } finally { if (this.j != null) this.j.close();
/*     */            }
/*     */       
/*     */       } 
/*     */     }
/*     */     
/*     */     public void shutdown() {
/*     */       try {
/* 413 */         JedisSentinelPool.LOG.debug("Shutting down listener on {}:{}", this.host, Integer.valueOf(this.port));
/* 414 */         this.running.set(false);
/*     */         
/* 416 */         if (this.j != null) {
/* 417 */           this.j.close();
/*     */         }
/* 419 */       } catch (RuntimeException e) {
/* 420 */         JedisSentinelPool.LOG.error("Caught exception while shutting down: ", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\JedisSentinelPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */