/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.json;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.commands.ProtocolCommand;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ 
/*    */ public class JsonProtocol {
/*    */   public enum JsonCommand
/*    */     implements ProtocolCommand {
/*  9 */     DEL("JSON.DEL"),
/* 10 */     GET("JSON.GET"),
/* 11 */     MGET("JSON.MGET"),
/* 12 */     SET("JSON.SET"),
/* 13 */     TYPE("JSON.TYPE"),
/* 14 */     STRAPPEND("JSON.STRAPPEND"),
/* 15 */     STRLEN("JSON.STRLEN"),
/* 16 */     ARRAPPEND("JSON.ARRAPPEND"),
/* 17 */     ARRINDEX("JSON.ARRINDEX"),
/* 18 */     ARRINSERT("JSON.ARRINSERT"),
/* 19 */     ARRLEN("JSON.ARRLEN"),
/* 20 */     ARRPOP("JSON.ARRPOP"),
/* 21 */     ARRTRIM("JSON.ARRTRIM"),
/* 22 */     CLEAR("JSON.CLEAR"),
/* 23 */     TOGGLE("JSON.TOGGLE");
/*    */     
/*    */     private final byte[] raw;
/*    */     
/*    */     JsonCommand(String alt) {
/* 28 */       this.raw = SafeEncoder.encode(alt);
/*    */     }
/*    */ 
/*    */     
/*    */     public byte[] getRaw() {
/* 33 */       return this.raw;
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\json\JsonProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */