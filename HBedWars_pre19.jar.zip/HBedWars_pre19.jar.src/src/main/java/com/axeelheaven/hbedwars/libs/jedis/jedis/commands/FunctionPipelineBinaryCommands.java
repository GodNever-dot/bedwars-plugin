package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FunctionRestorePolicy;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.FunctionLoadParams;
import java.util.List;

public interface FunctionPipelineBinaryCommands {
  Response<Object> fcall(byte[] paramArrayOfbyte, List<byte[]> paramList1, List<byte[]> paramList2);
  
  Response<Object> fcallReadonly(byte[] paramArrayOfbyte, List<byte[]> paramList1, List<byte[]> paramList2);
  
  Response<String> functionDelete(byte[] paramArrayOfbyte);
  
  Response<byte[]> functionDump();
  
  Response<String> functionFlush();
  
  Response<String> functionFlush(FlushMode paramFlushMode);
  
  Response<String> functionKill();
  
  Response<List<Object>> functionListBinary();
  
  Response<List<Object>> functionList(byte[] paramArrayOfbyte);
  
  Response<List<Object>> functionListWithCodeBinary();
  
  Response<List<Object>> functionListWithCode(byte[] paramArrayOfbyte);
  
  Response<String> functionLoad(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
  
  Response<String> functionLoad(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, FunctionLoadParams paramFunctionLoadParams, byte[] paramArrayOfbyte3);
  
  Response<String> functionRestore(byte[] paramArrayOfbyte);
  
  Response<String> functionRestore(byte[] paramArrayOfbyte, FunctionRestorePolicy paramFunctionRestorePolicy);
  
  Response<Object> functionStatsBinary();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\FunctionPipelineBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */