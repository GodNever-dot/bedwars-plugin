package com.axeelheaven.hbedwars.cosmetics.windances;

import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import java.util.HashMap;

public class WinDanceManager {
    private final BedWars plugin;
    private final HashMap<String, WinDance> dances;
    
    public WinDanceManager(BedWars plugin) {
        this.plugin = plugin;
        this.dances = new HashMap<>();
    }
    
    public void registerDance(String name, WinDance dance) {
        this.dances.put(name, dance);
    }
    
    public WinDance getDance(String name) {
        return this.dances.get(name);
    }
    
    public void playDance(Player player, Location location) {
        WinDance dance = getDance(player.getName());
        if (dance != null) {
            dance.play(player, location);
        }
    }
    
    public HashMap<String, WinDance> getDances() {
        return this.dances;
    }
    
    public BedWars getPlugin() {
        return this.plugin;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\windances\WinDanceManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */