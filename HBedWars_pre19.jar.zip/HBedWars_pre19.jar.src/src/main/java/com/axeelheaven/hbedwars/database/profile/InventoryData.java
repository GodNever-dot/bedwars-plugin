package com.axeelheaven.hbedwars.database.profile;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import com.axeelheaven.hbedwars.BedWars;
import java.util.HashMap;
import java.util.Map;

public class InventoryData {
  private final BedWars plugin;
  private final Map<String, ItemStack[]> inventories;
  private final Map<String, ItemStack[]> armor;
  
  public InventoryData(BedWars plugin) {
    this.plugin = plugin;
    this.inventories = new HashMap<>();
    this.armor = new HashMap<>();
  }
  
  public void saveInventory(Player player) {
    inventories.put(player.getName(), player.getInventory().getContents());
    armor.put(player.getName(), player.getInventory().getArmorContents());
  }
  
  public void restoreInventory(Player player) {
    ItemStack[] contents = inventories.get(player.getName());
    ItemStack[] armorContents = armor.get(player.getName());
    
    if (contents != null) {
      player.getInventory().setContents(contents);
    }
    
    if (armorContents != null) {
      player.getInventory().setArmorContents(armorContents);
    }
    
    player.updateInventory();
  }
  
  public void clearData(Player player) {
    inventories.remove(player.getName());
    armor.remove(player.getName());
  }
  
  public boolean isAllowFlight() {
    // Byte code:
    //   0: aload_0
    //   1: getfield allowFlight : Z
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIlIIIIIIIlIII	F
    //   0	5	0	lllllllllllllllllIlIlIIIIIIIIlll	S
    //   0	5	0	lllllllllllllllllIlIlIIIIIIIlIIl	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  private static String lIllIIlIllIl(String lllllllllllllllllIlIIllllIlIlIIl, float lllllllllllllllllIlIIllllIlIIIll) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   40: iconst_0
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   58: iconst_0
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic lIllIIllIlll : (II)Z
    //   69: ifeq -> 118
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: aconst_null
    //   113: ifnull -> 62
    //   116: aconst_null
    //   117: areturn
    //   118: aload_2
    //   119: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   122: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	123	3	lllllllllllllllllIlIIllllIlIIIIl	Ljava/lang/String;
    //   0	123	1	lllllllllllllllllIlIIllllIlIlIII	Ljava/lang/String;
    //   37	86	3	lllllllllllllllllIlIIllllIlIIllI	[C
    //   0	123	5	lllllllllllllllllIlIIllllIIlllll	Ljava/lang/String;
    //   0	123	4	lllllllllllllllllIlIIllllIlIIIII	B
    //   0	123	8	lllllllllllllllllIlIIllllIIlllII	S
    //   0	123	2	lllllllllllllllllIlIIllllIlIIIlI	Ljava/lang/String;
    //   32	91	2	lllllllllllllllllIlIIllllIlIIlll	Ljava/lang/StringBuilder;
    //   0	123	0	lllllllllllllllllIlIIllllIlIIlII	Ljava/lang/Exception;
    //   0	123	1	lllllllllllllllllIlIIllllIlIIIll	F
    //   0	123	0	lllllllllllllllllIlIIllllIlIlIIl	Ljava/lang/String;
    //   0	123	7	lllllllllllllllllIlIIllllIIlllIl	B
    //   0	123	6	lllllllllllllllllIlIIllllIIllllI	I
    //   79	24	8	lllllllllllllllllIlIIllllIlIlIlI	C
    //   44	79	4	lllllllllllllllllIlIIllllIlIIlIl	I
  }
  
  public ItemStack[] getInventory() {
    // Byte code:
    //   0: aload_0
    //   1: getfield inventory : [Lorg/bukkit/inventory/ItemStack;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIlIIIIIllIlll	J
    //   0	5	0	lllllllllllllllllIlIlIIIIIllIllI	D
    //   0	5	0	lllllllllllllllllIlIlIIIIIlllIII	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  public double getHealth() {
    // Byte code:
    //   0: aload_0
    //   1: getfield health : D
    //   4: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIIlllllIlllll	B
    //   0	5	0	lllllllllllllllllIlIIlllllIlllIl	S
    //   0	5	0	lllllllllllllllllIlIIlllllIllllI	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  private static boolean lIIIIlIIIl(String lllllllllllllllllIlIIllllllIIlIl) {
    if (lIllIIllIllI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return (0x9 ^ 0x56 ^ 0xDA ^ 0x88) & (127 + 104 - 150 + 59 ^ 36 + 106 - 50 + 37 ^ -" ".length()); 
    } else {
    
    } 
    return llIlIIIIll[0];
  }
  
  public boolean isFlight() {
    // Byte code:
    //   0: aload_0
    //   1: getfield flight : Z
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIlIIIIlIlllII	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	5	0	lllllllllllllllllIlIlIIIIlIllIll	D
    //   0	5	0	lllllllllllllllllIlIlIIIIlIllIlI	S
  }
  
  public void load() {
    // Byte code:
    //   0: aload_0
    //   1: getfield player : Lorg/bukkit/entity/Player;
    //   4: invokeinterface isOnline : ()Z
    //   9: invokestatic lIIIIIllll : (I)Z
    //   12: invokestatic lIllIIllIIIl : (I)Z
    //   15: ifeq -> 19
    //   18: return
    //   19: aload_0
    //   20: getfield inventory : [Lorg/bukkit/inventory/ItemStack;
    //   23: invokestatic lIIIIlIIII : (Ljava/lang/Object;)Z
    //   26: invokestatic lIllIIllIIIl : (I)Z
    //   29: ifeq -> 56
    //   32: aload_0
    //   33: getfield player : Lorg/bukkit/entity/Player;
    //   36: invokeinterface getInventory : ()Lorg/bukkit/inventory/PlayerInventory;
    //   41: aload_0
    //   42: getfield inventory : [Lorg/bukkit/inventory/ItemStack;
    //   45: invokevirtual clone : ()Ljava/lang/Object;
    //   48: checkcast [Lorg/bukkit/inventory/ItemStack;
    //   51: invokeinterface setContents : ([Lorg/bukkit/inventory/ItemStack;)V
    //   56: aload_0
    //   57: getfield player : Lorg/bukkit/entity/Player;
    //   60: invokeinterface getInventory : ()Lorg/bukkit/inventory/PlayerInventory;
    //   65: aload_0
    //   66: getfield heldItemSlot : I
    //   69: invokeinterface setHeldItemSlot : (I)V
    //   74: aload_0
    //   75: getfield armorContents : [Lorg/bukkit/inventory/ItemStack;
    //   78: invokestatic lIIIIlIIII : (Ljava/lang/Object;)Z
    //   81: invokestatic lIllIIllIIIl : (I)Z
    //   84: ifeq -> 111
    //   87: aload_0
    //   88: getfield player : Lorg/bukkit/entity/Player;
    //   91: invokeinterface getInventory : ()Lorg/bukkit/inventory/PlayerInventory;
    //   96: aload_0
    //   97: getfield armorContents : [Lorg/bukkit/inventory/ItemStack;
    //   100: invokevirtual clone : ()Ljava/lang/Object;
    //   103: checkcast [Lorg/bukkit/inventory/ItemStack;
    //   106: invokeinterface setArmorContents : ([Lorg/bukkit/inventory/ItemStack;)V
    //   111: aload_0
    //   112: getfield enderContents : [Lorg/bukkit/inventory/ItemStack;
    //   115: invokestatic lIIIIlIIII : (Ljava/lang/Object;)Z
    //   118: invokestatic lIllIIllIIIl : (I)Z
    //   121: ifeq -> 148
    //   124: aload_0
    //   125: getfield player : Lorg/bukkit/entity/Player;
    //   128: invokeinterface getEnderChest : ()Lorg/bukkit/inventory/Inventory;
    //   133: aload_0
    //   134: getfield enderContents : [Lorg/bukkit/inventory/ItemStack;
    //   137: invokevirtual clone : ()Ljava/lang/Object;
    //   140: checkcast [Lorg/bukkit/inventory/ItemStack;
    //   143: invokeinterface setContents : ([Lorg/bukkit/inventory/ItemStack;)V
    //   148: aload_0
    //   149: getfield player : Lorg/bukkit/entity/Player;
    //   152: aload_0
    //   153: getfield level : I
    //   156: invokeinterface setLevel : (I)V
    //   161: aload_0
    //   162: getfield player : Lorg/bukkit/entity/Player;
    //   165: aload_0
    //   166: getfield exp : F
    //   169: invokeinterface setExp : (F)V
    //   174: aload_0
    //   175: getfield player : Lorg/bukkit/entity/Player;
    //   178: aload_0
    //   179: getfield food : I
    //   182: invokeinterface setFoodLevel : (I)V
    //   187: aload_0
    //   188: getfield player : Lorg/bukkit/entity/Player;
    //   191: aload_0
    //   192: getfield maxHealth : D
    //   195: dconst_1
    //   196: invokestatic lIIIIIlllI : (DD)I
    //   199: invokestatic lIIIIlIIIl : (I)Z
    //   202: invokestatic lIllIIllIIIl : (I)Z
    //   205: ifeq -> 235
    //   208: dconst_1
    //   209: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIlI : [Ljava/lang/String;
    //   212: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   215: iconst_0
    //   216: iaload
    //   217: aaload
    //   218: invokevirtual length : ()I
    //   221: ldc ''
    //   223: invokevirtual length : ()I
    //   226: pop2
    //   227: aconst_null
    //   228: invokestatic lIllIIllIIlI : (Ljava/lang/Object;)Z
    //   231: ifeq -> 239
    //   234: return
    //   235: aload_0
    //   236: getfield maxHealth : D
    //   239: invokeinterface setMaxHealth : (D)V
    //   244: aload_0
    //   245: getfield player : Lorg/bukkit/entity/Player;
    //   248: aload_0
    //   249: getfield health : D
    //   252: dconst_1
    //   253: invokestatic lIIIIIlllI : (DD)I
    //   256: invokestatic lIIIIlIIIl : (I)Z
    //   259: invokestatic lIllIIllIIIl : (I)Z
    //   262: ifeq -> 341
    //   265: dconst_1
    //   266: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIlI : [Ljava/lang/String;
    //   269: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   272: iconst_1
    //   273: iaload
    //   274: aaload
    //   275: invokevirtual length : ()I
    //   278: ldc ''
    //   280: invokevirtual length : ()I
    //   283: pop2
    //   284: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   287: iconst_2
    //   288: iaload
    //   289: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   292: iconst_3
    //   293: iaload
    //   294: iadd
    //   295: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   298: iconst_4
    //   299: iaload
    //   300: isub
    //   301: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   304: iconst_4
    //   305: iaload
    //   306: iadd
    //   307: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   310: iconst_4
    //   311: iaload
    //   312: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   315: iconst_5
    //   316: iaload
    //   317: iadd
    //   318: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   321: bipush #6
    //   323: iaload
    //   324: isub
    //   325: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   328: bipush #7
    //   330: iaload
    //   331: iadd
    //   332: ixor
    //   333: ineg
    //   334: invokestatic lIllIIllIIll : (I)Z
    //   337: ifeq -> 345
    //   340: return
    //   341: aload_0
    //   342: getfield health : D
    //   345: invokeinterface setHealth : (D)V
    //   350: aload_0
    //   351: getfield potionEffects : Ljava/util/Collection;
    //   354: invokestatic lIIIIlIIII : (Ljava/lang/Object;)Z
    //   357: invokestatic lIllIIllIIIl : (I)Z
    //   360: ifeq -> 419
    //   363: aload_0
    //   364: getfield player : Lorg/bukkit/entity/Player;
    //   367: invokeinterface getActivePotionEffects : ()Ljava/util/Collection;
    //   372: aload_0
    //   373: <illegal opcode> accept : (Lcom/axeelheaven/hbedwars/database/profile/InventoryData;)Ljava/util/function/Consumer;
    //   378: invokeinterface forEach : (Ljava/util/function/Consumer;)V
    //   383: aload_0
    //   384: getfield potionEffects : Ljava/util/Collection;
    //   387: aload_0
    //   388: getfield player : Lorg/bukkit/entity/Player;
    //   391: dup
    //   392: invokevirtual getClass : ()Ljava/lang/Class;
    //   395: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIlI : [Ljava/lang/String;
    //   398: getstatic com/axeelheaven/hbedwars/database/profile/InventoryData.llIlIIIIll : [I
    //   401: bipush #8
    //   403: iaload
    //   404: aaload
    //   405: invokevirtual length : ()I
    //   408: pop2
    //   409: <illegal opcode> accept : (Lorg/bukkit/entity/Player;)Ljava/util/function/Consumer;
    //   414: invokeinterface forEach : (Ljava/util/function/Consumer;)V
    //   419: aload_0
    //   420: getfield player : Lorg/bukkit/entity/Player;
    //   423: aload_0
    //   424: getfield allowFlight : Z
    //   427: invokeinterface setAllowFlight : (Z)V
    //   432: aload_0
    //   433: getfield player : Lorg/bukkit/entity/Player;
    //   436: aload_0
    //   437: getfield flight : Z
    //   440: invokeinterface setFlying : (Z)V
    //   445: aload_0
    //   446: getfield gameMode : Lorg/bukkit/GameMode;
    //   449: invokestatic lIIIIlIIII : (Ljava/lang/Object;)Z
    //   452: invokestatic lIllIIllIIIl : (I)Z
    //   455: ifeq -> 471
    //   458: aload_0
    //   459: getfield player : Lorg/bukkit/entity/Player;
    //   462: aload_0
    //   463: getfield gameMode : Lorg/bukkit/GameMode;
    //   466: invokeinterface setGameMode : (Lorg/bukkit/GameMode;)V
    //   471: aload_0
    //   472: getfield player : Lorg/bukkit/entity/Player;
    //   475: aload_0
    //   476: getfield fireTick : I
    //   479: invokeinterface setFireTicks : (I)V
    //   484: aload_0
    //   485: getfield player : Lorg/bukkit/entity/Player;
    //   488: invokeinterface updateInventory : ()V
    //   493: aload_0
    //   494: getfield player : Lorg/bukkit/entity/Player;
    //   497: invokeinterface closeInventory : ()V
    //   502: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	503	0	lllllllllllllllllIlIlIIIIlIllllI	D
    //   0	503	0	lllllllllllllllllIlIlIIIIlIlllll	D
    //   0	503	0	lllllllllllllllllIlIlIIIIllIIIII	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  public void setInventory(float lllllllllllllllllIlIlIIIIIllIIll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield inventory : [Lorg/bukkit/inventory/ItemStack;
    //   5: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	6	0	lllllllllllllllllIlIlIIIIIllIIlI	D
    //   0	6	1	lllllllllllllllllIlIlIIIIIllIIIl	[Lorg/bukkit/inventory/ItemStack;
    //   0	6	0	lllllllllllllllllIlIlIIIIIlIllll	J
    //   0	6	0	lllllllllllllllllIlIlIIIIIllIIII	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	6	1	lllllllllllllllllIlIlIIIIIllIIll	F
    //   0	6	1	lllllllllllllllllIlIlIIIIIlIlllI	D
  }
  
  private static int lIllIIllIlII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  public GameMode getGameMode() {
    // Byte code:
    //   0: aload_0
    //   1: getfield gameMode : Lorg/bukkit/GameMode;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIIlllllIlIlIl	C
    //   0	5	0	lllllllllllllllllIlIIlllllIlIllI	B
    //   0	5	0	lllllllllllllllllIlIIlllllIlIlll	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  private static String lIllIIlIlllI(String lllllllllllllllllIlIIllllIllIlll, String lllllllllllllllllIlIIllllIllIllI) {
    try {
      SecretKeySpec lllllllllllllllllIlIIllllIllllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIIllllIllIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIlIIllllIlllIll = Cipher.getInstance("Blowfish");
      lllllllllllllllllIlIIllllIlllIll.init(llIlIIIIll[8], lllllllllllllllllIlIIllllIllllII);
      return new String(lllllllllllllllllIlIIllllIlllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIIllllIllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIlIIllllIlllIlI) {
      lllllllllllllllllIlIIllllIlllIlI.printStackTrace();
      return null;
    } 
  }
  
  public int getLevel() {
    // Byte code:
    //   0: aload_0
    //   1: getfield level : I
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIIllllllIIIIl	D
    //   0	5	0	lllllllllllllllllIlIIllllllIIIll	Z
    //   0	5	0	lllllllllllllllllIlIIllllllIIIlI	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  private static boolean lIllIIllIlIl(long lllllllllllllllllIlIIllllIIIIlIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  public ItemStack[] getArmorContents() {
    // Byte code:
    //   0: aload_0
    //   1: getfield armorContents : [Lorg/bukkit/inventory/ItemStack;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIlIIIIllIlIII	Ljava/lang/Exception;
    //   0	5	0	lllllllllllllllllIlIlIIIIllIIllI	C
    //   0	5	0	lllllllllllllllllIlIlIIIIllIIlll	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  public void setArmorContents(String lllllllllllllllllIlIlIIIIIIlIIll) {
    ((InventoryData)super).armorContents = (ItemStack[])lllllllllllllllllIlIlIIIIIIlIIll;
  }
  
  public void setFireTick(String lllllllllllllllllIlIlIIIIIllllII) {
    this.fireTick = lllllllllllllllllIlIlIIIIIllllII;
  }
  
  public void setAllowFlight(boolean lllllllllllllllllIlIlIIIIlIIllIl) {
    this.allowFlight = lllllllllllllllllIlIlIIIIlIIllIl;
  }
  
  public float getExp() {
    // Byte code:
    //   0: aload_0
    //   1: getfield exp : F
    //   4: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIlIIIIllIIlII	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	5	0	lllllllllllllllllIlIlIIIIllIIIlI	C
    //   0	5	0	lllllllllllllllllIlIlIIIIllIIIll	Z
  }
  
  private static boolean lIllIIllIlll(float lllllllllllllllllIlIIllllIIIllII, String lllllllllllllllllIlIIllllIIIlIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  static {
    lIllIIllIIII();
    lIllIIlIllll();
  }
  
  private static boolean lIllIIllIIIl(float lllllllllllllllllIlIIllllIIIIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  public void save() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield player : Lorg/bukkit/entity/Player;
    //   5: invokeinterface getInventory : ()Lorg/bukkit/inventory/PlayerInventory;
    //   10: invokeinterface getContents : ()[Lorg/bukkit/inventory/ItemStack;
    //   15: invokevirtual clone : ()Ljava/lang/Object;
    //   18: checkcast [Lorg/bukkit/inventory/ItemStack;
    //   21: putfield inventory : [Lorg/bukkit/inventory/ItemStack;
    //   24: aload_0
    //   25: aload_0
    //   26: getfield player : Lorg/bukkit/entity/Player;
    //   29: invokeinterface getInventory : ()Lorg/bukkit/inventory/PlayerInventory;
    //   34: invokeinterface getHeldItemSlot : ()I
    //   39: putfield heldItemSlot : I
    //   42: aload_0
    //   43: aload_0
    //   44: getfield player : Lorg/bukkit/entity/Player;
    //   47: invokeinterface getInventory : ()Lorg/bukkit/inventory/PlayerInventory;
    //   52: invokeinterface getArmorContents : ()[Lorg/bukkit/inventory/ItemStack;
    //   57: invokevirtual clone : ()Ljava/lang/Object;
    //   60: checkcast [Lorg/bukkit/inventory/ItemStack;
    //   63: putfield armorContents : [Lorg/bukkit/inventory/ItemStack;
    //   66: aload_0
    //   67: aload_0
    //   68: getfield player : Lorg/bukkit/entity/Player;
    //   71: invokeinterface getEnderChest : ()Lorg/bukkit/inventory/Inventory;
    //   76: invokeinterface getContents : ()[Lorg/bukkit/inventory/ItemStack;
    //   81: invokevirtual clone : ()Ljava/lang/Object;
    //   84: checkcast [Lorg/bukkit/inventory/ItemStack;
    //   87: putfield enderContents : [Lorg/bukkit/inventory/ItemStack;
    //   90: aload_0
    //   91: aload_0
    //   92: getfield player : Lorg/bukkit/entity/Player;
    //   95: invokeinterface getLevel : ()I
    //   100: putfield level : I
    //   103: aload_0
    //   104: aload_0
    //   105: getfield player : Lorg/bukkit/entity/Player;
    //   108: invokeinterface getExp : ()F
    //   113: putfield exp : F
    //   116: aload_0
    //   117: aload_0
    //   118: getfield player : Lorg/bukkit/entity/Player;
    //   121: invokeinterface getFoodLevel : ()I
    //   126: putfield food : I
    //   129: aload_0
    //   130: aload_0
    //   131: getfield player : Lorg/bukkit/entity/Player;
    //   134: invokeinterface getMaxHealth : ()D
    //   139: putfield maxHealth : D
    //   142: aload_0
    //   143: aload_0
    //   144: getfield player : Lorg/bukkit/entity/Player;
    //   147: invokeinterface getHealth : ()D
    //   152: putfield health : D
    //   155: aload_0
    //   156: aload_0
    //   157: getfield player : Lorg/bukkit/entity/Player;
    //   160: invokeinterface getActivePotionEffects : ()Ljava/util/Collection;
    //   165: putfield potionEffects : Ljava/util/Collection;
    //   168: aload_0
    //   169: aload_0
    //   170: getfield player : Lorg/bukkit/entity/Player;
    //   173: invokeinterface getAllowFlight : ()Z
    //   178: putfield allowFlight : Z
    //   181: aload_0
    //   182: aload_0
    //   183: getfield player : Lorg/bukkit/entity/Player;
    //   186: invokeinterface isFlying : ()Z
    //   191: putfield flight : Z
    //   194: aload_0
    //   195: aload_0
    //   196: getfield player : Lorg/bukkit/entity/Player;
    //   199: invokeinterface getGameMode : ()Lorg/bukkit/GameMode;
    //   204: putfield gameMode : Lorg/bukkit/GameMode;
    //   207: aload_0
    //   208: aload_0
    //   209: getfield player : Lorg/bukkit/entity/Player;
    //   212: invokeinterface getFireTicks : ()I
    //   217: putfield fireTick : I
    //   220: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	221	0	lllllllllllllllllIlIlIIIlIIIlIll	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	221	0	lllllllllllllllllIlIlIIIlIIIllII	S
    //   0	221	0	lllllllllllllllllIlIlIIIlIIIlIlI	I
  }
  
  public int getFood() {
    // Byte code:
    //   0: aload_0
    //   1: getfield food : I
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIlIIIIIIlllIl	S
    //   0	5	0	lllllllllllllllllIlIlIIIIIIllIll	D
    //   0	5	0	lllllllllllllllllIlIlIIIIIIlllII	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  public Player getPlayer() {
    // Byte code:
    //   0: aload_0
    //   1: getfield player : Lorg/bukkit/entity/Player;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIIlllllIlIIlI	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	5	0	lllllllllllllllllIlIIlllllIlIIIl	Z
    //   0	5	0	lllllllllllllllllIlIIlllllIlIIll	B
  }
  
  public void setFood(int lllllllllllllllllIlIlIIIIIIIIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield food : I
    //   5: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	6	0	lllllllllllllllllIlIlIIIIIIIIIll	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	6	0	lllllllllllllllllIlIlIIIIIIIIIII	C
    //   0	6	1	lllllllllllllllllIlIlIIIIIIIIIIl	C
    //   0	6	0	lllllllllllllllllIlIlIIIIIIIIlII	J
    //   0	6	1	lllllllllllllllllIlIlIIIIIIIIIlI	I
    //   0	6	1	lllllllllllllllllIlIlIIIIIIIIIIl	C
  }
  
  public void setHealth(double lllllllllllllllllIlIIlllllIIIIIl) {
    ((InventoryData)super).health = lllllllllllllllllIlIIlllllIIIIIl;
  }
  
  private static void lIllIIlIllll() {
    llIlIIIIlI = new String[llIlIIIIll[9]];
    llIlIIIIlI[llIlIIIIll[0]] = lIllIIlIllII("i0Fxo4zfoH4=", "XwHSP");
    llIlIIIIlI[llIlIIIIll[1]] = lIllIIlIllIl("", "IzAro");
    llIlIIIIlI[llIlIIIIll[8]] = lIllIIlIlllI("QyAUOCmiR08=", "UVBSG");
  }
  
  private static void lIllIIllIIII() {
    llIlIIIIll = new int[11];
    llIlIIIIll[0] = (169 + 15 - -11 + 13 ^ 49 + 85 - 26 + 23) & (0xC ^ 0x1D ^ 0x1E ^ 0x5C ^ -" ".length());
    llIlIIIIll[1] = " ".length();
    llIlIIIIll[2] = (0x61 ^ 0x2D) + 29 + 95 - 35 + 49 - 123 + 127 - 249 + 203 + 146 + 130 - 258 + 142;
    llIlIIIIll[3] = 0x26 ^ 0x20;
    llIlIIIIll[4] = (0x1 ^ 0x58) + (0x65 ^ 0x7E) - (0xF8 ^ 0xA0) + (0x6E ^ 0xD);
    llIlIIIIll[5] = 88 + 36 - 84 + 95;
    llIlIIIIll[6] = 0x16 ^ 0x66 ^ 0x89 ^ 0x91;
    llIlIIIIll[7] = 0x8D ^ 0x9B;
    llIlIIIIll[8] = "  ".length();
    llIlIIIIll[9] = "   ".length();
    llIlIIIIll[10] = 0x96 ^ 0x9E;
  }
  
  public void setMaxHealth(double lllllllllllllllllIlIlIIIIIIlIIII) {
    // Byte code:
    //   0: aload_0
    //   1: dload_1
    //   2: putfield maxHealth : D
    //   5: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	6	1	lllllllllllllllllIlIlIIIIIIIlIll	D
    //   0	6	1	lllllllllllllllllIlIlIIIIIIlIIII	D
    //   0	6	0	lllllllllllllllllIlIlIIIIIIIllIl	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	6	0	lllllllllllllllllIlIlIIIIIIIlllI	I
    //   0	6	0	lllllllllllllllllIlIlIIIIIIIllII	J
    //   0	6	1	lllllllllllllllllIlIlIIIIIIIllll	B
  }
  
  public void setHeldItemSlot(boolean lllllllllllllllllIlIlIIIIlllllII) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield heldItemSlot : I
    //   5: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	6	1	lllllllllllllllllIlIlIIIIllllllI	I
    //   0	6	1	lllllllllllllllllIlIlIIIIlllllII	Z
    //   0	6	0	lllllllllllllllllIlIlIIIIlllllIl	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	6	0	lllllllllllllllllIlIlIIIIllllIll	S
    //   0	6	0	lllllllllllllllllIlIlIIIIlllllll	Z
    //   0	6	1	lllllllllllllllllIlIlIIIIllllIlI	I
  }
  
  public int getFireTick() {
    // Byte code:
    //   0: aload_0
    //   1: getfield fireTick : I
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIlIIIIIlIIIIl	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	5	0	lllllllllllllllllIlIlIIIIIIlllll	C
    //   0	5	0	lllllllllllllllllIlIlIIIIIlIIIII	D
  }
  
  private static boolean lIllIIllIllI(String lllllllllllllllllIlIIllllIIIIIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < null);
  }
  
  private static String lIllIIlIllII(String lllllllllllllllllIlIIllllIIlIlII, String lllllllllllllllllIlIIllllIIlIIIl) {
    try {
      SecretKeySpec lllllllllllllllllIlIIllllIIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIIllllIIlIIIl.getBytes(StandardCharsets.UTF_8)), llIlIIIIll[10]), "DES");
      Cipher lllllllllllllllllIlIIllllIIlIllI = Cipher.getInstance("DES");
      lllllllllllllllllIlIIllllIIlIllI.init(llIlIIIIll[8], lllllllllllllllllIlIIllllIIlIlll);
      return new String(lllllllllllllllllIlIIllllIIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIIllllIIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIlIIllllIIlIlIl) {
      lllllllllllllllllIlIIllllIIlIlIl.printStackTrace();
      return null;
    } 
  }
  
  public ItemStack[] getEnderContents() {
    return this.enderContents;
  }
  
  private static boolean lIIIIlIIII(long lllllllllllllllllIlIIllllllIlIIl) {
    if (lIllIIllIIlI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return (0x3 ^ 0x6F ^ 0xF8 ^ 0x80) & (160 + 91 - 99 + 22 ^ 31 + 129 - 12 + 38 ^ -" ".length()); 
    } else {
    
    } 
    return llIlIIIIll[0];
  }
  
  private static boolean lIllIIllIIll(long lllllllllllllllllIlIIllllIIIIIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > null);
  }
  
  public InventoryData(char lllllllllllllllllIlIlIIIIlIlIllI) {
    this.player = lllllllllllllllllIlIlIIIIlIlIllI;
  }
  
  public double getMaxHealth() {
    // Byte code:
    //   0: aload_0
    //   1: getfield maxHealth : D
    //   4: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIlIIIIlIIIIll	Ljava/lang/Exception;
    //   0	5	0	lllllllllllllllllIlIlIIIIlIIIIlI	S
    //   0	5	0	lllllllllllllllllIlIlIIIIlIIIlII	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  private static boolean lIIIIIllll(boolean lllllllllllllllllIlIlIIIIIlIlIll) {
    if (lIllIIllIlIl(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return (0x66 ^ 0x5F ^ 0x27 ^ 0xC) & (0xAF ^ 0xC0 ^ 0x5F ^ 0x22 ^ -" ".length()); 
    } else {
    
    } 
    return llIlIIIIll[0];
  }
  
  public void setPotionEffects(long lllllllllllllllllIlIlIIIlIIIIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield potionEffects : Ljava/util/Collection;
    //   5: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	6	1	lllllllllllllllllIlIlIIIlIIIIlIl	Ljava/util/Collection;
    //   0	6	0	lllllllllllllllllIlIlIIIlIIIIllI	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	6	1	lllllllllllllllllIlIlIIIlIIIIIlI	J
    //   0	6	1	lllllllllllllllllIlIlIIIlIIIIlll	D
    //   0	6	0	lllllllllllllllllIlIlIIIlIIIIlII	J
    //   0	6	0	lllllllllllllllllIlIlIIIlIIIIIll	Ljava/lang/String;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   0	6	1	lllllllllllllllllIlIlIIIlIIIIlIl	Ljava/util/Collection<Lorg/bukkit/potion/PotionEffect;>;
    //   0	6	1	lllllllllllllllllIlIlIIIlIIIIIlI	Ljava/util/Collection<Lorg/bukkit/potion/PotionEffect;>;
    //   0	6	1	lllllllllllllllllIlIlIIIlIIIIlll	Ljava/util/Collection<Lorg/bukkit/potion/PotionEffect;>;
  }
  
  public void setGameMode(char lllllllllllllllllIlIlIIIIIlIIIll) {
    this.gameMode = lllllllllllllllllIlIlIIIIIlIIIll;
  }
  
  public void setLevel(byte lllllllllllllllllIlIIlllllIIlIll) {
    this.level = lllllllllllllllllIlIIlllllIIlIll;
  }
  
  private static int lIIIIIlllI(double paramDouble1, double paramDouble2) {
    return lIllIIllIlII(paramDouble1, paramDouble2);
  }
  
  private static boolean lIllIIllIIlI(Exception lllllllllllllllllIlIIllllIIIlIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  public Collection<PotionEffect> getPotionEffects() {
    return ((InventoryData)super).potionEffects;
  }
  
  public void setEnderContents(ItemStack[] lllllllllllllllllIlIIllllllllIIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield enderContents : [Lorg/bukkit/inventory/ItemStack;
    //   5: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	6	0	lllllllllllllllllIlIIllllllllIII	I
    //   0	6	1	lllllllllllllllllIlIIllllllllIlI	I
    //   0	6	1	lllllllllllllllllIlIIllllllllIIl	[Lorg/bukkit/inventory/ItemStack;
    //   0	6	0	lllllllllllllllllIlIIllllllllIll	D
    //   0	6	0	lllllllllllllllllIlIIlllllllllII	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   0	6	1	lllllllllllllllllIlIIlllllllIlll	Ljava/lang/Exception;
  }
  
  public void setFlight(boolean lllllllllllllllllIlIIllllllIllll) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield flight : Z
    //   5: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	6	1	lllllllllllllllllIlIIlllllllIIII	Ljava/lang/String;
    //   0	6	1	lllllllllllllllllIlIIllllllIllll	Z
    //   0	6	0	lllllllllllllllllIlIIllllllIllII	D
    //   0	6	1	lllllllllllllllllIlIIllllllIlIll	B
    //   0	6	0	lllllllllllllllllIlIIllllllIllIl	I
    //   0	6	0	lllllllllllllllllIlIIllllllIlllI	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  public int getHeldItemSlot() {
    // Byte code:
    //   0: aload_0
    //   1: getfield heldItemSlot : I
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIIlllllllIlIl	B
    //   0	5	0	lllllllllllllllllIlIIlllllllIIll	Z
    //   0	5	0	lllllllllllllllllIlIIlllllllIlII	Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
  }
  
  public void setExp(float lllllllllllllllllIlIlIIIIllIllII) {
    this.exp = lllllllllllllllllIlIlIIIIllIllII;
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\database\profile\InventoryData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */