/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.executors;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandObject;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Connection;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.providers.ConnectionProvider;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.IOUtils;
/*    */ 
/*    */ public class DefaultCommandExecutor
/*    */   implements CommandExecutor {
/*    */   protected final ConnectionProvider provider;
/*    */   
/*    */   public DefaultCommandExecutor(ConnectionProvider provider) {
/* 13 */     this.provider = provider;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 18 */     IOUtils.closeQuietly((AutoCloseable)this.provider);
/*    */   }
/*    */ 
/*    */   
/*    */   public final <T> T executeCommand(CommandObject<T> commandObject) {
/* 23 */     try (Connection connection = this.provider.getConnection(commandObject.getArguments())) {
/* 24 */       return (T)connection.executeCommand(commandObject);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\executors\DefaultCommandExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */