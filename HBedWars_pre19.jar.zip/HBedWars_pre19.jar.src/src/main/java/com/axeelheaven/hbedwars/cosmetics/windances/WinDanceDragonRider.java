package com.axeelheaven.hbedwars.cosmetics.windances;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.api.arena.Arena;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;

public class WinDanceDragonRider extends WinDance {
  private static String lIIIlIIIllIlI(short llllllllllllllllIIIllIlIlllllllI, String llllllllllllllllIIIllIllIIIIIIlI) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIlIIIIIll : [I
    //   40: iconst_2
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIlIIIIIll : [I
    //   58: iconst_2
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic lIIIlllIlIlll : (II)Z
    //   69: ifeq -> 127
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: ldc ' '
    //   114: invokevirtual length : ()I
    //   117: ldc ' '
    //   119: invokevirtual length : ()I
    //   122: if_icmpeq -> 62
    //   125: aconst_null
    //   126: areturn
    //   127: aload_2
    //   128: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   131: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	132	2	llllllllllllllllIIIllIlIllllllII	F
    //   0	132	4	llllllllllllllllIIIllIlIlllllIlI	I
    //   37	95	3	llllllllllllllllIIIllIllIIIIIIII	[C
    //   0	132	3	llllllllllllllllIIIllIlIlllllIll	Ljava/lang/Exception;
    //   0	132	0	llllllllllllllllIIIllIllIIIIIIll	Ljava/lang/String;
    //   0	132	5	llllllllllllllllIIIllIlIlllllIIl	Ljava/lang/Exception;
    //   0	132	8	llllllllllllllllIIIllIlIllllIllI	F
    //   0	132	6	llllllllllllllllIIIllIlIlllllIII	Ljava/lang/String;
    //   32	100	2	llllllllllllllllIIIllIllIIIIIIIl	Ljava/lang/StringBuilder;
    //   0	132	0	llllllllllllllllIIIllIlIlllllllI	S
    //   0	132	1	llllllllllllllllIIIllIlIllllllIl	S
    //   79	24	8	llllllllllllllllIIIllIllIIIIIlII	C
    //   0	132	7	llllllllllllllllIIIllIlIllllIlll	S
    //   0	132	1	llllllllllllllllIIIllIllIIIIIIlI	Ljava/lang/String;
    //   44	88	4	llllllllllllllllIIIllIlIllllllll	I
  }
  
  private static void lIlllllllll() {
    llllIIIII = new String[llllIIIIl[lIIlIIIIIll[0]]];
    llllIIIII[llllIIIIl[lIIlIIIIIll[1]]] = lIllllllllI(lIIIllIIlIl[lIIlIIIIIll[2]], lIIIllIIlIl[lIIlIIIIIll[1]]);
  }
  
  private static boolean llIIIIIIIll(String llllllllllllllllIIIllIllIIllIIll) {
    if (lIIIlllIlIlIl(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return (0xBB ^ 0xC1 ^ 0x1 ^ 0x24) & (0xF4 ^ 0xA0 ^ 0x42 ^ 0x49 ^ -" ".length()); 
    } else {
    
    } 
    return lIIlIIIIIll[2];
  }
  
  private static String lIIIlIIIllIll(boolean llllllllllllllllIIIllIlIlllIllII, String llllllllllllllllIIIllIlIlllIllIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIlIIIIIll : [I
    //   23: bipush #20
    //   25: iaload
    //   26: invokestatic copyOf : ([BI)[B
    //   29: ldc_w 'DES'
    //   32: invokespecial <init> : ([BLjava/lang/String;)V
    //   35: astore_2
    //   36: ldc_w 'DES'
    //   39: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   42: astore_3
    //   43: aload_3
    //   44: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIlIIIIIll : [I
    //   47: iconst_3
    //   48: iaload
    //   49: aload_2
    //   50: invokevirtual init : (ILjava/security/Key;)V
    //   53: new java/lang/String
    //   56: dup
    //   57: aload_3
    //   58: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   61: aload_0
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   68: invokevirtual decode : ([B)[B
    //   71: invokevirtual doFinal : ([B)[B
    //   74: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   77: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   80: areturn
    //   81: astore_2
    //   82: aload_2
    //   83: invokevirtual printStackTrace : ()V
    //   86: aconst_null
    //   87: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   36	45	2	llllllllllllllllIIIllIlIllllIIIl	Ljavax/crypto/spec/SecretKeySpec;
    //   0	88	2	llllllllllllllllIIIllIlIlllIlIlI	J
    //   0	88	0	llllllllllllllllIIIllIlIlllIlllI	Ljava/lang/String;
    //   43	38	3	llllllllllllllllIIIllIlIllllIIII	Ljavax/crypto/Cipher;
    //   0	88	0	llllllllllllllllIIIllIlIlllIllII	Z
    //   0	88	3	llllllllllllllllIIIllIlIlllIlIIl	Ljava/lang/String;
    //   82	4	2	llllllllllllllllIIIllIlIlllIllll	Ljava/lang/Exception;
    //   0	88	1	llllllllllllllllIIIllIlIlllIlIll	Z
    //   0	88	1	llllllllllllllllIIIllIlIlllIllIl	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	80	81	java/lang/Exception
  }
  
  private static String lIllllllllI(String llllllllllllllllIIIllIllIIllllll, float llllllllllllllllIIIllIllIlIIIIlI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIIllIIlIl : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIlIIIIIll : [I
    //   10: iconst_4
    //   11: iaload
    //   12: aaload
    //   13: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   16: aload_1
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   23: invokevirtual digest : ([B)[B
    //   26: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.llllIIIIl : [I
    //   29: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIlIIIIIll : [I
    //   32: iconst_4
    //   33: iaload
    //   34: iaload
    //   35: invokestatic copyOf : ([BI)[B
    //   38: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIIllIIlIl : [Ljava/lang/String;
    //   41: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIlIIIIIll : [I
    //   44: iconst_5
    //   45: iaload
    //   46: aaload
    //   47: invokespecial <init> : ([BLjava/lang/String;)V
    //   50: astore_2
    //   51: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIIllIIlIl : [Ljava/lang/String;
    //   54: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIlIIIIIll : [I
    //   57: bipush #6
    //   59: iaload
    //   60: aaload
    //   61: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   64: astore_3
    //   65: aload_3
    //   66: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.llllIIIIl : [I
    //   69: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIlIIIIIll : [I
    //   72: iconst_5
    //   73: iaload
    //   74: iaload
    //   75: aload_2
    //   76: invokevirtual init : (ILjava/security/Key;)V
    //   79: new java/lang/String
    //   82: dup
    //   83: aload_3
    //   84: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   87: aload_0
    //   88: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   91: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   94: invokevirtual decode : ([B)[B
    //   97: invokevirtual doFinal : ([B)[B
    //   100: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   103: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   106: areturn
    //   107: astore_2
    //   108: aload_2
    //   109: invokevirtual printStackTrace : ()V
    //   112: aconst_null
    //   113: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	114	3	llllllllllllllllIIIllIllIIlllIlI	B
    //   51	56	2	llllllllllllllllIIIllIllIlIIIIIl	Ljavax/crypto/spec/SecretKeySpec;
    //   0	114	0	llllllllllllllllIIIllIllIIlllIIl	S
    //   0	114	2	llllllllllllllllIIIllIllIIllIlll	D
    //   0	114	1	llllllllllllllllIIIllIllIIlllIll	Ljava/lang/String;
    //   65	42	3	llllllllllllllllIIIllIllIIllllII	Ljavax/crypto/Cipher;
    //   0	114	0	llllllllllllllllIIIllIllIIllllll	Ljava/lang/String;
    //   0	114	2	llllllllllllllllIIIllIllIIlllllI	B
    //   0	114	1	llllllllllllllllIIIllIllIlIIIIlI	F
    //   108	4	2	llllllllllllllllIIIllIllIIllllIl	Ljava/lang/Exception;
    //   0	114	0	llllllllllllllllIIIllIllIlIIIIII	I
    //   0	114	1	llllllllllllllllIIIllIllIIlllIII	J
    //   0	114	3	llllllllllllllllIIIllIllIIllIllI	Ljava/lang/Exception;
    // Exception table:
    //   from	to	target	type
    //   0	106	107	java/lang/Exception
  }
  
  private static void lIIIlllIlIIIl() {
    lIIlIIIIIll = new int[38];
    lIIlIIIIIll[0] = "   ".length();
    lIIlIIIIIll[1] = " ".length();
    lIIlIIIIIll[2] = (0xA0 ^ 0x8F) & (0x43 ^ 0x6C ^ 0xFFFFFFFF);
    lIIlIIIIIll[3] = "  ".length();
    lIIlIIIIIll[4] = 165 + 91 - 254 + 195 ^ 42 + 89 - 130 + 192;
    lIIlIIIIIll[5] = 0x29 ^ 0x2C;
    lIIlIIIIIll[6] = 78 + 87 - 119 + 117 ^ 69 + 106 - 84 + 74;
    lIIlIIIIIll[7] = 37 + 87 - 65 + 89;
    lIIlIIIIIll[8] = 131 + 95 - 99 + 46 ^ 56 + 29 - 28 + 90;
    lIIlIIIIIll[9] = "   ".length() ^ 0xB6 ^ 0xC5;
    lIIlIIIIIll[10] = 148 + 144 - 140 + 7 ^ 126 + 61 - 93 + 80;
    lIIlIIIIIll[11] = 0xB ^ 0x19;
    lIIlIIIIIll[12] = 0xE8 ^ 0x87;
    lIIlIIIIIll[13] = 157 + 100 - 156 + 68 ^ 77 + 118 - 124 + 64;
    lIIlIIIIIll[14] = 49 + 63 - 0 + 15 ^ 0x89 ^ 0x95;
    lIIlIIIIIll[15] = 0xA ^ 0x33;
    lIIlIIIIIll[16] = 0xAE ^ 0xC6 ^ 0x4 ^ 0x5B;
    lIIlIIIIIll[17] = 163 + 16 - 58 + 47 ^ 46 + 75 - 39 + 57;
    lIIlIIIIIll[18] = 0xA7 ^ 0xAC;
    lIIlIIIIIll[19] = 15 + 102 - -8 + 73 ^ 154 + 80 - 178 + 137;
    lIIlIIIIIll[20] = 0x85 ^ 0x8D;
    lIIlIIIIIll[21] = -" ".length();
    lIIlIIIIIll[22] = 0xFFFFFFFF & Integer.MAX_VALUE;
    lIIlIIIIIll[23] = 0x4B ^ 0x42;
    lIIlIIIIIll[24] = 0x44 ^ 0x30;
    lIIlIIIIIll[25] = 0xF9 ^ 0x85;
    lIIlIIIIIll[26] = 146 + 9 - 103 + 114 ^ 3 + 104 - 99 + 164;
    lIIlIIIIIll[27] = 68 + 61 - 45 + 47 ^ 10 + 32 - -89 + 12;
    lIIlIIIIIll[28] = 0x9D ^ 0xA8;
    lIIlIIIIIll[29] = 0x38 ^ 0x51 ^ 0x7D ^ 0x32;
    lIIlIIIIIll[30] = 0x43 ^ 0x1D;
    lIIlIIIIIll[31] = 78 + 76 - 31 + 9 + 5 + 92 - 47 + 98 - 138 + 33 - 92 + 119 + (0xDC ^ 0x98);
    lIIlIIIIIll[32] = 0x3F ^ 0x20;
    lIIlIIIIIll[33] = (0x1A ^ 0x34) + (0x24 ^ 0x4C) - (0xB0 ^ 0x88) + (0x54 ^ 0x79);
    lIIlIIIIIll[34] = 40 + 64 - -12 + 18;
    lIIlIIIIIll[35] = 0x83 ^ 0x87 ^ 0x54 ^ 0x5D;
    lIIlIIIIIll[36] = 0x5C ^ 0x67 ^ 0xE ^ 0x3B;
    lIIlIIIIIll[37] = 0xE3 ^ 0x80 ^ 0xFF ^ 0x93;
  }
  
  private static boolean lIIIlllIlIlIl(int llllllllllllllllIIIllIlIllIllIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static boolean lIIIlllIlIIlI(boolean llllllllllllllllIIIllIlIllIlllIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  static {
    lIIIlllIlIIIl();
    lIIIlIIlIllII();
    llIIIIIIIII();
    lIlllllllll();
  }
  
  private static boolean llIIIIIIlII(short llllllllllllllllIIIllIllIllIIIIl) {
    if (lIIIlllIlIIll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ("   ".length() <= ((0x2 ^ 0x27 ^ 0x6B ^ 0x54) & (1 + 71 - -22 + 63 ^ 71 + 109 - 179 + 134 ^ -" ".length())))
        return (43 + 64 - 97 + 128 ^ 51 + 50 - -20 + 24) & (0xE ^ 0x4F ^ 0x3F ^ 0x65 ^ -" ".length()); 
    } else {
    
    } 
    return lIIlIIIIIll[2];
  }
  
  private static void llIIIIIIIII() {
    llllIIIIl = new int[lIIlIIIIIll[6]];
    llllIIIIl[lIIlIIIIIll[2]] = lIIlIIIIIll[3] + lIIlIIIIIll[5] - lIIlIIIIIll[2] + lIIlIIIIIll[7] ^ lIIlIIIIIll[8] + lIIlIIIIIll[9] - lIIlIIIIIll[10] + lIIlIIIIIll[11];
    llllIIIIl[lIIlIIIIIll[1]] = (lIIlIIIIIll[12] ^ lIIlIIIIIll[13] ^ lIIlIIIIIll[14] ^ lIIlIIIIIll[15]) & (lIIlIIIIIll[16] ^ lIIlIIIIIll[4] ^ lIIlIIIIIll[17] ^ lIIlIIIIIll[18] ^ -lIIIllIIlIl[lIIlIIIIIll[19]].length());
    llllIIIIl[lIIlIIIIIll[3]] = -lIIIllIIlIl[lIIlIIIIIll[20]].length() & lIIlIIIIIll[21] & lIIlIIIIIll[22];
    llllIIIIl[lIIlIIIIIll[0]] = lIIIllIIlIl[lIIlIIIIIll[23]].length();
    llllIIIIl[lIIlIIIIIll[4]] = lIIlIIIIIll[24] ^ lIIlIIIIIll[25];
    llllIIIIl[lIIlIIIIIll[5]] = lIIIllIIlIl[lIIlIIIIIll[26]].length();
  }
  
  private static boolean llIIIIIIIlI(String llllllllllllllllIIIllIllIllllIIl) {
    if (lIIIlllIlIIlI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (-"   ".length() > 0)
        return "   ".length() & ("   ".length() ^ -" ".length()); 
    } else {
    
    } 
    return lIIlIIIIIll[2];
  }
  
  private static boolean lIIIlllIlIllI(short llllllllllllllllIIIllIlIllIllIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > null);
  }
  
  private static boolean lIIIlllIlIlll(Exception llllllllllllllllIIIllIlIlllIIIlI, Exception llllllllllllllllIIIllIlIlllIIIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIIIlllIlIIll(short llllllllllllllllIIIllIlIllIlllll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static void lIIIlIIlIllII() {
    lIIIllIIlIl = new String[lIIlIIIIIll[37]];
    lIIIllIIlIl[lIIlIIIIIll[2]] = lIIIlIIIllIIl("JUF7w8QUN91l26g6JnJruw+mcgw8VbLhQBS+R/xWshc=", "xlTmA");
    lIIIllIIlIl[lIIlIIIIIll[1]] = lIIIlIIIllIlI("AiMHDgA=", "LaJYQ");
    lIIIllIIlIl[lIIlIIIIIll[3]] = lIIIlIIIllIll("C9Et1T4vu1Q=", "dOnjJ");
    lIIIllIIlIl[lIIlIIIIIll[0]] = lIIIlIIIllIIl("JzeEpk7enPo=", "WYAur");
    lIIIllIIlIl[lIIlIIIIIll[4]] = lIIIlIIIllIIl("sskaZnKRjVE=", "dSrCG");
    lIIIllIIlIl[lIIlIIIIIll[5]] = lIIIlIIIllIlI("FCwH", "PiTAR");
    lIIIllIIlIl[lIIlIIIIIll[6]] = lIIIlIIIllIlI("Bisi", "BnqnE");
    lIIIllIIlIl[lIIlIIIIIll[19]] = lIIIlIIIllIlI("WA==", "xiuDa");
    lIIIllIIlIl[lIIlIIIIIll[20]] = lIIIlIIIllIIl("v93czarq24I=", "oufMA");
    lIIIllIIlIl[lIIlIIIIIll[23]] = lIIIlIIIllIlI("Tg==", "neFIQ");
    lIIIllIIlIl[lIIlIIIIIll[26]] = lIIIlIIIllIll("cySfXBwvMt4=", "YOPGh");
    lIIIllIIlIl[lIIlIIIIIll[18]] = lIIIlIIIllIIl("sTi2dXYXzeA=", "FKszO");
    lIIIllIIlIl[lIIlIIIIIll[27]] = lIIIlIIIllIlI("", "RkjpA");
    lIIIllIIlIl[lIIlIIIIIll[35]] = lIIIlIIIllIIl("M5Qjrax5rYY=", "bWtiz");
    lIIIllIIlIl[lIIlIIIIIll[36]] = lIIIlIIIllIll("tSAS6IalOck=", "GMDLu");
  }
  
  private static boolean lIIIlllIlIlII(String llllllllllllllllIIIllIlIlllIIllI, int llllllllllllllllIIIllIlIlllIIlIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public WinDanceDragonRider(boolean llllllllllllllllIIIllIllIlIIlIlI, String llllllllllllllllIIIllIllIlIlIIII, float llllllllllllllllIIIllIllIlIIlIII, String llllllllllllllllIIIllIllIlIlIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: iload_3
    //   3: iload #4
    //   5: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   8: aload_0
    //   9: aload_1
    //   10: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   13: aload_0
    //   14: new java/util/HashMap
    //   17: dup
    //   18: invokespecial <init> : ()V
    //   21: putfield runnable : Ljava/util/HashMap;
    //   24: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	25	0	llllllllllllllllIIIllIllIlIIlIll	Z
    //   0	25	4	llllllllllllllllIIIllIllIlIlIlII	Z
    //   0	25	2	llllllllllllllllIIIllIllIlIIlIIl	D
    //   0	25	3	llllllllllllllllIIIllIllIlIlIIIl	I
    //   0	25	1	llllllllllllllllIIIllIllIlIlIIlI	C
    //   0	25	3	llllllllllllllllIIIllIllIlIIlIII	F
    //   0	25	4	llllllllllllllllIIIllIllIlIlIlIl	Ljava/lang/String;
    //   0	25	0	llllllllllllllllIIIllIllIlIlIIll	F
    //   0	25	2	llllllllllllllllIIIllIllIlIlIIII	Ljava/lang/String;
    //   0	25	3	llllllllllllllllIIIllIllIlIIllll	I
    //   0	25	2	llllllllllllllllIIIllIllIlIIlllI	F
    //   0	25	0	llllllllllllllllIIIllIllIlIIllII	Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider;
    //   0	25	1	llllllllllllllllIIIllIllIlIIlIlI	Z
    //   0	25	4	llllllllllllllllIIIllIllIlIIIlll	J
    //   0	25	1	llllllllllllllllIIIllIllIlIIllIl	Lcom/axeelheaven/hbedwars/BedWars;
  }
  
  private static boolean llIIIIIIIIl(float llllllllllllllllIIIllIllIlIlllII, String llllllllllllllllIIIllIllIlIllIll) {
    if (lIIIlllIlIlII(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if ((0xAF ^ 0xAB) == -" ".length())
        return (0x98 ^ 0x92) & (0x55 ^ 0x5F ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIIlIIIIIll[2];
  }
  
  private static String lIIIlIIIllIIl(float llllllllllllllllIIIllIllIIIlIIIl, String llllllllllllllllIIIllIllIIIlIIlI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: ldc_w 'Blowfish'
    //   23: invokespecial <init> : ([BLjava/lang/String;)V
    //   26: astore_2
    //   27: ldc_w 'Blowfish'
    //   30: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   33: astore_3
    //   34: aload_3
    //   35: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceDragonRider.lIIlIIIIIll : [I
    //   38: iconst_3
    //   39: iaload
    //   40: aload_2
    //   41: invokevirtual init : (ILjava/security/Key;)V
    //   44: new java/lang/String
    //   47: dup
    //   48: aload_3
    //   49: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   52: aload_0
    //   53: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   56: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   59: invokevirtual decode : ([B)[B
    //   62: invokevirtual doFinal : ([B)[B
    //   65: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   68: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   71: areturn
    //   72: astore_2
    //   73: aload_2
    //   74: invokevirtual printStackTrace : ()V
    //   77: aconst_null
    //   78: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   27	45	2	llllllllllllllllIIIllIllIIIlIllI	Ljavax/crypto/spec/SecretKeySpec;
    //   73	4	2	llllllllllllllllIIIllIllIIIlIlII	Ljava/lang/Exception;
    //   0	79	0	llllllllllllllllIIIllIllIIIlIIll	Ljava/lang/String;
    //   0	79	2	llllllllllllllllIIIllIllIIIIllll	I
    //   0	79	0	llllllllllllllllIIIllIllIIIlIIIl	F
    //   0	79	1	llllllllllllllllIIIllIllIIIlIIII	S
    //   34	38	3	llllllllllllllllIIIllIllIIIlIlIl	Ljavax/crypto/Cipher;
    //   0	79	3	llllllllllllllllIIIllIllIIIIlllI	Z
    //   0	79	1	llllllllllllllllIIIllIllIIIlIIlI	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	71	72	java/lang/Exception
  }
  
  public void execute(long llllllllllllllllIIIllIllIllIIlll, long llllllllllllllllIIIllIllIllIIlIl) {
    AtomicInteger llllllllllllllllIIIllIllIllIllII = new AtomicInteger(llllllllllllllllIIIllIllIllIIllI.getArenaTask().getEndSeconds() * llllIIIIl[lIIlIIIIIll[2]]);
    EnderDragon llllllllllllllllIIIllIllIlllIIlI = (EnderDragon)llllllllllllllllIIIllIllIllIIlll.getWorld().spawn(llllllllllllllllIIIllIllIllIIlll.getLocation(), EnderDragon.class);
    llllllllllllllllIIIllIllIlllIIlI.setMetadata(llllIIIII[llllIIIIl[lIIlIIIIIll[1]]], (MetadataValue)new FixedMetadataValue((Plugin)this.plugin, getId()));
    llllllllllllllllIIIllIllIlllIIlI.setNoDamageTicks(llllIIIIl[lIIlIIIIIll[3]]);
    lIIIllIIlIl[lIIlIIIIIll[3]].length();
    lIIIllIIlIl[lIIlIIIIIll[0]].length();
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\windances\WinDanceDragonRider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */