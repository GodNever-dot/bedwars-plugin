/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ public class JedisClusterOperationException
/*    */   extends JedisException {
/*    */   private static final long serialVersionUID = 8124535086306604887L;
/*    */   
/*    */   public JedisClusterOperationException(String message) {
/*  8 */     super(message);
/*    */   }
/*    */   
/*    */   public JedisClusterOperationException(Throwable cause) {
/* 12 */     super(cause);
/*    */   }
/*    */   
/*    */   public JedisClusterOperationException(String message, Throwable cause) {
/* 16 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\JedisClusterOperationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */