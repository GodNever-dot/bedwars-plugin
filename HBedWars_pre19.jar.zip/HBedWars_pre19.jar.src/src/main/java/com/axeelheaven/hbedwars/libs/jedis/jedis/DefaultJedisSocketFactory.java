/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisConnectionException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.IOUtils;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLParameters;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ public class DefaultJedisSocketFactory
/*     */   implements JedisSocketFactory
/*     */ {
/*  19 */   protected static final HostAndPort DEFAULT_HOST_AND_PORT = new HostAndPort("127.0.0.1", 6379);
/*     */ 
/*     */   
/*  22 */   private volatile HostAndPort hostAndPort = DEFAULT_HOST_AND_PORT;
/*  23 */   private int connectionTimeout = 2000;
/*  24 */   private int socketTimeout = 2000;
/*     */   private boolean ssl = false;
/*  26 */   private SSLSocketFactory sslSocketFactory = null;
/*  27 */   private SSLParameters sslParameters = null;
/*  28 */   private HostnameVerifier hostnameVerifier = null;
/*  29 */   private HostAndPortMapper hostAndPortMapper = null;
/*     */ 
/*     */   
/*     */   public DefaultJedisSocketFactory() {}
/*     */   
/*     */   public DefaultJedisSocketFactory(HostAndPort hostAndPort) {
/*  35 */     this(hostAndPort, null);
/*     */   }
/*     */   
/*     */   public DefaultJedisSocketFactory(JedisClientConfig config) {
/*  39 */     this(null, config);
/*     */   }
/*     */   
/*     */   public DefaultJedisSocketFactory(HostAndPort hostAndPort, JedisClientConfig config) {
/*  43 */     if (hostAndPort != null) {
/*  44 */       this.hostAndPort = hostAndPort;
/*     */     }
/*  46 */     if (config != null) {
/*  47 */       this.connectionTimeout = config.getConnectionTimeoutMillis();
/*  48 */       this.socketTimeout = config.getSocketTimeoutMillis();
/*  49 */       this.ssl = config.isSsl();
/*  50 */       this.sslSocketFactory = config.getSslSocketFactory();
/*  51 */       this.sslParameters = config.getSslParameters();
/*  52 */       this.hostnameVerifier = config.getHostnameVerifier();
/*  53 */       this.hostAndPortMapper = config.getHostAndPortMapper();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Socket connectToFirstSuccessfulHost(HostAndPort hostAndPort) throws Exception {
/*  58 */     List<InetAddress> hosts = Arrays.asList(InetAddress.getAllByName(hostAndPort.getHost()));
/*  59 */     if (hosts.size() > 1) {
/*  60 */       Collections.shuffle(hosts);
/*     */     }
/*     */     
/*  63 */     JedisConnectionException jce = new JedisConnectionException("Failed to connect to any host resolved for DNS name.");
/*  64 */     for (InetAddress host : hosts) {
/*     */       try {
/*  66 */         Socket socket = new Socket();
/*     */         
/*  68 */         socket.setReuseAddress(true);
/*  69 */         socket.setKeepAlive(true);
/*  70 */         socket.setTcpNoDelay(true);
/*  71 */         socket.setSoLinger(true, 0);
/*     */         
/*  73 */         socket.connect(new InetSocketAddress(host.getHostAddress(), hostAndPort.getPort()), this.connectionTimeout);
/*  74 */         return socket;
/*  75 */       } catch (Exception e) {
/*  76 */         jce.addSuppressed(e);
/*     */       } 
/*     */     } 
/*  79 */     throw jce;
/*     */   }
/*     */ 
/*     */   
/*     */   public Socket createSocket() throws JedisConnectionException {
/*  84 */     Socket socket = null;
/*     */     try {
/*  86 */       HostAndPort _hostAndPort = getSocketHostAndPort();
/*  87 */       socket = connectToFirstSuccessfulHost(_hostAndPort);
/*  88 */       socket.setSoTimeout(this.socketTimeout);
/*     */       
/*  90 */       if (this.ssl) {
/*  91 */         SSLSocketFactory _sslSocketFactory = this.sslSocketFactory;
/*  92 */         if (null == _sslSocketFactory) {
/*  93 */           _sslSocketFactory = (SSLSocketFactory)SSLSocketFactory.getDefault();
/*     */         }
/*  95 */         socket = _sslSocketFactory.createSocket(socket, _hostAndPort.getHost(), _hostAndPort.getPort(), true);
/*     */         
/*  97 */         if (null != this.sslParameters) {
/*  98 */           ((SSLSocket)socket).setSSLParameters(this.sslParameters);
/*     */         }
/*     */         
/* 101 */         if (null != this.hostnameVerifier && 
/* 102 */           !this.hostnameVerifier.verify(_hostAndPort.getHost(), ((SSLSocket)socket).getSession())) {
/* 103 */           String message = String.format("The connection to '%s' failed ssl/tls hostname verification.", new Object[] { _hostAndPort
/* 104 */                 .getHost() });
/* 105 */           throw new JedisConnectionException(message);
/*     */         } 
/*     */       } 
/*     */       
/* 109 */       return socket;
/*     */     }
/* 111 */     catch (Exception ex) {
/* 112 */       IOUtils.closeQuietly(socket);
/* 113 */       if (ex instanceof JedisConnectionException) {
/* 114 */         throw (JedisConnectionException)ex;
/*     */       }
/* 116 */       throw new JedisConnectionException("Failed to create socket.", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateHostAndPort(HostAndPort hostAndPort) {
/* 122 */     this.hostAndPort = hostAndPort;
/*     */   }
/*     */   
/*     */   public HostAndPort getHostAndPort() {
/* 126 */     return this.hostAndPort;
/*     */   }
/*     */   
/*     */   protected HostAndPort getSocketHostAndPort() {
/* 130 */     HostAndPortMapper mapper = this.hostAndPortMapper;
/* 131 */     HostAndPort hap = this.hostAndPort;
/* 132 */     if (mapper != null) {
/* 133 */       HostAndPort mapped = mapper.getHostAndPort(hap);
/* 134 */       if (mapped != null) {
/* 135 */         return mapped;
/*     */       }
/*     */     } 
/* 138 */     return hap;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 143 */     return "DefaultJedisSocketFactory{" + this.hostAndPort.toString() + "}";
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\DefaultJedisSocketFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */