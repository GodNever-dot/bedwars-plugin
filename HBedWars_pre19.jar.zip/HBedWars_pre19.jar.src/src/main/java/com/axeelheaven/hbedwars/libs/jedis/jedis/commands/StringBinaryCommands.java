package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.BitCountOption;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.BitOP;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.BitPosParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GetExParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.LCSParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.SetParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.StrAlgoLCSParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LCSMatchResult;
import java.util.List;

public interface StringBinaryCommands {
  String set(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  String set(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, SetParams paramSetParams);
  
  byte[] get(byte[] paramArrayOfbyte);
  
  byte[] getDel(byte[] paramArrayOfbyte);
  
  byte[] getEx(byte[] paramArrayOfbyte, GetExParams paramGetExParams);
  
  boolean setbit(byte[] paramArrayOfbyte, long paramLong, boolean paramBoolean);
  
  boolean getbit(byte[] paramArrayOfbyte, long paramLong);
  
  long setrange(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2);
  
  byte[] getrange(byte[] paramArrayOfbyte, long paramLong1, long paramLong2);
  
  byte[] getSet(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  long setnx(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  String setex(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2);
  
  String psetex(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2);
  
  List<byte[]> mget(byte[]... paramVarArgs);
  
  String mset(byte[]... paramVarArgs);
  
  long msetnx(byte[]... paramVarArgs);
  
  long incr(byte[] paramArrayOfbyte);
  
  long incrBy(byte[] paramArrayOfbyte, long paramLong);
  
  double incrByFloat(byte[] paramArrayOfbyte, double paramDouble);
  
  long decr(byte[] paramArrayOfbyte);
  
  long decrBy(byte[] paramArrayOfbyte, long paramLong);
  
  long append(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  byte[] substr(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  long strlen(byte[] paramArrayOfbyte);
  
  long bitcount(byte[] paramArrayOfbyte);
  
  long bitcount(byte[] paramArrayOfbyte, long paramLong1, long paramLong2);
  
  long bitcount(byte[] paramArrayOfbyte, long paramLong1, long paramLong2, BitCountOption paramBitCountOption);
  
  long bitpos(byte[] paramArrayOfbyte, boolean paramBoolean);
  
  long bitpos(byte[] paramArrayOfbyte, boolean paramBoolean, BitPosParams paramBitPosParams);
  
  List<Long> bitfield(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  List<Long> bitfieldReadonly(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  long bitop(BitOP paramBitOP, byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  @Deprecated
  LCSMatchResult strAlgoLCSKeys(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, StrAlgoLCSParams paramStrAlgoLCSParams);
  
  LCSMatchResult lcs(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, LCSParams paramLCSParams);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\StringBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */