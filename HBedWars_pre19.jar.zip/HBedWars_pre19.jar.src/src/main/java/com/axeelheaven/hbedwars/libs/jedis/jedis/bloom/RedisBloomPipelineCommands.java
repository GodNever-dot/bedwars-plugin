package com.axeelheaven.hbedwars.libs.jedis.jedis.bloom;

public interface RedisBloomPipelineCommands extends BloomFilterPipelineCommands, CuckooFilterPipelineCommands, CountMinSketchPipelineCommands, TopKFilterPipelineCommands {}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\bloom\RedisBloomPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */