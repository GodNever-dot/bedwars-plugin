package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ClusterFailoverOption;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ClusterResetType;
import java.util.List;
import java.util.Map;

public interface ClusterCommands {
  String asking();
  
  String readonly();
  
  String readwrite();
  
  String clusterNodes();
  
  String clusterReplicas(String paramString);
  
  String clusterMeet(String paramString, int paramInt);
  
  String clusterAddSlots(int... paramVarArgs);
  
  String clusterDelSlots(int... paramVarArgs);
  
  String clusterInfo();
  
  List<String> clusterGetKeysInSlot(int paramInt1, int paramInt2);
  
  List<byte[]> clusterGetKeysInSlotBinary(int paramInt1, int paramInt2);
  
  String clusterSetSlotNode(int paramInt, String paramString);
  
  String clusterSetSlotMigrating(int paramInt, String paramString);
  
  String clusterSetSlotImporting(int paramInt, String paramString);
  
  String clusterSetSlotStable(int paramInt);
  
  String clusterForget(String paramString);
  
  String clusterFlushSlots();
  
  long clusterKeySlot(String paramString);
  
  long clusterCountFailureReports(String paramString);
  
  long clusterCountKeysInSlot(int paramInt);
  
  String clusterSaveConfig();
  
  String clusterSetConfigEpoch(long paramLong);
  
  String clusterBumpEpoch();
  
  String clusterReplicate(String paramString);
  
  @Deprecated
  List<String> clusterSlaves(String paramString);
  
  String clusterFailover();
  
  String clusterFailover(ClusterFailoverOption paramClusterFailoverOption);
  
  List<Object> clusterSlots();
  
  String clusterReset();
  
  String clusterReset(ClusterResetType paramClusterResetType);
  
  String clusterMyId();
  
  List<Map<String, Object>> clusterLinks();
  
  String clusterAddSlotsRange(int... paramVarArgs);
  
  String clusterDelSlotsRange(int... paramVarArgs);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\ClusterCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */