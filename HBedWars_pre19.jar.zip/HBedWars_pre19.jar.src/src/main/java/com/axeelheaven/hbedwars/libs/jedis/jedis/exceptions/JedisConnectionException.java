/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ public class JedisConnectionException
/*    */   extends JedisException {
/*    */   private static final long serialVersionUID = 3878126572474819403L;
/*    */   
/*    */   public JedisConnectionException(String message) {
/*  8 */     super(message);
/*    */   }
/*    */   
/*    */   public JedisConnectionException(Throwable cause) {
/* 12 */     super(cause);
/*    */   }
/*    */   
/*    */   public JedisConnectionException(String message, Throwable cause) {
/* 16 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\JedisConnectionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */