/*      */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ExpiryOption;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.GeoUnit;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ListDirection;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.SortedSetOption;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.bloom.RedisBloomProtocol;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.commands.ProtocolCommand;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.json.JsonProtocol;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.json.Path;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.json.Path2;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoRadiusParam;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoSearchParam;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.IParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.MigrateParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ScanParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.SortingParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.StrAlgoLCSParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ZAddParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ZParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ZRangeParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.GeoRadiusResponse;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LCSMatchResult;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.ScanResult;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamEntry;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.Tuple;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.search.Query;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.search.Schema;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.search.SearchProtocol;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.timeseries.TSElement;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.timeseries.TSKeyedElements;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.timeseries.TimeSeriesProtocol;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.KeyValue;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ public class CommandObjects {
/*      */   protected CommandArguments commandArguments(ProtocolCommand command) {
/*   39 */     return new CommandArguments(command);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Boolean> exists(String key) {
/*   44 */     return new CommandObject<>(commandArguments(Protocol.Command.EXISTS).key(key), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> exists(String... keys) {
/*   48 */     return new CommandObject<>(commandArguments(Protocol.Command.EXISTS).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> exists(byte[] key) {
/*   52 */     return new CommandObject<>(commandArguments(Protocol.Command.EXISTS).key(key), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> exists(byte[]... keys) {
/*   56 */     return new CommandObject<>(commandArguments(Protocol.Command.EXISTS).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> persist(String key) {
/*   60 */     return new CommandObject<>(commandArguments(Protocol.Command.PERSIST).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> persist(byte[] key) {
/*   64 */     return new CommandObject<>(commandArguments(Protocol.Command.PERSIST).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> type(String key) {
/*   68 */     return new CommandObject<>(commandArguments(Protocol.Command.TYPE).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> type(byte[] key) {
/*   72 */     return new CommandObject<>(commandArguments(Protocol.Command.TYPE).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> dump(String key) {
/*   76 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.DUMP).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> dump(byte[] key) {
/*   80 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.DUMP).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> restore(String key, long ttl, byte[] serializedValue) {
/*   84 */     return new CommandObject<>(commandArguments(Protocol.Command.RESTORE).key(key).add(Long.valueOf(ttl))
/*   85 */         .add(serializedValue), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> restore(String key, long ttl, byte[] serializedValue, RestoreParams params) {
/*   89 */     return new CommandObject<>(commandArguments(Protocol.Command.RESTORE).key(key).add(Long.valueOf(ttl))
/*   90 */         .add(serializedValue).addParams((IParams)params), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> restore(byte[] key, long ttl, byte[] serializedValue) {
/*   94 */     return new CommandObject<>(commandArguments(Protocol.Command.RESTORE).key(key).add(Long.valueOf(ttl))
/*   95 */         .add(serializedValue), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> restore(byte[] key, long ttl, byte[] serializedValue, RestoreParams params) {
/*   99 */     return new CommandObject<>(commandArguments(Protocol.Command.RESTORE).key(key).add(Long.valueOf(ttl))
/*  100 */         .add(serializedValue).addParams((IParams)params), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> expire(String key, long seconds) {
/*  104 */     return new CommandObject<>(commandArguments(Protocol.Command.EXPIRE).key(key).add(Long.valueOf(seconds)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> expire(byte[] key, long seconds) {
/*  108 */     return new CommandObject<>(commandArguments(Protocol.Command.EXPIRE).key(key).add(Long.valueOf(seconds)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> expire(String key, long seconds, ExpiryOption expiryOption) {
/*  112 */     return new CommandObject<>(commandArguments(Protocol.Command.EXPIRE).key(key).add(Long.valueOf(seconds)).add(expiryOption), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> expire(byte[] key, long seconds, ExpiryOption expiryOption) {
/*  117 */     return new CommandObject<>(commandArguments(Protocol.Command.EXPIRE).key(key).add(Long.valueOf(seconds)).add(expiryOption), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> pexpire(String key, long milliseconds) {
/*  122 */     return new CommandObject<>(commandArguments(Protocol.Command.PEXPIRE).key(key).add(Long.valueOf(milliseconds)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pexpire(byte[] key, long milliseconds) {
/*  126 */     return new CommandObject<>(commandArguments(Protocol.Command.PEXPIRE).key(key).add(Long.valueOf(milliseconds)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pexpire(String key, long milliseconds, ExpiryOption expiryOption) {
/*  130 */     return new CommandObject<>(commandArguments(Protocol.Command.PEXPIRE).key(key).add(Long.valueOf(milliseconds)).add(expiryOption), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> pexpire(byte[] key, long milliseconds, ExpiryOption expiryOption) {
/*  135 */     return new CommandObject<>(commandArguments(Protocol.Command.PEXPIRE).key(key).add(Long.valueOf(milliseconds)).add(expiryOption), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> expireTime(String key) {
/*  140 */     return new CommandObject<>(commandArguments(Protocol.Command.EXPIRETIME).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> expireTime(byte[] key) {
/*  144 */     return new CommandObject<>(commandArguments(Protocol.Command.EXPIRETIME).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pexpireTime(String key) {
/*  148 */     return new CommandObject<>(commandArguments(Protocol.Command.PEXPIRETIME).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pexpireTime(byte[] key) {
/*  152 */     return new CommandObject<>(commandArguments(Protocol.Command.PEXPIRETIME).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> expireAt(String key, long unixTime) {
/*  156 */     return new CommandObject<>(commandArguments(Protocol.Command.EXPIREAT).key(key).add(Long.valueOf(unixTime)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> expireAt(byte[] key, long unixTime) {
/*  160 */     return new CommandObject<>(commandArguments(Protocol.Command.EXPIREAT).key(key).add(Long.valueOf(unixTime)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> expireAt(String key, long unixTime, ExpiryOption expiryOption) {
/*  164 */     return new CommandObject<>(commandArguments(Protocol.Command.EXPIREAT).key(key).add(Long.valueOf(unixTime)).add(expiryOption), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> expireAt(byte[] key, long unixTime, ExpiryOption expiryOption) {
/*  168 */     return new CommandObject<>(commandArguments(Protocol.Command.EXPIREAT).key(key).add(Long.valueOf(unixTime)).add(expiryOption), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pexpireAt(String key, long millisecondsTimestamp) {
/*  172 */     return new CommandObject<>(commandArguments(Protocol.Command.PEXPIREAT).key(key).add(Long.valueOf(millisecondsTimestamp)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pexpireAt(byte[] key, long millisecondsTimestamp) {
/*  176 */     return new CommandObject<>(commandArguments(Protocol.Command.PEXPIREAT).key(key).add(Long.valueOf(millisecondsTimestamp)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pexpireAt(String key, long millisecondsTimestamp, ExpiryOption expiryOption) {
/*  180 */     return new CommandObject<>(commandArguments(Protocol.Command.PEXPIREAT).key(key).add(Long.valueOf(millisecondsTimestamp)).add(expiryOption), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> pexpireAt(byte[] key, long millisecondsTimestamp, ExpiryOption expiryOption) {
/*  185 */     return new CommandObject<>(commandArguments(Protocol.Command.PEXPIREAT).key(key).add(Long.valueOf(millisecondsTimestamp)).add(expiryOption), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> ttl(String key) {
/*  190 */     return new CommandObject<>(commandArguments(Protocol.Command.TTL).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> ttl(byte[] key) {
/*  194 */     return new CommandObject<>(commandArguments(Protocol.Command.TTL).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pttl(String key) {
/*  198 */     return new CommandObject<>(commandArguments(Protocol.Command.PTTL).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pttl(byte[] key) {
/*  202 */     return new CommandObject<>(commandArguments(Protocol.Command.PTTL).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> touch(String key) {
/*  206 */     return new CommandObject<>(commandArguments(Protocol.Command.TOUCH).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> touch(String... keys) {
/*  210 */     return new CommandObject<>(commandArguments(Protocol.Command.TOUCH).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> touch(byte[] key) {
/*  214 */     return new CommandObject<>(commandArguments(Protocol.Command.TOUCH).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> touch(byte[]... keys) {
/*  218 */     return new CommandObject<>(commandArguments(Protocol.Command.TOUCH).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> sort(String key) {
/*  222 */     return new CommandObject<>(commandArguments(Protocol.Command.SORT).key(key), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> sort(String key, SortingParams sortingParams) {
/*  226 */     return new CommandObject<>(commandArguments(Protocol.Command.SORT).key(key).addParams((IParams)sortingParams), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> sort(byte[] key) {
/*  230 */     return new CommandObject<>(commandArguments(Protocol.Command.SORT).key(key), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> sort(byte[] key, SortingParams sortingParams) {
/*  234 */     return new CommandObject<>(commandArguments(Protocol.Command.SORT).key(key).addParams((IParams)sortingParams), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sort(String key, String dstkey) {
/*  238 */     return new CommandObject<>(commandArguments(Protocol.Command.SORT).key(key)
/*  239 */         .add(Protocol.Keyword.STORE).key(dstkey), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sort(String key, SortingParams sortingParams, String dstkey) {
/*  243 */     return new CommandObject<>(commandArguments(Protocol.Command.SORT).key(key).addParams((IParams)sortingParams)
/*  244 */         .add(Protocol.Keyword.STORE).key(dstkey), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sort(byte[] key, byte[] dstkey) {
/*  248 */     return new CommandObject<>(commandArguments(Protocol.Command.SORT).key(key)
/*  249 */         .add(Protocol.Keyword.STORE).key(dstkey), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sort(byte[] key, SortingParams sortingParams, byte[] dstkey) {
/*  253 */     return new CommandObject<>(commandArguments(Protocol.Command.SORT).key(key).addParams((IParams)sortingParams)
/*  254 */         .add(Protocol.Keyword.STORE).key(dstkey), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> sortReadonly(byte[] key, SortingParams sortingParams) {
/*  258 */     return new CommandObject<>(commandArguments(Protocol.Command.SORT_RO).key(key).addParams((IParams)sortingParams), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<String>> sortReadonly(String key, SortingParams sortingParams) {
/*  263 */     return new CommandObject<>(commandArguments(Protocol.Command.SORT_RO).key(key).addParams((IParams)sortingParams), BuilderFactory.STRING_LIST);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> del(String key) {
/*  268 */     return new CommandObject<>(commandArguments(Protocol.Command.DEL).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> del(String... keys) {
/*  272 */     return new CommandObject<>(commandArguments(Protocol.Command.DEL).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> del(byte[] key) {
/*  276 */     return new CommandObject<>(commandArguments(Protocol.Command.DEL).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> del(byte[]... keys) {
/*  280 */     return new CommandObject<>(commandArguments(Protocol.Command.DEL).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> unlink(String key) {
/*  284 */     return new CommandObject<>(commandArguments(Protocol.Command.UNLINK).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> unlink(String... keys) {
/*  288 */     return new CommandObject<>(commandArguments(Protocol.Command.UNLINK).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> unlink(byte[] key) {
/*  292 */     return new CommandObject<>(commandArguments(Protocol.Command.UNLINK).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> unlink(byte[]... keys) {
/*  296 */     return new CommandObject<>(commandArguments(Protocol.Command.UNLINK).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> copy(String srcKey, String dstKey, boolean replace) {
/*  300 */     CommandArguments args = commandArguments(Protocol.Command.COPY).key(srcKey).key(dstKey);
/*  301 */     if (replace) {
/*  302 */       args.add(Protocol.Keyword.REPLACE);
/*      */     }
/*  304 */     return new CommandObject<>(args, BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> copy(byte[] srcKey, byte[] dstKey, boolean replace) {
/*  308 */     CommandArguments args = commandArguments(Protocol.Command.COPY).key(srcKey).key(dstKey);
/*  309 */     if (replace) {
/*  310 */       args.add(Protocol.Keyword.REPLACE);
/*      */     }
/*  312 */     return new CommandObject<>(args, BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> rename(String oldkey, String newkey) {
/*  316 */     return new CommandObject<>(commandArguments(Protocol.Command.RENAME).key(oldkey).key(newkey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> renamenx(String oldkey, String newkey) {
/*  320 */     return new CommandObject<>(commandArguments(Protocol.Command.RENAMENX).key(oldkey).key(newkey), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> rename(byte[] oldkey, byte[] newkey) {
/*  324 */     return new CommandObject<>(commandArguments(Protocol.Command.RENAME).key(oldkey).key(newkey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> renamenx(byte[] oldkey, byte[] newkey) {
/*  328 */     return new CommandObject<>(commandArguments(Protocol.Command.RENAMENX).key(oldkey).key(newkey), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public CommandObject<Long> dbSize() {
/*  332 */     return new CommandObject<>(commandArguments(Protocol.Command.DBSIZE), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public CommandObject<Set<String>> keys(String pattern) {
/*  336 */     CommandArguments args = commandArguments(Protocol.Command.KEYS).key(pattern);
/*  337 */     return new CommandObject<>(args, BuilderFactory.STRING_SET);
/*      */   }
/*      */   
/*      */   public CommandObject<Set<byte[]>> keys(byte[] pattern) {
/*  341 */     CommandArguments args = commandArguments(Protocol.Command.KEYS).key(pattern);
/*  342 */     return new CommandObject<>(args, BuilderFactory.BINARY_SET);
/*      */   }
/*      */   
/*      */   public CommandObject<ScanResult<String>> scan(String cursor) {
/*  346 */     return new CommandObject<>(commandArguments(Protocol.Command.SCAN).add(cursor), BuilderFactory.SCAN_RESPONSE);
/*      */   }
/*      */   
/*      */   public CommandObject<ScanResult<String>> scan(String cursor, ScanParams params) {
/*  350 */     return new CommandObject<>(commandArguments(Protocol.Command.SCAN).add(cursor).addParams((IParams)params), BuilderFactory.SCAN_RESPONSE);
/*      */   }
/*      */   
/*      */   public CommandObject<ScanResult<String>> scan(String cursor, ScanParams params, String type) {
/*  354 */     return new CommandObject<>(commandArguments(Protocol.Command.SCAN).add(cursor).addParams((IParams)params).add(Protocol.Keyword.TYPE).add(type), BuilderFactory.SCAN_RESPONSE);
/*      */   }
/*      */   
/*      */   public CommandObject<ScanResult<byte[]>> scan(byte[] cursor) {
/*  358 */     return new CommandObject<>(commandArguments(Protocol.Command.SCAN).add(cursor), BuilderFactory.SCAN_BINARY_RESPONSE);
/*      */   }
/*      */   
/*      */   public CommandObject<ScanResult<byte[]>> scan(byte[] cursor, ScanParams params) {
/*  362 */     return new CommandObject<>(commandArguments(Protocol.Command.SCAN).add(cursor).addParams((IParams)params), BuilderFactory.SCAN_BINARY_RESPONSE);
/*      */   }
/*      */   
/*      */   public CommandObject<ScanResult<byte[]>> scan(byte[] cursor, ScanParams params, byte[] type) {
/*  366 */     return new CommandObject<>(commandArguments(Protocol.Command.SCAN).add(cursor).addParams((IParams)params).add(Protocol.Keyword.TYPE).add(type), BuilderFactory.SCAN_BINARY_RESPONSE);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> randomKey() {
/*  370 */     return new CommandObject<>(commandArguments(Protocol.Command.RANDOMKEY), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> randomBinaryKey() {
/*  374 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.RANDOMKEY), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<String> set(String key, String value) {
/*  380 */     return new CommandObject<>(commandArguments(Protocol.Command.SET).key(key).add(value), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> set(String key, String value, SetParams params) {
/*  384 */     return new CommandObject<>(commandArguments(Protocol.Command.SET).key(key).add(value).addParams((IParams)params), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> set(byte[] key, byte[] value) {
/*  388 */     return new CommandObject<>(commandArguments(Protocol.Command.SET).key(key).add(value), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> set(byte[] key, byte[] value, SetParams params) {
/*  392 */     return new CommandObject<>(commandArguments(Protocol.Command.SET).key(key).add(value).addParams((IParams)params), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> get(String key) {
/*  396 */     return new CommandObject<>(commandArguments(Protocol.Command.GET).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> getDel(String key) {
/*  400 */     return new CommandObject<>(commandArguments(Protocol.Command.GETDEL).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> getEx(String key, GetExParams params) {
/*  404 */     return new CommandObject<>(commandArguments(Protocol.Command.GETEX).key(key).addParams((IParams)params), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> get(byte[] key) {
/*  408 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.GET).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> getDel(byte[] key) {
/*  412 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.GETDEL).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> getEx(byte[] key, GetExParams params) {
/*  416 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.GETEX).key(key).addParams((IParams)params), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> getSet(String key, String value) {
/*  420 */     return new CommandObject<>(commandArguments(Protocol.Command.GETSET).key(key).add(value), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> getSet(byte[] key, byte[] value) {
/*  424 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.GETSET).key(key).add(value), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> setnx(String key, String value) {
/*  428 */     return new CommandObject<>(commandArguments(Protocol.Command.SETNX).key(key).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> setex(String key, long seconds, String value) {
/*  432 */     return new CommandObject<>(commandArguments(Protocol.Command.SETEX).key(key).add(Long.valueOf(seconds)).add(value), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> psetex(String key, long milliseconds, String value) {
/*  436 */     return new CommandObject<>(commandArguments(Protocol.Command.PSETEX).key(key).add(Long.valueOf(milliseconds)).add(value), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> setnx(byte[] key, byte[] value) {
/*  440 */     return new CommandObject<>(commandArguments(Protocol.Command.SETNX).key(key).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> setex(byte[] key, long seconds, byte[] value) {
/*  444 */     return new CommandObject<>(commandArguments(Protocol.Command.SETEX).key(key).add(Long.valueOf(seconds)).add(value), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> psetex(byte[] key, long milliseconds, byte[] value) {
/*  448 */     return new CommandObject<>(commandArguments(Protocol.Command.PSETEX).key(key).add(Long.valueOf(milliseconds)).add(value), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> setbit(String key, long offset, boolean value) {
/*  452 */     return new CommandObject<>(commandArguments(Protocol.Command.SETBIT).key(key).add(Long.valueOf(offset)).add(Boolean.valueOf(value)), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> setbit(byte[] key, long offset, boolean value) {
/*  456 */     return new CommandObject<>(commandArguments(Protocol.Command.SETBIT).key(key).add(Long.valueOf(offset)).add(Boolean.valueOf(value)), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> getbit(String key, long offset) {
/*  460 */     return new CommandObject<>(commandArguments(Protocol.Command.GETBIT).key(key).add(Long.valueOf(offset)), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> getbit(byte[] key, long offset) {
/*  464 */     return new CommandObject<>(commandArguments(Protocol.Command.GETBIT).key(key).add(Long.valueOf(offset)), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> setrange(String key, long offset, String value) {
/*  468 */     return new CommandObject<>(commandArguments(Protocol.Command.SETRANGE).key(key).add(Long.valueOf(offset)).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> setrange(byte[] key, long offset, byte[] value) {
/*  472 */     return new CommandObject<>(commandArguments(Protocol.Command.SETRANGE).key(key).add(Long.valueOf(offset)).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> getrange(String key, long startOffset, long endOffset) {
/*  476 */     return new CommandObject<>(commandArguments(Protocol.Command.GETRANGE).key(key).add(Long.valueOf(startOffset)).add(Long.valueOf(endOffset)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> getrange(byte[] key, long startOffset, long endOffset) {
/*  480 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.GETRANGE).key(key).add(Long.valueOf(startOffset)).add(Long.valueOf(endOffset)), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> mget(String... keys) {
/*  484 */     return new CommandObject<>(commandArguments(Protocol.Command.MGET).keys((Object[])keys), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> mget(byte[]... keys) {
/*  488 */     return new CommandObject<>(commandArguments(Protocol.Command.MGET).keys((Object[])keys), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> mset(String... keysvalues) {
/*  492 */     return new CommandObject<>(addFlatKeyValueArgs(commandArguments(Protocol.Command.MSET), keysvalues), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> msetnx(String... keysvalues) {
/*  496 */     return new CommandObject<>(addFlatKeyValueArgs(commandArguments(Protocol.Command.MSETNX), keysvalues), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> mset(byte[]... keysvalues) {
/*  500 */     return new CommandObject<>(addFlatKeyValueArgs(commandArguments(Protocol.Command.MSET), keysvalues), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> msetnx(byte[]... keysvalues) {
/*  504 */     return new CommandObject<>(addFlatKeyValueArgs(commandArguments(Protocol.Command.MSETNX), keysvalues), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> incr(String key) {
/*  508 */     return new CommandObject<>(commandArguments(Protocol.Command.INCR).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> incrBy(String key, long increment) {
/*  512 */     return new CommandObject<>(commandArguments(Protocol.Command.INCRBY).key(key).add(Long.valueOf(increment)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> incrByFloat(String key, double increment) {
/*  516 */     return new CommandObject<>(commandArguments(Protocol.Command.INCRBYFLOAT).key(key).add(Double.valueOf(increment)), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> incr(byte[] key) {
/*  520 */     return new CommandObject<>(commandArguments(Protocol.Command.INCR).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> incrBy(byte[] key, long increment) {
/*  524 */     return new CommandObject<>(commandArguments(Protocol.Command.INCRBY).key(key).add(Long.valueOf(increment)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> incrByFloat(byte[] key, double increment) {
/*  528 */     return new CommandObject<>(commandArguments(Protocol.Command.INCRBYFLOAT).key(key).add(Double.valueOf(increment)), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> decr(String key) {
/*  532 */     return new CommandObject<>(commandArguments(Protocol.Command.DECR).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> decrBy(String key, long decrement) {
/*  536 */     return new CommandObject<>(commandArguments(Protocol.Command.DECRBY).key(key).add(Long.valueOf(decrement)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> decr(byte[] key) {
/*  540 */     return new CommandObject<>(commandArguments(Protocol.Command.DECR).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> decrBy(byte[] key, long decrement) {
/*  544 */     return new CommandObject<>(commandArguments(Protocol.Command.DECRBY).key(key).add(Long.valueOf(decrement)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> append(String key, String value) {
/*  548 */     return new CommandObject<>(commandArguments(Protocol.Command.APPEND).key(key).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> append(byte[] key, byte[] value) {
/*  552 */     return new CommandObject<>(commandArguments(Protocol.Command.APPEND).key(key).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> substr(String key, int start, int end) {
/*  556 */     return new CommandObject<>(commandArguments(Protocol.Command.SUBSTR).key(key).add(Integer.valueOf(start)).add(Integer.valueOf(end)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> substr(byte[] key, int start, int end) {
/*  560 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.SUBSTR).key(key).add(Integer.valueOf(start)).add(Integer.valueOf(end)), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> strlen(String key) {
/*  564 */     return new CommandObject<>(commandArguments(Protocol.Command.STRLEN).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> strlen(byte[] key) {
/*  568 */     return new CommandObject<>(commandArguments(Protocol.Command.STRLEN).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitcount(String key) {
/*  572 */     return new CommandObject<>(commandArguments(Protocol.Command.BITCOUNT).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitcount(String key, long start, long end) {
/*  576 */     return new CommandObject<>(commandArguments(Protocol.Command.BITCOUNT).key(key).add(Long.valueOf(start)).add(Long.valueOf(end)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitcount(String key, long start, long end, BitCountOption option) {
/*  580 */     return new CommandObject<>(commandArguments(Protocol.Command.BITCOUNT).key(key).add(Long.valueOf(start)).add(Long.valueOf(end)).add(option), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitcount(byte[] key) {
/*  584 */     return new CommandObject<>(commandArguments(Protocol.Command.BITCOUNT).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitcount(byte[] key, long start, long end) {
/*  588 */     return new CommandObject<>(commandArguments(Protocol.Command.BITCOUNT).key(key).add(Long.valueOf(start)).add(Long.valueOf(end)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitcount(byte[] key, long start, long end, BitCountOption option) {
/*  592 */     return new CommandObject<>(commandArguments(Protocol.Command.BITCOUNT).key(key).add(Long.valueOf(start)).add(Long.valueOf(end)).add(option), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitpos(String key, boolean value) {
/*  596 */     return new CommandObject<>(commandArguments(Protocol.Command.BITPOS).key(key).add(Integer.valueOf(value ? 1 : 0)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitpos(String key, boolean value, BitPosParams params) {
/*  600 */     return new CommandObject<>(commandArguments(Protocol.Command.BITPOS).key(key).add(Integer.valueOf(value ? 1 : 0)).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitpos(byte[] key, boolean value) {
/*  604 */     return new CommandObject<>(commandArguments(Protocol.Command.BITPOS).key(key).add(Integer.valueOf(value ? 1 : 0)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitpos(byte[] key, boolean value, BitPosParams params) {
/*  608 */     return new CommandObject<>(commandArguments(Protocol.Command.BITPOS).key(key).add(Integer.valueOf(value ? 1 : 0)).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> bitfield(String key, String... arguments) {
/*  612 */     return new CommandObject<>(commandArguments(Protocol.Command.BITFIELD).key(key).addObjects((Object[])arguments), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> bitfieldReadonly(String key, String... arguments) {
/*  616 */     return new CommandObject<>(commandArguments(Protocol.Command.BITFIELD_RO).key(key).addObjects((Object[])arguments), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> bitfield(byte[] key, byte[]... arguments) {
/*  620 */     return new CommandObject<>(commandArguments(Protocol.Command.BITFIELD).key(key).addObjects((Object[])arguments), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> bitfieldReadonly(byte[] key, byte[]... arguments) {
/*  624 */     return new CommandObject<>(commandArguments(Protocol.Command.BITFIELD_RO).key(key).addObjects((Object[])arguments), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitop(BitOP op, String destKey, String... srcKeys) {
/*  628 */     return new CommandObject<>(commandArguments(Protocol.Command.BITOP).add(op).key(destKey).keys((Object[])srcKeys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> bitop(BitOP op, byte[] destKey, byte[]... srcKeys) {
/*  632 */     return new CommandObject<>(commandArguments(Protocol.Command.BITOP).add(op).key(destKey).keys((Object[])srcKeys), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final CommandObject<LCSMatchResult> strAlgoLCSKeys(String keyA, String keyB, StrAlgoLCSParams params) {
/*  641 */     return new CommandObject<>(commandArguments(Protocol.Command.STRALGO).add(Protocol.Keyword.LCS).add(Protocol.Keyword.KEYS)
/*  642 */         .key(keyA).key(keyB).addParams((IParams)params), BuilderFactory.STR_ALGO_LCS_RESULT_BUILDER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final CommandObject<LCSMatchResult> strAlgoLCSKeys(byte[] keyA, byte[] keyB, StrAlgoLCSParams params) {
/*  651 */     return new CommandObject<>(commandArguments(Protocol.Command.STRALGO).add(Protocol.Keyword.LCS).add(Protocol.Keyword.KEYS)
/*  652 */         .key(keyA).key(keyB).addParams((IParams)params), BuilderFactory.STR_ALGO_LCS_RESULT_BUILDER);
/*      */   }
/*      */   
/*      */   public final CommandObject<LCSMatchResult> lcs(String keyA, String keyB, LCSParams params) {
/*  656 */     return new CommandObject<>(commandArguments(Protocol.Command.LCS).key(keyA).key(keyB)
/*  657 */         .addParams((IParams)params), BuilderFactory.STR_ALGO_LCS_RESULT_BUILDER);
/*      */   }
/*      */   
/*      */   public final CommandObject<LCSMatchResult> lcs(byte[] keyA, byte[] keyB, LCSParams params) {
/*  661 */     return new CommandObject<>(commandArguments(Protocol.Command.LCS).key(keyA).key(keyB)
/*  662 */         .addParams((IParams)params), BuilderFactory.STR_ALGO_LCS_RESULT_BUILDER);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> rpush(String key, String... strings) {
/*  668 */     return new CommandObject<>(commandArguments(Protocol.Command.RPUSH).key(key).addObjects((Object[])strings), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> rpush(byte[] key, byte[]... strings) {
/*  672 */     return new CommandObject<>(commandArguments(Protocol.Command.RPUSH).key(key).addObjects((Object[])strings), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> lpush(String key, String... strings) {
/*  676 */     return new CommandObject<>(commandArguments(Protocol.Command.LPUSH).key(key).addObjects((Object[])strings), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> lpush(byte[] key, byte[]... strings) {
/*  680 */     return new CommandObject<>(commandArguments(Protocol.Command.LPUSH).key(key).addObjects((Object[])strings), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> llen(String key) {
/*  684 */     return new CommandObject<>(commandArguments(Protocol.Command.LLEN).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> llen(byte[] key) {
/*  688 */     return new CommandObject<>(commandArguments(Protocol.Command.LLEN).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> lrange(String key, long start, long stop) {
/*  692 */     return new CommandObject<>(commandArguments(Protocol.Command.LRANGE).key(key).add(Long.valueOf(start)).add(Long.valueOf(stop)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> lrange(byte[] key, long start, long stop) {
/*  696 */     return new CommandObject<>(commandArguments(Protocol.Command.LRANGE).key(key).add(Long.valueOf(start)).add(Long.valueOf(stop)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> ltrim(String key, long start, long stop) {
/*  700 */     return new CommandObject<>(commandArguments(Protocol.Command.LTRIM).key(key).add(Long.valueOf(start)).add(Long.valueOf(stop)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> ltrim(byte[] key, long start, long stop) {
/*  704 */     return new CommandObject<>(commandArguments(Protocol.Command.LTRIM).key(key).add(Long.valueOf(start)).add(Long.valueOf(stop)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> lindex(String key, long index) {
/*  708 */     return new CommandObject<>(commandArguments(Protocol.Command.LINDEX).key(key).add(Long.valueOf(index)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> lindex(byte[] key, long index) {
/*  712 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.LINDEX).key(key).add(Long.valueOf(index)), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> lset(String key, long index, String value) {
/*  716 */     return new CommandObject<>(commandArguments(Protocol.Command.LSET).key(key).add(Long.valueOf(index)).add(value), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> lset(byte[] key, long index, byte[] value) {
/*  720 */     return new CommandObject<>(commandArguments(Protocol.Command.LSET).key(key).add(Long.valueOf(index)).add(value), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> lrem(String key, long count, String value) {
/*  724 */     return new CommandObject<>(commandArguments(Protocol.Command.LREM).key(key).add(Long.valueOf(count)).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> lrem(byte[] key, long count, byte[] value) {
/*  728 */     return new CommandObject<>(commandArguments(Protocol.Command.LREM).key(key).add(Long.valueOf(count)).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> lpop(String key) {
/*  732 */     return new CommandObject<>(commandArguments(Protocol.Command.LPOP).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> lpop(String key, int count) {
/*  736 */     return new CommandObject<>(commandArguments(Protocol.Command.LPOP).key(key).add(Integer.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> lpop(byte[] key) {
/*  740 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.LPOP).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> lpop(byte[] key, int count) {
/*  744 */     return new CommandObject<>(commandArguments(Protocol.Command.LPOP).key(key).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> rpop(String key) {
/*  748 */     return new CommandObject<>(commandArguments(Protocol.Command.RPOP).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> rpop(String key, int count) {
/*  752 */     return new CommandObject<>(commandArguments(Protocol.Command.RPOP).key(key).add(Integer.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> rpop(byte[] key) {
/*  756 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.RPOP).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> rpop(byte[] key, int count) {
/*  760 */     return new CommandObject<>(commandArguments(Protocol.Command.RPOP).key(key).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> lpos(String key, String element) {
/*  764 */     return new CommandObject<>(commandArguments(Protocol.Command.LPOS).key(key).add(element), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> lpos(String key, String element, LPosParams params) {
/*  768 */     return new CommandObject<>(commandArguments(Protocol.Command.LPOS).key(key).add(element).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> lpos(String key, String element, LPosParams params, long count) {
/*  772 */     return new CommandObject<>(commandArguments(Protocol.Command.LPOS).key(key).add(element)
/*  773 */         .addParams((IParams)params).add(Protocol.Keyword.COUNT).add(Long.valueOf(count)), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> lpos(byte[] key, byte[] element) {
/*  777 */     return new CommandObject<>(commandArguments(Protocol.Command.LPOS).key(key).add(element), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> lpos(byte[] key, byte[] element, LPosParams params) {
/*  781 */     return new CommandObject<>(commandArguments(Protocol.Command.LPOS).key(key).add(element).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> lpos(byte[] key, byte[] element, LPosParams params, long count) {
/*  785 */     return new CommandObject<>(commandArguments(Protocol.Command.LPOS).key(key).add(element)
/*  786 */         .addParams((IParams)params).add(Protocol.Keyword.COUNT).add(Long.valueOf(count)), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> linsert(String key, ListPosition where, String pivot, String value) {
/*  790 */     return new CommandObject<>(commandArguments(Protocol.Command.LINSERT).key(key).add(where)
/*  791 */         .add(pivot).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> linsert(byte[] key, ListPosition where, byte[] pivot, byte[] value) {
/*  795 */     return new CommandObject<>(commandArguments(Protocol.Command.LINSERT).key(key).add(where)
/*  796 */         .add(pivot).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> lpushx(String key, String... strings) {
/*  800 */     return new CommandObject<>(commandArguments(Protocol.Command.LPUSHX).key(key).addObjects((Object[])strings), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> rpushx(String key, String... strings) {
/*  804 */     return new CommandObject<>(commandArguments(Protocol.Command.RPUSHX).key(key).addObjects((Object[])strings), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> lpushx(byte[] key, byte[]... args) {
/*  808 */     return new CommandObject<>(commandArguments(Protocol.Command.LPUSHX).key(key).addObjects((Object[])args), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> rpushx(byte[] key, byte[]... args) {
/*  812 */     return new CommandObject<>(commandArguments(Protocol.Command.RPUSHX).key(key).addObjects((Object[])args), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> blpop(int timeout, String key) {
/*  816 */     return new CommandObject<>(commandArguments(Protocol.Command.BLPOP).blocking().key(key).add(Integer.valueOf(timeout)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> blpop(int timeout, String... keys) {
/*  820 */     return new CommandObject<>(commandArguments(Protocol.Command.BLPOP).blocking().keys((Object[])keys).add(Integer.valueOf(timeout)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyedListElement> blpop(double timeout, String key) {
/*  824 */     return new CommandObject<>(commandArguments(Protocol.Command.BLPOP).blocking().key(key).add(Double.valueOf(timeout)), BuilderFactory.KEYED_LIST_ELEMENT);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyedListElement> blpop(double timeout, String... keys) {
/*  828 */     return new CommandObject<>(commandArguments(Protocol.Command.BLPOP).blocking().keys((Object[])keys).add(Double.valueOf(timeout)), BuilderFactory.KEYED_LIST_ELEMENT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> blpop(int timeout, byte[]... keys) {
/*  832 */     return new CommandObject<>(commandArguments(Protocol.Command.BLPOP).blocking().keys((Object[])keys).add(Integer.valueOf(timeout)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> blpop(double timeout, byte[]... keys) {
/*  836 */     return new CommandObject<>(commandArguments(Protocol.Command.BLPOP).blocking().keys((Object[])keys).add(Double.valueOf(timeout)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> brpop(int timeout, String key) {
/*  840 */     return new CommandObject<>(commandArguments(Protocol.Command.BRPOP).blocking().key(key).add(Integer.valueOf(timeout)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> brpop(int timeout, String... keys) {
/*  844 */     return new CommandObject<>(commandArguments(Protocol.Command.BRPOP).blocking().keys((Object[])keys).add(Integer.valueOf(timeout)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyedListElement> brpop(double timeout, String key) {
/*  848 */     return new CommandObject<>(commandArguments(Protocol.Command.BRPOP).blocking().key(key).add(Double.valueOf(timeout)), BuilderFactory.KEYED_LIST_ELEMENT);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyedListElement> brpop(double timeout, String... keys) {
/*  852 */     return new CommandObject<>(commandArguments(Protocol.Command.BRPOP).blocking().keys((Object[])keys).add(Double.valueOf(timeout)), BuilderFactory.KEYED_LIST_ELEMENT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> brpop(int timeout, byte[]... keys) {
/*  856 */     return new CommandObject<>(commandArguments(Protocol.Command.BRPOP).blocking().keys((Object[])keys).add(Integer.valueOf(timeout)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> brpop(double timeout, byte[]... keys) {
/*  860 */     return new CommandObject<>(commandArguments(Protocol.Command.BRPOP).blocking().keys((Object[])keys).add(Double.valueOf(timeout)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> rpoplpush(String srckey, String dstkey) {
/*  864 */     return new CommandObject<>(commandArguments(Protocol.Command.RPOPLPUSH).key(srckey).key(dstkey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> brpoplpush(String source, String destination, int timeout) {
/*  868 */     return new CommandObject<>(commandArguments(Protocol.Command.BRPOPLPUSH).blocking().key(source)
/*  869 */         .key(destination).add(Integer.valueOf(timeout)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> rpoplpush(byte[] srckey, byte[] dstkey) {
/*  873 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.RPOPLPUSH).key(srckey).key(dstkey), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> brpoplpush(byte[] source, byte[] destination, int timeout) {
/*  877 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.BRPOPLPUSH).blocking().key(source)
/*  878 */         .key(destination).add(Integer.valueOf(timeout)), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> lmove(String srcKey, String dstKey, ListDirection from, ListDirection to) {
/*  882 */     return new CommandObject<>(commandArguments(Protocol.Command.LMOVE).key(srcKey).key(dstKey)
/*  883 */         .add(from).add(to), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> blmove(String srcKey, String dstKey, ListDirection from, ListDirection to, double timeout) {
/*  887 */     return new CommandObject<>(commandArguments(Protocol.Command.BLMOVE).blocking().key(srcKey)
/*  888 */         .key(dstKey).add(from).add(to).add(Double.valueOf(timeout)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> lmove(byte[] srcKey, byte[] dstKey, ListDirection from, ListDirection to) {
/*  892 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.LMOVE).key(srcKey).key(dstKey)
/*  893 */         .add(from).add(to), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> blmove(byte[] srcKey, byte[] dstKey, ListDirection from, ListDirection to, double timeout) {
/*  897 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.BLMOVE).blocking().key(srcKey)
/*  898 */         .key(dstKey).add(from).add(to).add(Double.valueOf(timeout)), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<String, List<String>>> lmpop(ListDirection direction, String... keys) {
/*  902 */     return new CommandObject<>(commandArguments(Protocol.Command.LMPOP).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/*  903 */         .add(direction), BuilderFactory.KEYED_STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<String, List<String>>> lmpop(ListDirection direction, int count, String... keys) {
/*  907 */     return new CommandObject<>(commandArguments(Protocol.Command.LMPOP).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/*  908 */         .add(direction).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.KEYED_STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<String, List<String>>> blmpop(long timeout, ListDirection direction, String... keys) {
/*  912 */     return new CommandObject<>(commandArguments(Protocol.Command.BLMPOP).blocking().add(Long.valueOf(timeout))
/*  913 */         .add(Integer.valueOf(keys.length)).keys((Object[])keys).add(direction), BuilderFactory.KEYED_STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<String, List<String>>> blmpop(long timeout, ListDirection direction, int count, String... keys) {
/*  917 */     return new CommandObject<>(commandArguments(Protocol.Command.BLMPOP).blocking().add(Long.valueOf(timeout))
/*  918 */         .add(Integer.valueOf(keys.length)).keys((Object[])keys).add(direction).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.KEYED_STRING_LIST);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<KeyValue<byte[], List<byte[]>>> lmpop(ListDirection direction, byte[]... keys) {
/*  923 */     return new CommandObject<>(commandArguments(Protocol.Command.LMPOP).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/*  924 */         .add(direction), BuilderFactory.KEYED_BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<byte[], List<byte[]>>> lmpop(ListDirection direction, int count, byte[]... keys) {
/*  928 */     return new CommandObject<>(commandArguments(Protocol.Command.LMPOP).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/*  929 */         .add(direction).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.KEYED_BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<byte[], List<byte[]>>> blmpop(long timeout, ListDirection direction, byte[]... keys) {
/*  933 */     return new CommandObject<>(commandArguments(Protocol.Command.BLMPOP).blocking().add(Long.valueOf(timeout))
/*  934 */         .add(Integer.valueOf(keys.length)).keys((Object[])keys).add(direction), BuilderFactory.KEYED_BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<byte[], List<byte[]>>> blmpop(long timeout, ListDirection direction, int count, byte[]... keys) {
/*  938 */     return new CommandObject<>(commandArguments(Protocol.Command.BLMPOP).blocking().add(Long.valueOf(timeout))
/*  939 */         .add(Integer.valueOf(keys.length)).keys((Object[])keys).add(direction).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.KEYED_BINARY_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> hset(String key, String field, String value) {
/*  946 */     return new CommandObject<>(commandArguments(Protocol.Command.HSET).key(key).add(field).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hset(String key, Map<String, String> hash) {
/*  950 */     return new CommandObject<>(addFlatMapArgs(commandArguments(Protocol.Command.HSET).key(key), hash), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> hget(String key, String field) {
/*  954 */     return new CommandObject<>(commandArguments(Protocol.Command.HGET).key(key).add(field), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hsetnx(String key, String field, String value) {
/*  958 */     return new CommandObject<>(commandArguments(Protocol.Command.HSETNX).key(key).add(field).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> hmset(String key, Map<String, String> hash) {
/*  962 */     return new CommandObject<>(addFlatMapArgs(commandArguments(Protocol.Command.HMSET).key(key), hash), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> hmget(String key, String... fields) {
/*  966 */     return new CommandObject<>(commandArguments(Protocol.Command.HMGET).key(key).addObjects((Object[])fields), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hset(byte[] key, byte[] field, byte[] value) {
/*  970 */     return new CommandObject<>(commandArguments(Protocol.Command.HSET).key(key).add(field).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hset(byte[] key, Map<byte[], byte[]> hash) {
/*  974 */     return new CommandObject<>(addFlatMapArgs(commandArguments(Protocol.Command.HSET).key(key), hash), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> hget(byte[] key, byte[] field) {
/*  978 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.HGET).key(key).add(field), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hsetnx(byte[] key, byte[] field, byte[] value) {
/*  982 */     return new CommandObject<>(commandArguments(Protocol.Command.HSETNX).key(key).add(field).add(value), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> hmset(byte[] key, Map<byte[], byte[]> hash) {
/*  986 */     return new CommandObject<>(addFlatMapArgs(commandArguments(Protocol.Command.HMSET).key(key), hash), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> hmget(byte[] key, byte[]... fields) {
/*  990 */     return new CommandObject<>(commandArguments(Protocol.Command.HMGET).key(key).addObjects((Object[])fields), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hincrBy(String key, String field, long value) {
/*  994 */     return new CommandObject<>(commandArguments(Protocol.Command.HINCRBY).key(key).add(field).add(Long.valueOf(value)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> hincrByFloat(String key, String field, double value) {
/*  998 */     return new CommandObject<>(commandArguments(Protocol.Command.HINCRBYFLOAT).key(key).add(field).add(Double.valueOf(value)), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> hexists(String key, String field) {
/* 1002 */     return new CommandObject<>(commandArguments(Protocol.Command.HEXISTS).key(key).add(field), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hdel(String key, String... field) {
/* 1006 */     return new CommandObject<>(commandArguments(Protocol.Command.HDEL).key(key).addObjects((Object[])field), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hlen(String key) {
/* 1010 */     return new CommandObject<>(commandArguments(Protocol.Command.HLEN).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hincrBy(byte[] key, byte[] field, long value) {
/* 1014 */     return new CommandObject<>(commandArguments(Protocol.Command.HINCRBY).key(key).add(field).add(Long.valueOf(value)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> hincrByFloat(byte[] key, byte[] field, double value) {
/* 1018 */     return new CommandObject<>(commandArguments(Protocol.Command.HINCRBYFLOAT).key(key).add(field).add(Double.valueOf(value)), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> hexists(byte[] key, byte[] field) {
/* 1022 */     return new CommandObject<>(commandArguments(Protocol.Command.HEXISTS).key(key).add(field), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hdel(byte[] key, byte[]... field) {
/* 1026 */     return new CommandObject<>(commandArguments(Protocol.Command.HDEL).key(key).addObjects((Object[])field), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hlen(byte[] key) {
/* 1030 */     return new CommandObject<>(commandArguments(Protocol.Command.HLEN).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<String>> hkeys(String key) {
/* 1034 */     return new CommandObject<>(commandArguments(Protocol.Command.HKEYS).key(key), BuilderFactory.STRING_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> hvals(String key) {
/* 1038 */     return new CommandObject<>(commandArguments(Protocol.Command.HVALS).key(key), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<byte[]>> hkeys(byte[] key) {
/* 1042 */     return new CommandObject<>(commandArguments(Protocol.Command.HKEYS).key(key), BuilderFactory.BINARY_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> hvals(byte[] key) {
/* 1046 */     return new CommandObject<>(commandArguments(Protocol.Command.HVALS).key(key), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Map<String, String>> hgetAll(String key) {
/* 1050 */     return new CommandObject<>(commandArguments(Protocol.Command.HGETALL).key(key), BuilderFactory.STRING_MAP);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> hrandfield(String key) {
/* 1054 */     return new CommandObject<>(commandArguments(Protocol.Command.HRANDFIELD).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> hrandfield(String key, long count) {
/* 1058 */     return new CommandObject<>(commandArguments(Protocol.Command.HRANDFIELD).key(key).add(Long.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Map<String, String>> hrandfieldWithValues(String key, long count) {
/* 1062 */     return new CommandObject<>(commandArguments(Protocol.Command.HRANDFIELD).key(key).add(Long.valueOf(count)).add(Protocol.Keyword.WITHVALUES), BuilderFactory.STRING_MAP);
/*      */   }
/*      */   
/*      */   public final CommandObject<Map<byte[], byte[]>> hgetAll(byte[] key) {
/* 1066 */     return new CommandObject<>(commandArguments(Protocol.Command.HGETALL).key(key), BuilderFactory.BINARY_MAP);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> hrandfield(byte[] key) {
/* 1070 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.HRANDFIELD).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> hrandfield(byte[] key, long count) {
/* 1074 */     return new CommandObject<>(commandArguments(Protocol.Command.HRANDFIELD).key(key).add(Long.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Map<byte[], byte[]>> hrandfieldWithValues(byte[] key, long count) {
/* 1078 */     return new CommandObject<>(commandArguments(Protocol.Command.HRANDFIELD).key(key).add(Long.valueOf(count)).add(Protocol.Keyword.WITHVALUES), BuilderFactory.BINARY_MAP);
/*      */   }
/*      */   
/*      */   public final CommandObject<ScanResult<Map.Entry<String, String>>> hscan(String key, String cursor, ScanParams params) {
/* 1082 */     return new CommandObject<>(commandArguments(Protocol.Command.HSCAN).key(key).add(cursor).addParams((IParams)params), BuilderFactory.HSCAN_RESPONSE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hstrlen(String key, String field) {
/* 1086 */     return new CommandObject<>(commandArguments(Protocol.Command.HSTRLEN).key(key).add(field), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<ScanResult<Map.Entry<byte[], byte[]>>> hscan(byte[] key, byte[] cursor, ScanParams params) {
/* 1090 */     return new CommandObject<>(commandArguments(Protocol.Command.HSCAN).key(key).add(cursor).addParams((IParams)params), BuilderFactory.HSCAN_BINARY_RESPONSE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> hstrlen(byte[] key, byte[] field) {
/* 1094 */     return new CommandObject<>(commandArguments(Protocol.Command.HSTRLEN).key(key).add(field), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> sadd(String key, String... members) {
/* 1100 */     return new CommandObject<>(commandArguments(Protocol.Command.SADD).key(key).addObjects((Object[])members), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sadd(byte[] key, byte[]... members) {
/* 1104 */     return new CommandObject<>(commandArguments(Protocol.Command.SADD).key(key).addObjects((Object[])members), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<String>> smembers(String key) {
/* 1108 */     return new CommandObject<>(commandArguments(Protocol.Command.SMEMBERS).key(key), BuilderFactory.STRING_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<byte[]>> smembers(byte[] key) {
/* 1112 */     return new CommandObject<>(commandArguments(Protocol.Command.SMEMBERS).key(key), BuilderFactory.BINARY_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> srem(String key, String... members) {
/* 1116 */     return new CommandObject<>(commandArguments(Protocol.Command.SREM).key(key).addObjects((Object[])members), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> srem(byte[] key, byte[]... members) {
/* 1120 */     return new CommandObject<>(commandArguments(Protocol.Command.SREM).key(key).addObjects((Object[])members), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> spop(String key) {
/* 1124 */     return new CommandObject<>(commandArguments(Protocol.Command.SPOP).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> spop(byte[] key) {
/* 1128 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.SPOP).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<String>> spop(String key, long count) {
/* 1132 */     return new CommandObject<>(commandArguments(Protocol.Command.SPOP).key(key).add(Long.valueOf(count)), BuilderFactory.STRING_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<byte[]>> spop(byte[] key, long count) {
/* 1136 */     return new CommandObject<>(commandArguments(Protocol.Command.SPOP).key(key).add(Long.valueOf(count)), BuilderFactory.BINARY_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> scard(String key) {
/* 1140 */     return new CommandObject<>(commandArguments(Protocol.Command.SCARD).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> scard(byte[] key) {
/* 1144 */     return new CommandObject<>(commandArguments(Protocol.Command.SCARD).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> sismember(String key, String member) {
/* 1148 */     return new CommandObject<>(commandArguments(Protocol.Command.SISMEMBER).key(key).add(member), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> sismember(byte[] key, byte[] member) {
/* 1152 */     return new CommandObject<>(commandArguments(Protocol.Command.SISMEMBER).key(key).add(member), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> smismember(String key, String... members) {
/* 1156 */     return new CommandObject<>(commandArguments(Protocol.Command.SMISMEMBER).key(key).addObjects((Object[])members), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> smismember(byte[] key, byte[]... members) {
/* 1160 */     return new CommandObject<>(commandArguments(Protocol.Command.SMISMEMBER).key(key).addObjects((Object[])members), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> srandmember(String key) {
/* 1164 */     return new CommandObject<>(commandArguments(Protocol.Command.SRANDMEMBER).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> srandmember(byte[] key) {
/* 1168 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.SRANDMEMBER).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> srandmember(String key, int count) {
/* 1172 */     return new CommandObject<>(commandArguments(Protocol.Command.SRANDMEMBER).key(key).add(Integer.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> srandmember(byte[] key, int count) {
/* 1176 */     return new CommandObject<>(commandArguments(Protocol.Command.SRANDMEMBER).key(key).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<ScanResult<String>> sscan(String key, String cursor, ScanParams params) {
/* 1180 */     return new CommandObject<>(commandArguments(Protocol.Command.SSCAN).key(key).add(cursor).addParams((IParams)params), BuilderFactory.SSCAN_RESPONSE);
/*      */   }
/*      */   
/*      */   public final CommandObject<ScanResult<byte[]>> sscan(byte[] key, byte[] cursor, ScanParams params) {
/* 1184 */     return new CommandObject<>(commandArguments(Protocol.Command.SSCAN).key(key).add(cursor).addParams((IParams)params), BuilderFactory.SSCAN_BINARY_RESPONSE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<String>> sdiff(String... keys) {
/* 1188 */     return new CommandObject<>(commandArguments(Protocol.Command.SDIFF).keys((Object[])keys), BuilderFactory.STRING_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sdiffstore(String dstkey, String... keys) {
/* 1192 */     return new CommandObject<>(commandArguments(Protocol.Command.SDIFFSTORE).key(dstkey).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<byte[]>> sdiff(byte[]... keys) {
/* 1196 */     return new CommandObject<>(commandArguments(Protocol.Command.SDIFF).keys((Object[])keys), BuilderFactory.BINARY_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sdiffstore(byte[] dstkey, byte[]... keys) {
/* 1200 */     return new CommandObject<>(commandArguments(Protocol.Command.SDIFFSTORE).key(dstkey).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<String>> sinter(String... keys) {
/* 1204 */     return new CommandObject<>(commandArguments(Protocol.Command.SINTER).keys((Object[])keys), BuilderFactory.STRING_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sinterstore(String dstkey, String... keys) {
/* 1208 */     return new CommandObject<>(commandArguments(Protocol.Command.SINTERSTORE).key(dstkey).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sintercard(String... keys) {
/* 1212 */     return new CommandObject<>(commandArguments(Protocol.Command.SINTERCARD).add(Integer.valueOf(keys.length)).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sintercard(int limit, String... keys) {
/* 1216 */     return new CommandObject<>(commandArguments(Protocol.Command.SINTERCARD).add(Integer.valueOf(keys.length)).keys((Object[])keys).add(Protocol.Keyword.LIMIT).add(Integer.valueOf(limit)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<byte[]>> sinter(byte[]... keys) {
/* 1220 */     return new CommandObject<>(commandArguments(Protocol.Command.SINTER).keys((Object[])keys), BuilderFactory.BINARY_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sinterstore(byte[] dstkey, byte[]... keys) {
/* 1224 */     return new CommandObject<>(commandArguments(Protocol.Command.SINTERSTORE).key(dstkey).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sintercard(byte[]... keys) {
/* 1228 */     return new CommandObject<>(commandArguments(Protocol.Command.SINTERCARD).add(Integer.valueOf(keys.length)).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sintercard(int limit, byte[]... keys) {
/* 1232 */     return new CommandObject<>(commandArguments(Protocol.Command.SINTERCARD).add(Integer.valueOf(keys.length)).keys((Object[])keys).add(Protocol.Keyword.LIMIT).add(Integer.valueOf(limit)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<String>> sunion(String... keys) {
/* 1236 */     return new CommandObject<>(commandArguments(Protocol.Command.SUNION).keys((Object[])keys), BuilderFactory.STRING_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sunionstore(String dstkey, String... keys) {
/* 1240 */     return new CommandObject<>(commandArguments(Protocol.Command.SUNIONSTORE).key(dstkey).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<byte[]>> sunion(byte[]... keys) {
/* 1244 */     return new CommandObject<>(commandArguments(Protocol.Command.SUNION).keys((Object[])keys), BuilderFactory.BINARY_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> sunionstore(byte[] dstkey, byte[]... keys) {
/* 1248 */     return new CommandObject<>(commandArguments(Protocol.Command.SUNIONSTORE).key(dstkey).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> smove(String srckey, String dstkey, String member) {
/* 1252 */     return new CommandObject<>(commandArguments(Protocol.Command.SMOVE).key(srckey).key(dstkey).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> smove(byte[] srckey, byte[] dstkey, byte[] member) {
/* 1256 */     return new CommandObject<>(commandArguments(Protocol.Command.SMOVE).key(srckey).key(dstkey).add(member), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> zadd(String key, double score, String member) {
/* 1262 */     return new CommandObject<>(commandArguments(Protocol.Command.ZADD).key(key).add(Double.valueOf(score)).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zadd(String key, double score, String member, ZAddParams params) {
/* 1266 */     return new CommandObject<>(commandArguments(Protocol.Command.ZADD).key(key).addParams((IParams)params)
/* 1267 */         .add(Double.valueOf(score)).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zadd(String key, Map<String, Double> scoreMembers) {
/* 1271 */     return new CommandObject<>(addSortedSetFlatMapArgs(commandArguments(Protocol.Command.ZADD).key(key), scoreMembers), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zadd(String key, Map<String, Double> scoreMembers, ZAddParams params) {
/* 1275 */     return new CommandObject<>(addSortedSetFlatMapArgs(commandArguments(Protocol.Command.ZADD).key(key).addParams((IParams)params), scoreMembers), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> zaddIncr(String key, double score, String member, ZAddParams params) {
/* 1279 */     return new CommandObject<>(commandArguments(Protocol.Command.ZADD).key(key).add(Protocol.Keyword.INCR)
/* 1280 */         .addParams((IParams)params).add(Double.valueOf(score)).add(member), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zadd(byte[] key, double score, byte[] member) {
/* 1284 */     return new CommandObject<>(commandArguments(Protocol.Command.ZADD).key(key).add(Double.valueOf(score)).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zadd(byte[] key, double score, byte[] member, ZAddParams params) {
/* 1288 */     return new CommandObject<>(commandArguments(Protocol.Command.ZADD).key(key).addParams((IParams)params)
/* 1289 */         .add(Double.valueOf(score)).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zadd(byte[] key, Map<byte[], Double> scoreMembers) {
/* 1293 */     return new CommandObject<>(addSortedSetFlatMapArgs(commandArguments(Protocol.Command.ZADD).key(key), scoreMembers), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zadd(byte[] key, Map<byte[], Double> scoreMembers, ZAddParams params) {
/* 1297 */     return new CommandObject<>(addSortedSetFlatMapArgs(commandArguments(Protocol.Command.ZADD).key(key).addParams((IParams)params), scoreMembers), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> zaddIncr(byte[] key, double score, byte[] member, ZAddParams params) {
/* 1301 */     return new CommandObject<>(commandArguments(Protocol.Command.ZADD).key(key).add(Protocol.Keyword.INCR)
/* 1302 */         .addParams((IParams)params).add(Double.valueOf(score)).add(member), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> zincrby(String key, double increment, String member) {
/* 1306 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINCRBY).key(key).add(Double.valueOf(increment)).add(member), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> zincrby(String key, double increment, String member, ZIncrByParams params) {
/* 1310 */     return new CommandObject<>(commandArguments(Protocol.Command.ZADD).key(key).addParams((IParams)params).add(Double.valueOf(increment)).add(member), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> zincrby(byte[] key, double increment, byte[] member) {
/* 1314 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINCRBY).key(key).add(Double.valueOf(increment)).add(member), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> zincrby(byte[] key, double increment, byte[] member, ZIncrByParams params) {
/* 1318 */     return new CommandObject<>(commandArguments(Protocol.Command.ZADD).key(key).addParams((IParams)params).add(Double.valueOf(increment)).add(member), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zrem(String key, String... members) {
/* 1322 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREM).key(key).addObjects((Object[])members), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zrem(byte[] key, byte[]... members) {
/* 1326 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREM).key(key).addObjects((Object[])members), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zrank(String key, String member) {
/* 1330 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANK).key(key).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zrevrank(String key, String member) {
/* 1334 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANK).key(key).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zrank(byte[] key, byte[] member) {
/* 1338 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANK).key(key).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zrevrank(byte[] key, byte[] member) {
/* 1342 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANK).key(key).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> zrandmember(String key) {
/* 1346 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANDMEMBER).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrandmember(String key, long count) {
/* 1350 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANDMEMBER).key(key).add(Long.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrandmemberWithScores(String key, long count) {
/* 1354 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANDMEMBER).key(key).add(Long.valueOf(count)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> zrandmember(byte[] key) {
/* 1358 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.ZRANDMEMBER).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrandmember(byte[] key, long count) {
/* 1362 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANDMEMBER).key(key).add(Long.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrandmemberWithScores(byte[] key, long count) {
/* 1366 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANDMEMBER).key(key).add(Long.valueOf(count)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zcard(String key) {
/* 1370 */     return new CommandObject<>(commandArguments(Protocol.Command.ZCARD).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> zscore(String key, String member) {
/* 1374 */     return new CommandObject<>(commandArguments(Protocol.Command.ZSCORE).key(key).add(member), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Double>> zmscore(String key, String... members) {
/* 1378 */     return new CommandObject<>(commandArguments(Protocol.Command.ZMSCORE).key(key).addObjects((Object[])members), BuilderFactory.DOUBLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zcard(byte[] key) {
/* 1382 */     return new CommandObject<>(commandArguments(Protocol.Command.ZCARD).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> zscore(byte[] key, byte[] member) {
/* 1386 */     return new CommandObject<>(commandArguments(Protocol.Command.ZSCORE).key(key).add(member), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Double>> zmscore(byte[] key, byte[]... members) {
/* 1390 */     return new CommandObject<>(commandArguments(Protocol.Command.ZMSCORE).key(key).addObjects((Object[])members), BuilderFactory.DOUBLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Tuple> zpopmax(String key) {
/* 1394 */     return new CommandObject<>(commandArguments(Protocol.Command.ZPOPMAX).key(key), BuilderFactory.TUPLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zpopmax(String key, int count) {
/* 1398 */     return new CommandObject<>(commandArguments(Protocol.Command.ZPOPMAX).key(key).add(Integer.valueOf(count)), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Tuple> zpopmin(String key) {
/* 1402 */     return new CommandObject<>(commandArguments(Protocol.Command.ZPOPMIN).key(key), BuilderFactory.TUPLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zpopmin(String key, int count) {
/* 1406 */     return new CommandObject<>(commandArguments(Protocol.Command.ZPOPMIN).key(key).add(Integer.valueOf(count)), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Tuple> zpopmax(byte[] key) {
/* 1410 */     return new CommandObject<>(commandArguments(Protocol.Command.ZPOPMAX).key(key), BuilderFactory.TUPLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zpopmax(byte[] key, int count) {
/* 1414 */     return new CommandObject<>(commandArguments(Protocol.Command.ZPOPMAX).key(key).add(Integer.valueOf(count)), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Tuple> zpopmin(byte[] key) {
/* 1418 */     return new CommandObject<>(commandArguments(Protocol.Command.ZPOPMIN).key(key), BuilderFactory.TUPLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zpopmin(byte[] key, int count) {
/* 1422 */     return new CommandObject<>(commandArguments(Protocol.Command.ZPOPMIN).key(key).add(Integer.valueOf(count)), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyedZSetElement> bzpopmax(double timeout, String... keys) {
/* 1426 */     return new CommandObject<>(commandArguments(Protocol.Command.BZPOPMAX).blocking().keys((Object[])keys).add(Double.valueOf(timeout)), BuilderFactory.KEYED_ZSET_ELEMENT);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyedZSetElement> bzpopmin(double timeout, String... keys) {
/* 1430 */     return new CommandObject<>(commandArguments(Protocol.Command.BZPOPMIN).blocking().keys((Object[])keys).add(Double.valueOf(timeout)), BuilderFactory.KEYED_ZSET_ELEMENT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> bzpopmax(double timeout, byte[]... keys) {
/* 1434 */     return new CommandObject<>(commandArguments(Protocol.Command.BZPOPMAX).blocking().keys((Object[])keys).add(Double.valueOf(timeout)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> bzpopmin(double timeout, byte[]... keys) {
/* 1438 */     return new CommandObject<>(commandArguments(Protocol.Command.BZPOPMIN).blocking().keys((Object[])keys).add(Double.valueOf(timeout)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zcount(String key, double min, double max) {
/* 1442 */     return new CommandObject<>(commandArguments(Protocol.Command.ZCOUNT).key(key).add(Double.valueOf(min)).add(Double.valueOf(max)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zcount(String key, String min, String max) {
/* 1446 */     return new CommandObject<>(commandArguments(Protocol.Command.ZCOUNT).key(key).add(min).add(max), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zcount(byte[] key, double min, double max) {
/* 1450 */     return new CommandObject<>(commandArguments(Protocol.Command.ZCOUNT).key(key).add(Double.valueOf(min)).add(Double.valueOf(max)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zcount(byte[] key, byte[] min, byte[] max) {
/* 1454 */     return new CommandObject<>(commandArguments(Protocol.Command.ZCOUNT).key(key).add(min).add(max), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrange(String key, long start, long stop) {
/* 1458 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGE).key(key).add(Long.valueOf(start)).add(Long.valueOf(stop)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrevrange(String key, long start, long stop) {
/* 1462 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGE).key(key).add(Long.valueOf(start)).add(Long.valueOf(stop)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeWithScores(String key, long start, long stop) {
/* 1466 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGE).key(key)
/* 1467 */         .add(Long.valueOf(start)).add(Long.valueOf(stop)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrevrangeWithScores(String key, long start, long stop) {
/* 1471 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGE).key(key)
/* 1472 */         .add(Long.valueOf(start)).add(Long.valueOf(stop)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrange(String key, ZRangeParams zRangeParams) {
/* 1476 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGE).key(key).addParams((IParams)zRangeParams), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeWithScores(String key, ZRangeParams zRangeParams) {
/* 1480 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGE).key(key).addParams((IParams)zRangeParams).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zrangestore(String dest, String src, ZRangeParams zRangeParams) {
/* 1484 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGESTORE).key(dest).add(src).addParams((IParams)zRangeParams), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrangeByScore(String key, double min, double max) {
/* 1488 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(Double.valueOf(min)).add(Double.valueOf(max)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrangeByScore(String key, String min, String max) {
/* 1492 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(min).add(max), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrevrangeByScore(String key, double max, double min) {
/* 1496 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(Double.valueOf(max)).add(Double.valueOf(min)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrevrangeByScore(String key, String max, String min) {
/* 1500 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(max).add(min), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrangeByScore(String key, double min, double max, int offset, int count) {
/* 1504 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(Double.valueOf(min)).add(Double.valueOf(max))
/* 1505 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrangeByScore(String key, String min, String max, int offset, int count) {
/* 1509 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(min).add(max)
/* 1510 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrevrangeByScore(String key, double max, double min, int offset, int count) {
/* 1514 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(Double.valueOf(max)).add(Double.valueOf(min))
/* 1515 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrevrangeByScore(String key, String max, String min, int offset, int count) {
/* 1519 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(max).add(min)
/* 1520 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeByScoreWithScores(String key, double min, double max) {
/* 1524 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(Double.valueOf(min)).add(Double.valueOf(max))
/* 1525 */         .add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeByScoreWithScores(String key, String min, String max) {
/* 1529 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(min).add(max)
/* 1530 */         .add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrevrangeByScoreWithScores(String key, double max, double min) {
/* 1534 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(Double.valueOf(max)).add(Double.valueOf(min))
/* 1535 */         .add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrevrangeByScoreWithScores(String key, String max, String min) {
/* 1539 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(max).add(min)
/* 1540 */         .add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeByScoreWithScores(String key, double min, double max, int offset, int count) {
/* 1544 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(Double.valueOf(min)).add(Double.valueOf(max))
/* 1545 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeByScoreWithScores(String key, String min, String max, int offset, int count) {
/* 1549 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(min).add(max)
/* 1550 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrevrangeByScoreWithScores(String key, double max, double min, int offset, int count) {
/* 1554 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(Double.valueOf(max)).add(Double.valueOf(min))
/* 1555 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrevrangeByScoreWithScores(String key, String max, String min, int offset, int count) {
/* 1559 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(max).add(min)
/* 1560 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrange(byte[] key, long start, long stop) {
/* 1564 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGE).key(key).add(Long.valueOf(start)).add(Long.valueOf(stop)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrevrange(byte[] key, long start, long stop) {
/* 1568 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGE).key(key).add(Long.valueOf(start)).add(Long.valueOf(stop)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeWithScores(byte[] key, long start, long stop) {
/* 1572 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGE).key(key)
/* 1573 */         .add(Long.valueOf(start)).add(Long.valueOf(stop)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrevrangeWithScores(byte[] key, long start, long stop) {
/* 1577 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGE).key(key)
/* 1578 */         .add(Long.valueOf(start)).add(Long.valueOf(stop)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrange(byte[] key, ZRangeParams zRangeParams) {
/* 1582 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGE).key(key).addParams((IParams)zRangeParams), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeWithScores(byte[] key, ZRangeParams zRangeParams) {
/* 1586 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGE).key(key).addParams((IParams)zRangeParams).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zrangestore(byte[] dest, byte[] src, ZRangeParams zRangeParams) {
/* 1590 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGESTORE).key(dest).add(src).addParams((IParams)zRangeParams), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrangeByScore(byte[] key, double min, double max) {
/* 1594 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(Double.valueOf(min)).add(Double.valueOf(max)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrangeByScore(byte[] key, byte[] min, byte[] max) {
/* 1598 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(min).add(max), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrevrangeByScore(byte[] key, double max, double min) {
/* 1602 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(Double.valueOf(max)).add(Double.valueOf(min)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrevrangeByScore(byte[] key, byte[] max, byte[] min) {
/* 1606 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(max).add(min), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrangeByScore(byte[] key, double min, double max, int offset, int count) {
/* 1610 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(Double.valueOf(min)).add(Double.valueOf(max))
/* 1611 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrangeByScore(byte[] key, byte[] min, byte[] max, int offset, int count) {
/* 1615 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(min).add(max)
/* 1616 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrevrangeByScore(byte[] key, double max, double min, int offset, int count) {
/* 1620 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(Double.valueOf(max)).add(Double.valueOf(min))
/* 1621 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrevrangeByScore(byte[] key, byte[] max, byte[] min, int offset, int count) {
/* 1625 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(max).add(min)
/* 1626 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeByScoreWithScores(byte[] key, double min, double max) {
/* 1630 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(Double.valueOf(min)).add(Double.valueOf(max))
/* 1631 */         .add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max) {
/* 1635 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(min).add(max)
/* 1636 */         .add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrevrangeByScoreWithScores(byte[] key, double max, double min) {
/* 1640 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(Double.valueOf(max)).add(Double.valueOf(min))
/* 1641 */         .add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min) {
/* 1645 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(max).add(min)
/* 1646 */         .add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeByScoreWithScores(byte[] key, double min, double max, int offset, int count) {
/* 1650 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(Double.valueOf(min)).add(Double.valueOf(max))
/* 1651 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max, int offset, int count) {
/* 1655 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYSCORE).key(key).add(min).add(max)
/* 1656 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrevrangeByScoreWithScores(byte[] key, double max, double min, int offset, int count) {
/* 1660 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(Double.valueOf(max)).add(Double.valueOf(min))
/* 1661 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Tuple>> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min, int offset, int count) {
/* 1665 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYSCORE).key(key).add(max).add(min)
/* 1666 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zremrangeByRank(String key, long start, long stop) {
/* 1670 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREMRANGEBYRANK).key(key).add(Long.valueOf(start)).add(Long.valueOf(stop)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zremrangeByScore(String key, double min, double max) {
/* 1674 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREMRANGEBYSCORE).key(key).add(Double.valueOf(min)).add(Double.valueOf(max)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zremrangeByScore(String key, String min, String max) {
/* 1678 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREMRANGEBYSCORE).key(key).add(min).add(max), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zremrangeByRank(byte[] key, long start, long stop) {
/* 1682 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREMRANGEBYRANK).key(key).add(Long.valueOf(start)).add(Long.valueOf(stop)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zremrangeByScore(byte[] key, double min, double max) {
/* 1686 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREMRANGEBYSCORE).key(key).add(Double.valueOf(min)).add(Double.valueOf(max)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zremrangeByScore(byte[] key, byte[] min, byte[] max) {
/* 1690 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREMRANGEBYSCORE).key(key).add(min).add(max), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zlexcount(String key, String min, String max) {
/* 1694 */     return new CommandObject<>(commandArguments(Protocol.Command.ZLEXCOUNT).key(key).add(min).add(max), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrangeByLex(String key, String min, String max) {
/* 1698 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYLEX).key(key).add(min).add(max), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrangeByLex(String key, String min, String max, int offset, int count) {
/* 1702 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYLEX).key(key).add(min).add(max)
/* 1703 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrevrangeByLex(String key, String max, String min) {
/* 1707 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYLEX).key(key).add(max).add(min), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> zrevrangeByLex(String key, String max, String min, int offset, int count) {
/* 1711 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYLEX).key(key).add(max).add(min)
/* 1712 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zremrangeByLex(String key, String min, String max) {
/* 1716 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREMRANGEBYLEX).key(key).add(min).add(max), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zlexcount(byte[] key, byte[] min, byte[] max) {
/* 1720 */     return new CommandObject<>(commandArguments(Protocol.Command.ZLEXCOUNT).key(key).add(min).add(max), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrangeByLex(byte[] key, byte[] min, byte[] max) {
/* 1724 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYLEX).key(key).add(min).add(max), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrangeByLex(byte[] key, byte[] min, byte[] max, int offset, int count) {
/* 1728 */     return new CommandObject<>(commandArguments(Protocol.Command.ZRANGEBYLEX).key(key).add(min).add(max)
/* 1729 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrevrangeByLex(byte[] key, byte[] max, byte[] min) {
/* 1733 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYLEX).key(key).add(max).add(min), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> zrevrangeByLex(byte[] key, byte[] max, byte[] min, int offset, int count) {
/* 1737 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREVRANGEBYLEX).key(key).add(max).add(min)
/* 1738 */         .add(Protocol.Keyword.LIMIT).add(Integer.valueOf(offset)).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zremrangeByLex(byte[] key, byte[] min, byte[] max) {
/* 1742 */     return new CommandObject<>(commandArguments(Protocol.Command.ZREMRANGEBYLEX).key(key).add(min).add(max), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<ScanResult<Tuple>> zscan(String key, String cursor, ScanParams params) {
/* 1746 */     return new CommandObject<>(commandArguments(Protocol.Command.ZSCAN).key(key).add(cursor).addParams((IParams)params), BuilderFactory.ZSCAN_RESPONSE);
/*      */   }
/*      */   
/*      */   public final CommandObject<ScanResult<Tuple>> zscan(byte[] key, byte[] cursor, ScanParams params) {
/* 1750 */     return new CommandObject<>(commandArguments(Protocol.Command.ZSCAN).key(key).add(cursor).addParams((IParams)params), BuilderFactory.ZSCAN_RESPONSE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<String>> zdiff(String... keys) {
/* 1754 */     return new CommandObject<>(commandArguments(Protocol.Command.ZDIFF).add(Integer.valueOf(keys.length)).keys((Object[])keys), BuilderFactory.STRING_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<Tuple>> zdiffWithScores(String... keys) {
/* 1758 */     return new CommandObject<>(commandArguments(Protocol.Command.ZDIFF).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1759 */         .add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_ZSET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zdiffStore(String dstkey, String... keys) {
/* 1763 */     return new CommandObject<>(commandArguments(Protocol.Command.ZDIFFSTORE).key(dstkey).add(Integer.valueOf(keys.length)).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<byte[]>> zdiff(byte[]... keys) {
/* 1767 */     return new CommandObject<>(commandArguments(Protocol.Command.ZDIFF).add(Integer.valueOf(keys.length)).keys((Object[])keys), BuilderFactory.BINARY_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<Tuple>> zdiffWithScores(byte[]... keys) {
/* 1771 */     return new CommandObject<>(commandArguments(Protocol.Command.ZDIFF).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1772 */         .add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_ZSET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zdiffStore(byte[] dstkey, byte[]... keys) {
/* 1776 */     return new CommandObject<>(commandArguments(Protocol.Command.ZDIFFSTORE).key(dstkey)
/* 1777 */         .add(Integer.valueOf(keys.length)).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zinterstore(String dstkey, String... sets) {
/* 1781 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTERSTORE).key(dstkey)
/* 1782 */         .add(Integer.valueOf(sets.length)).keys((Object[])sets), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zinterstore(String dstkey, ZParams params, String... sets) {
/* 1786 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTERSTORE).key(dstkey)
/* 1787 */         .add(Integer.valueOf(sets.length)).keys((Object[])sets).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<String>> zinter(ZParams params, String... keys) {
/* 1791 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTER).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1792 */         .addParams((IParams)params), BuilderFactory.STRING_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<Tuple>> zinterWithScores(ZParams params, String... keys) {
/* 1796 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTER).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1797 */         .addParams((IParams)params).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_ZSET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zintercard(String... keys) {
/* 1801 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTERCARD).add(Integer.valueOf(keys.length))
/* 1802 */         .keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zintercard(long limit, String... keys) {
/* 1806 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTERCARD).add(Integer.valueOf(keys.length))
/* 1807 */         .keys((Object[])keys).add(Protocol.Keyword.LIMIT).add(Long.valueOf(limit)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zinterstore(byte[] dstkey, byte[]... sets) {
/* 1811 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTERSTORE).key(dstkey)
/* 1812 */         .add(Integer.valueOf(sets.length)).keys((Object[])sets), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zinterstore(byte[] dstkey, ZParams params, byte[]... sets) {
/* 1816 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTERSTORE).key(dstkey)
/* 1817 */         .add(Integer.valueOf(sets.length)).keys((Object[])sets).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zintercard(byte[]... keys) {
/* 1821 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTERCARD).add(Integer.valueOf(keys.length))
/* 1822 */         .keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zintercard(long limit, byte[]... keys) {
/* 1826 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTERCARD).add(Integer.valueOf(keys.length))
/* 1827 */         .keys((Object[])keys).add(Protocol.Keyword.LIMIT).add(Long.valueOf(limit)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<byte[]>> zinter(ZParams params, byte[]... keys) {
/* 1831 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTER).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1832 */         .addParams((IParams)params), BuilderFactory.BINARY_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<Tuple>> zinterWithScores(ZParams params, byte[]... keys) {
/* 1836 */     return new CommandObject<>(commandArguments(Protocol.Command.ZINTER).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1837 */         .addParams((IParams)params).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_ZSET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zunionstore(String dstkey, String... sets) {
/* 1841 */     return new CommandObject<>(commandArguments(Protocol.Command.ZUNIONSTORE).key(dstkey)
/* 1842 */         .add(Integer.valueOf(sets.length)).keys((Object[])sets), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zunionstore(String dstkey, ZParams params, String... sets) {
/* 1846 */     return new CommandObject<>(commandArguments(Protocol.Command.ZUNIONSTORE).key(dstkey)
/* 1847 */         .add(Integer.valueOf(sets.length)).keys((Object[])sets).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<String>> zunion(ZParams params, String... keys) {
/* 1851 */     return new CommandObject<>(commandArguments(Protocol.Command.ZUNION).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1852 */         .addParams((IParams)params), BuilderFactory.STRING_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<Tuple>> zunionWithScores(ZParams params, String... keys) {
/* 1856 */     return new CommandObject<>(commandArguments(Protocol.Command.ZUNION).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1857 */         .addParams((IParams)params).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_ZSET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zunionstore(byte[] dstkey, byte[]... sets) {
/* 1861 */     return new CommandObject<>(commandArguments(Protocol.Command.ZUNIONSTORE).key(dstkey)
/* 1862 */         .add(Integer.valueOf(sets.length)).keys((Object[])sets), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> zunionstore(byte[] dstkey, ZParams params, byte[]... sets) {
/* 1866 */     return new CommandObject<>(commandArguments(Protocol.Command.ZUNIONSTORE).key(dstkey)
/* 1867 */         .add(Integer.valueOf(sets.length)).keys((Object[])sets).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<byte[]>> zunion(ZParams params, byte[]... keys) {
/* 1871 */     return new CommandObject<>(commandArguments(Protocol.Command.ZUNION).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1872 */         .addParams((IParams)params), BuilderFactory.BINARY_SET);
/*      */   }
/*      */   
/*      */   public final CommandObject<Set<Tuple>> zunionWithScores(ZParams params, byte[]... keys) {
/* 1876 */     return new CommandObject<>(commandArguments(Protocol.Command.ZUNION).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1877 */         .addParams((IParams)params).add(Protocol.Keyword.WITHSCORES), BuilderFactory.TUPLE_ZSET);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<String, List<Tuple>>> zmpop(SortedSetOption option, String... keys) {
/* 1881 */     return new CommandObject<>(commandArguments(Protocol.Command.ZMPOP).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1882 */         .add(option), BuilderFactory.KEYED_TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<String, List<Tuple>>> zmpop(SortedSetOption option, int count, String... keys) {
/* 1886 */     return new CommandObject<>(commandArguments(Protocol.Command.ZMPOP).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1887 */         .add(option).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.KEYED_TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<String, List<Tuple>>> bzmpop(long timeout, SortedSetOption option, String... keys) {
/* 1891 */     return new CommandObject<>(commandArguments(Protocol.Command.BZMPOP).blocking().add(Long.valueOf(timeout)).add(Integer.valueOf(keys.length))
/* 1892 */         .keys((Object[])keys).add(option), BuilderFactory.KEYED_TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<String, List<Tuple>>> bzmpop(long timeout, SortedSetOption option, int count, String... keys) {
/* 1896 */     return new CommandObject<>(commandArguments(Protocol.Command.BZMPOP).blocking().add(Long.valueOf(timeout)).add(Integer.valueOf(keys.length))
/* 1897 */         .keys((Object[])keys).add(option).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.KEYED_TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<byte[], List<Tuple>>> zmpop(SortedSetOption option, byte[]... keys) {
/* 1901 */     return new CommandObject<>(commandArguments(Protocol.Command.ZMPOP).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1902 */         .add(option), BuilderFactory.BINARY_KEYED_TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<byte[], List<Tuple>>> zmpop(SortedSetOption option, int count, byte[]... keys) {
/* 1906 */     return new CommandObject<>(commandArguments(Protocol.Command.ZMPOP).add(Integer.valueOf(keys.length)).keys((Object[])keys)
/* 1907 */         .add(option).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.BINARY_KEYED_TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<byte[], List<Tuple>>> bzmpop(long timeout, SortedSetOption option, byte[]... keys) {
/* 1911 */     return new CommandObject<>(commandArguments(Protocol.Command.BZMPOP).blocking().add(Long.valueOf(timeout)).add(Integer.valueOf(keys.length))
/* 1912 */         .keys((Object[])keys).add(option), BuilderFactory.BINARY_KEYED_TUPLE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<KeyValue<byte[], List<Tuple>>> bzmpop(long timeout, SortedSetOption option, int count, byte[]... keys) {
/* 1916 */     return new CommandObject<>(commandArguments(Protocol.Command.BZMPOP).blocking().add(Long.valueOf(timeout)).add(Integer.valueOf(keys.length))
/* 1917 */         .keys((Object[])keys).add(option).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.BINARY_KEYED_TUPLE_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> geoadd(String key, double longitude, double latitude, String member) {
/* 1923 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOADD).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude)).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> geoadd(String key, Map<String, GeoCoordinate> memberCoordinateMap) {
/* 1927 */     return new CommandObject<>(addGeoCoordinateFlatMapArgs(commandArguments(Protocol.Command.GEOADD).key(key), memberCoordinateMap), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> geoadd(String key, GeoAddParams params, Map<String, GeoCoordinate> memberCoordinateMap) {
/* 1931 */     return new CommandObject<>(addGeoCoordinateFlatMapArgs(commandArguments(Protocol.Command.GEOADD).key(key).addParams((IParams)params), memberCoordinateMap), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> geodist(String key, String member1, String member2) {
/* 1935 */     return new CommandObject<>(commandArguments(Protocol.Command.GEODIST).key(key).add(member1).add(member2), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> geodist(String key, String member1, String member2, GeoUnit unit) {
/* 1939 */     return new CommandObject<>(commandArguments(Protocol.Command.GEODIST).key(key).add(member1).add(member2).add(unit), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> geohash(String key, String... members) {
/* 1943 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOHASH).key(key).addObjects((Object[])members), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoCoordinate>> geopos(String key, String... members) {
/* 1947 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOPOS).key(key).addObjects((Object[])members), BuilderFactory.GEO_COORDINATE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> geoadd(byte[] key, double longitude, double latitude, byte[] member) {
/* 1951 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOADD).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude)).add(member), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> geoadd(byte[] key, Map<byte[], GeoCoordinate> memberCoordinateMap) {
/* 1955 */     return new CommandObject<>(addGeoCoordinateFlatMapArgs(commandArguments(Protocol.Command.GEOADD).key(key), memberCoordinateMap), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> geoadd(byte[] key, GeoAddParams params, Map<byte[], GeoCoordinate> memberCoordinateMap) {
/* 1959 */     return new CommandObject<>(addGeoCoordinateFlatMapArgs(commandArguments(Protocol.Command.GEOADD).key(key).addParams((IParams)params), memberCoordinateMap), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> geodist(byte[] key, byte[] member1, byte[] member2) {
/* 1963 */     return new CommandObject<>(commandArguments(Protocol.Command.GEODIST).key(key).add(member1).add(member2), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Double> geodist(byte[] key, byte[] member1, byte[] member2, GeoUnit unit) {
/* 1967 */     return new CommandObject<>(commandArguments(Protocol.Command.GEODIST).key(key).add(member1).add(member2).add(unit), BuilderFactory.DOUBLE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> geohash(byte[] key, byte[]... members) {
/* 1971 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOHASH).key(key).addObjects((Object[])members), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoCoordinate>> geopos(byte[] key, byte[]... members) {
/* 1975 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOPOS).key(key).addObjects((Object[])members), BuilderFactory.GEO_COORDINATE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadius(String key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 1979 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUS).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude))
/* 1980 */         .add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadius(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 1985 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUS).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude))
/* 1986 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusReadonly(String key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 1990 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUS_RO).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude))
/* 1991 */         .add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusReadonly(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 1996 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUS_RO).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude))
/* 1997 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> georadiusStore(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 2002 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUS).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude))
/* 2003 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param).addParams((IParams)storeParam), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusByMember(String key, String member, double radius, GeoUnit unit) {
/* 2007 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUSBYMEMBER).key(key).add(member)
/* 2008 */         .add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusByMember(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 2013 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUSBYMEMBER).key(key).add(member)
/* 2014 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusByMemberReadonly(String key, String member, double radius, GeoUnit unit) {
/* 2018 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUSBYMEMBER_RO).key(key).add(member)
/* 2019 */         .add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusByMemberReadonly(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 2024 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUSBYMEMBER_RO).key(key).add(member)
/* 2025 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> georadiusByMemberStore(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 2030 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUSBYMEMBER).key(key).add(member)
/* 2031 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param).addParams((IParams)storeParam), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadius(byte[] key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 2035 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUS).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude))
/* 2036 */         .add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadius(byte[] key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 2041 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUS).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude))
/* 2042 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusReadonly(byte[] key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 2047 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUS_RO).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude))
/* 2048 */         .add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusReadonly(byte[] key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 2053 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUS_RO).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude))
/* 2054 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> georadiusStore(byte[] key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 2059 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUS).key(key).add(Double.valueOf(longitude)).add(Double.valueOf(latitude))
/* 2060 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param).addParams((IParams)storeParam), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusByMember(byte[] key, byte[] member, double radius, GeoUnit unit) {
/* 2064 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUSBYMEMBER).key(key).add(member)
/* 2065 */         .add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusByMember(byte[] key, byte[] member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 2069 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUSBYMEMBER).key(key).add(member)
/* 2070 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusByMemberReadonly(byte[] key, byte[] member, double radius, GeoUnit unit) {
/* 2074 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUSBYMEMBER_RO).key(key).add(member)
/* 2075 */         .add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> georadiusByMemberReadonly(byte[] key, byte[] member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 2079 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUSBYMEMBER_RO).key(key).add(member)
/* 2080 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> georadiusByMemberStore(byte[] key, byte[] member, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 2085 */     return new CommandObject<>(commandArguments(Protocol.Command.GEORADIUSBYMEMBER).key(key).add(member)
/* 2086 */         .add(Double.valueOf(radius)).add(unit).addParams((IParams)param).addParams((IParams)storeParam), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> geosearch(String key, String member, double radius, GeoUnit unit) {
/* 2091 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCH).key(key).add(Protocol.Keyword.FROMMEMBER).add(member)
/* 2092 */         .add(Protocol.Keyword.BYRADIUS).add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> geosearch(String key, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 2097 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCH).key(key)
/* 2098 */         .add(Protocol.Keyword.FROMLONLAT).add(Double.valueOf(coord.getLongitude())).add(Double.valueOf(coord.getLatitude()))
/* 2099 */         .add(Protocol.Keyword.BYRADIUS).add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> geosearch(String key, String member, double width, double height, GeoUnit unit) {
/* 2104 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCH).key(key).add(Protocol.Keyword.FROMMEMBER).add(member)
/* 2105 */         .add(Protocol.Keyword.BYBOX).add(Double.valueOf(width)).add(Double.valueOf(height)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> geosearch(String key, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 2110 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCH).key(key)
/* 2111 */         .add(Protocol.Keyword.FROMLONLAT).add(Double.valueOf(coord.getLongitude())).add(Double.valueOf(coord.getLatitude()))
/* 2112 */         .add(Protocol.Keyword.BYBOX).add(Double.valueOf(width)).add(Double.valueOf(height)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> geosearch(String key, GeoSearchParam params) {
/* 2116 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCH).key(key).addParams((IParams)params), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> geosearchStore(String dest, String src, String member, double radius, GeoUnit unit) {
/* 2122 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src).add(Protocol.Keyword.FROMMEMBER).add(member)
/* 2123 */         .add(Protocol.Keyword.BYRADIUS).add(Double.valueOf(radius)).add(unit), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> geosearchStore(String dest, String src, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 2128 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src).add(Protocol.Keyword.FROMLONLAT).add(Double.valueOf(coord.getLongitude()))
/* 2129 */         .add(Double.valueOf(coord.getLatitude())).add(Protocol.Keyword.BYRADIUS).add(Double.valueOf(radius)).add(unit), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> geosearchStore(String dest, String src, String member, double width, double height, GeoUnit unit) {
/* 2134 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src).add(Protocol.Keyword.FROMMEMBER).add(member)
/* 2135 */         .add(Protocol.Keyword.BYBOX).add(Double.valueOf(width)).add(Double.valueOf(height)).add(unit), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> geosearchStore(String dest, String src, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 2140 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src)
/* 2141 */         .add(Protocol.Keyword.FROMLONLAT).add(Double.valueOf(coord.getLongitude())).add(Double.valueOf(coord.getLatitude()))
/* 2142 */         .add(Protocol.Keyword.BYBOX).add(Double.valueOf(width)).add(Double.valueOf(height)).add(unit), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> geosearchStore(String dest, String src, GeoSearchParam params) {
/* 2146 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> geosearchStoreStoreDist(String dest, String src, GeoSearchParam params) {
/* 2150 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src).addParams((IParams)params).add(Protocol.Keyword.STOREDIST), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> geosearch(byte[] key, byte[] member, double radius, GeoUnit unit) {
/* 2155 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCH).key(key).add(Protocol.Keyword.FROMMEMBER).add(member)
/* 2156 */         .add(Protocol.Keyword.BYRADIUS).add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> geosearch(byte[] key, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 2161 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCH).key(key)
/* 2162 */         .add(Protocol.Keyword.FROMLONLAT).add(Double.valueOf(coord.getLongitude())).add(Double.valueOf(coord.getLatitude()))
/* 2163 */         .add(Protocol.Keyword.BYRADIUS).add(Double.valueOf(radius)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> geosearch(byte[] key, byte[] member, double width, double height, GeoUnit unit) {
/* 2168 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCH).key(key).add(Protocol.Keyword.FROMMEMBER).add(member)
/* 2169 */         .add(Protocol.Keyword.BYBOX).add(Double.valueOf(width)).add(Double.valueOf(height)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> geosearch(byte[] key, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 2174 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCH).key(key)
/* 2175 */         .add(Protocol.Keyword.FROMLONLAT).add(Double.valueOf(coord.getLongitude())).add(Double.valueOf(coord.getLatitude()))
/* 2176 */         .add(Protocol.Keyword.BYBOX).add(Double.valueOf(width)).add(Double.valueOf(height)).add(unit), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<GeoRadiusResponse>> geosearch(byte[] key, GeoSearchParam params) {
/* 2180 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCH).key(key).addParams((IParams)params), BuilderFactory.GEORADIUS_WITH_PARAMS_RESULT);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> geosearchStore(byte[] dest, byte[] src, byte[] member, double radius, GeoUnit unit) {
/* 2186 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src).add(Protocol.Keyword.FROMMEMBER).add(member)
/* 2187 */         .add(Protocol.Keyword.BYRADIUS).add(Double.valueOf(radius)).add(unit), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> geosearchStore(byte[] dest, byte[] src, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 2192 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src)
/* 2193 */         .add(Protocol.Keyword.FROMLONLAT).add(Double.valueOf(coord.getLongitude())).add(Double.valueOf(coord.getLatitude()))
/* 2194 */         .add(Protocol.Keyword.BYRADIUS).add(Double.valueOf(radius)).add(unit), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> geosearchStore(byte[] dest, byte[] src, byte[] member, double width, double height, GeoUnit unit) {
/* 2199 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src).add(Protocol.Keyword.FROMMEMBER).add(member)
/* 2200 */         .add(Protocol.Keyword.BYBOX).add(Double.valueOf(width)).add(Double.valueOf(height)).add(unit), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> geosearchStore(byte[] dest, byte[] src, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 2205 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src)
/* 2206 */         .add(Protocol.Keyword.FROMLONLAT).add(Double.valueOf(coord.getLongitude())).add(Double.valueOf(coord.getLatitude()))
/* 2207 */         .add(Protocol.Keyword.BYBOX).add(Double.valueOf(width)).add(Double.valueOf(height)).add(unit), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> geosearchStore(byte[] dest, byte[] src, GeoSearchParam params) {
/* 2211 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> geosearchStoreStoreDist(byte[] dest, byte[] src, GeoSearchParam params) {
/* 2215 */     return new CommandObject<>(commandArguments(Protocol.Command.GEOSEARCHSTORE).key(dest).add(src).addParams((IParams)params).add(Protocol.Keyword.STOREDIST), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> pfadd(String key, String... elements) {
/* 2221 */     return new CommandObject<>(commandArguments(Protocol.Command.PFADD).key(key).addObjects((Object[])elements), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> pfmerge(String destkey, String... sourcekeys) {
/* 2225 */     return new CommandObject<>(commandArguments(Protocol.Command.PFMERGE).key(destkey).keys((Object[])sourcekeys), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pfadd(byte[] key, byte[]... elements) {
/* 2229 */     return new CommandObject<>(commandArguments(Protocol.Command.PFADD).key(key).addObjects((Object[])elements), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> pfmerge(byte[] destkey, byte[]... sourcekeys) {
/* 2233 */     return new CommandObject<>(commandArguments(Protocol.Command.PFMERGE).key(destkey).keys((Object[])sourcekeys), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pfcount(String key) {
/* 2237 */     return new CommandObject<>(commandArguments(Protocol.Command.PFCOUNT).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pfcount(String... keys) {
/* 2241 */     return new CommandObject<>(commandArguments(Protocol.Command.PFCOUNT).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pfcount(byte[] key) {
/* 2245 */     return new CommandObject<>(commandArguments(Protocol.Command.PFCOUNT).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> pfcount(byte[]... keys) {
/* 2249 */     return new CommandObject<>(commandArguments(Protocol.Command.PFCOUNT).keys((Object[])keys), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<StreamEntryID> xadd(String key, StreamEntryID id, Map<String, String> hash) {
/* 2255 */     return new CommandObject<>(addFlatMapArgs(commandArguments(Protocol.Command.XADD).key(key).add((id == null) ? StreamEntryID.NEW_ENTRY : id), hash), BuilderFactory.STREAM_ENTRY_ID);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<StreamEntryID> xadd(String key, XAddParams params, Map<String, String> hash) {
/* 2260 */     return new CommandObject<>(addFlatMapArgs(commandArguments(Protocol.Command.XADD).key(key).addParams((IParams)params), hash), BuilderFactory.STREAM_ENTRY_ID);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> xlen(String key) {
/* 2265 */     return new CommandObject<>(commandArguments(Protocol.Command.XLEN).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> xadd(byte[] key, XAddParams params, Map<byte[], byte[]> hash) {
/* 2269 */     return (CommandObject)new CommandObject<>(addFlatMapArgs(commandArguments(Protocol.Command.XADD).key(key).addParams((IParams)params), hash), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> xlen(byte[] key) {
/* 2274 */     return new CommandObject<>(commandArguments(Protocol.Command.XLEN).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<StreamEntry>> xrange(String key, StreamEntryID start, StreamEntryID end) {
/* 2278 */     return new CommandObject<>(commandArguments(Protocol.Command.XRANGE).key(key).add((start == null) ? "-" : start).add((end == null) ? "+" : end), BuilderFactory.STREAM_ENTRY_LIST);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<StreamEntry>> xrange(String key, StreamEntryID start, StreamEntryID end, int count) {
/* 2283 */     return new CommandObject<>(commandArguments(Protocol.Command.XRANGE).key(key).add((start == null) ? "-" : start).add((end == null) ? "+" : end)
/* 2284 */         .add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.STREAM_ENTRY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<StreamEntry>> xrevrange(String key, StreamEntryID end, StreamEntryID start) {
/* 2288 */     return new CommandObject<>(commandArguments(Protocol.Command.XREVRANGE).key(key).add((end == null) ? "+" : end).add((start == null) ? "-" : start), BuilderFactory.STREAM_ENTRY_LIST);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<StreamEntry>> xrevrange(String key, StreamEntryID end, StreamEntryID start, int count) {
/* 2293 */     return new CommandObject<>(commandArguments(Protocol.Command.XREVRANGE).key(key).add((end == null) ? "+" : end).add((start == null) ? "-" : start)
/* 2294 */         .add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.STREAM_ENTRY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<StreamEntry>> xrange(String key, String start, String end) {
/* 2298 */     return new CommandObject<>(commandArguments(Protocol.Command.XRANGE).key(key).add(start).add(end), BuilderFactory.STREAM_ENTRY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<StreamEntry>> xrange(String key, String start, String end, int count) {
/* 2302 */     return new CommandObject<>(commandArguments(Protocol.Command.XRANGE).key(key).add(start).add(end).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.STREAM_ENTRY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<StreamEntry>> xrevrange(String key, String end, String start) {
/* 2306 */     return new CommandObject<>(commandArguments(Protocol.Command.XREVRANGE).key(key).add(end).add(start), BuilderFactory.STREAM_ENTRY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<StreamEntry>> xrevrange(String key, String end, String start, int count) {
/* 2310 */     return new CommandObject<>(commandArguments(Protocol.Command.XREVRANGE).key(key).add(end).add(start).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.STREAM_ENTRY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> xrange(byte[] key, byte[] start, byte[] end) {
/* 2314 */     return new CommandObject<>(commandArguments(Protocol.Command.XRANGE).key(key).add((start == null) ? "-" : start).add((end == null) ? "+" : end), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<byte[]>> xrange(byte[] key, byte[] start, byte[] end, int count) {
/* 2319 */     return new CommandObject<>(commandArguments(Protocol.Command.XRANGE).key(key).add((start == null) ? "-" : start).add((end == null) ? "+" : end)
/* 2320 */         .add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> xrevrange(byte[] key, byte[] end, byte[] start) {
/* 2324 */     return new CommandObject<>(commandArguments(Protocol.Command.XREVRANGE).key(key).add((end == null) ? "+" : end).add((start == null) ? "-" : start), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<byte[]>> xrevrange(byte[] key, byte[] end, byte[] start, int count) {
/* 2329 */     return new CommandObject<>(commandArguments(Protocol.Command.XREVRANGE).key(key).add((end == null) ? "+" : end).add((start == null) ? "-" : start)
/* 2330 */         .add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xack(String key, String group, StreamEntryID... ids) {
/* 2334 */     return new CommandObject<>(commandArguments(Protocol.Command.XACK).key(key).add(group).addObjects((Object[])ids), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xack(byte[] key, byte[] group, byte[]... ids) {
/* 2338 */     return new CommandObject<>(commandArguments(Protocol.Command.XACK).key(key).add(group).addObjects((Object[])ids), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<String> xgroupCreate(String key, String groupName, StreamEntryID id, boolean makeStream) {
/* 2343 */     CommandArguments args = commandArguments(Protocol.Command.XGROUP).add(Protocol.Keyword.CREATE).key(key).add(groupName).add((id == null) ? "0-0" : id);
/* 2344 */     if (makeStream) args.add(Protocol.Keyword.MKSTREAM); 
/* 2345 */     return new CommandObject<>(args, BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> xgroupSetID(String key, String groupName, StreamEntryID id) {
/* 2349 */     return new CommandObject<>(commandArguments(Protocol.Command.XGROUP).add(Protocol.Keyword.SETID)
/* 2350 */         .key(key).add(groupName).add(id), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xgroupDestroy(String key, String groupName) {
/* 2354 */     return new CommandObject<>(commandArguments(Protocol.Command.XGROUP).add(Protocol.Keyword.DESTROY)
/* 2355 */         .key(key).add(groupName), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> xgroupCreateConsumer(String key, String groupName, String consumerName) {
/* 2359 */     return new CommandObject<>(commandArguments(Protocol.Command.XGROUP).add(Protocol.Keyword.CREATECONSUMER)
/* 2360 */         .key(key).add(groupName).add(consumerName), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xgroupDelConsumer(String key, String groupName, String consumerName) {
/* 2364 */     return new CommandObject<>(commandArguments(Protocol.Command.XGROUP).add(Protocol.Keyword.DELCONSUMER)
/* 2365 */         .key(key).add(groupName).add(consumerName), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<String> xgroupCreate(byte[] key, byte[] groupName, byte[] id, boolean makeStream) {
/* 2370 */     CommandArguments args = commandArguments(Protocol.Command.XGROUP).add(Protocol.Keyword.CREATE).key(key).add(groupName).add(id);
/* 2371 */     if (makeStream) args.add(Protocol.Keyword.MKSTREAM); 
/* 2372 */     return new CommandObject<>(args, BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> xgroupSetID(byte[] key, byte[] groupName, byte[] id) {
/* 2376 */     return new CommandObject<>(commandArguments(Protocol.Command.XGROUP).add(Protocol.Keyword.SETID)
/* 2377 */         .key(key).add(groupName).add(id), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xgroupDestroy(byte[] key, byte[] groupName) {
/* 2381 */     return new CommandObject<>(commandArguments(Protocol.Command.XGROUP).add(Protocol.Keyword.DESTROY)
/* 2382 */         .key(key).add(groupName), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> xgroupCreateConsumer(byte[] key, byte[] groupName, byte[] consumerName) {
/* 2386 */     return new CommandObject<>(commandArguments(Protocol.Command.XGROUP).add(Protocol.Keyword.CREATECONSUMER)
/* 2387 */         .key(key).add(groupName).add(consumerName), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xgroupDelConsumer(byte[] key, byte[] groupName, byte[] consumerName) {
/* 2391 */     return new CommandObject<>(commandArguments(Protocol.Command.XGROUP).add(Protocol.Keyword.DELCONSUMER)
/* 2392 */         .key(key).add(groupName).add(consumerName), BuilderFactory.LONG);
/*      */   }
/*      */   public final CommandObject<Long> xdel(String key, StreamEntryID... ids) {
/* 2395 */     return new CommandObject<>(commandArguments(Protocol.Command.XDEL).key(key).addObjects((Object[])ids), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xtrim(String key, long maxLen, boolean approximate) {
/* 2399 */     CommandArguments args = commandArguments(Protocol.Command.XTRIM).key(key).add(Protocol.Keyword.MAXLEN);
/* 2400 */     if (approximate) args.add(Protocol.BYTES_TILDE); 
/* 2401 */     args.add(Long.valueOf(maxLen));
/* 2402 */     return new CommandObject<>(args, BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xtrim(String key, XTrimParams params) {
/* 2406 */     return new CommandObject<>(commandArguments(Protocol.Command.XTRIM).key(key).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xdel(byte[] key, byte[]... ids) {
/* 2410 */     return new CommandObject<>(commandArguments(Protocol.Command.XDEL).key(key).addObjects((Object[])ids), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xtrim(byte[] key, long maxLen, boolean approximateLength) {
/* 2414 */     CommandArguments args = commandArguments(Protocol.Command.XTRIM).key(key).add(Protocol.Keyword.MAXLEN);
/* 2415 */     if (approximateLength) args.add(Protocol.BYTES_TILDE); 
/* 2416 */     args.add(Long.valueOf(maxLen));
/* 2417 */     return new CommandObject<>(args, BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> xtrim(byte[] key, XTrimParams params) {
/* 2421 */     return new CommandObject<>(commandArguments(Protocol.Command.XTRIM).key(key).addParams((IParams)params), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<StreamPendingSummary> xpending(String key, String groupName) {
/* 2425 */     return new CommandObject<>(commandArguments(Protocol.Command.XPENDING).key(key).add(groupName), BuilderFactory.STREAM_PENDING_SUMMARY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final CommandObject<List<StreamPendingEntry>> xpending(String key, String groupName, StreamEntryID start, StreamEntryID end, int count, String consumerName) {
/* 2436 */     CommandArguments args = commandArguments(Protocol.Command.XPENDING).key(key).add(groupName).add((start == null) ? "-" : start).add((end == null) ? "+" : end).add(Integer.valueOf(count));
/* 2437 */     if (consumerName != null) args.add(consumerName); 
/* 2438 */     return new CommandObject<>(args, BuilderFactory.STREAM_PENDING_ENTRY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<StreamPendingEntry>> xpending(String key, String groupName, XPendingParams params) {
/* 2442 */     return new CommandObject<>(commandArguments(Protocol.Command.XPENDING).key(key).add(groupName)
/* 2443 */         .addParams((IParams)params), BuilderFactory.STREAM_PENDING_ENTRY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> xpending(byte[] key, byte[] groupName) {
/* 2447 */     return new CommandObject(commandArguments(Protocol.Command.XPENDING).key(key).add(groupName), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final CommandObject<List<Object>> xpending(byte[] key, byte[] groupName, byte[] start, byte[] end, int count, byte[] consumerName) {
/* 2458 */     CommandArguments args = commandArguments(Protocol.Command.XPENDING).key(key).add(groupName).add((start == null) ? "-" : start).add((end == null) ? "+" : end).add(Integer.valueOf(count));
/* 2459 */     if (consumerName != null) args.add(consumerName); 
/* 2460 */     return new CommandObject<>(args, BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Object>> xpending(byte[] key, byte[] groupName, XPendingParams params) {
/* 2464 */     return new CommandObject<>(commandArguments(Protocol.Command.XPENDING).key(key).add(groupName)
/* 2465 */         .addParams((IParams)params), BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<StreamEntry>> xclaim(String key, String group, String consumerName, long minIdleTime, XClaimParams params, StreamEntryID... ids) {
/* 2470 */     return new CommandObject<>(commandArguments(Protocol.Command.XCLAIM).key(key).add(group)
/* 2471 */         .add(consumerName).add(Long.valueOf(minIdleTime)).addObjects((Object[])ids).addParams((IParams)params), BuilderFactory.STREAM_ENTRY_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<List<StreamEntryID>> xclaimJustId(String key, String group, String consumerName, long minIdleTime, XClaimParams params, StreamEntryID... ids) {
/* 2477 */     return new CommandObject<>(commandArguments(Protocol.Command.XCLAIM).key(key).add(group)
/* 2478 */         .add(consumerName).add(Long.valueOf(minIdleTime)).addObjects((Object[])ids).addParams((IParams)params)
/* 2479 */         .add(Protocol.Keyword.JUSTID), BuilderFactory.STREAM_ENTRY_ID_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Map.Entry<StreamEntryID, List<StreamEntry>>> xautoclaim(String key, String group, String consumerName, long minIdleTime, StreamEntryID start, XAutoClaimParams params) {
/* 2485 */     return new CommandObject<>(commandArguments(Protocol.Command.XAUTOCLAIM).key(key).add(group)
/* 2486 */         .add(consumerName).add(Long.valueOf(minIdleTime)).add(start).addParams((IParams)params), BuilderFactory.STREAM_AUTO_CLAIM_RESPONSE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Map.Entry<StreamEntryID, List<StreamEntryID>>> xautoclaimJustId(String key, String group, String consumerName, long minIdleTime, StreamEntryID start, XAutoClaimParams params) {
/* 2493 */     return new CommandObject<>(commandArguments(Protocol.Command.XAUTOCLAIM).key(key).add(group)
/* 2494 */         .add(consumerName).add(Long.valueOf(minIdleTime)).add(start).addParams((IParams)params)
/* 2495 */         .add(Protocol.Keyword.JUSTID), BuilderFactory.STREAM_AUTO_CLAIM_ID_RESPONSE);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<byte[]>> xclaim(byte[] key, byte[] group, byte[] consumerName, long minIdleTime, XClaimParams params, byte[]... ids) {
/* 2500 */     return new CommandObject<>(commandArguments(Protocol.Command.XCLAIM).key(key).add(group)
/* 2501 */         .add(consumerName).add(Long.valueOf(minIdleTime)).addObjects((Object[])ids).addParams((IParams)params), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<List<byte[]>> xclaimJustId(byte[] key, byte[] group, byte[] consumerName, long minIdleTime, XClaimParams params, byte[]... ids) {
/* 2507 */     return new CommandObject<>(commandArguments(Protocol.Command.XCLAIM).key(key).add(group)
/* 2508 */         .add(consumerName).add(Long.valueOf(minIdleTime)).addObjects((Object[])ids).addParams((IParams)params)
/* 2509 */         .add(Protocol.Keyword.JUSTID), BuilderFactory.BINARY_LIST);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<Object>> xautoclaim(byte[] key, byte[] groupName, byte[] consumerName, long minIdleTime, byte[] start, XAutoClaimParams params) {
/* 2514 */     return new CommandObject<>(commandArguments(Protocol.Command.XAUTOCLAIM).key(key).add(groupName)
/* 2515 */         .add(consumerName).add(Long.valueOf(minIdleTime)).add(start).addParams((IParams)params), BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<List<Object>> xautoclaimJustId(byte[] key, byte[] groupName, byte[] consumerName, long minIdleTime, byte[] start, XAutoClaimParams params) {
/* 2521 */     return new CommandObject<>(commandArguments(Protocol.Command.XAUTOCLAIM).key(key).add(groupName)
/* 2522 */         .add(consumerName).add(Long.valueOf(minIdleTime)).add(start).addParams((IParams)params)
/* 2523 */         .add(Protocol.Keyword.JUSTID), BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<StreamInfo> xinfoStream(String key) {
/* 2527 */     return new CommandObject<>(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.STREAM).key(key), BuilderFactory.STREAM_INFO);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> xinfoStream(byte[] key) {
/* 2531 */     return new CommandObject(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.STREAM).key(key), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<StreamFullInfo> xinfoStreamFull(String key) {
/* 2535 */     return new CommandObject<>(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.STREAM).key(key).add(Protocol.Keyword.FULL), BuilderFactory.STREAM_INFO_FULL);
/*      */   }
/*      */   
/*      */   public final CommandObject<StreamFullInfo> xinfoStreamFull(String key, int count) {
/* 2539 */     return new CommandObject<>(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.STREAM).key(key).add(Protocol.Keyword.FULL).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.STREAM_INFO_FULL);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> xinfoStreamFull(byte[] key, int count) {
/* 2543 */     return new CommandObject(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.STREAM).key(key).add(Protocol.Keyword.FULL).add(Protocol.Keyword.COUNT).add(Integer.valueOf(count)), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> xinfoStreamFull(byte[] key) {
/* 2547 */     return new CommandObject(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.STREAM).key(key).add(Protocol.Keyword.FULL), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public final CommandObject<List<StreamGroupInfo>> xinfoGroup(String key) {
/* 2552 */     return new CommandObject<>(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.GROUPS).key(key), BuilderFactory.STREAM_GROUP_INFO_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<StreamGroupInfo>> xinfoGroups(String key) {
/* 2556 */     return new CommandObject<>(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.GROUPS).key(key), BuilderFactory.STREAM_GROUP_INFO_LIST);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public final CommandObject<List<Object>> xinfoGroup(byte[] key) {
/* 2561 */     return new CommandObject<>(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.GROUPS).key(key), BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Object>> xinfoGroups(byte[] key) {
/* 2565 */     return new CommandObject<>(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.GROUPS).key(key), BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<StreamConsumersInfo>> xinfoConsumers(String key, String group) {
/* 2569 */     return new CommandObject<>(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.CONSUMERS).key(key).add(group), BuilderFactory.STREAM_CONSUMERS_INFO_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Object>> xinfoConsumers(byte[] key, byte[] group) {
/* 2573 */     return new CommandObject<>(commandArguments(Protocol.Command.XINFO).add(Protocol.Keyword.CONSUMERS).key(key).add(group), BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<Map.Entry<String, List<StreamEntry>>>> xread(XReadParams xReadParams, Map<String, StreamEntryID> streams) {
/* 2578 */     CommandArguments args = commandArguments(Protocol.Command.XREAD).addParams((IParams)xReadParams).add(Protocol.Keyword.STREAMS);
/* 2579 */     Set<Map.Entry<String, StreamEntryID>> entrySet = streams.entrySet();
/* 2580 */     entrySet.forEach(entry -> args.key(entry.getKey()));
/* 2581 */     entrySet.forEach(entry -> args.add(entry.getValue()));
/* 2582 */     return new CommandObject<>(args, BuilderFactory.STREAM_READ_RESPONSE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<List<Map.Entry<String, List<StreamEntry>>>> xreadGroup(String groupName, String consumer, XReadGroupParams xReadGroupParams, Map<String, StreamEntryID> streams) {
/* 2590 */     CommandArguments args = commandArguments(Protocol.Command.XREADGROUP).add(Protocol.Keyword.GROUP).add(groupName).add(consumer).addParams((IParams)xReadGroupParams).add(Protocol.Keyword.STREAMS);
/* 2591 */     Set<Map.Entry<String, StreamEntryID>> entrySet = streams.entrySet();
/* 2592 */     entrySet.forEach(entry -> args.key(entry.getKey()));
/* 2593 */     entrySet.forEach(entry -> args.add(entry.getValue()));
/* 2594 */     return new CommandObject<>(args, BuilderFactory.STREAM_READ_RESPONSE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<byte[]>> xread(XReadParams xReadParams, Map.Entry<byte[], byte[]>... streams) {
/* 2598 */     CommandArguments args = commandArguments(Protocol.Command.XREAD).addParams((IParams)xReadParams).add(Protocol.Keyword.STREAMS);
/* 2599 */     for (Map.Entry<byte[], byte[]> entry : streams) {
/* 2600 */       args.key(entry.getKey());
/*      */     }
/* 2602 */     for (Map.Entry<byte[], byte[]> entry : streams) {
/* 2603 */       args.add(entry.getValue());
/*      */     }
/* 2605 */     return new CommandObject<>(args, BuilderFactory.BINARY_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<List<byte[]>> xreadGroup(byte[] groupName, byte[] consumer, XReadGroupParams xReadGroupParams, Map.Entry<byte[], byte[]>... streams) {
/* 2612 */     CommandArguments args = commandArguments(Protocol.Command.XREADGROUP).add(Protocol.Keyword.GROUP).add(groupName).add(consumer).addParams((IParams)xReadGroupParams).add(Protocol.Keyword.STREAMS);
/* 2613 */     for (Map.Entry<byte[], byte[]> entry : streams) {
/* 2614 */       args.key(entry.getKey());
/*      */     }
/* 2616 */     for (Map.Entry<byte[], byte[]> entry : streams) {
/* 2617 */       args.add(entry.getValue());
/*      */     }
/* 2619 */     return new CommandObject<>(args, BuilderFactory.BINARY_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> eval(String script) {
/* 2625 */     return new CommandObject(commandArguments(Protocol.Command.EVAL).add(script).add(Integer.valueOf(0)), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> eval(String script, String sampleKey) {
/* 2629 */     return new CommandObject(commandArguments(Protocol.Command.EVAL).add(script).add(Integer.valueOf(0)).processKey(sampleKey), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> eval(String script, int keyCount, String... params) {
/* 2633 */     return new CommandObject(commandArguments(Protocol.Command.EVAL).add(script).add(Integer.valueOf(keyCount))
/* 2634 */         .addObjects((Object[])params).processKeys(Arrays.<String>copyOf(params, keyCount)), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> eval(String script, List<String> keys, List<String> args) {
/* 2639 */     String[] keysArray = keys.<String>toArray(new String[keys.size()]);
/* 2640 */     String[] argsArray = args.<String>toArray(new String[args.size()]);
/* 2641 */     return new CommandObject(commandArguments(Protocol.Command.EVAL).add(script).add(Integer.valueOf(keysArray.length))
/* 2642 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> evalReadonly(String script, List<String> keys, List<String> args) {
/* 2647 */     String[] keysArray = keys.<String>toArray(new String[keys.size()]);
/* 2648 */     String[] argsArray = args.<String>toArray(new String[args.size()]);
/* 2649 */     return new CommandObject(commandArguments(Protocol.Command.EVAL_RO).add(script).add(Integer.valueOf(keysArray.length))
/* 2650 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> eval(byte[] script) {
/* 2655 */     return new CommandObject(commandArguments(Protocol.Command.EVAL).add(script).add(Integer.valueOf(0)), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> eval(byte[] script, byte[] sampleKey) {
/* 2659 */     return new CommandObject(commandArguments(Protocol.Command.EVAL).add(script).add(Integer.valueOf(0)).processKey(sampleKey), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> eval(byte[] script, int keyCount, byte[]... params) {
/* 2663 */     return new CommandObject(commandArguments(Protocol.Command.EVAL).add(script).add(Integer.valueOf(keyCount))
/* 2664 */         .addObjects((Object[])params).processKeys(Arrays.<byte[]>copyOf(params, keyCount)), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> eval(byte[] script, List<byte[]> keys, List<byte[]> args) {
/* 2669 */     byte[][] keysArray = keys.<byte[]>toArray(new byte[keys.size()][]);
/* 2670 */     byte[][] argsArray = args.<byte[]>toArray(new byte[args.size()][]);
/* 2671 */     return new CommandObject(commandArguments(Protocol.Command.EVAL).add(script).add(Integer.valueOf(keysArray.length))
/* 2672 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> evalReadonly(byte[] script, List<byte[]> keys, List<byte[]> args) {
/* 2677 */     byte[][] keysArray = keys.<byte[]>toArray(new byte[keys.size()][]);
/* 2678 */     byte[][] argsArray = args.<byte[]>toArray(new byte[args.size()][]);
/* 2679 */     return new CommandObject(commandArguments(Protocol.Command.EVAL_RO).add(script).add(Integer.valueOf(keysArray.length))
/* 2680 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> evalsha(String sha1) {
/* 2685 */     return new CommandObject(commandArguments(Protocol.Command.EVALSHA).add(sha1).add(Integer.valueOf(0)), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> evalsha(String sha1, String sampleKey) {
/* 2689 */     return new CommandObject(commandArguments(Protocol.Command.EVALSHA).add(sha1).add(Integer.valueOf(0)).processKey(sampleKey), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> evalsha(String sha1, int keyCount, String... params) {
/* 2693 */     return new CommandObject(commandArguments(Protocol.Command.EVALSHA).add(sha1).add(Integer.valueOf(keyCount))
/* 2694 */         .addObjects((Object[])params).processKeys(Arrays.<String>copyOf(params, keyCount)), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> evalsha(String sha1, List<String> keys, List<String> args) {
/* 2699 */     String[] keysArray = keys.<String>toArray(new String[keys.size()]);
/* 2700 */     String[] argsArray = args.<String>toArray(new String[args.size()]);
/* 2701 */     return new CommandObject(commandArguments(Protocol.Command.EVALSHA).add(sha1).add(Integer.valueOf(keysArray.length))
/* 2702 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> evalshaReadonly(String sha1, List<String> keys, List<String> args) {
/* 2707 */     String[] keysArray = keys.<String>toArray(new String[keys.size()]);
/* 2708 */     String[] argsArray = args.<String>toArray(new String[args.size()]);
/* 2709 */     return new CommandObject(commandArguments(Protocol.Command.EVALSHA_RO).add(sha1).add(Integer.valueOf(keysArray.length))
/* 2710 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> evalsha(byte[] sha1) {
/* 2715 */     return new CommandObject(commandArguments(Protocol.Command.EVALSHA).add(sha1).add(Integer.valueOf(0)), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> evalsha(byte[] sha1, byte[] sampleKey) {
/* 2719 */     return new CommandObject(commandArguments(Protocol.Command.EVALSHA).add(sha1).add(Integer.valueOf(0)).processKey(sampleKey), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> evalsha(byte[] sha1, int keyCount, byte[]... params) {
/* 2723 */     return new CommandObject(commandArguments(Protocol.Command.EVALSHA).add(sha1).add(Integer.valueOf(keyCount))
/* 2724 */         .addObjects((Object[])params).processKeys(Arrays.<byte[]>copyOf(params, keyCount)), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> evalsha(byte[] sha1, List<byte[]> keys, List<byte[]> args) {
/* 2729 */     byte[][] keysArray = keys.<byte[]>toArray(new byte[keys.size()][]);
/* 2730 */     byte[][] argsArray = args.<byte[]>toArray(new byte[args.size()][]);
/* 2731 */     return new CommandObject(commandArguments(Protocol.Command.EVALSHA).add(sha1).add(Integer.valueOf(keysArray.length))
/* 2732 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> evalshaReadonly(byte[] sha1, List<byte[]> keys, List<byte[]> args) {
/* 2737 */     byte[][] keysArray = keys.<byte[]>toArray(new byte[keys.size()][]);
/* 2738 */     byte[][] argsArray = args.<byte[]>toArray(new byte[args.size()][]);
/* 2739 */     return new CommandObject(commandArguments(Protocol.Command.EVALSHA_RO).add(sha1).add(Integer.valueOf(keysArray.length))
/* 2740 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<Boolean>> scriptExists(String sampleKey, String... sha1s) {
/* 2745 */     return new CommandObject<>(commandArguments(Protocol.Command.SCRIPT).add(Protocol.Keyword.EXISTS).addObjects((Object[])sha1s)
/* 2746 */         .processKey(sampleKey), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> scriptLoad(String script, String sampleKey) {
/* 2750 */     return new CommandObject<>(commandArguments(Protocol.Command.SCRIPT).add(Protocol.Keyword.LOAD).add(script).processKey(sampleKey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> scriptFlush(String sampleKey) {
/* 2754 */     return new CommandObject<>(commandArguments(Protocol.Command.SCRIPT).add(Protocol.Keyword.FLUSH).processKey(sampleKey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> scriptFlush(String sampleKey, FlushMode flushMode) {
/* 2758 */     return new CommandObject<>(commandArguments(Protocol.Command.SCRIPT).add(Protocol.Keyword.FLUSH).add(flushMode).processKey(sampleKey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> scriptKill(String sampleKey) {
/* 2762 */     return new CommandObject<>(commandArguments(Protocol.Command.SCRIPT).add(Protocol.Keyword.KILL).processKey(sampleKey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> scriptExists(byte[] sampleKey, byte[]... sha1s) {
/* 2766 */     return new CommandObject<>(commandArguments(Protocol.Command.SCRIPT).add(Protocol.Keyword.EXISTS).addObjects((Object[])sha1s)
/* 2767 */         .processKey(sampleKey), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> scriptLoad(byte[] script, byte[] sampleKey) {
/* 2771 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.SCRIPT).add(Protocol.Keyword.LOAD).add(script).processKey(sampleKey), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> scriptFlush(byte[] sampleKey) {
/* 2775 */     return new CommandObject<>(commandArguments(Protocol.Command.SCRIPT).add(Protocol.Keyword.FLUSH).processKey(sampleKey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> scriptFlush(byte[] sampleKey, FlushMode flushMode) {
/* 2779 */     return new CommandObject<>(commandArguments(Protocol.Command.SCRIPT).add(Protocol.Keyword.FLUSH).add(flushMode).processKey(sampleKey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> scriptKill(byte[] sampleKey) {
/* 2783 */     return new CommandObject<>(commandArguments(Protocol.Command.SCRIPT).add(Protocol.Keyword.KILL).processKey(sampleKey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> fcall(String name, List<String> keys, List<String> args) {
/* 2787 */     String[] keysArray = keys.<String>toArray(new String[keys.size()]);
/* 2788 */     String[] argsArray = args.<String>toArray(new String[args.size()]);
/* 2789 */     return new CommandObject(commandArguments(Protocol.Command.FCALL).add(name).add(Integer.valueOf(keysArray.length))
/* 2790 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> fcallReadonly(String name, List<String> keys, List<String> args) {
/* 2795 */     String[] keysArray = keys.<String>toArray(new String[keys.size()]);
/* 2796 */     String[] argsArray = args.<String>toArray(new String[args.size()]);
/* 2797 */     return new CommandObject(commandArguments(Protocol.Command.FCALL_RO).add(name).add(Integer.valueOf(keysArray.length))
/* 2798 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.ENCODED_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<String> functionDelete(String libraryName) {
/* 2803 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.DELETE).add(libraryName), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<LibraryInfo>> functionList() {
/* 2807 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LIST), BuilderFactory.LIBRARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<LibraryInfo>> functionList(String libraryNamePattern) {
/* 2811 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LIST).add(Protocol.Keyword.LIBRARYNAME)
/* 2812 */         .add(libraryNamePattern), BuilderFactory.LIBRARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<LibraryInfo>> functionListWithCode() {
/* 2816 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LIST).add(Protocol.Keyword.WITHCODE), BuilderFactory.LIBRARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<LibraryInfo>> functionListWithCode(String libraryNamePattern) {
/* 2820 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LIST).add(Protocol.Keyword.LIBRARYNAME)
/* 2821 */         .add(libraryNamePattern).add(Protocol.Keyword.WITHCODE), BuilderFactory.LIBRARY_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> functionLoad(String engineName, String libraryName, String functionCode) {
/* 2825 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LOAD).add(engineName)
/* 2826 */         .add(libraryName).add(functionCode), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> functionLoad(String engineName, String libraryName, FunctionLoadParams params, String functionCode) {
/* 2830 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LOAD).add(engineName)
/* 2831 */         .add(libraryName).addParams((IParams)params).add(functionCode), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<FunctionStats> functionStats() {
/* 2835 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.STATS), FunctionStats.FUNCTION_STATS_BUILDER);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> functionStatsBinary() {
/* 2839 */     return new CommandObject(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.STATS), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> functionFlush() {
/* 2843 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.FLUSH), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> functionFlush(FlushMode mode) {
/* 2847 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.FLUSH).add(mode), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> functionKill() {
/* 2851 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.KILL), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> fcall(byte[] name, List<byte[]> keys, List<byte[]> args) {
/* 2855 */     byte[][] keysArray = keys.<byte[]>toArray(new byte[keys.size()][]);
/* 2856 */     byte[][] argsArray = args.<byte[]>toArray(new byte[args.size()][]);
/* 2857 */     return new CommandObject(commandArguments(Protocol.Command.FCALL).add(name).add(Integer.valueOf(keysArray.length))
/* 2858 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Object> fcallReadonly(byte[] name, List<byte[]> keys, List<byte[]> args) {
/* 2863 */     byte[][] keysArray = keys.<byte[]>toArray(new byte[keys.size()][]);
/* 2864 */     byte[][] argsArray = args.<byte[]>toArray(new byte[args.size()][]);
/* 2865 */     return new CommandObject(commandArguments(Protocol.Command.FCALL_RO).add(name).add(Integer.valueOf(keysArray.length))
/* 2866 */         .keys((Object[])keysArray).addObjects((Object[])argsArray), BuilderFactory.RAW_OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<String> functionDelete(byte[] libraryName) {
/* 2871 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.DELETE).add(libraryName), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> functionDump() {
/* 2875 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.DUMP), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Object>> functionListBinary() {
/* 2879 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LIST), BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Object>> functionList(byte[] libraryNamePattern) {
/* 2883 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LIST).add(Protocol.Keyword.LIBRARYNAME)
/* 2884 */         .add(libraryNamePattern), BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Object>> functionListWithCodeBinary() {
/* 2888 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LIST).add(Protocol.Keyword.WITHCODE), BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Object>> functionListWithCode(byte[] libraryNamePattern) {
/* 2892 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LIST).add(Protocol.Keyword.LIBRARYNAME)
/* 2893 */         .add(libraryNamePattern).add(Protocol.Keyword.WITHCODE), BuilderFactory.RAW_OBJECT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> functionLoad(byte[] engineName, byte[] libraryName, byte[] functionCode) {
/* 2897 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LOAD).add(engineName)
/* 2898 */         .add(libraryName).add(functionCode), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> functionLoad(byte[] engineName, byte[] libraryName, FunctionLoadParams params, byte[] functionCode) {
/* 2902 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Keyword.LOAD).add(engineName)
/* 2903 */         .add(libraryName).addParams((IParams)params).add(functionCode), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> functionRestore(byte[] serializedValue) {
/* 2907 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Command.RESTORE).add(serializedValue), BuilderFactory.STRING);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<String> functionRestore(byte[] serializedValue, FunctionRestorePolicy policy) {
/* 2912 */     return new CommandObject<>(commandArguments(Protocol.Command.FUNCTION).add(Protocol.Command.RESTORE).add(serializedValue)
/* 2913 */         .add(policy.getRaw()), BuilderFactory.STRING);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final CommandObject<LCSMatchResult> strAlgoLCSStrings(String strA, String strB, StrAlgoLCSParams params) {
/* 2920 */     return new CommandObject<>(commandArguments(Protocol.Command.STRALGO).add(Protocol.Keyword.LCS).add(Protocol.Keyword.STRINGS)
/* 2921 */         .add(strA).add(strB).addParams((IParams)params), BuilderFactory.STR_ALGO_LCS_RESULT_BUILDER);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final CommandObject<LCSMatchResult> strAlgoLCSStrings(byte[] strA, byte[] strB, StrAlgoLCSParams params) {
/* 2927 */     return new CommandObject<>(commandArguments(Protocol.Command.STRALGO).add(Protocol.Keyword.LCS).add(Protocol.Keyword.STRINGS)
/* 2928 */         .add(strA).add(strB).addParams((IParams)params), BuilderFactory.STR_ALGO_LCS_RESULT_BUILDER);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Boolean> copy(String srcKey, String dstKey, int dstDB, boolean replace) {
/* 2933 */     CommandArguments args = commandArguments(Protocol.Command.COPY).key(srcKey).key(dstKey).add(Protocol.Keyword.DB).add(Integer.valueOf(dstDB));
/* 2934 */     if (replace) args.add(Protocol.Keyword.REPLACE); 
/* 2935 */     return new CommandObject<>(args, BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> copy(byte[] srcKey, byte[] dstKey, int dstDB, boolean replace) {
/* 2939 */     CommandArguments args = commandArguments(Protocol.Command.COPY).key(srcKey).key(dstKey).add(Protocol.Keyword.DB).add(Integer.valueOf(dstDB));
/* 2940 */     if (replace) args.add(Protocol.Keyword.REPLACE); 
/* 2941 */     return new CommandObject<>(args, BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> migrate(String host, int port, String key, int timeout) {
/* 2945 */     return migrate(host, port, key, 0, timeout);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> migrate(String host, int port, String key, int destinationDB, int timeout) {
/* 2949 */     return new CommandObject<>(commandArguments(Protocol.Command.MIGRATE).add(host).add(Integer.valueOf(port)).key(key)
/* 2950 */         .add(Integer.valueOf(destinationDB)).add(Integer.valueOf(timeout)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> migrate(String host, int port, int timeout, MigrateParams params, String... keys) {
/* 2954 */     return migrate(host, port, 0, timeout, params, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<String> migrate(String host, int port, int destinationDB, int timeout, MigrateParams params, String... keys) {
/* 2959 */     return new CommandObject<>(commandArguments(Protocol.Command.MIGRATE).add(host).add(Integer.valueOf(port)).add(new byte[0])
/* 2960 */         .add(Integer.valueOf(destinationDB)).add(Integer.valueOf(timeout)).addParams((IParams)params).add(Protocol.Keyword.KEYS).keys((Object[])keys), BuilderFactory.STRING);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<String> migrate(String host, int port, byte[] key, int timeout) {
/* 2965 */     return migrate(host, port, key, 0, timeout);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> migrate(String host, int port, byte[] key, int destinationDB, int timeout) {
/* 2969 */     return new CommandObject<>(commandArguments(Protocol.Command.MIGRATE).add(host).add(Integer.valueOf(port)).key(key)
/* 2970 */         .add(Integer.valueOf(destinationDB)).add(Integer.valueOf(timeout)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> migrate(String host, int port, int timeout, MigrateParams params, byte[]... keys) {
/* 2974 */     return migrate(host, port, 0, timeout, params, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<String> migrate(String host, int port, int destinationDB, int timeout, MigrateParams params, byte[]... keys) {
/* 2979 */     return new CommandObject<>(commandArguments(Protocol.Command.MIGRATE).add(host).add(Integer.valueOf(port)).add(new byte[0])
/* 2980 */         .add(Integer.valueOf(destinationDB)).add(Integer.valueOf(timeout)).addParams((IParams)params).add(Protocol.Keyword.KEYS).keys((Object[])keys), BuilderFactory.STRING);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<Long> memoryUsage(String key) {
/* 2985 */     return new CommandObject<>(commandArguments(Protocol.Command.MEMORY).add(Protocol.Keyword.USAGE).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> memoryUsage(String key, int samples) {
/* 2989 */     return new CommandObject<>(commandArguments(Protocol.Command.MEMORY).add(Protocol.Keyword.USAGE).key(key).add(Protocol.Keyword.SAMPLES).add(Integer.valueOf(samples)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> memoryUsage(byte[] key) {
/* 2993 */     return new CommandObject<>(commandArguments(Protocol.Command.MEMORY).add(Protocol.Keyword.USAGE).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> memoryUsage(byte[] key, int samples) {
/* 2997 */     return new CommandObject<>(commandArguments(Protocol.Command.MEMORY).add(Protocol.Keyword.USAGE).key(key).add(Protocol.Keyword.SAMPLES).add(Integer.valueOf(samples)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> objectRefcount(String key) {
/* 3001 */     return new CommandObject<>(commandArguments(Protocol.Command.OBJECT).add(Protocol.Keyword.REFCOUNT).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> objectEncoding(String key) {
/* 3005 */     return new CommandObject<>(commandArguments(Protocol.Command.OBJECT).add(Protocol.Keyword.ENCODING).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> objectIdletime(String key) {
/* 3009 */     return new CommandObject<>(commandArguments(Protocol.Command.OBJECT).add(Protocol.Keyword.IDLETIME).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> objectFreq(String key) {
/* 3013 */     return new CommandObject<>(commandArguments(Protocol.Command.OBJECT).add(Protocol.Keyword.FREQ).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> objectRefcount(byte[] key) {
/* 3017 */     return new CommandObject<>(commandArguments(Protocol.Command.OBJECT).add(Protocol.Keyword.REFCOUNT).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<byte[]> objectEncoding(byte[] key) {
/* 3021 */     return (CommandObject)new CommandObject<>(commandArguments(Protocol.Command.OBJECT).add(Protocol.Keyword.ENCODING).key(key), (Builder)BuilderFactory.BINARY);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> objectIdletime(byte[] key) {
/* 3025 */     return new CommandObject<>(commandArguments(Protocol.Command.OBJECT).add(Protocol.Keyword.IDLETIME).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> objectFreq(byte[] key) {
/* 3029 */     return new CommandObject<>(commandArguments(Protocol.Command.OBJECT).add(Protocol.Keyword.FREQ).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public CommandObject<Long> waitReplicas(int replicas, long timeout) {
/* 3033 */     return new CommandObject<>(commandArguments(Protocol.Command.WAIT).add(Integer.valueOf(replicas)).add(Long.valueOf(timeout)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> waitReplicas(String sampleKey, int replicas, long timeout) {
/* 3037 */     return new CommandObject<>(commandArguments(Protocol.Command.WAIT).add(Integer.valueOf(replicas)).add(Long.valueOf(timeout)).processKey(sampleKey), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> waitReplicas(byte[] sampleKey, int replicas, long timeout) {
/* 3041 */     return new CommandObject<>(commandArguments(Protocol.Command.WAIT).add(Integer.valueOf(replicas)).add(Long.valueOf(timeout)).processKey(sampleKey), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> publish(String channel, String message) {
/* 3045 */     return new CommandObject<>(commandArguments(Protocol.Command.PUBLISH).add(channel).add(message), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> publish(byte[] channel, byte[] message) {
/* 3049 */     return new CommandObject<>(commandArguments(Protocol.Command.PUBLISH).add(channel).add(message), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CommandObject<String> ftCreate(String indexName, IndexOptions indexOptions, Schema schema) {
/* 3056 */     CommandArguments args = commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.CREATE).add(indexName).addParams((IParams)indexOptions).add(SearchProtocol.SearchKeyword.SCHEMA);
/* 3057 */     schema.fields.forEach(field -> field.addParams(args));
/* 3058 */     return new CommandObject<>(args, BuilderFactory.STRING);
/*      */   }
/*      */ 
/*      */   
/*      */   public CommandObject<String> ftAlter(String indexName, Schema schema) {
/* 3063 */     CommandArguments args = commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.ALTER).add(indexName).add(SearchProtocol.SearchKeyword.SCHEMA).add(SearchProtocol.SearchKeyword.ADD);
/* 3064 */     schema.fields.forEach(field -> field.addParams(args));
/* 3065 */     return new CommandObject<>(args, BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public CommandObject<SearchResult> ftSearch(String indexName, Query query) {
/* 3069 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.SEARCH).add(indexName).addParams((IParams)query), (Builder<SearchResult>)new SearchResult.SearchResultBuilder(
/* 3070 */           !query.getNoContent(), query.getWithScores(), query.getWithPayloads(), true));
/*      */   }
/*      */   
/*      */   public CommandObject<SearchResult> ftSearch(byte[] indexName, Query query) {
/* 3074 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.SEARCH).add(indexName).addParams((IParams)query), (Builder<SearchResult>)new SearchResult.SearchResultBuilder(
/* 3075 */           !query.getNoContent(), query.getWithScores(), query.getWithPayloads(), false));
/*      */   }
/*      */   
/*      */   public CommandObject<String> ftExplain(String indexName, Query query) {
/* 3079 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.EXPLAIN).add(indexName).addParams((IParams)query), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public CommandObject<List<String>> ftExplainCLI(String indexName, Query query) {
/* 3083 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.EXPLAINCLI).add(indexName).addParams((IParams)query), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public CommandObject<AggregationResult> ftAggregate(String indexName, AggregationBuilder aggr) {
/* 3087 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.AGGREGATE).add(indexName).addObjects(aggr.getArgs()), 
/* 3088 */         !aggr.isWithCursor() ? BuilderFactory.SEARCH_AGGREGATION_RESULT : BuilderFactory.SEARCH_AGGREGATION_RESULT_WITH_CURSOR);
/*      */   }
/*      */   
/*      */   public CommandObject<AggregationResult> ftCursorRead(String indexName, long cursorId, int count) {
/* 3092 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.CURSOR).add(SearchProtocol.SearchKeyword.READ)
/* 3093 */         .add(indexName).add(Long.valueOf(cursorId)).add(Integer.valueOf(count)), BuilderFactory.SEARCH_AGGREGATION_RESULT_WITH_CURSOR);
/*      */   }
/*      */   
/*      */   public CommandObject<String> ftCursorDel(String indexName, long cursorId) {
/* 3097 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.CURSOR).add(SearchProtocol.SearchKeyword.DEL)
/* 3098 */         .add(indexName).add(Long.valueOf(cursorId)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public CommandObject<String> ftDropIndex(String indexName) {
/* 3102 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.DROPINDEX).add(indexName), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public CommandObject<String> ftDropIndexDD(String indexName) {
/* 3106 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.DROPINDEX).add(indexName).add(SearchProtocol.SearchKeyword.DD), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public CommandObject<String> ftSynUpdate(String indexName, String synonymGroupId, String... terms) {
/* 3110 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.SYNUPDATE).add(indexName)
/* 3111 */         .add(synonymGroupId).addObjects((Object[])terms), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public CommandObject<Map<String, List<String>>> ftSynDump(String indexName) {
/* 3115 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.SYNDUMP).add(indexName), BuilderFactory.SEARCH_SYNONYM_GROUPS);
/*      */   }
/*      */   
/*      */   public CommandObject<Map<String, Object>> ftInfo(String indexName) {
/* 3119 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.INFO).add(indexName), BuilderFactory.ENCODED_OBJECT_MAP);
/*      */   }
/*      */   
/*      */   public CommandObject<String> ftAliasAdd(String aliasName, String indexName) {
/* 3123 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.ALIASADD).add(aliasName).add(indexName), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public CommandObject<String> ftAliasUpdate(String aliasName, String indexName) {
/* 3127 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.ALIASUPDATE).add(aliasName).add(indexName), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public CommandObject<String> ftAliasDel(String aliasName) {
/* 3131 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.ALIASDEL).add(aliasName), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Map<String, String>> ftConfigGet(String option) {
/* 3135 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.CONFIG).add(SearchProtocol.SearchKeyword.GET).add(option), BuilderFactory.STRING_MAP_FROM_PAIRS);
/*      */   }
/*      */   
/*      */   public CommandObject<Map<String, String>> ftConfigGet(String indexName, String option) {
/* 3139 */     return ftConfigGet(option);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> ftConfigSet(String option, String value) {
/* 3143 */     return new CommandObject<>(commandArguments((ProtocolCommand)SearchProtocol.SearchCommand.CONFIG).add(SearchProtocol.SearchKeyword.SET).add(option).add(value), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public CommandObject<String> ftConfigSet(String indexName, String option, String value) {
/* 3147 */     return ftConfigSet(option, value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<String> jsonSet(String key, Path2 path, Object object) {
/* 3153 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.SET).key(key).add(path).add(object), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> jsonSetWithEscape(String key, Path2 path, Object object) {
/* 3157 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.SET).key(key).add(path).add(GSON.toJson(object)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> jsonSet(String key, Path path, Object pojo) {
/* 3161 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.SET).key(key).add(path).add(GSON.toJson(pojo)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> jsonSet(String key, Path2 path, Object object, JsonSetParams params) {
/* 3165 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.SET).key(key).add(path).add(object).addParams((IParams)params), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> jsonSetWithEscape(String key, Path2 path, Object object, JsonSetParams params) {
/* 3169 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.SET).key(key).add(path).add(GSON.toJson(object)).addParams((IParams)params), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> jsonSet(String key, Path path, Object pojo, JsonSetParams params) {
/* 3173 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.SET).key(key).add(path).add(GSON.toJson(pojo)).addParams((IParams)params), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> jsonGet(String key) {
/* 3177 */     return new CommandObject(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.GET).key(key), new GsonObjectBuilder(Object.class));
/*      */   }
/*      */   
/*      */   public final <T> CommandObject<T> jsonGet(String key, Class<T> clazz) {
/* 3181 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.GET).key(key), new GsonObjectBuilder<>(clazz));
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> jsonGet(String key, Path2... paths) {
/* 3185 */     return new CommandObject(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.GET).key(key).addObjects((Object[])paths), BuilderFactory.JSON_OBJECT);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> jsonGet(String key, Path... paths) {
/* 3189 */     return new CommandObject(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.GET).key(key).addObjects((Object[])paths), new GsonObjectBuilder(Object.class));
/*      */   }
/*      */   
/*      */   public final <T> CommandObject<T> jsonGet(String key, Class<T> clazz, Path... paths) {
/* 3193 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.GET).key(key).addObjects((Object[])paths), new GsonObjectBuilder<>(clazz));
/*      */   }
/*      */   
/*      */   public final CommandObject<List<JSONArray>> jsonMGet(Path2 path, String... keys) {
/* 3197 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.MGET).keys((Object[])keys).add(path), BuilderFactory.JSON_ARRAY_LIST);
/*      */   }
/*      */   
/*      */   public final <T> CommandObject<List<T>> jsonMGet(Path path, Class<T> clazz, String... keys) {
/* 3201 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.MGET).keys((Object[])keys).add(path), new GsonObjectListBuilder<>(clazz));
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonDel(String key) {
/* 3205 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.DEL).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonDel(String key, Path2 path) {
/* 3209 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.DEL).key(key).add(path), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonDel(String key, Path path) {
/* 3213 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.DEL).key(key).add(path), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonClear(String key) {
/* 3217 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.CLEAR).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonClear(String key, Path2 path) {
/* 3221 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.CLEAR).key(key).add(path), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonClear(String key, Path path) {
/* 3225 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.CLEAR).key(key).add(path), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> jsonToggle(String key, Path2 path) {
/* 3229 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.TOGGLE).key(key).add(path), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> jsonToggle(String key, Path path) {
/* 3233 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.TOGGLE).key(key).add(path), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Class<?>> jsonType(String key) {
/* 3237 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.TYPE).key(key), BuilderFactory.JSON_TYPE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Class<?>>> jsonType(String key, Path2 path) {
/* 3241 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.TYPE).key(key).add(path), BuilderFactory.JSON_TYPE_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Class<?>> jsonType(String key, Path path) {
/* 3245 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.TYPE).key(key).add(path), BuilderFactory.JSON_TYPE);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonStrAppend(String key, Object string) {
/* 3249 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.STRAPPEND).key(key).add(GSON.toJson(string)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> jsonStrAppend(String key, Path2 path, Object string) {
/* 3253 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.STRAPPEND).key(key).add(path).add(GSON.toJson(string)), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonStrAppend(String key, Path path, Object string) {
/* 3257 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.STRAPPEND).key(key).add(path).add(GSON.toJson(string)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonStrLen(String key) {
/* 3261 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.STRLEN).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> jsonStrLen(String key, Path2 path) {
/* 3265 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.STRLEN).key(key).add(path), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonStrLen(String key, Path path) {
/* 3269 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.STRLEN).key(key).add(path), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonArrAppend(String key, String path, JSONObject... objects) {
/* 3273 */     CommandArguments args = commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRAPPEND).key(key).add(path);
/* 3274 */     for (JSONObject object : objects) {
/* 3275 */       args.add(object);
/*      */     }
/* 3277 */     return new CommandObject<>(args, BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> jsonArrAppend(String key, Path2 path, Object... objects) {
/* 3281 */     CommandArguments args = commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRAPPEND).key(key).add(path).addObjects(objects);
/* 3282 */     return new CommandObject<>(args, BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> jsonArrAppendWithEscape(String key, Path2 path, Object... objects) {
/* 3286 */     CommandArguments args = commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRAPPEND).key(key).add(path);
/* 3287 */     for (Object object : objects) {
/* 3288 */       args.add(GSON.toJson(object));
/*      */     }
/* 3290 */     return new CommandObject<>(args, BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonArrAppend(String key, Path path, Object... pojos) {
/* 3294 */     CommandArguments args = commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRAPPEND).key(key).add(path);
/* 3295 */     for (Object pojo : pojos) {
/* 3296 */       args.add(GSON.toJson(pojo));
/*      */     }
/* 3298 */     return new CommandObject<>(args, BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> jsonArrIndex(String key, Path2 path, Object scalar) {
/* 3302 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRINDEX).key(key).add(path).add(scalar), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> jsonArrIndexWithEscape(String key, Path2 path, Object scalar) {
/* 3306 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRINDEX).key(key).add(path).add(GSON.toJson(scalar)), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonArrIndex(String key, Path path, Object scalar) {
/* 3310 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRINDEX).key(key).add(path).add(GSON.toJson(scalar)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> jsonArrInsert(String key, Path2 path, int index, Object... objects) {
/* 3314 */     CommandArguments args = commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRINSERT).key(key).add(path).add(Integer.valueOf(index)).addObjects(objects);
/* 3315 */     return new CommandObject<>(args, BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> jsonArrInsertWithEscape(String key, Path2 path, int index, Object... objects) {
/* 3319 */     CommandArguments args = commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRINSERT).key(key).add(path).add(Integer.valueOf(index));
/* 3320 */     for (Object object : objects) {
/* 3321 */       args.add(GSON.toJson(object));
/*      */     }
/* 3323 */     return new CommandObject<>(args, BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonArrInsert(String key, Path path, int index, Object... pojos) {
/* 3327 */     CommandArguments args = commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRINSERT).key(key).add(path).add(Integer.valueOf(index));
/* 3328 */     for (Object pojo : pojos) {
/* 3329 */       args.add(GSON.toJson(pojo));
/*      */     }
/* 3331 */     return new CommandObject<>(args, BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> jsonArrPop(String key) {
/* 3335 */     return new CommandObject(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRPOP).key(key), new GsonObjectBuilder(Object.class));
/*      */   }
/*      */   
/*      */   public final <T> CommandObject<T> jsonArrPop(String key, Class<T> clazz) {
/* 3339 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRPOP).key(key), new GsonObjectBuilder<>(clazz));
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Object>> jsonArrPop(String key, Path2 path) {
/* 3343 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRPOP).key(key).add(path), new GsonObjectListBuilder(Object.class));
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> jsonArrPop(String key, Path path) {
/* 3347 */     return new CommandObject(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRPOP).key(key).add(path), new GsonObjectBuilder(Object.class));
/*      */   }
/*      */   
/*      */   public final <T> CommandObject<T> jsonArrPop(String key, Class<T> clazz, Path path) {
/* 3351 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRPOP).key(key).add(path), new GsonObjectBuilder<>(clazz));
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Object>> jsonArrPop(String key, Path2 path, int index) {
/* 3355 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRPOP).key(key).add(path).add(Integer.valueOf(index)), new GsonObjectListBuilder(Object.class));
/*      */   }
/*      */   
/*      */   public final CommandObject<Object> jsonArrPop(String key, Path path, int index) {
/* 3359 */     return new CommandObject(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRPOP).key(key).add(path).add(Integer.valueOf(index)), new GsonObjectBuilder(Object.class));
/*      */   }
/*      */   
/*      */   public final <T> CommandObject<T> jsonArrPop(String key, Class<T> clazz, Path path, int index) {
/* 3363 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRPOP).key(key).add(path).add(Integer.valueOf(index)), new GsonObjectBuilder<>(clazz));
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonArrLen(String key) {
/* 3367 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRLEN).key(key), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> jsonArrLen(String key, Path2 path) {
/* 3371 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRLEN).key(key).add(path), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonArrLen(String key, Path path) {
/* 3375 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRLEN).key(key).add(path), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> jsonArrTrim(String key, Path2 path, int start, int stop) {
/* 3379 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRTRIM).key(key).add(path).add(Integer.valueOf(start)).add(Integer.valueOf(stop)), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> jsonArrTrim(String key, Path path, int start, int stop) {
/* 3383 */     return new CommandObject<>(commandArguments((ProtocolCommand)JsonProtocol.JsonCommand.ARRTRIM).key(key).add(path).add(Integer.valueOf(start)).add(Integer.valueOf(stop)), BuilderFactory.LONG);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<String> tsCreate(String key) {
/* 3389 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.CREATE).key(key), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> tsCreate(String key, TSCreateParams createParams) {
/* 3393 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.CREATE).key(key).addParams((IParams)createParams), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> tsDel(String key, long fromTimestamp, long toTimestamp) {
/* 3397 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.DEL).key(key)
/* 3398 */         .add(Long.valueOf(fromTimestamp)).add(Long.valueOf(toTimestamp)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> tsAlter(String key, TSAlterParams alterParams) {
/* 3402 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.ALTER).key(key).addParams((IParams)alterParams), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> tsAdd(String key, double value) {
/* 3406 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.ADD).key(key)
/* 3407 */         .add(Protocol.BYTES_ASTERISK).add(Double.valueOf(value)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> tsAdd(String key, long timestamp, double value) {
/* 3411 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.ADD).key(key)
/* 3412 */         .add(Long.valueOf(timestamp)).add(Double.valueOf(value)), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> tsAdd(String key, long timestamp, double value, TSCreateParams createParams) {
/* 3416 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.ADD).key(key)
/* 3417 */         .add(Long.valueOf(timestamp)).add(Double.valueOf(value)).addParams((IParams)createParams), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<TSElement>> tsRange(String key, long fromTimestamp, long toTimestamp) {
/* 3421 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.RANGE).key(key)
/* 3422 */         .add(Long.valueOf(fromTimestamp)).add(Long.valueOf(toTimestamp)), BuilderFactory.TIMESERIES_ELEMENT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<TSElement>> tsRange(String key, TSRangeParams rangeParams) {
/* 3426 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.RANGE).key(key)
/* 3427 */         .addParams((IParams)rangeParams), BuilderFactory.TIMESERIES_ELEMENT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<TSElement>> tsRevRange(String key, long fromTimestamp, long toTimestamp) {
/* 3431 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.REVRANGE).key(key)
/* 3432 */         .add(Long.valueOf(fromTimestamp)).add(Long.valueOf(toTimestamp)), BuilderFactory.TIMESERIES_ELEMENT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<TSElement>> tsRevRange(String key, TSRangeParams rangeParams) {
/* 3436 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.REVRANGE).key(key)
/* 3437 */         .addParams((IParams)rangeParams), BuilderFactory.TIMESERIES_ELEMENT_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<TSKeyedElements>> tsMRange(long fromTimestamp, long toTimestamp, String... filters) {
/* 3441 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.MRANGE).add(Long.valueOf(fromTimestamp))
/* 3442 */         .add(Long.valueOf(toTimestamp)).add(TimeSeriesProtocol.TimeSeriesKeyword.FILTER).addObjects((Object[])filters), BuilderFactory.TIMESERIES_MRANGE_RESPONSE);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<TSKeyedElements>> tsMRange(TSMRangeParams multiRangeParams) {
/* 3447 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.MRANGE)
/* 3448 */         .addParams((IParams)multiRangeParams), BuilderFactory.TIMESERIES_MRANGE_RESPONSE);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<TSKeyedElements>> tsMRevRange(long fromTimestamp, long toTimestamp, String... filters) {
/* 3452 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.MREVRANGE).add(Long.valueOf(fromTimestamp))
/* 3453 */         .add(Long.valueOf(toTimestamp)).add(TimeSeriesProtocol.TimeSeriesKeyword.FILTER).addObjects((Object[])filters), BuilderFactory.TIMESERIES_MRANGE_RESPONSE);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<List<TSKeyedElements>> tsMRevRange(TSMRangeParams multiRangeParams) {
/* 3458 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.MREVRANGE).addParams((IParams)multiRangeParams), BuilderFactory.TIMESERIES_MRANGE_RESPONSE);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<TSElement> tsGet(String key) {
/* 3463 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.GET).key(key), BuilderFactory.TIMESERIES_ELEMENT);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<TSKeyValue<TSElement>>> tsMGet(TSMGetParams multiGetParams, String... filters) {
/* 3467 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.MGET).addParams((IParams)multiGetParams)
/* 3468 */         .add(TimeSeriesProtocol.TimeSeriesKeyword.FILTER).addObjects((Object[])filters), BuilderFactory.TIMESERIES_MGET_RESPONSE);
/*      */   }
/*      */ 
/*      */   
/*      */   public final CommandObject<String> tsCreateRule(String sourceKey, String destKey, AggregationType aggregationType, long timeBucket) {
/* 3473 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.CREATERULE).key(sourceKey).key(destKey)
/* 3474 */         .add(TimeSeriesProtocol.TimeSeriesKeyword.AGGREGATION).add(aggregationType).add(Long.valueOf(timeBucket)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> tsDeleteRule(String sourceKey, String destKey) {
/* 3478 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.DELETERULE).key(sourceKey).key(destKey), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> tsQueryIndex(String... filters) {
/* 3482 */     return new CommandObject<>(commandArguments((ProtocolCommand)TimeSeriesProtocol.TimeSeriesCommand.QUERYINDEX)
/* 3483 */         .addObjects((Object[])filters), BuilderFactory.STRING_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final CommandObject<String> bfReserve(String key, double errorRate, long capacity) {
/* 3489 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.BloomFilterCommand.RESERVE).key(key)
/* 3490 */         .add(Double.valueOf(errorRate)).add(Long.valueOf(capacity)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> bfReserve(String key, double errorRate, long capacity, BFReserveParams reserveParams) {
/* 3494 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.BloomFilterCommand.RESERVE).key(key)
/* 3495 */         .add(Double.valueOf(errorRate)).add(Long.valueOf(capacity)).addParams((IParams)reserveParams), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> bfAdd(String key, String item) {
/* 3499 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.BloomFilterCommand.ADD).key(key).add(item), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> bfMAdd(String key, String... items) {
/* 3503 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.BloomFilterCommand.MADD).key(key)
/* 3504 */         .addObjects((Object[])items), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> bfInsert(String key, String... items) {
/* 3508 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.BloomFilterCommand.INSERT).key(key)
/* 3509 */         .add(RedisBloomProtocol.RedisBloomKeyword.ITEMS).addObjects((Object[])items), BuilderFactory.BOOLEAN_WITH_ERROR_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> bfInsert(String key, BFInsertParams insertParams, String... items) {
/* 3513 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.BloomFilterCommand.INSERT).key(key).addParams((IParams)insertParams)
/* 3514 */         .add(RedisBloomProtocol.RedisBloomKeyword.ITEMS).addObjects((Object[])items), BuilderFactory.BOOLEAN_WITH_ERROR_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> bfExists(String key, String item) {
/* 3518 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.BloomFilterCommand.EXISTS).key(key).add(item), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> bfMExists(String key, String... items) {
/* 3522 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.BloomFilterCommand.MEXISTS).key(key)
/* 3523 */         .addObjects((Object[])items), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Map<String, Object>> bfInfo(String key) {
/* 3527 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.BloomFilterCommand.INFO).key(key), BuilderFactory.ENCODED_OBJECT_MAP);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> cfReserve(String key, long capacity) {
/* 3531 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.RESERVE).key(key).add(Long.valueOf(capacity)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> cfReserve(String key, long capacity, CFReserveParams reserveParams) {
/* 3535 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.RESERVE).key(key).add(Long.valueOf(capacity)).addParams((IParams)reserveParams), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> cfAdd(String key, String item) {
/* 3539 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.ADD).key(key).add(item), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> cfAddNx(String key, String item) {
/* 3543 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.ADDNX).key(key).add(item), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> cfInsert(String key, String... items) {
/* 3547 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.INSERT).key(key)
/* 3548 */         .add(RedisBloomProtocol.RedisBloomKeyword.ITEMS).addObjects((Object[])items), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> cfInsert(String key, CFInsertParams insertParams, String... items) {
/* 3552 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.INSERT).key(key)
/* 3553 */         .addParams((IParams)insertParams).add(RedisBloomProtocol.RedisBloomKeyword.ITEMS).addObjects((Object[])items), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> cfInsertNx(String key, String... items) {
/* 3557 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.INSERTNX).key(key)
/* 3558 */         .add(RedisBloomProtocol.RedisBloomKeyword.ITEMS).addObjects((Object[])items), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> cfInsertNx(String key, CFInsertParams insertParams, String... items) {
/* 3562 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.INSERTNX).key(key)
/* 3563 */         .addParams((IParams)insertParams).add(RedisBloomProtocol.RedisBloomKeyword.ITEMS).addObjects((Object[])items), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> cfExists(String key, String item) {
/* 3567 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.EXISTS).key(key).add(item), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> cfMExists(String key, String... items) {
/* 3571 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.MEXISTS).key(key)
/* 3572 */         .addObjects((Object[])items), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Boolean> cfDel(String key, String item) {
/* 3576 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.DEL).key(key).add(item), BuilderFactory.BOOLEAN);
/*      */   }
/*      */   
/*      */   public final CommandObject<Long> cfCount(String key, String item) {
/* 3580 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.COUNT).key(key).add(item), BuilderFactory.LONG);
/*      */   }
/*      */   
/*      */   public final CommandObject<Map<String, Object>> cfInfo(String key) {
/* 3584 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CuckooFilterCommand.INFO).key(key), BuilderFactory.ENCODED_OBJECT_MAP);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> cmsInitByDim(String key, long width, long depth) {
/* 3588 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CountMinSketchCommand.INITBYDIM).key(key).add(Long.valueOf(width)).add(Long.valueOf(depth)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> cmsInitByProb(String key, double error, double probability) {
/* 3592 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CountMinSketchCommand.INITBYPROB).key(key).add(Double.valueOf(error)).add(Double.valueOf(probability)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> cmsIncrBy(String key, Map<String, Long> itemIncrements) {
/* 3596 */     CommandArguments args = commandArguments((ProtocolCommand)RedisBloomProtocol.CountMinSketchCommand.INCRBY).key(key);
/* 3597 */     itemIncrements.entrySet().forEach(entry -> args.add(entry.getKey()).add(entry.getValue()));
/* 3598 */     return new CommandObject<>(args, BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> cmsQuery(String key, String... items) {
/* 3602 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CountMinSketchCommand.QUERY).key(key).addObjects((Object[])items), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> cmsMerge(String destKey, String... keys) {
/* 3606 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CountMinSketchCommand.MERGE).key(destKey)
/* 3607 */         .add(Integer.valueOf(keys.length)).keys((Object[])keys), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> cmsMerge(String destKey, Map<String, Long> keysAndWeights) {
/* 3611 */     CommandArguments args = commandArguments((ProtocolCommand)RedisBloomProtocol.CountMinSketchCommand.MERGE).key(destKey);
/* 3612 */     args.add(Integer.valueOf(keysAndWeights.size()));
/* 3613 */     keysAndWeights.entrySet().forEach(entry -> args.key(entry.getKey()));
/* 3614 */     args.add(RedisBloomProtocol.RedisBloomKeyword.WEIGHTS);
/* 3615 */     keysAndWeights.entrySet().forEach(entry -> args.add(entry.getValue()));
/* 3616 */     return new CommandObject<>(args, BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<Map<String, Object>> cmsInfo(String key) {
/* 3620 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.CountMinSketchCommand.INFO).key(key), BuilderFactory.ENCODED_OBJECT_MAP);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> topkReserve(String key, long topk) {
/* 3624 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.TopKCommand.RESERVE).key(key).add(Long.valueOf(topk)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<String> topkReserve(String key, long topk, long width, long depth, double decay) {
/* 3628 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.TopKCommand.RESERVE).key(key).add(Long.valueOf(topk))
/* 3629 */         .add(Long.valueOf(width)).add(Long.valueOf(depth)).add(Double.valueOf(decay)), BuilderFactory.STRING);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> topkAdd(String key, String... items) {
/* 3633 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.TopKCommand.ADD).key(key).addObjects((Object[])items), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> topkIncrBy(String key, Map<String, Long> itemIncrements) {
/* 3637 */     CommandArguments args = commandArguments((ProtocolCommand)RedisBloomProtocol.TopKCommand.INCRBY).key(key);
/* 3638 */     itemIncrements.entrySet().forEach(entry -> args.add(entry.getKey()).add(entry.getValue()));
/* 3639 */     return new CommandObject<>(args, BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Boolean>> topkQuery(String key, String... items) {
/* 3643 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.TopKCommand.QUERY).key(key).addObjects((Object[])items), BuilderFactory.BOOLEAN_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<Long>> topkCount(String key, String... items) {
/* 3647 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.TopKCommand.COUNT).key(key).addObjects((Object[])items), BuilderFactory.LONG_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<List<String>> topkList(String key) {
/* 3651 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.TopKCommand.LIST).key(key), BuilderFactory.STRING_LIST);
/*      */   }
/*      */   
/*      */   public final CommandObject<Map<String, Object>> topkInfo(String key) {
/* 3655 */     return new CommandObject<>(commandArguments((ProtocolCommand)RedisBloomProtocol.TopKCommand.INFO).key(key), BuilderFactory.ENCODED_OBJECT_MAP);
/*      */   }
/*      */ 
/*      */   
/* 3659 */   private static final Gson GSON = new Gson();
/*      */   
/*      */   private class GsonObjectBuilder<T>
/*      */     extends Builder<T> {
/*      */     private final Class<T> clazz;
/*      */     
/*      */     public GsonObjectBuilder(Class<T> clazz) {
/* 3666 */       this.clazz = clazz;
/*      */     }
/*      */ 
/*      */     
/*      */     public T build(Object data) {
/* 3671 */       return (T)CommandObjects.GSON.fromJson(BuilderFactory.STRING.build(data), this.clazz);
/*      */     }
/*      */   }
/*      */   
/*      */   private class GsonObjectListBuilder<T>
/*      */     extends Builder<List<T>> {
/*      */     private final Class<T> clazz;
/*      */     
/*      */     public GsonObjectListBuilder(Class<T> clazz) {
/* 3680 */       this.clazz = clazz;
/*      */     }
/*      */ 
/*      */     
/*      */     public List<T> build(Object data) {
/* 3685 */       if (data == null) {
/* 3686 */         return null;
/*      */       }
/* 3688 */       List<String> list = BuilderFactory.STRING_LIST.build(data);
/* 3689 */       return (List<T>)list.stream().map(s -> CommandObjects.GSON.fromJson(s, this.clazz)).collect(Collectors.toList());
/*      */     }
/*      */   }
/*      */   
/*      */   private CommandArguments addFlatKeyValueArgs(CommandArguments args, String... keyvalues) {
/* 3694 */     for (int i = 0; i < keyvalues.length; i += 2) {
/* 3695 */       args.key(keyvalues[i]).add(keyvalues[i + 1]);
/*      */     }
/* 3697 */     return args;
/*      */   }
/*      */   
/*      */   private CommandArguments addFlatKeyValueArgs(CommandArguments args, byte[]... keyvalues) {
/* 3701 */     for (int i = 0; i < keyvalues.length; i += 2) {
/* 3702 */       args.key(keyvalues[i]).add(keyvalues[i + 1]);
/*      */     }
/* 3704 */     return args;
/*      */   }
/*      */   
/*      */   private CommandArguments addFlatMapArgs(CommandArguments args, Map<?, ?> map) {
/* 3708 */     for (Map.Entry<? extends Object, ? extends Object> entry : map.entrySet()) {
/* 3709 */       args.add(entry.getKey());
/* 3710 */       args.add(entry.getValue());
/*      */     } 
/* 3712 */     return args;
/*      */   }
/*      */   
/*      */   private CommandArguments addSortedSetFlatMapArgs(CommandArguments args, Map<?, Double> map) {
/* 3716 */     for (Map.Entry<? extends Object, Double> entry : map.entrySet()) {
/* 3717 */       args.add(entry.getValue());
/* 3718 */       args.add(entry.getKey());
/*      */     } 
/* 3720 */     return args;
/*      */   }
/*      */   
/*      */   private CommandArguments addGeoCoordinateFlatMapArgs(CommandArguments args, Map<?, GeoCoordinate> map) {
/* 3724 */     for (Map.Entry<? extends Object, GeoCoordinate> entry : map.entrySet()) {
/* 3725 */       GeoCoordinate ord = entry.getValue();
/* 3726 */       args.add(Double.valueOf(ord.getLongitude()));
/* 3727 */       args.add(Double.valueOf(ord.getLatitude()));
/* 3728 */       args.add(entry.getKey());
/*      */     } 
/* 3730 */     return args;
/*      */   }
/*      */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\CommandObjects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */