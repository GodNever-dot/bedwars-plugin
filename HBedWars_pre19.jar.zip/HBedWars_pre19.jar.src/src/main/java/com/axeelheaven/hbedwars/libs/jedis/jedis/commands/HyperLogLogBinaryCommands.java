package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

public interface HyperLogLogBinaryCommands {
  long pfadd(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  String pfmerge(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  long pfcount(byte[] paramArrayOfbyte);
  
  long pfcount(byte[]... paramVarArgs);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\HyperLogLogBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */