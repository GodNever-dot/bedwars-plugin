package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.SaveMode;
import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.LolwutParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ShutdownParams;

public interface ServerCommands {
  String ping();
  
  String ping(String paramString);
  
  String echo(String paramString);
  
  byte[] echo(byte[] paramArrayOfbyte);
  
  String quit();
  
  String flushDB();
  
  String flushAll();
  
  String flushAll(FlushMode paramFlushMode);
  
  String auth(String paramString);
  
  String auth(String paramString1, String paramString2);
  
  String save();
  
  String bgsave();
  
  String bgsaveSchedule();
  
  String bgrewriteaof();
  
  long lastsave();
  
  void shutdown() throws JedisException;
  
  @Deprecated
  void shutdown(SaveMode paramSaveMode) throws JedisException;
  
  void shutdown(ShutdownParams paramShutdownParams) throws JedisException;
  
  String shutdownAbort();
  
  String info();
  
  String info(String paramString);
  
  @Deprecated
  String slaveof(String paramString, int paramInt);
  
  @Deprecated
  String slaveofNoOne();
  
  String replicaof(String paramString, int paramInt);
  
  String replicaofNoOne();
  
  long waitReplicas(int paramInt, long paramLong);
  
  String lolwut();
  
  String lolwut(LolwutParams paramLolwutParams);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\ServerCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */