/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.search.aggr;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Row
/*    */ {
/*    */   private final Map<String, Object> fields;
/*    */   
/*    */   public Row(Map<String, Object> fields) {
/* 15 */     this.fields = fields;
/*    */   }
/*    */   
/*    */   public boolean containsKey(String key) {
/* 19 */     return this.fields.containsKey(key);
/*    */   }
/*    */   
/*    */   public String getString(String key) {
/* 23 */     if (!containsKey(key)) {
/* 24 */       return "";
/*    */     }
/* 26 */     return new String((byte[])this.fields.get(key));
/*    */   }
/*    */   
/*    */   public long getLong(String key) {
/* 30 */     if (!containsKey(key)) {
/* 31 */       return 0L;
/*    */     }
/* 33 */     return Long.parseLong(getString(key));
/*    */   }
/*    */   
/*    */   public double getDouble(String key) {
/* 37 */     if (!containsKey(key)) {
/* 38 */       return 0.0D;
/*    */     }
/* 40 */     return Double.parseDouble(getString(key));
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\search\aggr\Row.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */