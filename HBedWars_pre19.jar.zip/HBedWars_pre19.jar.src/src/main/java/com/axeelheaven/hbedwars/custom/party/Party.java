package com.axeelheaven.hbedwars.custom.party;

import com.axeelheaven.hbedwars.BedWars;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.bukkit.entity.Player;

public class Party implements Serializable {
  private final BedWars plugin;
  private final Player leader;
  private final List<Player> members;
  private final HashMap<String, Long> invite;
  private final String name;
  private final List<String> players;
  
  public Party(BedWars plugin, Player leader) {
    this.plugin = plugin;
    this.leader = leader;
    this.members = new ArrayList<>();
    this.invite = new HashMap<>();
    this.name = leader.getName();
    this.players = new ArrayList<>();
    this.players.add(leader.getName());
  }
  
  public void addMember(Player player) {
    if (!this.members.contains(player)) {
      this.members.add(player);
      this.players.add(player.getName());
    }
  }
  
  public void removeMember(Player player) {
    this.members.remove(player);
    this.players.remove(player.getName());
  }
  
  public void addInvite(Player player) {
    this.invite.put(player.getName(), System.currentTimeMillis() + 30000L);
  }
  
  public void removeInvite(Player player) {
    this.invite.remove(player.getName());
  }
  
  public boolean hasInvite(Player player) {
    return this.invite.containsKey(player.getName()) && 
           this.invite.get(player.getName()) > System.currentTimeMillis();
  }
  
  public boolean isMember(Player player) {
    return this.members.contains(player);
  }
  
  public boolean isLeader(Player player) {
    return this.leader.equals(player);
  }
  
  public Player getLeader() {
    return this.leader;
  }
  
  public List<Player> getMembers() {
    return this.members;
  }
  
  public String getName() {
    return this.name;
  }
  
  public List<String> getPlayers() {
    return this.players;
  }
  
  public HashMap<String, Long> getInvites() {
    return this.invite;
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\party\Party.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
 */