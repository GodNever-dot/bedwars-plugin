package com.axeelheaven.hbedwars.arena.task;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.arena.ArenaMob;
import java.util.ArrayList;
import org.bukkit.scheduler.BukkitRunnable;

public class MobTask extends BukkitRunnable {
  private final BedWars plugin;

  public MobTask(BedWars plugin) {
    this.plugin = plugin;
  }
  
  public void run() {
    new ArrayList<>(plugin.getGameManager().getArenaMobs().values()).forEach(ArenaMob::refresh);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\arena\task\MobTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */