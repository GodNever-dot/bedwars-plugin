/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.bloom;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.Rawable;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.commands.ProtocolCommand;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*     */ 
/*     */ public class RedisBloomProtocol
/*     */ {
/*     */   public enum BloomFilterCommand
/*     */     implements ProtocolCommand {
/*  11 */     RESERVE("BF.RESERVE"),
/*  12 */     ADD("BF.ADD"),
/*  13 */     MADD("BF.MADD"),
/*  14 */     EXISTS("BF.EXISTS"),
/*  15 */     MEXISTS("BF.MEXISTS"),
/*  16 */     INSERT("BF.INSERT"),
/*  17 */     INFO("BF.INFO");
/*     */     
/*     */     private final byte[] raw;
/*     */     
/*     */     BloomFilterCommand(String alt) {
/*  22 */       this.raw = SafeEncoder.encode(alt);
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getRaw() {
/*  27 */       return this.raw;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum CuckooFilterCommand
/*     */     implements ProtocolCommand {
/*  33 */     RESERVE("CF.RESERVE"),
/*  34 */     ADD("CF.ADD"),
/*  35 */     ADDNX("CF.ADDNX"),
/*  36 */     INSERT("CF.INSERT"),
/*  37 */     INSERTNX("CF.INSERTNX"),
/*  38 */     EXISTS("CF.EXISTS"),
/*  39 */     MEXISTS("CF.MEXISTS"),
/*  40 */     DEL("CF.DEL"),
/*  41 */     COUNT("CF.COUNT"),
/*  42 */     SCANDUMP("CF.SCANDUMP"),
/*  43 */     LOADCHUNK("CF.LOADCHUNK"),
/*  44 */     INFO("CF.INFO");
/*     */     
/*     */     private final byte[] raw;
/*     */     
/*     */     CuckooFilterCommand(String alt) {
/*  49 */       this.raw = SafeEncoder.encode(alt);
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getRaw() {
/*  54 */       return this.raw;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum CountMinSketchCommand
/*     */     implements ProtocolCommand {
/*  60 */     INITBYDIM("CMS.INITBYDIM"),
/*  61 */     INITBYPROB("CMS.INITBYPROB"),
/*  62 */     INCRBY("CMS.INCRBY"),
/*  63 */     QUERY("CMS.QUERY"),
/*  64 */     MERGE("CMS.MERGE"),
/*  65 */     INFO("CMS.INFO");
/*     */     
/*     */     private final byte[] raw;
/*     */     
/*     */     CountMinSketchCommand(String alt) {
/*  70 */       this.raw = SafeEncoder.encode(alt);
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getRaw() {
/*  75 */       return this.raw;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum TopKCommand
/*     */     implements ProtocolCommand {
/*  81 */     RESERVE("TOPK.RESERVE"),
/*  82 */     ADD("TOPK.ADD"),
/*  83 */     INCRBY("TOPK.INCRBY"),
/*  84 */     QUERY("TOPK.QUERY"),
/*  85 */     COUNT("TOPK.COUNT"),
/*  86 */     LIST("TOPK.LIST"),
/*  87 */     INFO("TOPK.INFO");
/*     */     
/*     */     private final byte[] raw;
/*     */     
/*     */     TopKCommand(String alt) {
/*  92 */       this.raw = SafeEncoder.encode(alt);
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getRaw() {
/*  97 */       return this.raw;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum RedisBloomKeyword
/*     */     implements Rawable {
/* 103 */     CAPACITY, ERROR, NOCREATE, EXPANSION, NONSCALING, BUCKETSIZE, MAXITERATIONS, ITEMS, WEIGHTS;
/*     */     
/*     */     private final byte[] raw;
/*     */     
/*     */     RedisBloomKeyword() {
/* 108 */       this.raw = SafeEncoder.encode(name());
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getRaw() {
/* 113 */       return this.raw;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\bloom\RedisBloomProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */