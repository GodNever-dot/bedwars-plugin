package com.axeelheaven.hbedwars.cosmetics.windances;

import com.axeelheaven.hbedwars.BedWars;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.entity.Player;

public class WinDanceMeteors extends WinDance {
  private static boolean lIlIIIlIlI(int lllllllllllllllllIIllIlIlIIIllIl) {
    if (lIllllIlIIll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (((28 + 93 - 108 + 114 ^ 0x16 ^ 0x76) & (0xFE ^ 0xA6 ^ 0x19 ^ 0x5E ^ -" ".length())) != 0)
        return (0x24 ^ 0x71 ^ 0x51 ^ 0x37) & (1 + 78 - -35 + 70 ^ 37 + 10 - -63 + 29 ^ -" ".length()); 
    } else {
    
    } 
    return llIlIlllll[0];
  }
  
  private static void lIllllIlIIII() {
    llIlIlllll = new int[32];
    llIlIlllll[0] = (0xF ^ 0x28) & (0x38 ^ 0x1F ^ 0xFFFFFFFF);
    llIlIlllll[1] = " ".length();
    llIlIlllll[2] = "  ".length();
    llIlIlllll[3] = 0xF ^ 0x63 ^ 0x7F ^ 0x79;
    llIlIlllll[4] = 0x3 ^ 0x5B;
    llIlIlllll[5] = 114 + 133 - 233 + 158;
    llIlIlllll[6] = (0x1B ^ 0x39) + (0x69 ^ 0x1A) - (0xE2 ^ 0x8B) + (0x15 ^ 0x67);
    llIlIlllll[7] = -" ".length();
    llIlIlllll[8] = "   ".length();
    llIlIlllll[9] = 0x4D ^ 0x2C ^ 0x3 ^ 0x66;
    llIlIlllll[10] = 0x65 ^ 0x16 ^ 0xD6 ^ 0xA0;
    llIlIlllll[11] = 0x43 ^ 0x45;
    llIlIlllll[12] = 121 + 92 - 26 + 37;
    llIlIlllll[13] = 164 + 145 - 210 + 76;
    llIlIlllll[14] = 0x5A ^ 0x27 ^ 0x41 ^ 0x70;
    llIlIlllll[15] = 0x51 ^ 0x30 ^ 0xB3 ^ 0x82;
    llIlIlllll[16] = 0xC5 ^ 0x8C ^ 0xED ^ 0xA8;
    llIlIlllll[17] = 16 + 35 - 37 + 227 ^ 23 + 19 - -25 + 69;
    llIlIlllll[18] = 33 + 65 - 14 + 48 + 121 + 71 - 161 + 118 - 86 + 88 - 35 + 0 + (0xB5 ^ 0xA9);
    llIlIlllll[19] = (0xAE ^ 0x9B) + (0x6B ^ 0x2) - (0xCE ^ 0x84) + (0x6E ^ 0x56);
    llIlIlllll[20] = 0x7B ^ 0x7C;
    llIlIlllll[21] = 0x2C ^ 0x24;
    llIlIlllll[22] = 0xD ^ 0x2E;
    llIlIlllll[23] = 0xE9 ^ 0xC2;
    llIlIlllll[24] = 0x15 ^ 0x40 ^ 0xC0 ^ 0x9C;
    llIlIlllll[25] = 0x34 ^ 0x7F ^ 0xEE ^ 0xAF;
    llIlIlllll[26] = 0x51 ^ 0x5A;
    llIlIlllll[27] = 0x68 ^ 0x65;
    llIlIlllll[28] = 0x45 ^ 0x4B;
    llIlIlllll[29] = 0x1B ^ 0x14;
    llIlIlllll[30] = 141 + 16 - 86 + 108 ^ 131 + 142 - 145 + 35;
    llIlIlllll[31] = 108 + 51 - 132 + 147 ^ 170 + 34 - 126 + 113;
  }
  
  public void execute(char lllllllllllllllllIIllIlIlIIllIII, int lllllllllllllllllIIllIlIlIIlIlll) {
    AtomicInteger lllllllllllllllllIIllIlIlIIllllI = new AtomicInteger(lllllllllllllllllIIllIlIlIIlIlll.getArenaTask().getEndSeconds() * llIlIlIl[llIlIlllll[2]]);
    llIlIllllI[llIlIlllll[0]].length();
  }
  
  private static boolean lIllllIlIlII(char lllllllllllllllllIIllIlIIIIIllII, float lllllllllllllllllIIllIlIIIIIlIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static String lIllllIIlllI(String lllllllllllllllllIIllIlIIIlllIIl, boolean lllllllllllllllllIIllIlIIIllIllI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   22: bipush #21
    //   24: iaload
    //   25: invokestatic copyOf : ([BI)[B
    //   28: ldc 'DES'
    //   30: invokespecial <init> : ([BLjava/lang/String;)V
    //   33: astore_2
    //   34: ldc 'DES'
    //   36: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   39: astore_3
    //   40: aload_3
    //   41: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   44: iconst_2
    //   45: iaload
    //   46: aload_2
    //   47: invokevirtual init : (ILjava/security/Key;)V
    //   50: new java/lang/String
    //   53: dup
    //   54: aload_3
    //   55: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   58: aload_0
    //   59: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   62: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   65: invokevirtual decode : ([B)[B
    //   68: invokevirtual doFinal : ([B)[B
    //   71: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   74: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   77: areturn
    //   78: astore_2
    //   79: aload_2
    //   80: invokevirtual printStackTrace : ()V
    //   83: aconst_null
    //   84: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	85	0	lllllllllllllllllIIllIlIIIllIlll	D
    //   0	85	1	lllllllllllllllllIIllIlIIIlllIII	Ljava/lang/String;
    //   34	44	2	lllllllllllllllllIIllIlIIIllllII	Ljavax/crypto/spec/SecretKeySpec;
    //   0	85	2	lllllllllllllllllIIllIlIIIllIlIl	J
    //   0	85	0	lllllllllllllllllIIllIlIIIlllIIl	Ljava/lang/String;
    //   0	85	3	lllllllllllllllllIIllIlIIIllIlII	Ljava/lang/String;
    //   79	4	2	lllllllllllllllllIIllIlIIIlllIlI	Ljava/lang/Exception;
    //   0	85	1	lllllllllllllllllIIllIlIIIllIllI	Z
    //   40	38	3	lllllllllllllllllIIllIlIIIlllIll	Ljavax/crypto/Cipher;
    // Exception table:
    //   from	to	target	type
    //   0	77	78	java/lang/Exception
  }
  
  private static void lIlIIIIllI() {
    llIlIlII = new String[llIlIlIl[llIlIlllll[8]]];
    llIlIlII[llIlIlIl[llIlIlllll[0]]] = lIlIIIIlII(llIlIllllI[llIlIlllll[27]], llIlIllllI[llIlIlllll[28]]);
    llIlIlII[llIlIlIl[llIlIlllll[1]]] = lIlIIIIlIl(llIlIllllI[llIlIlllll[29]], llIlIllllI[llIlIlllll[30]]);
  }
  
  private static boolean lIlIIIlIll(int lllllllllllllllllIIllIlIlIIlIIIl, long lllllllllllllllllIIllIlIlIIlIIll) {
    if (lIllllIlIIlI(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if ("  ".length() != "  ".length())
        return (151 + 193 - 274 + 124 ^ 38 + 44 - -52 + 11) & (" ".length() ^ 0x22 ^ 0x70 ^ -" ".length()); 
    } else {
    
    } 
    return llIlIlllll[0];
  }
  
  private static String lIlIIIIlII(int lllllllllllllllllIIllIlIIlllIlII, boolean lllllllllllllllllIIllIlIIlllllII) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlIl : [I
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   43: iconst_0
    //   44: iaload
    //   45: iaload
    //   46: istore #4
    //   48: aload_0
    //   49: invokevirtual toCharArray : ()[C
    //   52: astore #5
    //   54: aload #5
    //   56: arraylength
    //   57: istore #6
    //   59: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlIl : [I
    //   62: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   65: iconst_0
    //   66: iaload
    //   67: iaload
    //   68: istore #7
    //   70: iload #7
    //   72: iload #6
    //   74: invokestatic lIlIIIlIll : (II)Z
    //   77: invokestatic lIllllIlIIIl : (I)Z
    //   80: ifeq -> 181
    //   83: aload #5
    //   85: iload #7
    //   87: caload
    //   88: istore #8
    //   90: aload_2
    //   91: iload #8
    //   93: aload_3
    //   94: iload #4
    //   96: aload_3
    //   97: arraylength
    //   98: irem
    //   99: caload
    //   100: ixor
    //   101: i2c
    //   102: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   105: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIllllI : [Ljava/lang/String;
    //   108: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   111: iconst_1
    //   112: iaload
    //   113: aaload
    //   114: invokevirtual length : ()I
    //   117: pop2
    //   118: iinc #4, 1
    //   121: iinc #7, 1
    //   124: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIllllI : [Ljava/lang/String;
    //   127: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   130: iconst_2
    //   131: iaload
    //   132: aaload
    //   133: invokevirtual length : ()I
    //   136: ldc ''
    //   138: invokevirtual length : ()I
    //   141: pop2
    //   142: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   145: iconst_3
    //   146: iaload
    //   147: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   150: iconst_4
    //   151: iaload
    //   152: ixor
    //   153: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   156: iconst_5
    //   157: iaload
    //   158: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   161: bipush #6
    //   163: iaload
    //   164: ixor
    //   165: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   168: bipush #7
    //   170: iaload
    //   171: ixor
    //   172: iand
    //   173: invokestatic lIllllIlIIIl : (I)Z
    //   176: ifeq -> 70
    //   179: aconst_null
    //   180: areturn
    //   181: aload_2
    //   182: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   185: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	186	8	lllllllllllllllllIIllIlIIllIllII	Z
    //   0	186	3	lllllllllllllllllIIllIlIIlllIIIl	S
    //   0	186	1	lllllllllllllllllIIllIlIIlllIlIl	Ljava/lang/String;
    //   0	186	6	lllllllllllllllllIIllIlIIlllllll	Ljava/lang/String;
    //   0	186	2	lllllllllllllllllIIllIlIIlllIIlI	I
    //   0	186	4	lllllllllllllllllIIllIlIIlllllIl	B
    //   0	186	3	lllllllllllllllllIIllIlIIllllIII	S
    //   0	186	6	lllllllllllllllllIIllIlIIllIlllI	Ljava/lang/Exception;
    //   0	186	0	lllllllllllllllllIIllIlIlIIIIIIl	I
    //   0	186	8	lllllllllllllllllIIllIlIIllllIIl	Ljava/lang/Exception;
    //   0	186	5	lllllllllllllllllIIllIlIIllIllll	F
    //   0	186	2	lllllllllllllllllIIllIlIIllllIlI	J
    //   0	186	5	lllllllllllllllllIIllIlIIlllIllI	F
    //   0	186	7	lllllllllllllllllIIllIlIIllIllIl	C
    //   0	186	1	lllllllllllllllllIIllIlIIlllllII	Z
    //   0	186	7	lllllllllllllllllIIllIlIIllllIll	J
    //   37	149	3	lllllllllllllllllIIllIlIlIIIIIlI	[C
    //   0	186	0	lllllllllllllllllIIllIlIIlllIlII	I
    //   48	138	4	lllllllllllllllllIIllIlIIllllllI	I
    //   0	186	4	lllllllllllllllllIIllIlIIlllIIII	S
    //   32	154	2	lllllllllllllllllIIllIlIlIIIIIII	Ljava/lang/StringBuilder;
    //   90	31	8	lllllllllllllllllIIllIlIlIIIIIll	C
    //   0	186	0	lllllllllllllllllIIllIlIIlllIlll	Ljava/lang/String;
    //   0	186	1	lllllllllllllllllIIllIlIIlllIIll	F
  }
  
  static {
    lIllllIlIIII();
    lIllllIIllll();
    lIlIIIIlll();
    lIlIIIIllI();
  }
  
  private static String lIllllIIllIl(float lllllllllllllllllIIllIlIIIIlIIlI, String lllllllllllllllllIIllIlIIIIlIIll) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc_w 'Blowfish'
    //   22: invokespecial <init> : ([BLjava/lang/String;)V
    //   25: astore_2
    //   26: ldc_w 'Blowfish'
    //   29: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   32: astore_3
    //   33: aload_3
    //   34: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   37: iconst_2
    //   38: iaload
    //   39: aload_2
    //   40: invokevirtual init : (ILjava/security/Key;)V
    //   43: new java/lang/String
    //   46: dup
    //   47: aload_3
    //   48: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   51: aload_0
    //   52: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   55: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   58: invokevirtual decode : ([B)[B
    //   61: invokevirtual doFinal : ([B)[B
    //   64: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   67: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   70: areturn
    //   71: astore_2
    //   72: aload_2
    //   73: invokevirtual printStackTrace : ()V
    //   76: aconst_null
    //   77: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   26	45	2	lllllllllllllllllIIllIlIIIIlIlll	Ljavax/crypto/spec/SecretKeySpec;
    //   33	38	3	lllllllllllllllllIIllIlIIIIlIllI	Ljavax/crypto/Cipher;
    //   0	78	0	lllllllllllllllllIIllIlIIIIlIlII	Ljava/lang/String;
    //   0	78	2	lllllllllllllllllIIllIlIIIIlIIII	F
    //   0	78	3	lllllllllllllllllIIllIlIIIIIllll	I
    //   0	78	0	lllllllllllllllllIIllIlIIIIlIIlI	F
    //   0	78	1	lllllllllllllllllIIllIlIIIIlIIIl	I
    //   72	4	2	lllllllllllllllllIIllIlIIIIlIlIl	Ljava/lang/Exception;
    //   0	78	1	lllllllllllllllllIIllIlIIIIlIIll	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	70	71	java/lang/Exception
  }
  
  private static boolean lIllllIlIIll(char lllllllllllllllllIIllIlIIIIIIIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  public WinDanceMeteors(short lllllllllllllllllIIllIlIlIlIllIl, String lllllllllllllllllIIllIlIlIllIlll, byte lllllllllllllllllIIllIlIlIllIIll, char lllllllllllllllllIIllIlIlIlllIlI, boolean lllllllllllllllllIIllIlIlIllIIII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_3
    //   2: iload #4
    //   4: iload #5
    //   6: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   9: aload_0
    //   10: aload_1
    //   11: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   14: aload_0
    //   15: new java/util/HashMap
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putfield runnable : Ljava/util/HashMap;
    //   25: aload_0
    //   26: aload_0
    //   27: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   30: invokevirtual getWindances : ()Lcom/axeelheaven/hbedwars/custom/config/HConfiguration;
    //   33: new java/lang/StringBuilder
    //   36: dup
    //   37: invokespecial <init> : ()V
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlII : [Ljava/lang/String;
    //   43: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlIl : [I
    //   46: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   49: iconst_0
    //   50: iaload
    //   51: iaload
    //   52: aaload
    //   53: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: aload_2
    //   57: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlII : [Ljava/lang/String;
    //   63: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlIl : [I
    //   66: getstatic com/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors.llIlIlllll : [I
    //   69: iconst_1
    //   70: iaload
    //   71: iaload
    //   72: aaload
    //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   79: dconst_1
    //   80: invokevirtual getDouble : (Ljava/lang/String;D)D
    //   83: putfield velocity : D
    //   86: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	87	5	lllllllllllllllllIIllIlIlIlIlIIl	J
    //   0	87	3	lllllllllllllllllIIllIlIlIlIllll	Ljava/lang/String;
    //   0	87	1	lllllllllllllllllIIllIlIlIllIllI	Lcom/axeelheaven/hbedwars/BedWars;
    //   0	87	1	lllllllllllllllllIIllIlIlIlIllIl	S
    //   0	87	2	lllllllllllllllllIIllIlIlIllIIlI	C
    //   0	87	4	lllllllllllllllllIIllIlIlIlllIIl	I
    //   0	87	0	lllllllllllllllllIIllIlIlIllIlIl	J
    //   0	87	4	lllllllllllllllllIIllIlIlIlllIlI	C
    //   0	87	5	lllllllllllllllllIIllIlIlIllIIII	Z
    //   0	87	4	lllllllllllllllllIIllIlIlIlIlIlI	F
    //   0	87	2	lllllllllllllllllIIllIlIlIllIlll	Ljava/lang/String;
    //   0	87	1	lllllllllllllllllIIllIlIlIllIlII	S
    //   0	87	3	lllllllllllllllllIIllIlIlIllIIll	B
    //   0	87	2	lllllllllllllllllIIllIlIlIlIllII	I
    //   0	87	5	lllllllllllllllllIIllIlIlIlllIII	J
    //   0	87	0	lllllllllllllllllIIllIlIlIlIlllI	J
    //   0	87	0	lllllllllllllllllIIllIlIlIllIIIl	Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceMeteors;
    //   0	87	3	lllllllllllllllllIIllIlIlIlIlIll	B
  }
  
  private static void lIllllIIllll() {
    llIlIllllI = new String[llIlIlllll[31]];
    llIlIllllI[llIlIlllll[0]] = lIllllIIllII("", "NxWlQ");
    llIlIllllI[llIlIlllll[1]] = lIllllIIllIl("8qfFkZLg1E0=", "PtUhn");
    llIlIllllI[llIlIlllll[2]] = lIllllIIlllI("Py/erIwdJ6A=", "YcZCI");
    llIlIllllI[llIlIlllll[8]] = lIllllIIlllI("CdFYDE/e7RM=", "BKRSL");
    llIlIllllI[llIlIlllll[9]] = lIllllIIllIl("06w8GHDWVV0=", "PWFFO");
    llIlIllllI[llIlIlllll[10]] = lIllllIIllIl("9Ia0RSE3X9Q=", "HnsTn");
    llIlIllllI[llIlIlllll[11]] = lIllllIIllII("", "SRFVH");
    llIlIllllI[llIlIlllll[20]] = lIllllIIllII("dg==", "VcBVO");
    llIlIllllI[llIlIlllll[21]] = lIllllIIllII("cg==", "RoYfM");
    llIlIllllI[llIlIlllll[24]] = lIllllIIllIl("FRmUEc5WK5A=", "qxeqg");
    llIlIllllI[llIlIlllll[25]] = lIllllIIllII("ODxZ", "uxlbT");
    llIlIllllI[llIlIlllll[26]] = lIllllIIlllI("b73vam1z//S+ekriMmYQlA==", "iMukG");
    llIlIllllI[llIlIlllll[16]] = lIllllIIllII("MwEEBwwYHgM=", "qmkpj");
    llIlIllllI[llIlIlllll[27]] = lIllllIIllIl("7WIQIl24ZDINsn+8XJWLMg==", "kEOPl");
    llIlIllllI[llIlIlllll[28]] = lIllllIIlllI("2g4SSJGIIQU=", "oZZJd");
    llIlIllllI[llIlIlllll[29]] = lIllllIIlllI("8zf7gRTw4ZUifWSmJRHQoeNaakompKd1yEqVn85V0/k=", "xZCZT");
    llIlIllllI[llIlIlllll[30]] = lIllllIIllII("BDYNHQI=", "MTIZR");
  }
  
  private static String lIlIIIIlIl(String lllllllllllllllllIIllIlIIlIIlllI, String lllllllllllllllllIIllIlIIlIlIIll) {
    try {
      SecretKeySpec lllllllllllllllllIIllIlIIlIIllIl = new SecretKeySpec(MessageDigest.getInstance(llIlIllllI[llIlIlllll[25]]).digest(lllllllllllllllllIIllIlIIlIlIIll.getBytes(StandardCharsets.UTF_8)), llIlIllllI[llIlIlllll[26]]);
      Cipher lllllllllllllllllIIllIlIIlIIllll = Cipher.getInstance(llIlIllllI[llIlIlllll[16]]);
      lllllllllllllllllIIllIlIIlIIllll.init(llIlIlIl[llIlIlllll[8]], lllllllllllllllllIIllIlIIlIIllIl);
      return new String(lllllllllllllllllIIllIlIIlIIllll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIllIlIIlIIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIIllIlIIlIIlIll) {
      lllllllllllllllllIIllIlIIlIIllII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIllllIIllII(String lllllllllllllllllIIllIlIIIlIlIIl, String lllllllllllllllllIIllIlIIIlIIIll) {
    String str = new String(Base64.getDecoder().decode(lllllllllllllllllIIllIlIIIlIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIllIlIIIlIIlll = new StringBuilder();
    char[] lllllllllllllllllIIllIlIIIlIIllI = lllllllllllllllllIIllIlIIIlIIIll.toCharArray();
    int lllllllllllllllllIIllIlIIIlIIlIl = llIlIlllll[0];
    char[] arrayOfChar1 = str.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIlIlllll[0];
    while (lIllllIlIIlI(j, i)) {
      char lllllllllllllllllIIllIlIIIlIlIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllllIIllIlIIIlIIlIl++;
      j++;
      "".length();
      if (((0x75 ^ 0x78) & (0x79 ^ 0x74 ^ 0xFFFFFFFF)) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllllIIllIlIIIlIIlll);
  }
  
  private static boolean lIlIIIlIII(char lllllllllllllllllIIllIlIIlIIIIlI, byte lllllllllllllllllIIllIlIIlIIIIIl) {
    if (lIllllIlIlII(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (" ".length() == 0)
        return (0x64 ^ 0x58) & (0x65 ^ 0x59 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIlIlllll[0];
  }
  
  private static boolean lIlIIIlIIl(float lllllllllllllllllIIllIlIlIlIIllI) {
    if (lIllllIlIIIl(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (((0xDF ^ 0x88) & (0x7D ^ 0x2A ^ 0xFFFFFFFF)) > 0)
        return (0x39 ^ 0x33) & (0x95 ^ 0x9F ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIlIlllll[0];
  }
  
  private static boolean lIllllIlIIlI(byte lllllllllllllllllIIllIlIIIIIlIII, double lllllllllllllllllIIllIlIIIIIIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static void lIlIIIIlll() {
    llIlIlIl = new int[llIlIlllll[9]];
    llIlIlIl[llIlIlllll[0]] = (llIlIlllll[12] ^ llIlIlllll[13] ^ llIlIlllll[14] ^ llIlIlllll[15]) & (llIlIlllll[16] ^ llIlIlllll[17] ^ llIlIlllll[18] ^ llIlIlllll[19] ^ -llIlIllllI[llIlIlllll[20]].length());
    llIlIlIl[llIlIlllll[1]] = llIlIllllI[llIlIlllll[21]].length();
    llIlIlIl[llIlIlllll[2]] = llIlIlllll[22] ^ llIlIlllll[23];
    llIlIlIl[llIlIlllll[8]] = llIlIllllI[llIlIlllll[24]].length();
  }
  
  private static boolean lIllllIlIIIl(long lllllllllllllllllIIllIlIIIIIIlIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\windances\WinDanceMeteors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */