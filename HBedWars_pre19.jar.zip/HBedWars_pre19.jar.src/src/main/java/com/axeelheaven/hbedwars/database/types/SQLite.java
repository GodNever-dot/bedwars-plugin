package com.axeelheaven.hbedwars.database.types;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.database.Database;
import com.axeelheaven.hbedwars.database.cache.Callback;
import com.axeelheaven.hbedwars.database.profile.HData;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.UUID;

public class SQLite extends Database {
    private final BedWars plugin;
    private Connection connection;
    private String tableName;
    private File databaseFile;

    public SQLite(BedWars plugin) {
        this.plugin = plugin;
        this.tableName = plugin.getSettings().getString("database.table");
        this.databaseFile = new File(plugin.getDataFolder(), "database.db");
    }

    @Override
    public boolean connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            this.connection = DriverManager.getConnection("jdbc:sqlite:" + this.databaseFile);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void get(Callback callback) {
        // Implementation for getting data
    }

    @Override
    public boolean exists(UUID uuid) {
        try {
            PreparedStatement statement = this.connection.prepareStatement(
                "SELECT * FROM " + this.tableName + " WHERE uuid = ?"
            );
            statement.setString(1, uuid.toString());
            ResultSet result = statement.executeQuery();
            return result.next();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void create(UUID uuid, String name) {
        try {
            if (!exists(uuid)) {
                PreparedStatement statement = this.connection.prepareStatement(
                    "INSERT INTO " + this.tableName + " (uuid, name) VALUES (?, ?)"
                );
                statement.setString(1, uuid.toString());
                statement.setString(2, name);
                statement.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void load(HData data) {
        // Implementation for loading data
    }

    @Override
    public void save(HData data) {
        // Implementation for saving data
    }

    @Override
    public boolean tables() {
        try {
            PreparedStatement statement = this.connection.prepareStatement(
                "CREATE TABLE IF NOT EXISTS " + this.tableName + " (" +
                "uuid VARCHAR(36) PRIMARY KEY, " +
                "name VARCHAR(16) NOT NULL" +
                ")"
            );
            statement.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void close() {
        try {
            if (this.connection != null && !this.connection.isClosed()) {
                this.connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}