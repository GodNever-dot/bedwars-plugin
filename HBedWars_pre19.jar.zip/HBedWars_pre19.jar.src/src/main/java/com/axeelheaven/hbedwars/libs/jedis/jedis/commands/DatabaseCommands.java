package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.MigrateParams;

public interface DatabaseCommands {
  String select(int paramInt);
  
  long dbSize();
  
  String flushDB(FlushMode paramFlushMode);
  
  String swapDB(int paramInt1, int paramInt2);
  
  long move(String paramString, int paramInt);
  
  long move(byte[] paramArrayOfbyte, int paramInt);
  
  boolean copy(String paramString1, String paramString2, int paramInt, boolean paramBoolean);
  
  boolean copy(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt, boolean paramBoolean);
  
  String migrate(String paramString1, int paramInt1, String paramString2, int paramInt2, int paramInt3);
  
  String migrate(String paramString, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3);
  
  String migrate(String paramString, int paramInt1, int paramInt2, int paramInt3, MigrateParams paramMigrateParams, String... paramVarArgs);
  
  String migrate(String paramString, int paramInt1, int paramInt2, int paramInt3, MigrateParams paramMigrateParams, byte[]... paramVarArgs);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\DatabaseCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */