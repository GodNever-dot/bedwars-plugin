package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FunctionRestorePolicy;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.FunctionLoadParams;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.FunctionStats;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LibraryInfo;
import java.util.List;

public interface FunctionPipelineCommands {
  Response<Object> fcall(String paramString, List<String> paramList1, List<String> paramList2);
  
  Response<Object> fcallReadonly(String paramString, List<String> paramList1, List<String> paramList2);
  
  Response<String> functionDelete(String paramString);
  
  Response<byte[]> functionDump();
  
  Response<String> functionFlush();
  
  Response<String> functionFlush(FlushMode paramFlushMode);
  
  Response<String> functionKill();
  
  Response<List<LibraryInfo>> functionList();
  
  Response<List<LibraryInfo>> functionList(String paramString);
  
  Response<List<LibraryInfo>> functionListWithCode();
  
  Response<List<LibraryInfo>> functionListWithCode(String paramString);
  
  Response<String> functionLoad(String paramString1, String paramString2, String paramString3);
  
  Response<String> functionLoad(String paramString1, String paramString2, FunctionLoadParams paramFunctionLoadParams, String paramString3);
  
  Response<String> functionRestore(byte[] paramArrayOfbyte);
  
  Response<String> functionRestore(byte[] paramArrayOfbyte, FunctionRestorePolicy paramFunctionRestorePolicy);
  
  Response<FunctionStats> functionStats();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\FunctionPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */