/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph.entities;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Node
/*    */   extends GraphEntity
/*    */ {
/* 13 */   private final List<String> labels = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addLabel(String label) {
/* 19 */     this.labels.add(label);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeLabel(String label) {
/* 26 */     this.labels.remove(label);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getLabel(int index) {
/* 36 */     return this.labels.get(index);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getNumberOfLabels() {
/* 44 */     return this.labels.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 49 */     if (this == o) return true; 
/* 50 */     if (!(o instanceof Node)) return false; 
/* 51 */     if (!super.equals(o)) return false; 
/* 52 */     Node node = (Node)o;
/* 53 */     return Objects.equals(this.labels, node.labels);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 58 */     return Objects.hash(new Object[] { Integer.valueOf(super.hashCode()), this.labels });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     StringBuilder sb = new StringBuilder("Node{");
/* 64 */     sb.append("labels=").append(this.labels);
/* 65 */     sb.append(", id=").append(this.id);
/* 66 */     sb.append(", propertyMap=").append(this.propertyMap);
/* 67 */     sb.append('}');
/* 68 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\entities\Node.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */