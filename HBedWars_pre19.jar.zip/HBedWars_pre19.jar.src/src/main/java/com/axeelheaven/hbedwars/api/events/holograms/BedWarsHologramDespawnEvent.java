/*    */ package com.axeelheaven.hbedwars.api.events.holograms;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.custom.holograms.Hologram;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsHologramDespawnEvent
/*    */   extends Event {
/*    */   private final Player player;
/*    */   private final Hologram hologram;
/* 12 */   private static final HandlerList handlerList = new HandlerList(); public Player getPlayer() {
/* 13 */     return this.player; } public Hologram getHologram() {
/* 14 */     return this.hologram;
/*    */   }
/*    */   public BedWarsHologramDespawnEvent(Player player, Hologram hologram) {
/* 17 */     this.player = player;
/* 18 */     this.hologram = hologram;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 23 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 27 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\holograms\BedWarsHologramDespawnEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */