/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.providers.ConnectionProvider;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.providers.PooledConnectionProvider;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.JedisURIHelper;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.Pool;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.PooledObjectFactory;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*     */ import java.net.URI;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLParameters;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ public class JedisPooled
/*     */   extends UnifiedJedis
/*     */ {
/*     */   public JedisPooled() {
/*  18 */     this("127.0.0.1", 6379);
/*     */   }
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String url) {
/*  22 */     this(poolConfig, URI.create(url));
/*     */   }
/*     */   
/*     */   public JedisPooled(String host, int port) {
/*  26 */     this(new GenericObjectPoolConfig(), host, port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(String url) {
/*  39 */     this(URI.create(url));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(String url, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  57 */     this(URI.create(url), sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */   
/*     */   public JedisPooled(URI uri) {
/*  61 */     super(uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(URI uri, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  66 */     this(new GenericObjectPoolConfig(), uri, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(URI uri, int timeout) {
/*  71 */     this(new GenericObjectPoolConfig(), uri, timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(URI uri, int timeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  76 */     this(new GenericObjectPoolConfig(), uri, timeout, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String password) {
/*  82 */     this(poolConfig, host, port, timeout, password, 0);
/*     */   }
/*     */   
/*     */   public JedisPooled(String host, int port, String user, String password) {
/*  86 */     this(new GenericObjectPoolConfig(), host, port, user, password);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, String user, String password) {
/*  91 */     this(poolConfig, host, port, 2000, user, password, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String user, String password) {
/*  97 */     this(poolConfig, host, port, timeout, user, password, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String password, boolean ssl) {
/* 102 */     this(poolConfig, host, port, timeout, password, 0, ssl);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String user, String password, boolean ssl) {
/* 107 */     this(poolConfig, host, port, timeout, user, password, 0, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String password, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 114 */     this(poolConfig, host, port, timeout, password, 0, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port) {
/* 120 */     this(poolConfig, host, port, 2000);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, boolean ssl) {
/* 125 */     this(poolConfig, host, port, 2000, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 131 */     this(poolConfig, host, port, 2000, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout) {
/* 137 */     this(poolConfig, host, port, timeout, (String)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, boolean ssl) {
/* 142 */     this(poolConfig, host, port, timeout, (String)null, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 149 */     this(poolConfig, host, port, timeout, (String)null, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String password, int database) {
/* 155 */     this(poolConfig, host, port, timeout, password, database, (String)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String user, String password, int database) {
/* 160 */     this(poolConfig, host, port, timeout, user, password, database, (String)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String password, int database, boolean ssl) {
/* 165 */     this(poolConfig, host, port, timeout, password, database, (String)null, ssl);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String user, String password, int database, boolean ssl) {
/* 170 */     this(poolConfig, host, port, timeout, user, password, database, (String)null, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String password, int database, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 177 */     this(poolConfig, host, port, timeout, password, database, null, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String password, int database, String clientName) {
/* 183 */     this(poolConfig, host, port, timeout, timeout, password, database, clientName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String user, String password, int database, String clientName) {
/* 189 */     this(poolConfig, host, port, timeout, timeout, user, password, database, clientName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String password, int database, String clientName, boolean ssl) {
/* 195 */     this(poolConfig, host, port, timeout, timeout, password, database, clientName, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String user, String password, int database, String clientName, boolean ssl) {
/* 201 */     this(poolConfig, host, port, timeout, timeout, user, password, database, clientName, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int timeout, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 208 */     this(poolConfig, host, port, timeout, timeout, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 216 */     this(poolConfig, host, port, connectionTimeout, soTimeout, 0, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 225 */     this(poolConfig, host, port, connectionTimeout, soTimeout, infiniteSoTimeout, null, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String user, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 234 */     this(poolConfig, host, port, connectionTimeout, soTimeout, 0, user, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String user, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 243 */     this(new HostAndPort(host, port), DefaultJedisClientConfig.create(connectionTimeout, soTimeout, infiniteSoTimeout, user, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier, null));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(HostAndPort hostAndPort, JedisClientConfig clientConfig) {
/* 249 */     this(new GenericObjectPoolConfig(), hostAndPort, clientConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, HostAndPort hostAndPort, JedisClientConfig clientConfig) {
/* 254 */     this(hostAndPort, clientConfig, poolConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, JedisSocketFactory jedisSocketFactory, JedisClientConfig clientConfig) {
/* 259 */     this(new ConnectionFactory(jedisSocketFactory, clientConfig), poolConfig);
/*     */   }
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig) {
/* 263 */     this(poolConfig, "127.0.0.1", 6379);
/*     */   }
/*     */   
/*     */   public JedisPooled(String host, int port, boolean ssl) {
/* 267 */     this(new GenericObjectPoolConfig(), host, port, ssl);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String password, int database, String clientName) {
/* 273 */     this(poolConfig, host, port, connectionTimeout, soTimeout, (String)null, password, database, clientName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String user, String password, int database, String clientName) {
/* 279 */     this(poolConfig, host, port, connectionTimeout, soTimeout, 0, user, password, database, clientName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String user, String password, int database, String clientName) {
/* 285 */     this(new HostAndPort(host, port), DefaultJedisClientConfig.create(connectionTimeout, soTimeout, infiniteSoTimeout, user, password, database, clientName, false, null, null, null, null), poolConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(String host, int port, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 293 */     this(new GenericObjectPoolConfig(), host, port, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String password, int database, String clientName, boolean ssl) {
/* 300 */     this(poolConfig, host, port, connectionTimeout, soTimeout, password, database, clientName, ssl, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, String host, int port, int connectionTimeout, int soTimeout, String user, String password, int database, String clientName, boolean ssl) {
/* 307 */     this(poolConfig, host, port, connectionTimeout, soTimeout, user, password, database, clientName, ssl, (SSLSocketFactory)null, (SSLParameters)null, (HostnameVerifier)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, URI uri) {
/* 312 */     this(poolConfig, uri, 2000);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, URI uri, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 318 */     this(poolConfig, uri, 2000, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, URI uri, int timeout) {
/* 323 */     this(poolConfig, uri, timeout, timeout);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, URI uri, int timeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 329 */     this(poolConfig, uri, timeout, timeout, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, URI uri, int connectionTimeout, int soTimeout) {
/* 334 */     this(poolConfig, uri, connectionTimeout, soTimeout, (SSLSocketFactory)null, (SSLParameters)null, (HostnameVerifier)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, URI uri, int connectionTimeout, int soTimeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 340 */     this(poolConfig, uri, connectionTimeout, soTimeout, 0, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, URI uri, int connectionTimeout, int soTimeout, int infiniteSoTimeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 347 */     this(new HostAndPort(uri.getHost(), uri.getPort()), DefaultJedisClientConfig.create(connectionTimeout, soTimeout, infiniteSoTimeout, 
/* 348 */           JedisURIHelper.getUser(uri), 
/* 349 */           JedisURIHelper.getPassword(uri), JedisURIHelper.getDBIndex(uri), null, 
/* 350 */           JedisURIHelper.isRedisSSLScheme(uri), sslSocketFactory, sslParameters, hostnameVerifier, null));
/*     */   }
/*     */   
/*     */   public JedisPooled(GenericObjectPoolConfig<Connection> poolConfig, PooledObjectFactory<Connection> factory) {
/* 354 */     this(factory, poolConfig);
/*     */   }
/*     */   
/*     */   public JedisPooled(HostAndPort hostAndPort) {
/* 358 */     this(new ConnectionFactory(hostAndPort), new GenericObjectPoolConfig());
/*     */   }
/*     */   
/*     */   public JedisPooled(HostAndPort hostAndPort, GenericObjectPoolConfig<Connection> poolConfig) {
/* 362 */     this(new ConnectionFactory(hostAndPort), poolConfig);
/*     */   }
/*     */   
/*     */   public JedisPooled(HostAndPort hostAndPort, JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig) {
/* 366 */     this(new ConnectionFactory(hostAndPort, clientConfig), poolConfig);
/*     */   }
/*     */   
/*     */   public JedisPooled(PooledObjectFactory<Connection> factory, GenericObjectPoolConfig<Connection> poolConfig) {
/* 370 */     this(new PooledConnectionProvider(factory, poolConfig));
/*     */   }
/*     */   
/*     */   public JedisPooled(PooledConnectionProvider provider) {
/* 374 */     super((ConnectionProvider)provider);
/*     */   }
/*     */   
/*     */   public final Pool<Connection> getPool() {
/* 378 */     return ((PooledConnectionProvider)this.provider).getPool();
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\JedisPooled.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */