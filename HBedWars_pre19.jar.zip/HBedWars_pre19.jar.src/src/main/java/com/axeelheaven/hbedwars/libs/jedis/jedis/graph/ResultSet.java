/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;public interface ResultSet extends Iterable<Record> {
/*    */   int size();
/*    */   
/*    */   Header getHeader();
/*    */   
/*    */   Statistics getStatistics();
/*    */   
/*    */   public enum ColumnType {
/*  9 */     UNKNOWN,
/* 10 */     SCALAR,
/* 11 */     NODE,
/* 12 */     RELATION;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\ResultSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */