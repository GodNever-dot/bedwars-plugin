/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*    */ import java.time.Duration;
/*    */ 
/*    */ public class JedisPoolConfig
/*    */   extends GenericObjectPoolConfig<Jedis>
/*    */ {
/*    */   public JedisPoolConfig() {
/* 10 */     setTestWhileIdle(true);
/* 11 */     setMinEvictableIdleTime(Duration.ofMillis(60000L));
/* 12 */     setTimeBetweenEvictionRuns(Duration.ofMillis(30000L));
/* 13 */     setNumTestsPerEvictionRun(-1);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\JedisPoolConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */