/*    */ package com.axeelheaven.hbedwars.api.events.game.player;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.api.arena.Arena;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsPlayerKillEvent extends Event {
/*    */   private final Arena arena;
/*    */   private final Player player;
/* 11 */   private static final HandlerList handlerList = new HandlerList(); private final Player victim; public Arena getArena() {
/* 12 */     return this.arena; }
/* 13 */   public Player getPlayer() { return this.player; } public Player getVictim() { return this.victim; }
/*    */ 
/*    */   
/*    */   public BedWarsPlayerKillEvent(Arena arena, Player player, Player victim) {
/* 17 */     this.arena = arena;
/* 18 */     this.player = player;
/* 19 */     this.victim = victim;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 24 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 28 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\game\player\BedWarsPlayerKillEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */