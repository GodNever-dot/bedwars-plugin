package com.axeelheaven.hbedwars.cosmetics.beddestroys;

import com.axeelheaven.hbedwars.libs.xseries.XMaterial;
import org.bukkit.Effect;

public class BedDestroyLavaExplosion extends BedDestroy {
  public BedDestroyLavaExplosion(String lllllllllllllllllllIIIIIIllIlIll, String lllllllllllllllllllIIIIIIllIllII, Exception lllllllllllllllllllIIIIIIlllIIIl) {
    super(lllllllllllllllllllIIIIIIllIlIll, lllllllllllllllllllIIIIIIllIllII, lllllllllllllllllllIIIIIIlllIIIl);
  }
  
  static {
  
  }
  
  public void execute(float lllllllllllllllllllIIIIIIlllIlll) {
    lllllllllllllllllllIIIIIIlllIlll.getWorld().playEffect(lllllllllllllllllllIIIIIIlllIlll, Effect.STEP_SOUND, XMaterial.LAVA.parseMaterial());
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\beddestroys\BedDestroyLavaExplosion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */