package com.axeelheaven.hbedwars.commands;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.libs.json.simple.JSONObject;
import com.axeelheaven.hbedwars.libs.json.simple.parser.JSONParser;
import com.axeelheaven.hbedwars.libs.json.simple.parser.ParseException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class RejoinCommand implements CommandExecutor {
  private JSONObject getJsonObject(char llllllllllllllllllIlllllIIlIlIIl) {
    if (lIIIlIIIIllI(lIII(llllllllllllllllllIlllllIIlIlIIl)))
      try {
        return (JSONObject)this.jsonParser.parse(llllllllllllllllllIlllllIIlIlIIl);
      } catch (ParseException llllllllllllllllllIlllllIIlIlIll) {
        ParseException parseException1;
        return null;
      }  
    return null;
  }
  
  private static boolean lIIIlIIIllIl(String llllllllllllllllllIllllIIllllIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > null);
  }
  
  private static boolean llI(Exception llllllllllllllllllIlllllIIIIIlll) {
    if (lIIIlIIIlIIl(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ("  ".length() <= -" ".length())
        return (0x36 ^ 0x79) & (0x10 ^ 0x5F ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIlIlIIlll[1];
  }
  
  private static String l(boolean llllllllllllllllllIllllIllIIIlll, boolean llllllllllllllllllIllllIllIIlIll) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   10: bipush #53
    //   12: iaload
    //   13: aaload
    //   14: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   17: aload_1
    //   18: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   21: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   24: invokevirtual digest : ([B)[B
    //   27: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   30: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   33: bipush #54
    //   35: iaload
    //   36: aaload
    //   37: invokespecial <init> : ([BLjava/lang/String;)V
    //   40: astore_2
    //   41: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   44: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   47: bipush #39
    //   49: iaload
    //   50: aaload
    //   51: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   54: astore_3
    //   55: aload_3
    //   56: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lII : [I
    //   59: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   62: bipush #9
    //   64: iaload
    //   65: iaload
    //   66: aload_2
    //   67: invokevirtual init : (ILjava/security/Key;)V
    //   70: new java/lang/String
    //   73: dup
    //   74: aload_3
    //   75: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   78: aload_0
    //   79: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   82: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   85: invokevirtual decode : ([B)[B
    //   88: invokevirtual doFinal : ([B)[B
    //   91: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   94: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   97: areturn
    //   98: astore_2
    //   99: aload_2
    //   100: invokevirtual printStackTrace : ()V
    //   103: aconst_null
    //   104: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	105	1	llllllllllllllllllIllllIllIIIllI	Ljava/lang/String;
    //   55	43	3	llllllllllllllllllIllllIllIIlIlI	Ljavax/crypto/Cipher;
    //   0	105	1	llllllllllllllllllIllllIllIIlIll	Z
    //   0	105	3	llllllllllllllllllIllllIlIllllll	Ljava/lang/String;
    //   41	57	2	llllllllllllllllllIllllIllIIIlII	Ljavax/crypto/spec/SecretKeySpec;
    //   0	105	2	llllllllllllllllllIllllIllIIlIII	D
    //   99	4	2	llllllllllllllllllIllllIllIIIlIl	Ljava/lang/Exception;
    //   0	105	3	llllllllllllllllllIllllIllIIIIll	Z
    //   0	105	0	llllllllllllllllllIllllIllIIlIIl	Ljava/lang/String;
    //   0	105	1	llllllllllllllllllIllllIllIIIIIl	J
    //   0	105	2	llllllllllllllllllIllllIllIIIIII	C
    //   0	105	0	llllllllllllllllllIllllIllIIIlll	Z
    //   0	105	0	llllllllllllllllllIllllIllIIIIlI	F
    // Exception table:
    //   from	to	target	type
    //   0	97	98	java/lang/Exception
  }
  
  private static boolean lIIIlIIIlIIl(byte llllllllllllllllllIllllIIlllllII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static boolean lIIIlIIIlIII(int llllllllllllllllllIllllIlIIIIIll, int llllllllllllllllllIllllIlIIIIIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIII(short llllllllllllllllllIllllIlIllllII) {
    if (lIIIlIIIlllI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return "  ".length() & ("  ".length() ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIlIlIIlll[1];
  }
  
  private static boolean lIIl(Exception llllllllllllllllllIlllllIIIlllII, long llllllllllllllllllIlllllIIIlllIl) {
    if (lIIIlIIIlIII(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (((0xC ^ 0x31) & (0x44 ^ 0x79 ^ 0xFFFFFFFF)) == -" ".length())
        return (0xB1 ^ 0xB4) & (0x6C ^ 0x69 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIlIlIIlll[1];
  }
  
  private static String ll(String llllllllllllllllllIlllllIlIIIIll, String llllllllllllllllllIlllllIlIIIlIl) {
    llllllllllllllllllIlllllIIllllII = new String(Base64.getDecoder().decode(llllllllllllllllllIlllllIlIIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIlllllIlIIlIlI = new StringBuilder();
    char[] llllllllllllllllllIlllllIlIIlIll = llllllllllllllllllIlllllIlIIIlIl.toCharArray();
    int llllllllllllllllllIlllllIIllllll = lII[lIlIlIIlll[0]];
    char[] arrayOfChar1 = llllllllllllllllllIlllllIIllllII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lII[lIlIlIIlll[0]];
    while (lIIIlIIIIllI(lIIl(j, i))) {
      char llllllllllllllllllIlllllIlIIIIII = arrayOfChar1[j];
      lIlIIllllI[lIlIlIIlll[1]].length();
      llllllllllllllllllIlllllIIllllll++;
      j++;
      "".length();
      if (lIIIlIIIIlll(lIlIlIIlll[2] ^ lIlIlIIlll[3], (lIlIlIIlll[4] ^ lIlIlIIlll[5]) & (lIlIlIIlll[6] ^ lIlIlIIlll[7] ^ lIlIlIIlll[8])))
        return null; 
    } 
    return String.valueOf(llllllllllllllllllIlllllIlIIlIlI);
  }
  
  private static boolean lIIIlIIIIllI(long llllllllllllllllllIllllIIllllllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static String lI(double llllllllllllllllllIlllllIIIIllII, long llllllllllllllllllIlllllIIIlIlIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   10: bipush #9
    //   12: iaload
    //   13: aaload
    //   14: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   17: aload_1
    //   18: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   21: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   24: invokevirtual digest : ([B)[B
    //   27: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lII : [I
    //   30: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   33: bipush #10
    //   35: iaload
    //   36: iaload
    //   37: invokestatic copyOf : ([BI)[B
    //   40: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   43: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   46: bipush #11
    //   48: iaload
    //   49: aaload
    //   50: invokespecial <init> : ([BLjava/lang/String;)V
    //   53: astore_2
    //   54: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   57: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   60: bipush #12
    //   62: iaload
    //   63: aaload
    //   64: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   67: astore_3
    //   68: aload_3
    //   69: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lII : [I
    //   72: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   75: bipush #9
    //   77: iaload
    //   78: iaload
    //   79: aload_2
    //   80: invokevirtual init : (ILjava/security/Key;)V
    //   83: new java/lang/String
    //   86: dup
    //   87: aload_3
    //   88: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   91: aload_0
    //   92: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   95: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   98: invokevirtual decode : ([B)[B
    //   101: invokevirtual doFinal : ([B)[B
    //   104: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   107: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   110: areturn
    //   111: astore_2
    //   112: aload_2
    //   113: invokevirtual printStackTrace : ()V
    //   116: aconst_null
    //   117: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	118	1	llllllllllllllllllIlllllIIIIllIl	Ljava/lang/String;
    //   0	118	3	llllllllllllllllllIlllllIIIIlIIl	J
    //   54	57	2	llllllllllllllllllIlllllIIIlIIII	Ljavax/crypto/spec/SecretKeySpec;
    //   0	118	2	llllllllllllllllllIlllllIIIlIlIl	J
    //   0	118	1	llllllllllllllllllIlllllIIIIlllI	B
    //   112	4	2	llllllllllllllllllIlllllIIIlIlII	Ljava/lang/Exception;
    //   0	118	0	llllllllllllllllllIlllllIIIlIIIl	Ljava/lang/String;
    //   0	118	3	llllllllllllllllllIlllllIIIlIIlI	F
    //   0	118	2	llllllllllllllllllIlllllIIIIlIlI	Ljava/lang/Exception;
    //   0	118	0	llllllllllllllllllIlllllIIIIllII	D
    //   0	118	1	llllllllllllllllllIlllllIIIIlIll	J
    //   68	43	3	llllllllllllllllllIlllllIIIIllll	Ljavax/crypto/Cipher;
    //   0	118	0	llllllllllllllllllIlllllIIIlIIll	Ljava/lang/Exception;
    // Exception table:
    //   from	to	target	type
    //   0	110	111	java/lang/Exception
  }
  
  private static boolean lIIIlIIIIlll(byte llllllllllllllllllIllllIlIIIIlll, int llllllllllllllllllIllllIlIIIIllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static void lII() {
    ll = new String[lII[lIlIlIIlll[10]]];
    ll[lII[lIlIlIIlll[0]]] = l(lIlIIllllI[lIlIlIIlll[36]], lIlIIllllI[lIlIlIIlll[55]]);
    ll[lII[lIlIlIIlll[1]]] = l(lIlIIllllI[lIlIlIIlll[40]], lIlIIllllI[lIlIlIIlll[56]]);
    ll[lII[lIlIlIIlll[9]]] = l(lIlIIllllI[lIlIlIIlll[57]], lIlIIllllI[lIlIlIIlll[58]]);
    ll[lII[lIlIlIIlll[11]]] = lI(lIlIIllllI[lIlIlIIlll[20]], lIlIIllllI[lIlIlIIlll[59]]);
    ll[lII[lIlIlIIlll[12]]] = ll(lIlIIllllI[lIlIlIIlll[41]], lIlIIllllI[lIlIlIIlll[60]]);
    ll[lII[lIlIlIIlll[14]]] = l(lIlIIllllI[lIlIlIIlll[61]], lIlIIllllI[lIlIlIIlll[62]]);
    ll[lII[lIlIlIIlll[26]]] = l(lIlIIllllI[lIlIlIIlll[63]], lIlIIllllI[lIlIlIIlll[64]]);
    ll[lII[lIlIlIIlll[27]]] = ll(lIlIIllllI[lIlIlIIlll[65]], lIlIIllllI[lIlIlIIlll[66]]);
  }
  
  private static String lIIIIllIllII(String llllllllllllllllllIllllIlIlIIlII, String llllllllllllllllllIllllIlIIllllI) {
    String str = new String(Base64.getDecoder().decode(llllllllllllllllllIllllIlIlIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIllllIlIlIIIlI = new StringBuilder();
    char[] llllllllllllllllllIllllIlIlIIIIl = llllllllllllllllllIllllIlIIllllI.toCharArray();
    int llllllllllllllllllIllllIlIlIIIII = lIlIlIIlll[1];
    char[] arrayOfChar1 = str.toCharArray();
    int i = arrayOfChar1.length;
    llllllllllllllllllIllllIlIIllIII = lIlIlIIlll[1];
    while (lIIIlIIIlIII(llllllllllllllllllIllllIlIIllIII, i)) {
      char llllllllllllllllllIllllIlIlIIlIl = arrayOfChar1[llllllllllllllllllIllllIlIIllIII];
      "".length();
      llllllllllllllllllIllllIlIlIIIII++;
      llllllllllllllllllIllllIlIIllIII++;
      "".length();
      if ((0xBE ^ 0xBA) < ((0x54 ^ 0x4F) & (0x62 ^ 0x79 ^ 0xFFFFFFFF)))
        return null; 
    } 
    return String.valueOf(llllllllllllllllllIllllIlIlIIIlI);
  }
  
  private static boolean lIIIlIIIlllI(float llllllllllllllllllIllllIlIIIIIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static void lIIIlIIIIlIl() {
    lIlIlIIlll = new int[68];
    lIlIlIIlll[0] = " ".length();
    lIlIlIIlll[1] = (0x98 ^ 0x88) & (0x61 ^ 0x71 ^ 0xFFFFFFFF);
    lIlIlIIlll[2] = 0x7A ^ 0xD;
    lIlIlIIlll[3] = 0xC4 ^ 0xB7;
    lIlIlIIlll[4] = 0x2E ^ 0x5;
    lIlIlIIlll[5] = 0xB5 ^ 0x8D ^ 0x9B ^ 0x90;
    lIlIlIIlll[6] = (0xC ^ 0x58) + (0xED ^ 0x8E) - 75 + 37 - -18 + 16 + (0x22 ^ 0x47);
    lIlIlIIlll[7] = (0xBB ^ 0x80) + (0x22 ^ 0x43) - (0xD8 ^ 0x96) + (0x3D ^ 0x79);
    lIlIlIIlll[8] = -" ".length();
    lIlIlIIlll[9] = "  ".length();
    lIlIlIIlll[10] = 0x5 ^ 0xD;
    lIlIlIIlll[11] = "   ".length();
    lIlIlIIlll[12] = 0x2B ^ 0x2F;
    lIlIlIIlll[13] = 0x3F ^ 0x1B ^ 0x2D ^ 0x0;
    lIlIlIIlll[14] = 0xFE ^ 0x87 ^ 0xE7 ^ 0x9B;
    lIlIlIIlll[15] = 128 + 48 - 167 + 142;
    lIlIlIIlll[16] = 129 + 133 - 133 + 29;
    lIlIlIIlll[17] = (0x44 ^ 0x30) + (0x87 ^ 0x8D) - -(0x6B ^ 0x7F) + (0x53 ^ 0x5A);
    lIlIlIIlll[18] = 91 + 131 - 214 + 140;
    lIlIlIIlll[19] = 0x7D ^ 0x5 ^ 0xD5 ^ 0x95;
    lIlIlIIlll[20] = 0x64 ^ 0x7D;
    lIlIlIIlll[21] = 0x57 ^ 0x17;
    lIlIlIIlll[22] = 0x65 ^ 0x2C;
    lIlIlIIlll[23] = 0x5C ^ 0x7A;
    lIlIlIIlll[24] = 156 + 148 - 194 + 101 ^ 4 + 165 - 0 + 20;
    lIlIlIIlll[25] = 132 + 89 - 101 + 16;
    lIlIlIIlll[26] = 0x40 ^ 0x12 ^ 0x16 ^ 0x42;
    lIlIlIIlll[27] = 0x35 ^ 0x11 ^ 0x5B ^ 0x78;
    lIlIlIIlll[28] = 0x34 ^ 0x4E ^ 0x5B ^ 0x54;
    lIlIlIIlll[29] = 0x83 ^ 0x99 ^ 0xFB ^ 0xB9;
    lIlIlIIlll[30] = 0xD6 ^ 0x80;
    lIlIlIIlll[31] = 67 + 38 - -4 + 18;
    lIlIlIIlll[32] = (0x61 ^ 0x52) + 107 + 70 - 165 + 144 - (0x0 ^ 0x59) + (0x1C ^ 0x28);
    lIlIlIIlll[33] = (0x51 ^ 0x74) + (0x64 ^ 0xC) - 106 + 30 - 98 + 93 + 80 + 134 - 112 + 63;
    lIlIlIIlll[34] = 0xE4 ^ 0xC2 ^ 0xD5 ^ 0xB4;
    lIlIlIIlll[35] = 0x17 ^ 0x6D;
    lIlIlIIlll[36] = 0x42 ^ 0x8 ^ 0xD5 ^ 0x8C;
    lIlIlIIlll[37] = 15 + 127 - 19 + 8 ^ 58 + 178 - 108 + 52;
    lIlIlIIlll[38] = 0x83 ^ 0xC2;
    lIlIlIIlll[39] = 0x4A ^ 0xA ^ 0xCB ^ 0x99;
    lIlIlIIlll[40] = 0x83 ^ 0x96;
    lIlIlIIlll[41] = 0x2E ^ 0x23 ^ 0x6D ^ 0x7B;
    lIlIlIIlll[42] = 0xDA ^ 0xB8;
    lIlIlIIlll[43] = 0x23 ^ 0x47;
    lIlIlIIlll[44] = 0x38 ^ 0x32;
    lIlIlIIlll[45] = 0x2B ^ 0x7D ^ 0x15 ^ 0x48;
    lIlIlIIlll[46] = 0xC8 ^ 0xAA ^ 0x3C ^ 0x52;
    lIlIlIIlll[47] = 0xAC ^ 0xA1;
    lIlIlIIlll[48] = 0x7C ^ 0x1A;
    lIlIlIIlll[49] = 0xAC ^ 0x90;
    lIlIlIIlll[50] = 0x5F ^ 0xA;
    lIlIlIIlll[51] = 0x3E ^ 0x31;
    lIlIlIIlll[52] = 0x49 ^ 0x47;
    lIlIlIIlll[53] = 0x15 ^ 0x5;
    lIlIlIIlll[54] = 0x2 ^ 0x2F ^ 0x8D ^ 0xB1;
    lIlIlIIlll[55] = 97 + 12 - 107 + 127 ^ 42 + 138 - 160 + 129;
    lIlIlIIlll[56] = 0x7C ^ 0x6A;
    lIlIlIIlll[57] = 0xB8 ^ 0xB1 ^ 0x13 ^ 0xD;
    lIlIlIIlll[58] = 0x63 ^ 0x37 ^ 0x4 ^ 0x48;
    lIlIlIIlll[59] = 0xB6 ^ 0xAC;
    lIlIlIIlll[60] = 0x9 ^ 0x15;
    lIlIlIIlll[61] = 0xDF ^ 0xC2;
    lIlIlIIlll[62] = 0xBA ^ 0xBE ^ 0x37 ^ 0x2D;
    lIlIlIIlll[63] = 0x1 ^ 0x17 ^ 0xC ^ 0x5;
    lIlIlIIlll[64] = 0xFD ^ 0x8E ^ 0x68 ^ 0x3B;
    lIlIlIIlll[65] = 106 + 129 - 226 + 164 ^ 75 + 35 - 88 + 118;
    lIlIlIIlll[66] = 0x83 ^ 0xA1;
    lIlIlIIlll[67] = 50 + 65 - 92 + 148 ^ 7 + 117 - 41 + 53;
  }
  
  private static String lIIIIllIlIll(float llllllllllllllllllIllllIlIllIIlI, byte llllllllllllllllllIllllIlIllIIIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   23: bipush #10
    //   25: iaload
    //   26: invokestatic copyOf : ([BI)[B
    //   29: ldc_w 'DES'
    //   32: invokespecial <init> : ([BLjava/lang/String;)V
    //   35: astore_2
    //   36: ldc_w 'DES'
    //   39: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   42: astore_3
    //   43: aload_3
    //   44: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   47: bipush #9
    //   49: iaload
    //   50: aload_2
    //   51: invokevirtual init : (ILjava/security/Key;)V
    //   54: new java/lang/String
    //   57: dup
    //   58: aload_3
    //   59: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   62: aload_0
    //   63: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   66: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   69: invokevirtual decode : ([B)[B
    //   72: invokevirtual doFinal : ([B)[B
    //   75: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   78: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   81: areturn
    //   82: astore_2
    //   83: aload_2
    //   84: invokevirtual printStackTrace : ()V
    //   87: aconst_null
    //   88: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   83	4	2	llllllllllllllllllIllllIlIllIlIl	Ljava/lang/Exception;
    //   0	89	0	llllllllllllllllllIllllIlIllIlII	Ljava/lang/String;
    //   0	89	1	llllllllllllllllllIllllIlIllIIll	Ljava/lang/String;
    //   0	89	2	llllllllllllllllllIllllIlIllIIII	J
    //   43	39	3	llllllllllllllllllIllllIlIllIllI	Ljavax/crypto/Cipher;
    //   0	89	1	llllllllllllllllllIllllIlIllIIIl	B
    //   0	89	0	llllllllllllllllllIllllIlIllIIlI	F
    //   0	89	3	llllllllllllllllllIllllIlIlIllll	J
    //   36	46	2	llllllllllllllllllIllllIlIllIlll	Ljavax/crypto/spec/SecretKeySpec;
    // Exception table:
    //   from	to	target	type
    //   0	81	82	java/lang/Exception
  }
  
  public RejoinCommand(int llllllllllllllllllIlllllIIlIIIII) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: new com/axeelheaven/hbedwars/libs/json/simple/parser/JSONParser
    //   8: dup
    //   9: invokespecial <init> : ()V
    //   12: putfield jsonParser : Lcom/axeelheaven/hbedwars/libs/json/simple/parser/JSONParser;
    //   15: aload_0
    //   16: aload_1
    //   17: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   20: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	21	0	llllllllllllllllllIlllllIIlIIIlI	Z
    //   0	21	0	llllllllllllllllllIlllllIIlIIIIl	Z
    //   0	21	1	llllllllllllllllllIlllllIIlIIlIl	D
    //   0	21	1	llllllllllllllllllIlllllIIlIIIII	I
    //   0	21	1	llllllllllllllllllIlllllIIlIIIll	Lcom/axeelheaven/hbedwars/BedWars;
    //   0	21	0	llllllllllllllllllIlllllIIlIIlII	Lcom/axeelheaven/hbedwars/commands/RejoinCommand;
  }
  
  private static boolean lll(long llllllllllllllllllIlllllIIIIIlII) {
    if (lIIIlIIIIllI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return (0x46 ^ 0x14) & (0x4D ^ 0x1F ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIlIlIIlll[1];
  }
  
  private static void lIIIlIIIIIII() {
    lIlIIllllI = new String[lIlIlIIlll[67]];
    lIlIIllllI[lIlIlIIlll[1]] = lIIIIllIlIll("q7IWKfMFjv4=", "GHBmu");
    lIlIIllllI[lIlIlIIlll[0]] = lIIIIllIllII("", "QxyTs");
    lIlIIllllI[lIlIlIIlll[9]] = lIIIIllIllII("GgJv", "WFZJK");
    lIlIIllllI[lIlIlIIlll[11]] = lIIIIllIllIl("NJd/XfT7OeQ=", "LDqUf");
    lIlIIllllI[lIlIlIIlll[12]] = lIIIIllIllII("Dj8h", "JzrOA");
    lIlIIllllI[lIlIlIIlll[14]] = lIIIIllIllII("ZA==", "DrKLy");
    lIlIIllllI[lIlIlIIlll[26]] = lIIIIllIllIl("QHAYbGAYbDo=", "bPaek");
    lIlIIllllI[lIlIlIIlll[27]] = lIIIIllIlIll("axKjcUvWXjU=", "ppgUJ");
    lIlIIllllI[lIlIlIIlll[10]] = lIIIIllIllIl("uulTyjYGCs0=", "AhLst");
    lIlIIllllI[lIlIlIIlll[13]] = lIIIIllIlIll("XtNypVQZ0tY=", "wEstg");
    lIlIIllllI[lIlIlIIlll[44]] = lIIIIllIlIll("X1rTkbY0bHM=", "CHCOF");
    lIlIIllllI[lIlIlIIlll[45]] = lIIIIllIllII("", "FCQvc");
    lIlIIllllI[lIlIlIIlll[46]] = lIIIIllIllIl("5O5W2BAkLeA=", "vkRdi");
    lIlIIllllI[lIlIlIIlll[47]] = lIIIIllIllII("aHFT", "HQshc");
    lIlIIllllI[lIlIlIIlll[52]] = lIIIIllIllIl("4A9sKEKO0DQ=", "srdPQ");
    lIlIIllllI[lIlIlIIlll[51]] = lIIIIllIllIl("kl11jlG1xRc=", "nXMoB");
    lIlIIllllI[lIlIlIIlll[53]] = lIIIIllIllII("AANa", "MGocm");
    lIlIIllllI[lIlIlIIlll[54]] = lIIIIllIllIl("I5kldx80Thq5RO7wCQM9uA==", "Wucnn");
    lIlIIllllI[lIlIlIIlll[39]] = lIIIIllIllIl("EPEOyHaYt7R+YSGfh8084w==", "HNmqg");
    lIlIIllllI[lIlIlIIlll[36]] = lIIIIllIlIll("4jS02/0wUrixJH+rYcCCuA==", "uaxcz");
    lIlIIllllI[lIlIlIIlll[55]] = lIIIIllIllIl("7Le8vpaKII0=", "KBdZm");
    lIlIIllllI[lIlIlIIlll[40]] = lIIIIllIllII("OgAlQwwlLgYcYDRH", "mzatK");
    lIlIIllllI[lIlIlIIlll[56]] = lIIIIllIllIl("CrWeaOcxg00=", "saWto");
    lIlIIllllI[lIlIlIIlll[57]] = lIIIIllIlIll("0Pr51/x7nXAmBlx0TGdjIA==", "ryQZM");
    lIlIIllllI[lIlIlIIlll[58]] = lIIIIllIllII("ARY3Ci0=", "lFUkg");
    lIlIIllllI[lIlIlIIlll[20]] = lIIIIllIlIll("1crGhEgly74Vy57+ObM3t4JT8aFt62/X05tXXJTmYAE=", "Ghkkb");
    lIlIIllllI[lIlIlIIlll[59]] = lIIIIllIlIll("AypKgqqsaYk=", "MknyN");
    lIlIIllllI[lIlIlIIlll[41]] = lIIIIllIlIll("Qzzvi+spAlo0KSpZPLN7kQ==", "SEJUP");
    lIlIIllllI[lIlIlIIlll[60]] = lIIIIllIlIll("Xzw+rRIlUpA=", "jLOFN");
    lIlIIllllI[lIlIlIIlll[61]] = lIIIIllIllII("AkMtDGUZJD1eJQtV", "xhGkR");
    lIlIIllllI[lIlIlIIlll[62]] = lIIIIllIllII("LhY8BCQ=", "IqDUA");
    lIlIIllllI[lIlIlIIlll[63]] = lIIIIllIlIll("PY9HzChMao/c2IocviLrpA==", "xuHZc");
    lIlIIllllI[lIlIlIIlll[64]] = lIIIIllIlIll("1lGHc1bpqCo=", "tmJNp");
    lIlIIllllI[lIlIlIIlll[65]] = lIIIIllIllII("Dws9AiESFikuNAwSKA80eAsfX0oJMhstIgUdLTcwLhYoISQpHABTCAYMISEtL20dASR8ZQ==", "AXxge");
    lIlIIllllI[lIlIlIIlll[66]] = lIIIIllIllII("IygbKwk=", "SzqGY");
  }
  
  static {
    lIIIlIIIIlIl();
    lIIIlIIIIIII();
    lIl();
    lII();
  }
  
  public boolean onCommand(CommandSender llllllllllllllllllIllllIllIlllIl, Command llllllllllllllllllIllllIllIlIlll, String llllllllllllllllllIllllIllIllIll, String[] llllllllllllllllllIllllIllIllIII) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof org/bukkit/entity/Player
    //   4: invokestatic llI : (I)Z
    //   7: invokestatic lIIIlIIIIllI : (I)Z
    //   10: ifeq -> 23
    //   13: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lII : [I
    //   16: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   19: iconst_1
    //   20: iaload
    //   21: iaload
    //   22: ireturn
    //   23: aload_1
    //   24: checkcast org/bukkit/entity/Player
    //   27: astore #5
    //   29: aload_0
    //   30: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   33: invokevirtual getGameManager : ()Lcom/axeelheaven/hbedwars/GameManager;
    //   36: aload #5
    //   38: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   43: invokevirtual getData : (Ljava/util/UUID;)Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   46: astore #6
    //   48: aload_0
    //   49: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   52: invokevirtual getBungeeMode : ()Lcom/axeelheaven/hbedwars/bungeemode/BungeeMode;
    //   55: getstatic com/axeelheaven/hbedwars/bungeemode/BungeeMode.BUNGEELOBBY : Lcom/axeelheaven/hbedwars/bungeemode/BungeeMode;
    //   58: invokevirtual equals : (Ljava/lang/Object;)Z
    //   61: invokestatic lll : (I)Z
    //   64: invokestatic lIIIlIIIIllI : (I)Z
    //   67: ifeq -> 225
    //   70: aload_0
    //   71: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   74: invokevirtual getLobbyManager : ()Lcom/axeelheaven/hbedwars/bungeemode/lobby/LobbyManager;
    //   77: invokevirtual getRedisMessenger : ()Lcom/axeelheaven/hbedwars/bungeemode/redis/RedisMessenger;
    //   80: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.ll : [Ljava/lang/String;
    //   83: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lII : [I
    //   86: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   89: iconst_0
    //   90: iaload
    //   91: iaload
    //   92: aaload
    //   93: aload #5
    //   95: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   100: invokevirtual toString : ()Ljava/lang/String;
    //   103: invokevirtual sendMessage : (Ljava/lang/String;Ljava/lang/String;)V
    //   106: aload_0
    //   107: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   110: invokevirtual getServer : ()Lorg/bukkit/Server;
    //   113: invokeinterface getScheduler : ()Lorg/bukkit/scheduler/BukkitScheduler;
    //   118: aload_0
    //   119: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   122: aload_0
    //   123: aload #5
    //   125: aload #6
    //   127: <illegal opcode> run : (Lcom/axeelheaven/hbedwars/commands/RejoinCommand;Lorg/bukkit/entity/Player;Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/lang/Runnable;
    //   132: invokeinterface runTask : (Lorg/bukkit/plugin/Plugin;Ljava/lang/Runnable;)Lorg/bukkit/scheduler/BukkitTask;
    //   137: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   140: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   143: bipush #45
    //   145: iaload
    //   146: aaload
    //   147: invokevirtual length : ()I
    //   150: pop2
    //   151: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   154: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   157: bipush #46
    //   159: iaload
    //   160: aaload
    //   161: invokevirtual length : ()I
    //   164: ldc ''
    //   166: invokevirtual length : ()I
    //   169: pop2
    //   170: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   173: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   176: bipush #47
    //   178: iaload
    //   179: aaload
    //   180: invokevirtual length : ()I
    //   183: ineg
    //   184: invokestatic lIIIlIIIllIl : (I)Z
    //   187: ifeq -> 520
    //   190: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   193: bipush #48
    //   195: iaload
    //   196: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   199: bipush #49
    //   201: iaload
    //   202: ixor
    //   203: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   206: bipush #50
    //   208: iaload
    //   209: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   212: bipush #51
    //   214: iaload
    //   215: ixor
    //   216: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   219: bipush #8
    //   221: iaload
    //   222: ixor
    //   223: iand
    //   224: ireturn
    //   225: aload_0
    //   226: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   229: invokevirtual getBungeeMode : ()Lcom/axeelheaven/hbedwars/bungeemode/BungeeMode;
    //   232: getstatic com/axeelheaven/hbedwars/bungeemode/BungeeMode.MULTIARENA : Lcom/axeelheaven/hbedwars/bungeemode/BungeeMode;
    //   235: invokevirtual equals : (Ljava/lang/Object;)Z
    //   238: invokestatic lll : (I)Z
    //   241: invokestatic lIIIlIIIIllI : (I)Z
    //   244: ifeq -> 520
    //   247: aload_0
    //   248: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   251: invokevirtual getArenaManager : ()Lcom/axeelheaven/hbedwars/arena/ArenaManager;
    //   254: invokevirtual getRejoin : ()Ljava/util/HashMap;
    //   257: aload #5
    //   259: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   264: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   267: invokestatic llI : (I)Z
    //   270: invokestatic lIIIlIIIIllI : (I)Z
    //   273: ifeq -> 321
    //   276: aload_0
    //   277: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   280: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   283: aload #6
    //   285: invokevirtual getLanguage : ()Ljava/lang/String;
    //   288: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   291: aload #5
    //   293: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.REJOIN_NO_ARENA : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   296: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lII : [I
    //   299: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   302: iconst_0
    //   303: iaload
    //   304: iaload
    //   305: anewarray java/lang/String
    //   308: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   311: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lII : [I
    //   314: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   317: iconst_1
    //   318: iaload
    //   319: iaload
    //   320: ireturn
    //   321: aload_0
    //   322: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   325: invokevirtual getArenaManager : ()Lcom/axeelheaven/hbedwars/arena/ArenaManager;
    //   328: invokevirtual getRejoin : ()Ljava/util/HashMap;
    //   331: aload #5
    //   333: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   338: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   341: checkcast com/axeelheaven/hbedwars/arena/Rejoin
    //   344: astore #7
    //   346: aload #7
    //   348: invokevirtual canRejoin : ()Z
    //   351: invokestatic llI : (I)Z
    //   354: invokestatic lIIIlIIIIllI : (I)Z
    //   357: ifeq -> 439
    //   360: aload_0
    //   361: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   364: invokevirtual getArenaManager : ()Lcom/axeelheaven/hbedwars/arena/ArenaManager;
    //   367: invokevirtual getRejoin : ()Ljava/util/HashMap;
    //   370: aload #5
    //   372: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   377: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   380: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   383: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   386: bipush #52
    //   388: iaload
    //   389: aaload
    //   390: invokevirtual length : ()I
    //   393: pop2
    //   394: aload_0
    //   395: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   398: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   401: aload #6
    //   403: invokevirtual getLanguage : ()Ljava/lang/String;
    //   406: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   409: aload #5
    //   411: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.REJOIN_DENIED : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   414: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lII : [I
    //   417: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   420: iconst_0
    //   421: iaload
    //   422: iaload
    //   423: anewarray java/lang/String
    //   426: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   429: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lII : [I
    //   432: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   435: iconst_1
    //   436: iaload
    //   437: iaload
    //   438: ireturn
    //   439: aload #5
    //   441: invokeinterface getWorld : ()Lorg/bukkit/World;
    //   446: aload_0
    //   447: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   450: invokevirtual getGameManager : ()Lcom/axeelheaven/hbedwars/GameManager;
    //   453: invokevirtual getSpawnpoint : ()Lorg/bukkit/Location;
    //   456: invokevirtual getWorld : ()Lorg/bukkit/World;
    //   459: invokevirtual equals : (Ljava/lang/Object;)Z
    //   462: invokestatic lll : (I)Z
    //   465: invokestatic lIIIlIIIIllI : (I)Z
    //   468: ifeq -> 479
    //   471: aload #6
    //   473: invokevirtual getInventoryData : ()Lcom/axeelheaven/hbedwars/database/profile/InventoryData;
    //   476: invokevirtual save : ()V
    //   479: aload #7
    //   481: aload #5
    //   483: invokevirtual join : (Lorg/bukkit/entity/Player;)V
    //   486: aload_0
    //   487: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   490: invokevirtual getArenaManager : ()Lcom/axeelheaven/hbedwars/arena/ArenaManager;
    //   493: invokevirtual getRejoin : ()Ljava/util/HashMap;
    //   496: aload #5
    //   498: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   503: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   506: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIIllllI : [Ljava/lang/String;
    //   509: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   512: bipush #51
    //   514: iaload
    //   515: aaload
    //   516: invokevirtual length : ()I
    //   519: pop2
    //   520: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lII : [I
    //   523: getstatic com/axeelheaven/hbedwars/commands/RejoinCommand.lIlIlIIlll : [I
    //   526: iconst_0
    //   527: iaload
    //   528: iaload
    //   529: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	530	6	llllllllllllllllllIllllIllIllIlI	Ljava/lang/String;
    //   0	530	6	llllllllllllllllllIllllIllIlIIIl	S
    //   0	530	5	llllllllllllllllllIllllIllIlIIlI	C
    //   0	530	5	llllllllllllllllllIllllIllIlIllI	Z
    //   29	501	5	llllllllllllllllllIllllIlllIIIII	Lorg/bukkit/entity/Player;
    //   346	174	7	llllllllllllllllllIllllIllIllIIl	Lcom/axeelheaven/hbedwars/arena/Rejoin;
    //   0	530	1	llllllllllllllllllIllllIllIlllII	C
    //   0	530	7	llllllllllllllllllIllllIllIllllI	Ljava/lang/String;
    //   48	482	6	llllllllllllllllllIllllIllIlIlIl	Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   0	530	7	llllllllllllllllllIllllIllIlIIII	B
    //   0	530	0	llllllllllllllllllIllllIlllIIIIl	J
    //   0	530	3	llllllllllllllllllIllllIllIllIll	Ljava/lang/String;
    //   0	530	0	llllllllllllllllllIllllIllIlIlII	S
    //   0	530	1	llllllllllllllllllIllllIllIlllIl	Lorg/bukkit/command/CommandSender;
    //   0	530	4	llllllllllllllllllIllllIllIllIII	[Ljava/lang/String;
    //   0	530	1	llllllllllllllllllIllllIllIlIIll	F
    //   0	530	2	llllllllllllllllllIllllIllIlIlll	Lorg/bukkit/command/Command;
    //   0	530	0	llllllllllllllllllIllllIllIlllll	Lcom/axeelheaven/hbedwars/commands/RejoinCommand;
  }
  
  private static void lIl() {
    lII = new int[lIlIlIIlll[13]];
    lII[lIlIlIIlll[1]] = lIlIIllllI[lIlIlIIlll[14]].length();
    lII[lIlIlIIlll[0]] = (lIlIlIIlll[15] ^ lIlIlIIlll[16] ^ lIlIlIIlll[17] ^ lIlIlIIlll[18]) & (lIlIlIIlll[19] + lIlIlIIlll[20] - lIlIlIIlll[9] + lIlIlIIlll[21] ^ lIlIlIIlll[22] + lIlIlIIlll[23] - lIlIlIIlll[24] + lIlIlIIlll[25] ^ -lIlIIllllI[lIlIlIIlll[26]].length());
    lII[lIlIlIIlll[9]] = lIlIIllllI[lIlIlIIlll[27]].length();
    lII[lIlIlIIlll[11]] = lIlIIllllI[lIlIlIIlll[10]].length();
    lII[lIlIlIIlll[12]] = lIlIlIIlll[28] ^ lIlIlIIlll[29] ^ lIlIlIIlll[30] ^ lIlIlIIlll[31];
    lII[lIlIlIIlll[14]] = lIlIlIIlll[32] ^ lIlIlIIlll[33];
    lII[lIlIlIIlll[26]] = lIlIlIIlll[22] + lIlIlIIlll[13] - lIlIlIIlll[34] + lIlIlIIlll[35] ^ lIlIlIIlll[36] + lIlIlIIlll[37] - lIlIlIIlll[10] + lIlIlIIlll[38];
    lII[lIlIlIIlll[27]] = lIlIlIIlll[39] ^ lIlIlIIlll[40];
    lII[lIlIlIIlll[10]] = lIlIlIIlll[41] ^ lIlIlIIlll[40] ^ lIlIlIIlll[42] ^ lIlIlIIlll[43];
  }
  
  private static String lIIIIllIllIl(String llllllllllllllllllIllllIlIIIllll, String llllllllllllllllllIllllIlIIIlllI) {
    try {
      SecretKeySpec llllllllllllllllllIllllIlIIlIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIllllIlIIIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIllllIlIIlIIIl = Cipher.getInstance("Blowfish");
      llllllllllllllllllIllllIlIIlIIIl.init(lIlIlIIlll[9], llllllllllllllllllIllllIlIIlIIlI);
      return new String(llllllllllllllllllIllllIlIIlIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllllllIllllIlIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception llllllllllllllllllIllllIlIIlIIII) {
      llllllllllllllllllIllllIlIIlIIII.printStackTrace();
      return null;
    } 
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\commands\RejoinCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */