/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.providers.ClusterConnectionProvider;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.providers.ConnectionProvider;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.IOUtils;
/*    */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class ClusterPipeline extends MultiNodePipelineBase {
/*    */   private final ClusterConnectionProvider provider;
/* 11 */   private AutoCloseable closeable = null;
/*    */   
/*    */   public ClusterPipeline(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig) {
/* 14 */     this(new ClusterConnectionProvider(clusterNodes, clientConfig));
/* 15 */     this.closeable = (AutoCloseable)this.provider;
/*    */   }
/*    */ 
/*    */   
/*    */   public ClusterPipeline(Set<HostAndPort> clusterNodes, JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig) {
/* 20 */     this(new ClusterConnectionProvider(clusterNodes, clientConfig, poolConfig));
/* 21 */     this.closeable = (AutoCloseable)this.provider;
/*    */   }
/*    */   
/*    */   public ClusterPipeline(ClusterConnectionProvider provider) {
/* 25 */     super(new ClusterCommandObjects());
/* 26 */     this.provider = provider;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/*    */     try {
/* 32 */       super.close();
/*    */     } finally {
/* 34 */       IOUtils.closeQuietly(this.closeable);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected HostAndPort getNodeKey(CommandArguments args) {
/* 40 */     return this.provider.getNode(((ClusterCommandArguments)args).getCommandHashSlot());
/*    */   }
/*    */ 
/*    */   
/*    */   protected Connection getConnection(HostAndPort nodeKey) {
/* 45 */     return this.provider.getConnection(nodeKey);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void prepareGraphCommands() {
/* 52 */     prepareGraphCommands((ConnectionProvider)this.provider);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\ClusterPipeline.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */