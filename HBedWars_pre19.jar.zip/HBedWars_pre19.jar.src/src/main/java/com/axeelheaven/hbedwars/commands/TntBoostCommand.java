package com.axeelheaven.hbedwars.commands;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.database.profile.HData;
import com.axeelheaven.hbedwars.languague.Language;
import com.axeelheaven.hbedwars.languague.LanguageProvider;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TntBoostCommand implements CommandExecutor {
    private final BedWars plugin;
    
    public TntBoostCommand(BedWars plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can only be used by players!");
            return true;
        }
        
        Player player = (Player) sender;
        HData data = plugin.getDataManager().getData(player.getName());
        
        if (args.length == 0) {
            Language lang = LanguageProvider.getLanguage(data.getLanguage());
            player.sendMessage(lang.getMessage("tnt-boost.help"));
            return true;
        }
        
        if (args[0].equalsIgnoreCase("toggle")) {
            data.setTntBoost(!data.isTntBoost());
            Language lang = LanguageProvider.getLanguage(data.getLanguage());
            player.sendMessage(lang.getMessage("tnt-boost." + (data.isTntBoost() ? "enabled" : "disabled")));
            return true;
        }
        
        return false;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\commands\TntBoostCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */