/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.Rawable;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Params
/*    */ {
/*    */   private Map<String, Object> params;
/*    */   
/*    */   public <T> T getParam(String name) {
/* 18 */     if (this.params == null) return null;
/*    */     
/* 20 */     return (T)this.params.get(name);
/*    */   }
/*    */   
/*    */   public byte[][] getByteParams() {
/* 24 */     if (this.params == null) return new byte[0][]; 
/* 25 */     ArrayList<byte[]> byteParams = (ArrayList)new ArrayList<>();
/*    */     
/* 27 */     for (Map.Entry<String, Object> param : this.params.entrySet()) {
/* 28 */       byteParams.add(SafeEncoder.encode(param.getKey()));
/*    */       
/* 30 */       Object value = param.getValue();
/* 31 */       if (value != null) {
/* 32 */         if (value instanceof byte[]) {
/* 33 */           byteParams.add((byte[])value); continue;
/* 34 */         }  if (value instanceof Rawable) {
/* 35 */           byteParams.add(((Rawable)value).getRaw()); continue;
/* 36 */         }  if (value instanceof Boolean) {
/* 37 */           byteParams.add(Protocol.toByteArray(((Boolean)value).booleanValue())); continue;
/* 38 */         }  if (value instanceof Integer) {
/* 39 */           byteParams.add(Protocol.toByteArray(((Integer)value).intValue())); continue;
/* 40 */         }  if (value instanceof Long) {
/* 41 */           byteParams.add(Protocol.toByteArray(((Long)value).longValue())); continue;
/* 42 */         }  if (value instanceof Double) {
/* 43 */           byteParams.add(Protocol.toByteArray(((Double)value).doubleValue())); continue;
/*    */         } 
/* 45 */         byteParams.add(SafeEncoder.encode(String.valueOf(value)));
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 50 */     return byteParams.<byte[]>toArray(new byte[byteParams.size()][]);
/*    */   }
/*    */   
/*    */   protected boolean contains(String name) {
/* 54 */     if (this.params == null) return false;
/*    */     
/* 56 */     return this.params.containsKey(name);
/*    */   }
/*    */   
/*    */   protected void addParam(String name, Object value) {
/* 60 */     if (this.params == null) {
/* 61 */       this.params = new HashMap<>();
/*    */     }
/* 63 */     this.params.put(name, value);
/*    */   }
/*    */   
/*    */   protected void addParam(String name) {
/* 67 */     if (this.params == null) {
/* 68 */       this.params = new HashMap<>();
/*    */     }
/* 70 */     this.params.put(name, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 75 */     ArrayList<Object> paramsFlatList = new ArrayList();
/* 76 */     if (this.params != null) {
/* 77 */       for (Map.Entry<String, Object> param : this.params.entrySet()) {
/* 78 */         paramsFlatList.add(param.getKey());
/* 79 */         Object value = param.getValue();
/* 80 */         if (value != null) {
/* 81 */           paramsFlatList.add(SafeEncoder.encodeObject(value));
/*    */         }
/*    */       } 
/*    */     }
/* 85 */     return paramsFlatList.toString();
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\Params.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */