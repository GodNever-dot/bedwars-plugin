package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FunctionRestorePolicy;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.FunctionLoadParams;
import java.util.List;

public interface FunctionBinaryCommands {
  Object fcall(byte[] paramArrayOfbyte, List<byte[]> paramList1, List<byte[]> paramList2);
  
  Object fcallReadonly(byte[] paramArrayOfbyte, List<byte[]> paramList1, List<byte[]> paramList2);
  
  String functionDelete(byte[] paramArrayOfbyte);
  
  byte[] functionDump();
  
  String functionFlush();
  
  String functionFlush(FlushMode paramFlushMode);
  
  String functionKill();
  
  List<Object> functionListBinary();
  
  List<Object> functionList(byte[] paramArrayOfbyte);
  
  List<Object> functionListWithCodeBinary();
  
  List<Object> functionListWithCode(byte[] paramArrayOfbyte);
  
  String functionLoad(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
  
  String functionLoad(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, FunctionLoadParams paramFunctionLoadParams, byte[] paramArrayOfbyte3);
  
  String functionRestore(byte[] paramArrayOfbyte);
  
  String functionRestore(byte[] paramArrayOfbyte, FunctionRestorePolicy paramFunctionRestorePolicy);
  
  Object functionStatsBinary();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\FunctionBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */