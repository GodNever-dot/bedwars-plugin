/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XReadParams
/*    */   implements IParams
/*    */ {
/* 11 */   private Integer count = null;
/* 12 */   private Integer block = null;
/*    */   
/*    */   public static XReadParams xReadParams() {
/* 15 */     return new XReadParams();
/*    */   }
/*    */   
/*    */   public XReadParams count(int count) {
/* 19 */     this.count = Integer.valueOf(count);
/* 20 */     return this;
/*    */   }
/*    */   
/*    */   public XReadParams block(int block) {
/* 24 */     this.block = Integer.valueOf(block);
/* 25 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 30 */     if (this.count != null) {
/* 31 */       args.add(Protocol.Keyword.COUNT);
/* 32 */       args.add(Protocol.toByteArray(this.count.intValue()));
/*    */     } 
/* 34 */     if (this.block != null) {
/* 35 */       args.add(Protocol.Keyword.BLOCK);
/* 36 */       args.add(Protocol.toByteArray(this.block.intValue()));
/* 37 */       args.blocking();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\XReadParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */