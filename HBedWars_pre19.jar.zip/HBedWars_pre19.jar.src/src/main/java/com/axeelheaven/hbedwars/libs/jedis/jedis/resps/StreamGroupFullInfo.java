/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.StreamEntryID;
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamGroupFullInfo
/*    */   implements Serializable
/*    */ {
/*    */   public static final String NAME = "name";
/*    */   public static final String CONSUMERS = "consumers";
/*    */   public static final String PENDING = "pending";
/*    */   public static final String LAST_DELIVERED = "last-delivered-id";
/*    */   public static final String PEL_COUNT = "pel-count";
/*    */   private final String name;
/*    */   private final List<StreamConsumerFullInfo> consumers;
/*    */   private final List<String> pending;
/*    */   private final Long pelCount;
/*    */   private final StreamEntryID lastDeliveredId;
/*    */   private final Map<String, Object> groupFullInfo;
/*    */   
/*    */   public StreamGroupFullInfo(Map<String, Object> map) {
/* 35 */     this.groupFullInfo = map;
/* 36 */     this.name = (String)map.get("name");
/* 37 */     this.consumers = (List<StreamConsumerFullInfo>)map.get("consumers");
/* 38 */     this.pending = (List<String>)map.get("pending");
/* 39 */     this.lastDeliveredId = (StreamEntryID)map.get("last-delivered-id");
/* 40 */     this.pelCount = (Long)map.get("pel-count");
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 45 */     return this.name;
/*    */   }
/*    */   
/*    */   public List<StreamConsumerFullInfo> getConsumers() {
/* 49 */     return this.consumers;
/*    */   }
/*    */   
/*    */   public List<String> getPending() {
/* 53 */     return this.pending;
/*    */   }
/*    */   
/*    */   public StreamEntryID getLastDeliveredId() {
/* 57 */     return this.lastDeliveredId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Object> getGroupFullInfo() {
/* 64 */     return this.groupFullInfo;
/*    */   }
/*    */   
/*    */   public Long getPelCount() {
/* 68 */     return this.pelCount;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\StreamGroupFullInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */