package com.axeelheaven.hbedwars;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.entity.Player;
import com.axeelheaven.hbedwars.database.profile.HData;
import com.axeelheaven.hbedwars.custom.config.HConfiguration;
import java.util.HashMap;
import java.util.Map;
import java.io.File;

public class BedWars extends JavaPlugin {
    private Map<String, HData> playerData;
    private HConfiguration settings;
    
    @Override
    public void onEnable() {
        this.playerData = new HashMap<>();
        this.settings = new HConfiguration(new File(getDataFolder(), "config.yml"));
        this.settings.load();
    }
    
    @Override
    public void onDisable() {
        this.playerData.clear();
    }
    
    public HData getPlayerData(Player player) {
        return playerData.computeIfAbsent(player.getName(), k -> new HData(player));
    }

    public HConfiguration getSettings() {
        return settings;
    }

    public File getDataFolder() {
        return super.getDataFolder();
    }
}