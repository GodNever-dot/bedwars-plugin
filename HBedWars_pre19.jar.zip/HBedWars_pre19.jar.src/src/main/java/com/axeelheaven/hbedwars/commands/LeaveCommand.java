package com.axeelheaven.hbedwars.commands;

import com.axeelheaven.hbedwars.BedWars;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;

public class LeaveCommand implements CommandExecutor {
  static {
    lIlIIllIlIIl();
    lIlIIllIIlIl();
    llIIIIIIl();
  }
  
  private static boolean lIlIIllIlIll(byte lllllllllllllllllIllIllIIlIlllII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static String lIlIIllIIlII(String lllllllllllllllllIllIllIlIIIlIII, String lllllllllllllllllIllIllIlIIIIlll) {
    try {
      SecretKeySpec lllllllllllllllllIllIllIlIIIlIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIllIllIlIIIIlll.getBytes(StandardCharsets.UTF_8)), llIIIIIllI[11]), "DES");
      Cipher lllllllllllllllllIllIllIlIIIlIlI = Cipher.getInstance("DES");
      lllllllllllllllllIllIllIlIIIlIlI.init(llIIIIIllI[2], lllllllllllllllllIllIllIlIIIlIll);
      return new String(lllllllllllllllllIllIllIlIIIlIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIllIllIlIIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIllIllIlIIIlIIl) {
      lllllllllllllllllIllIllIlIIIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIlIIllIlIIl() {
    llIIIIIllI = new int[12];
    llIIIIIllI[0] = " ".length();
    llIIIIIllI[1] = (0x67 ^ 0x31) & (0x7 ^ 0x51 ^ 0xFFFFFFFF);
    llIIIIIllI[2] = "  ".length();
    llIIIIIllI[3] = 0x13 ^ 0x43;
    llIIIIIllI[4] = 0x2A ^ 0x3B;
    llIIIIIllI[5] = 0xE7 ^ 0xB3;
    llIIIIIllI[6] = 96 + 92 - 19 + 15 ^ 130 + 141 - 112 + 4;
    llIIIIIllI[7] = (0x6D ^ 0x7C) + (0xC5 ^ 0x94) - (0x94 ^ 0xC0) + 29 + 38 - -47 + 69;
    llIIIIIllI[8] = 81 + 151 - 199 + 125;
    llIIIIIllI[9] = 77 + 187 - 63 + 4;
    llIIIIIllI[10] = (0x46 ^ 0x0) + (0xA6 ^ 0x9F) - (0x69 ^ 0x1B) + 72 + 52 - 40 + 55;
    llIIIIIllI[11] = 0xE1 ^ 0xB9 ^ 0x3C ^ 0x6C;
  }
  
  private static String lIlIIllIIIll(Exception lllllllllllllllllIllIllIllIIlIll, String lllllllllllllllllIllIllIllIIllll) {
    lllllllllllllllllIllIllIllIlIIII = new String(Base64.getDecoder().decode(lllllllllllllllllIllIllIllIIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIllIllIllIIlllI = new StringBuilder();
    char[] lllllllllllllllllIllIllIllIIllIl = lllllllllllllllllIllIllIllIIllll.toCharArray();
    int lllllllllllllllllIllIllIllIIllII = llIIIIIllI[1];
    char[] arrayOfChar1 = lllllllllllllllllIllIllIllIlIIII.toCharArray();
    lllllllllllllllllIllIllIllIIIlIl = arrayOfChar1.length;
    int i = llIIIIIllI[1];
    while (lIlIIllIllIl(i, lllllllllllllllllIllIllIllIIIlIl)) {
      char lllllllllllllllllIllIllIllIlIIIl = arrayOfChar1[i];
      "".length();
      lllllllllllllllllIllIllIllIIllII++;
      i++;
      "".length();
      if ("  ".length() > "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllllIllIllIllIIlllI);
  }
  
  private static boolean llIIIIIlI(int lllllllllllllllllIllIlllIIIIlllI) {
    if (lIlIIllIlIll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (((0x3C ^ 0x60) & (0x4D ^ 0x11 ^ 0xFFFFFFFF)) != 0)
        return (0xBF ^ 0x9A) & (0xAE ^ 0x8B ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIIIIIllI[1];
  }
  
  public boolean onCommand(String lllllllllllllllllIllIllIlllIIlll, Command lllllllllllllllllIllIllIlllllIII, String lllllllllllllllllIllIllIllllllll, String[] lllllllllllllllllIllIllIllllIllI) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof org/bukkit/entity/Player
    //   4: invokestatic llIIIIIlI : (I)Z
    //   7: invokestatic lIlIIllIllII : (I)Z
    //   10: ifeq -> 23
    //   13: getstatic com/axeelheaven/hbedwars/commands/LeaveCommand.lIIIIIlI : [I
    //   16: getstatic com/axeelheaven/hbedwars/commands/LeaveCommand.llIIIIIllI : [I
    //   19: iconst_1
    //   20: iaload
    //   21: iaload
    //   22: ireturn
    //   23: aload_1
    //   24: checkcast org/bukkit/entity/Player
    //   27: astore #5
    //   29: aload_0
    //   30: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   33: invokevirtual getGameManager : ()Lcom/axeelheaven/hbedwars/GameManager;
    //   36: aload #5
    //   38: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   43: invokevirtual getData : (Ljava/util/UUID;)Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   46: astore #6
    //   48: aload #6
    //   50: invokevirtual getArena : ()Lcom/axeelheaven/hbedwars/api/arena/Arena;
    //   53: invokestatic llIIIIIll : (Ljava/lang/Object;)Z
    //   56: invokestatic lIlIIllIllII : (I)Z
    //   59: ifeq -> 72
    //   62: aload #6
    //   64: invokevirtual getArena : ()Lcom/axeelheaven/hbedwars/api/arena/Arena;
    //   67: aload #5
    //   69: invokevirtual removePlayer : (Lorg/bukkit/entity/Player;)V
    //   72: getstatic com/axeelheaven/hbedwars/commands/LeaveCommand.lIIIIIlI : [I
    //   75: getstatic com/axeelheaven/hbedwars/commands/LeaveCommand.llIIIIIllI : [I
    //   78: iconst_0
    //   79: iaload
    //   80: iaload
    //   81: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	82	3	lllllllllllllllllIllIllIllllllll	Ljava/lang/String;
    //   0	82	6	lllllllllllllllllIllIllIlllIIIll	C
    //   0	82	1	lllllllllllllllllIllIllIllllIIIl	C
    //   0	82	0	lllllllllllllllllIllIllIllllllII	F
    //   48	34	6	lllllllllllllllllIllIllIlllIlIll	Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   0	82	1	lllllllllllllllllIllIllIlllIIlll	Ljava/lang/String;
    //   0	82	0	lllllllllllllllllIllIllIlllIlIIl	B
    //   0	82	2	lllllllllllllllllIllIllIlllllIII	Lorg/bukkit/command/Command;
    //   29	53	5	lllllllllllllllllIllIllIllllIIll	Lorg/bukkit/entity/Player;
    //   0	82	5	lllllllllllllllllIllIllIlllllIlI	C
    //   0	82	0	lllllllllllllllllIllIllIllllIlII	Lcom/axeelheaven/hbedwars/commands/LeaveCommand;
    //   0	82	5	lllllllllllllllllIllIllIlllIIlIl	B
    //   0	82	6	lllllllllllllllllIllIllIlllIllIl	Ljava/lang/String;
    //   0	82	1	lllllllllllllllllIllIllIlllIllll	Lorg/bukkit/command/CommandSender;
    //   0	82	4	lllllllllllllllllIllIllIllllIllI	[Ljava/lang/String;
  }
  
  private static void lIlIIllIIlIl() {
    llIIIIIlIl = new String[llIIIIIllI[2]];
    llIIIIIlIl[llIIIIIllI[1]] = lIlIIllIIIll("dQ==", "UWLQj");
    llIIIIIlIl[llIIIIIllI[0]] = lIlIIllIIlII("39y1tGYt3v4=", "FGntP");
  }
  
  private static void llIIIIIIl() {
    lIIIIIlI = new int[llIIIIIllI[2]];
    lIIIIIlI[llIIIIIllI[1]] = llIIIIIlIl[llIIIIIllI[1]].length();
    lIIIIIlI[llIIIIIllI[0]] = (llIIIIIllI[3] ^ llIIIIIllI[4] ^ llIIIIIllI[5] ^ llIIIIIllI[6]) & (llIIIIIllI[7] ^ llIIIIIllI[8] ^ llIIIIIllI[9] ^ llIIIIIllI[10] ^ -llIIIIIlIl[llIIIIIllI[0]].length());
  }
  
  public LeaveCommand(BedWars lllllllllllllllllIllIllIllIllllI) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   9: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	10	0	lllllllllllllllllIllIllIllIlllIl	Lcom/axeelheaven/hbedwars/commands/LeaveCommand;
    //   0	10	1	lllllllllllllllllIllIllIlllIIIII	Ljava/lang/Exception;
    //   0	10	1	lllllllllllllllllIllIllIllIllllI	Lcom/axeelheaven/hbedwars/BedWars;
    //   0	10	0	lllllllllllllllllIllIllIllIlllII	S
    //   0	10	0	lllllllllllllllllIllIllIllIlllll	C
    //   0	10	1	lllllllllllllllllIllIllIllIllIll	C
  }
  
  private static boolean llIIIIIll(String lllllllllllllllllIllIlllIIIlIIIl) {
    if (lIlIIllIlIlI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (-"   ".length() > 0)
        return (0xEA ^ 0xA4) & (0x50 ^ 0x1E ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIIIIIllI[1];
  }
  
  private static boolean lIlIIllIllIl(boolean lllllllllllllllllIllIllIIlllIIIl, byte lllllllllllllllllIllIllIIlllIIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIlIIllIllII(byte lllllllllllllllllIllIllIIllIIIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean lIlIIllIlIlI(double lllllllllllllllllIllIllIIllIlIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\commands\LeaveCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */