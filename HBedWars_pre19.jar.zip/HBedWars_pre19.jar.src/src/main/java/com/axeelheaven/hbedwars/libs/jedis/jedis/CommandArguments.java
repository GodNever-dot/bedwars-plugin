/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.Rawable;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.RawableFactory;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.commands.ProtocolCommand;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.IParams;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class CommandArguments
/*     */   implements Iterable<Rawable>
/*     */ {
/*     */   private final ArrayList<Rawable> args;
/*     */   private boolean blocking;
/*     */   
/*     */   private CommandArguments() {
/*  18 */     throw new InstantiationError();
/*     */   }
/*     */   
/*     */   public CommandArguments(ProtocolCommand command) {
/*  22 */     this.args = new ArrayList<>();
/*  23 */     this.args.add(command);
/*     */   }
/*     */   
/*     */   public ProtocolCommand getCommand() {
/*  27 */     return (ProtocolCommand)this.args.get(0);
/*     */   }
/*     */   
/*     */   public CommandArguments add(Object arg) {
/*  31 */     if (arg instanceof Rawable) {
/*  32 */       this.args.add((Rawable)arg);
/*  33 */     } else if (arg instanceof byte[]) {
/*  34 */       this.args.add(RawableFactory.from((byte[])arg));
/*  35 */     } else if (arg instanceof String) {
/*  36 */       this.args.add(RawableFactory.from((String)arg));
/*  37 */     } else if (arg instanceof Boolean) {
/*  38 */       this.args.add(RawableFactory.from(Integer.toString(((Boolean)arg).booleanValue() ? 1 : 0)));
/*     */     } else {
/*  40 */       if (arg == null) {
/*  41 */         throw new IllegalArgumentException("null is not a valid argument.");
/*     */       }
/*  43 */       this.args.add(RawableFactory.from(String.valueOf(arg)));
/*     */     } 
/*  45 */     return this;
/*     */   }
/*     */   
/*     */   public CommandArguments addObjects(Object... args) {
/*  49 */     for (Object arg : args) {
/*  50 */       add(arg);
/*     */     }
/*  52 */     return this;
/*     */   }
/*     */   
/*     */   public CommandArguments addObjects(Collection args) {
/*  56 */     for (Object arg : args) {
/*  57 */       add(arg);
/*     */     }
/*  59 */     return this;
/*     */   }
/*     */   
/*     */   public CommandArguments addObjects(int[] ints) {
/*  63 */     for (int i : ints) {
/*  64 */       add(Integer.valueOf(i));
/*     */     }
/*  66 */     return this;
/*     */   }
/*     */   
/*     */   public CommandArguments key(Object key) {
/*  70 */     if (key instanceof Rawable) {
/*  71 */       Rawable raw = (Rawable)key;
/*  72 */       processKey(raw.getRaw());
/*  73 */       this.args.add(raw);
/*  74 */     } else if (key instanceof byte[]) {
/*  75 */       byte[] raw = (byte[])key;
/*  76 */       processKey(raw);
/*  77 */       this.args.add(RawableFactory.from(raw));
/*  78 */     } else if (key instanceof String) {
/*  79 */       String raw = (String)key;
/*  80 */       processKey(raw);
/*  81 */       this.args.add(RawableFactory.from(raw));
/*     */     } else {
/*  83 */       throw new IllegalArgumentException("\"" + key.toString() + "\" is not a valid argument.");
/*     */     } 
/*  85 */     return this;
/*     */   }
/*     */   
/*     */   public final CommandArguments keys(Object... keys) {
/*  89 */     for (Object key : keys) {
/*  90 */       key(key);
/*     */     }
/*  92 */     return this;
/*     */   }
/*     */   
/*     */   public final CommandArguments addParams(IParams params) {
/*  96 */     params.addParams(this);
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected CommandArguments processKey(byte[] key) {
/* 102 */     return this;
/*     */   }
/*     */   
/*     */   protected final CommandArguments processKeys(byte[]... keys) {
/* 106 */     for (byte[] key : keys) {
/* 107 */       processKey(key);
/*     */     }
/* 109 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected CommandArguments processKey(String key) {
/* 114 */     return this;
/*     */   }
/*     */   
/*     */   protected final CommandArguments processKeys(String... keys) {
/* 118 */     for (String key : keys) {
/* 119 */       processKey(key);
/*     */     }
/* 121 */     return this;
/*     */   }
/*     */   
/*     */   public int size() {
/* 125 */     return this.args.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Rawable> iterator() {
/* 130 */     return this.args.iterator();
/*     */   }
/*     */   
/*     */   public boolean isBlocking() {
/* 134 */     return this.blocking;
/*     */   }
/*     */   
/*     */   public CommandArguments blocking() {
/* 138 */     this.blocking = true;
/* 139 */     return this;
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\CommandArguments.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */