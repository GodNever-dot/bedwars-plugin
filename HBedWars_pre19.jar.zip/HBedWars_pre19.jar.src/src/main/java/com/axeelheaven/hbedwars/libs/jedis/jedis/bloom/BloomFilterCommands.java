package com.axeelheaven.hbedwars.libs.jedis.jedis.bloom;

import java.util.List;
import java.util.Map;

public interface BloomFilterCommands {
  String bfReserve(String paramString, double paramDouble, long paramLong);
  
  String bfReserve(String paramString, double paramDouble, long paramLong, BFReserveParams paramBFReserveParams);
  
  boolean bfAdd(String paramString1, String paramString2);
  
  List<Boolean> bfMAdd(String paramString, String... paramVarArgs);
  
  List<Boolean> bfInsert(String paramString, String... paramVarArgs);
  
  List<Boolean> bfInsert(String paramString, BFInsertParams paramBFInsertParams, String... paramVarArgs);
  
  boolean bfExists(String paramString1, String paramString2);
  
  List<Boolean> bfMExists(String paramString, String... paramVarArgs);
  
  Map<String, Object> bfInfo(String paramString);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\bloom\BloomFilterCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */