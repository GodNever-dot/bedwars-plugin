/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.GeoCoordinate;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.GeoUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeoSearchParam
/*     */   implements IParams
/*     */ {
/*     */   private boolean fromMember = false;
/*     */   private boolean fromLonLat = false;
/*     */   private String member;
/*     */   private GeoCoordinate coord;
/*     */   private boolean byRadius = false;
/*     */   private boolean byBox = false;
/*     */   private double radius;
/*     */   private double width;
/*     */   private double height;
/*     */   private GeoUnit unit;
/*     */   private boolean withCoord = false;
/*     */   private boolean withDist = false;
/*     */   private boolean withHash = false;
/*  36 */   private Integer count = null;
/*     */   
/*     */   private boolean any = false;
/*     */   private boolean asc = false;
/*     */   private boolean desc = false;
/*     */   
/*     */   public static GeoSearchParam geoSearchParam() {
/*  43 */     return new GeoSearchParam();
/*     */   }
/*     */   public GeoSearchParam fromMember(String member) {
/*  46 */     this.fromMember = true;
/*  47 */     this.member = member;
/*  48 */     return this;
/*     */   }
/*     */   
/*     */   public GeoSearchParam fromLonLat(double longitude, double latitude) {
/*  52 */     this.fromLonLat = true;
/*  53 */     this.coord = new GeoCoordinate(longitude, latitude);
/*  54 */     return this;
/*     */   }
/*     */   
/*     */   public GeoSearchParam fromLonLat(GeoCoordinate coord) {
/*  58 */     this.fromLonLat = true;
/*  59 */     this.coord = coord;
/*  60 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public GeoSearchParam byRadius(double radius, GeoUnit unit) {
/*  65 */     this.byRadius = true;
/*  66 */     this.radius = radius;
/*  67 */     this.unit = unit;
/*  68 */     return this;
/*     */   }
/*     */   
/*     */   public GeoSearchParam byBox(double width, double height, GeoUnit unit) {
/*  72 */     this.byBox = true;
/*  73 */     this.width = width;
/*  74 */     this.height = height;
/*  75 */     this.unit = unit;
/*  76 */     return this;
/*     */   }
/*     */   
/*     */   public GeoSearchParam withCoord() {
/*  80 */     this.withCoord = true;
/*  81 */     return this;
/*     */   }
/*     */   
/*     */   public GeoSearchParam withDist() {
/*  85 */     this.withDist = true;
/*  86 */     return this;
/*     */   }
/*     */   
/*     */   public GeoSearchParam withHash() {
/*  90 */     this.withHash = true;
/*  91 */     return this;
/*     */   }
/*     */   
/*     */   public GeoSearchParam asc() {
/*  95 */     this.asc = true;
/*  96 */     return this;
/*     */   }
/*     */   
/*     */   public GeoSearchParam desc() {
/* 100 */     this.desc = true;
/* 101 */     return this;
/*     */   }
/*     */   
/*     */   public GeoSearchParam count(int count) {
/* 105 */     return count(count, false);
/*     */   }
/*     */   
/*     */   public GeoSearchParam count(int count, boolean any) {
/* 109 */     if (count > 0) {
/* 110 */       this.count = Integer.valueOf(count);
/*     */       
/* 112 */       if (any) {
/* 113 */         this.any = true;
/*     */       }
/*     */     } 
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addParams(CommandArguments args) {
/* 121 */     if (this.fromMember) {
/* 122 */       args.add(Protocol.Keyword.FROMMEMBER);
/* 123 */       args.add(this.member);
/* 124 */     } else if (this.fromLonLat) {
/* 125 */       args.add(Protocol.Keyword.FROMLONLAT);
/* 126 */       args.add(Double.valueOf(this.coord.getLongitude()));
/* 127 */       args.add(Double.valueOf(this.coord.getLatitude()));
/*     */     } 
/*     */     
/* 130 */     if (this.byRadius) {
/* 131 */       args.add(Protocol.Keyword.BYRADIUS);
/* 132 */       args.add(Double.valueOf(this.radius));
/* 133 */     } else if (this.byBox) {
/* 134 */       args.add(Protocol.Keyword.BYBOX);
/* 135 */       args.add(Double.valueOf(this.width));
/* 136 */       args.add(Double.valueOf(this.height));
/*     */     } 
/* 138 */     args.add(this.unit);
/*     */     
/* 140 */     if (this.withCoord) {
/* 141 */       args.add(Protocol.Keyword.WITHCOORD);
/*     */     }
/* 143 */     if (this.withDist) {
/* 144 */       args.add(Protocol.Keyword.WITHDIST);
/*     */     }
/* 146 */     if (this.withHash) {
/* 147 */       args.add(Protocol.Keyword.WITHHASH);
/*     */     }
/*     */     
/* 150 */     if (this.count != null) {
/* 151 */       args.add(Protocol.Keyword.COUNT).add(this.count);
/* 152 */       if (this.any) {
/* 153 */         args.add(Protocol.Keyword.ANY);
/*     */       }
/*     */     } 
/*     */     
/* 157 */     if (this.asc) {
/* 158 */       args.add(Protocol.Keyword.ASC);
/* 159 */     } else if (this.desc) {
/* 160 */       args.add(Protocol.Keyword.DESC);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\GeoSearchParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */