/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XAddParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XAutoClaimParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XClaimParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XReadGroupParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XReadParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XTrimParams;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public interface StreamPipelineBinaryCommands {
/*    */   default Response<byte[]> xadd(byte[] key, Map<byte[], byte[]> hash, XAddParams params) {
/* 14 */     return xadd(key, params, hash);
/*    */   }
/*    */   
/*    */   Response<byte[]> xadd(byte[] paramArrayOfbyte, XAddParams paramXAddParams, Map<byte[], byte[]> paramMap);
/*    */   
/*    */   Response<Long> xlen(byte[] paramArrayOfbyte);
/*    */   
/*    */   Response<List<byte[]>> xrange(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
/*    */   
/*    */   Response<List<byte[]>> xrange(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, int paramInt);
/*    */   
/*    */   Response<List<byte[]>> xrevrange(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
/*    */   
/*    */   Response<List<byte[]>> xrevrange(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, int paramInt);
/*    */   
/*    */   Response<Long> xack(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[]... paramVarArgs);
/*    */   
/*    */   Response<String> xgroupCreate(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, boolean paramBoolean);
/*    */   
/*    */   Response<String> xgroupSetID(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
/*    */   
/*    */   Response<Long> xgroupDestroy(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
/*    */   
/*    */   Response<Boolean> xgroupCreateConsumer(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
/*    */   
/*    */   Response<Long> xgroupDelConsumer(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3);
/*    */   
/*    */   Response<Long> xdel(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
/*    */   
/*    */   Response<Long> xtrim(byte[] paramArrayOfbyte, long paramLong, boolean paramBoolean);
/*    */   
/*    */   Response<Long> xtrim(byte[] paramArrayOfbyte, XTrimParams paramXTrimParams);
/*    */   
/*    */   Response<Object> xpending(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
/*    */   
/*    */   @Deprecated
/*    */   Response<List<Object>> xpending(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4, int paramInt, byte[] paramArrayOfbyte5);
/*    */   
/*    */   Response<List<Object>> xpending(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, XPendingParams paramXPendingParams);
/*    */   
/*    */   Response<List<byte[]>> xclaim(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, long paramLong, XClaimParams paramXClaimParams, byte[]... paramVarArgs);
/*    */   
/*    */   Response<List<byte[]>> xclaimJustId(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, long paramLong, XClaimParams paramXClaimParams, byte[]... paramVarArgs);
/*    */   
/*    */   Response<List<Object>> xautoclaim(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, long paramLong, byte[] paramArrayOfbyte4, XAutoClaimParams paramXAutoClaimParams);
/*    */   
/*    */   Response<List<Object>> xautoclaimJustId(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, long paramLong, byte[] paramArrayOfbyte4, XAutoClaimParams paramXAutoClaimParams);
/*    */   
/*    */   Response<Object> xinfoStream(byte[] paramArrayOfbyte);
/*    */   
/*    */   Response<Object> xinfoStreamFull(byte[] paramArrayOfbyte);
/*    */   
/*    */   Response<Object> xinfoStreamFull(byte[] paramArrayOfbyte, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   Response<List<Object>> xinfoGroup(byte[] paramArrayOfbyte);
/*    */   
/*    */   Response<List<Object>> xinfoGroups(byte[] paramArrayOfbyte);
/*    */   
/*    */   Response<List<Object>> xinfoConsumers(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
/*    */   
/*    */   Response<List<byte[]>> xread(XReadParams paramXReadParams, Map.Entry<byte[], byte[]>... paramVarArgs);
/*    */   
/*    */   Response<List<byte[]>> xreadGroup(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, XReadGroupParams paramXReadGroupParams, Map.Entry<byte[], byte[]>... paramVarArgs);
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\StreamPipelineBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */