package com.axeelheaven.hbedwars.database.cache.tops;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Top {
  public Top(char lllllllllllllllllIlIllllllIIIIll, short lllllllllllllllllIlIllllllIIIIlI, byte lllllllllllllllllIlIllllllIIIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: putfield name : Ljava/lang/String;
    //   9: aload_0
    //   10: iload_2
    //   11: putfield amount : I
    //   14: aload_0
    //   15: iload_3
    //   16: putfield position : I
    //   19: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	20	0	lllllllllllllllllIlIllllllIIIlll	Lcom/axeelheaven/hbedwars/database/cache/tops/Top;
    //   0	20	2	lllllllllllllllllIlIllllllIIIlIl	Ljava/lang/String;
    //   0	20	1	lllllllllllllllllIlIllllllIIllII	Ljava/lang/String;
    //   0	20	3	lllllllllllllllllIlIllllllIIlIll	I
    //   0	20	0	lllllllllllllllllIlIllllllIIIlII	S
    //   0	20	3	lllllllllllllllllIlIllllllIIIIIl	B
    //   0	20	2	lllllllllllllllllIlIllllllIIIIlI	S
    //   0	20	3	lllllllllllllllllIlIllllllIIIllI	Z
    //   0	20	2	lllllllllllllllllIlIllllllIIlIII	I
    //   0	20	0	lllllllllllllllllIlIllllllIIlIlI	C
    //   0	20	1	lllllllllllllllllIlIllllllIIIIll	C
    //   0	20	1	lllllllllllllllllIlIllllllIIlIIl	S
  }
  
  private static String lllIIlIlI(char lllllllllllllllllIlIlllllIllIIll, String lllllllllllllllllIlIlllllIllIlIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIIl : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   10: bipush #19
    //   12: iaload
    //   13: aaload
    //   14: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   17: aload_1
    //   18: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   21: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   24: invokevirtual digest : ([B)[B
    //   27: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.lIIlllII : [I
    //   30: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   33: bipush #11
    //   35: iaload
    //   36: iaload
    //   37: invokestatic copyOf : ([BI)[B
    //   40: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIIl : [Ljava/lang/String;
    //   43: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   46: bipush #25
    //   48: iaload
    //   49: aaload
    //   50: invokespecial <init> : ([BLjava/lang/String;)V
    //   53: astore_2
    //   54: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIIl : [Ljava/lang/String;
    //   57: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   60: bipush #11
    //   62: iaload
    //   63: aaload
    //   64: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   67: astore_3
    //   68: aload_3
    //   69: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.lIIlllII : [I
    //   72: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   75: bipush #18
    //   77: iaload
    //   78: iaload
    //   79: aload_2
    //   80: invokevirtual init : (ILjava/security/Key;)V
    //   83: new java/lang/String
    //   86: dup
    //   87: aload_3
    //   88: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   91: aload_0
    //   92: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   95: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   98: invokevirtual decode : ([B)[B
    //   101: invokevirtual doFinal : ([B)[B
    //   104: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   107: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   110: areturn
    //   111: astore_2
    //   112: aload_2
    //   113: invokevirtual printStackTrace : ()V
    //   116: aconst_null
    //   117: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	118	1	lllllllllllllllllIlIlllllIllIIlI	I
    //   0	118	2	lllllllllllllllllIlIlllllIllIIIl	I
    //   112	4	2	lllllllllllllllllIlIlllllIlllIII	Ljava/lang/Exception;
    //   0	118	3	lllllllllllllllllIlIlllllIllIlll	Ljava/lang/Exception;
    //   0	118	1	lllllllllllllllllIlIlllllIllIlIl	Ljava/lang/String;
    //   68	43	3	lllllllllllllllllIlIlllllIlllIlI	Ljavax/crypto/Cipher;
    //   0	118	3	lllllllllllllllllIlIlllllIllIIII	Z
    //   0	118	1	lllllllllllllllllIlIlllllIlllIIl	Ljava/lang/Exception;
    //   0	118	0	lllllllllllllllllIlIlllllIllllII	D
    //   0	118	0	lllllllllllllllllIlIlllllIllIIll	C
    //   0	118	0	lllllllllllllllllIlIlllllIllIlII	Ljava/lang/String;
    //   0	118	2	lllllllllllllllllIlIlllllIlllIll	J
    //   54	57	2	lllllllllllllllllIlIlllllIllIllI	Ljavax/crypto/spec/SecretKeySpec;
    // Exception table:
    //   from	to	target	type
    //   0	110	111	java/lang/Exception
  }
  
  public int getAmount() {
    // Byte code:
    //   0: aload_0
    //   1: getfield amount : I
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIllllllIlllll	Lcom/axeelheaven/hbedwars/database/cache/tops/Top;
    //   0	5	0	lllllllllllllllllIlIllllllIlllIl	C
    //   0	5	0	lllllllllllllllllIlIllllllIllllI	Ljava/lang/Exception;
  }
  
  public String toString() {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.lIIllIll : [Ljava/lang/String;
    //   10: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.lIIlllII : [I
    //   13: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: iaload
    //   19: aaload
    //   20: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: aload_0
    //   24: getfield name : Ljava/lang/String;
    //   27: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   30: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.lIIlllII : [I
    //   33: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   36: bipush #14
    //   38: iaload
    //   39: iaload
    //   40: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   43: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.lIIllIll : [Ljava/lang/String;
    //   46: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.lIIlllII : [I
    //   49: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   52: bipush #17
    //   54: iaload
    //   55: iaload
    //   56: aaload
    //   57: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: aload_0
    //   61: getfield amount : I
    //   64: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   67: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.lIIllIll : [Ljava/lang/String;
    //   70: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.lIIlllII : [I
    //   73: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   76: bipush #18
    //   78: iaload
    //   79: iaload
    //   80: aaload
    //   81: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: aload_0
    //   85: getfield position : I
    //   88: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   91: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.lIIlllII : [I
    //   94: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   97: bipush #19
    //   99: iaload
    //   100: iaload
    //   101: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   104: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   107: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	108	0	lllllllllllllllllIlIllllllIlIIlI	Ljava/lang/String;
    //   0	108	0	lllllllllllllllllIlIllllllIlIIIl	Z
    //   0	108	0	lllllllllllllllllIlIllllllIlIIll	Lcom/axeelheaven/hbedwars/database/cache/tops/Top;
  }
  
  private static String lIlIllIIllIl(String lllllllllllllllllIlIllllIlIlllII, String lllllllllllllllllIlIllllIlIllIll) {
    try {
      SecretKeySpec lllllllllllllllllIlIllllIlIlllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIllllIlIllIll.getBytes(StandardCharsets.UTF_8)), llIIlIIIll[28]), "DES");
      Cipher lllllllllllllllllIlIllllIlIllllI = Cipher.getInstance("DES");
      lllllllllllllllllIlIllllIlIllllI.init(llIIlIIIll[17], lllllllllllllllllIlIllllIlIlllll);
      return new String(lllllllllllllllllIlIllllIlIllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIllllIlIlllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIlIllllIlIlllIl) {
      lllllllllllllllllIlIllllIlIlllIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lllIIlIll(String lllllllllllllllllIlIlllllIIlllII, String lllllllllllllllllIlIlllllIIlIlII) {
    String str = new String(Base64.getDecoder().decode(lllllllllllllllllIlIlllllIIlllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIlIlllllIIllIII = new StringBuilder();
    char[] lllllllllllllllllIlIlllllIIlllIl = lllllllllllllllllIlIlllllIIlIlII.toCharArray();
    int lllllllllllllllllIlIlllllIlIIIII = lIIlllII[llIIlIIIll[1]];
    char[] arrayOfChar1 = str.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIIlllII[llIIlIIIll[1]];
    while (lIlIllIllIII(lllIIlllI(j, i))) {
      char lllllllllllllllllIlIlllllIIllIIl = arrayOfChar1[j];
      llIIlIIIIl[llIIlIIIll[0]].length();
      lllllllllllllllllIlIlllllIlIIIII++;
      j++;
      "".length();
      if (lIlIllIllIIl(llIIlIIIIl[llIIlIIIll[29]].length()))
        return null; 
    } 
    return String.valueOf(lllllllllllllllllIlIlllllIIllIII);
  }
  
  private static String lIlIllIIlIll(String lllllllllllllllllIlIllllIllllllI, boolean lllllllllllllllllIlIllllIllllIII) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   40: iconst_1
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   58: iconst_1
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic lIlIllIlIlll : (II)Z
    //   69: ifeq -> 141
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: bipush #98
    //   114: bipush #27
    //   116: iadd
    //   117: bipush #42
    //   119: isub
    //   120: bipush #71
    //   122: iadd
    //   123: bipush #79
    //   125: bipush #35
    //   127: iadd
    //   128: bipush #83
    //   130: isub
    //   131: sipush #128
    //   134: iadd
    //   135: ixor
    //   136: ifne -> 62
    //   139: aconst_null
    //   140: areturn
    //   141: aload_2
    //   142: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   145: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	146	5	lllllllllllllllllIlIllllIlllIlII	S
    //   0	146	1	lllllllllllllllllIlIllllIlllllIl	Ljava/lang/String;
    //   0	146	0	lllllllllllllllllIlIllllIllllIIl	B
    //   0	146	2	lllllllllllllllllIlIllllIlllIlll	Ljava/lang/String;
    //   79	24	8	lllllllllllllllllIlIllllIlllllll	C
    //   32	114	2	lllllllllllllllllIlIllllIlllllII	Ljava/lang/StringBuilder;
    //   0	146	6	lllllllllllllllllIlIllllIlllIIll	F
    //   0	146	8	lllllllllllllllllIlIllllIlllIIIl	B
    //   37	109	3	lllllllllllllllllIlIllllIllllIll	[C
    //   0	146	4	lllllllllllllllllIlIllllIlllIlIl	D
    //   44	102	4	lllllllllllllllllIlIllllIllllIlI	I
    //   0	146	3	lllllllllllllllllIlIllllIlllIllI	I
    //   0	146	0	lllllllllllllllllIlIllllIllllllI	Ljava/lang/String;
    //   0	146	1	lllllllllllllllllIlIllllIllllIII	Z
    //   0	146	7	lllllllllllllllllIlIllllIlllIIlI	B
  }
  
  private static void lIlIllIIlllI() {
    llIIlIIIIl = new String[llIIlIIIll[36]];
    llIIlIIIIl[llIIlIIIll[1]] = lIlIllIIlIll("Vw==", "wkkFf");
    llIIlIIIIl[llIIlIIIll[14]] = lIlIllIIllII("GtbWSkQgDaM=", "Khszq");
    llIIlIIIIl[llIIlIIIll[17]] = lIlIllIIllII("YHmNP682jlY=", "AmjfP");
    llIIlIIIIl[llIIlIIIll[18]] = lIlIllIIlIll("b0h0", "OhTIU");
    llIIlIIIIl[llIIlIIIll[19]] = lIlIllIIllII("kV2q9HsjuPk=", "VHgau");
    llIIlIIIIl[llIIlIIIll[25]] = lIlIllIIllIl("TLgKGr131XQ=", "KzCRZ");
    llIIlIIIIl[llIIlIIIll[11]] = lIlIllIIllIl("4iiq/zyCAak=", "INBzC");
    llIIlIIIIl[llIIlIIIll[0]] = lIlIllIIlIll("", "cweLq");
    llIIlIIIIl[llIIlIIIll[28]] = lIlIllIIllII("Luy0jwb0H5E=", "ocqOo");
    llIIlIIIIl[llIIlIIIll[29]] = lIlIllIIllII("SYgn4NlTVrc=", "rYfGo");
    llIIlIIIIl[llIIlIIIll[30]] = lIlIllIIllII("M2gEkGP4ovrqq5HQZ3/ZOkawDLG/lmQWKEQzb0bo1YA=", "fBZfT");
    llIIlIIIIl[llIIlIIIll[31]] = lIlIllIIlIll("KTkdCAk=", "qHeaD");
    llIIlIIIIl[llIIlIIIll[32]] = lIlIllIIllIl("7fyG7wygHN4D098PK2YLQ1OgY1XXeJI7w82R64ZqHms=", "tcbCU");
    llIIlIIIIl[llIIlIIIll[33]] = lIlIllIIllII("AMagZLMyVDg=", "EciYj");
    llIIlIIIIl[llIIlIIIll[34]] = lIlIllIIllIl("9wsyLJ9Joe8yyYJtPZNGsPwOW1UzWYwA", "sNoCQ");
    llIIlIIIIl[llIIlIIIll[35]] = lIlIllIIllII("/Dc49vUh5bw=", "FYJqt");
  }
  
  private static boolean lIlIllIlIlll(boolean lllllllllllllllllIlIllllIlIlIlII, String lllllllllllllllllIlIllllIlIlIIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public String getName() {
    return this.name;
  }
  
  public int getPosition() {
    // Byte code:
    //   0: aload_0
    //   1: getfield position : I
    //   4: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIlIllllllIllIll	Lcom/axeelheaven/hbedwars/database/cache/tops/Top;
    //   0	5	0	lllllllllllllllllIlIllllllIllIIl	C
    //   0	5	0	lllllllllllllllllIlIllllllIllIlI	Z
  }
  
  private static void lllIIllIl() {
    lIIlllII = new int[llIIlIIIll[0]];
    lIIlllII[llIIlIIIll[1]] = (llIIlIIIll[2] ^ llIIlIIIll[3] ^ llIIlIIIll[4] ^ llIIlIIIll[5]) & (llIIlIIIll[6] + llIIlIIIll[7] - llIIlIIIll[8] + llIIlIIIll[9] ^ llIIlIIIll[10] + llIIlIIIll[11] - llIIlIIIll[12] + llIIlIIIll[13] ^ -llIIlIIIIl[llIIlIIIll[1]].length());
    lIIlllII[llIIlIIIll[14]] = llIIlIIIll[15] ^ llIIlIIIll[16];
    lIIlllII[llIIlIIIll[17]] = llIIlIIIIl[llIIlIIIll[14]].length();
    lIIlllII[llIIlIIIll[18]] = llIIlIIIIl[llIIlIIIll[17]].length();
    lIIlllII[llIIlIIIll[19]] = llIIlIIIll[20] + llIIlIIIll[21] - llIIlIIIll[22] + llIIlIIIll[23] ^ llIIlIIIll[2] + llIIlIIIll[22] - llIIlIIIll[24] + llIIlIIIll[11];
    lIIlllII[llIIlIIIll[25]] = llIIlIIIIl[llIIlIIIll[18]].length();
    lIIlllII[llIIlIIIll[11]] = llIIlIIIll[26] ^ llIIlIIIll[27];
  }
  
  static {
    lIlIllIlIllI();
    lIlIllIIlllI();
    lllIIllIl();
    lllIIllII();
  }
  
  private static boolean lllIIlllI(String lllllllllllllllllIlIlllllIlIlIll, String lllllllllllllllllIlIlllllIlIllII) {
    if (lIlIllIlIlll(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (-(0xC2 ^ 0xC6) >= 0)
        return "  ".length() & ("  ".length() ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIIlIIIll[1];
  }
  
  private static void lIlIllIlIllI() {
    llIIlIIIll = new int[37];
    llIIlIIIll[0] = 0x31 ^ 0x6B ^ 0x2 ^ 0x5F;
    llIIlIIIll[1] = (0x35 ^ 0x62) & (0x52 ^ 0x5 ^ 0xFFFFFFFF);
    llIIlIIIll[2] = 0x49 ^ 0x27;
    llIIlIIIll[3] = 0x57 ^ 0x4C;
    llIIlIIIll[4] = 0x3D ^ 0x34 ^ 0xE3 ^ 0x89;
    llIIlIIIll[5] = 0x89 ^ 0xB9;
    llIIlIIIll[6] = 0xD4 ^ 0xB8;
    llIIlIIIll[7] = 94 + 99 - 117 + 124 ^ 118 + 102 - 173 + 87;
    llIIlIIIll[8] = 66 + 116 - 136 + 86 ^ 170 + 145 - 262 + 132;
    llIIlIIIll[9] = 0xC7 ^ 0xAD;
    llIIlIIIll[10] = 0x59 ^ 0x72 ^ 0xA ^ 0x64;
    llIIlIIIll[11] = 0x74 ^ 0x72;
    llIIlIIIll[12] = -(120 + 75 - 82 + 49 ^ 83 + 127 - 197 + 116);
    llIIlIIIll[13] = 0x7F ^ 0x2C;
    llIIlIIIll[14] = " ".length();
    llIIlIIIll[15] = 26 + 157 - 154 + 159;
    llIIlIIIll[16] = (0xF3 ^ 0x96) + (0xB7 ^ 0xB1) - (0xED ^ 0xA2) + 108 + 81 - 119 + 57;
    llIIlIIIll[17] = "  ".length();
    llIIlIIIll[18] = "   ".length();
    llIIlIIIll[19] = 0x1D ^ 0x19;
    llIIlIIIll[20] = 103 + 107 - 47 + 14 ^ 108 + 169 - 213 + 132;
    llIIlIIIll[21] = 62 + 146 - 74 + 24;
    llIIlIIIll[22] = 0xB3 ^ 0xC0;
    llIIlIIIll[23] = 0x44 ^ 0x50 ^ 0x84 ^ 0xAB;
    llIIlIIIll[24] = 0x77 ^ 0x12 ^ 0x34 ^ 0x10;
    llIIlIIIll[25] = 0x6E ^ 0x6B ^ (0x0 ^ 0x32) & (0xA1 ^ 0x93 ^ 0xFFFFFFFF);
    llIIlIIIll[26] = (0xE5 ^ 0x8B) + (0x6D ^ 0x32) - 69 + 27 - -27 + 8 + (0x52 ^ 0x69);
    llIIlIIIll[27] = (0x15 ^ 0x67) + (0xBC ^ 0x9D) - (0x7B ^ 0x2A) + (0x6A ^ 0x21);
    llIIlIIIll[28] = 0x38 ^ 0x30;
    llIIlIIIll[29] = 4 + 32 - 25 + 159 ^ 132 + 70 - 91 + 52;
    llIIlIIIll[30] = 50 + 104 - 22 + 7 ^ 75 + 72 - 52 + 34;
    llIIlIIIll[31] = 0x5A ^ 0x51;
    llIIlIIIll[32] = 0x90 ^ 0x9C;
    llIIlIIIll[33] = 0xC8 ^ 0xAB ^ 0xE3 ^ 0x8D;
    llIIlIIIll[34] = 0x80 ^ 0x8E;
    llIIlIIIll[35] = 0xB1 ^ 0xBE;
    llIIlIIIll[36] = 0x39 ^ 0x7E ^ 0xFF ^ 0xA8;
  }
  
  private static boolean lIlIllIllIII(char lllllllllllllllllIlIllllIlIlIIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static String lIlIllIIllII(float lllllllllllllllllIlIllllIllIIlll, String lllllllllllllllllIlIllllIllIlIII) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc_w 'Blowfish'
    //   22: invokespecial <init> : ([BLjava/lang/String;)V
    //   25: astore_2
    //   26: ldc_w 'Blowfish'
    //   29: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   32: astore_3
    //   33: aload_3
    //   34: getstatic com/axeelheaven/hbedwars/database/cache/tops/Top.llIIlIIIll : [I
    //   37: bipush #17
    //   39: iaload
    //   40: aload_2
    //   41: invokevirtual init : (ILjava/security/Key;)V
    //   44: new java/lang/String
    //   47: dup
    //   48: aload_3
    //   49: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   52: aload_0
    //   53: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   56: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   59: invokevirtual decode : ([B)[B
    //   62: invokevirtual doFinal : ([B)[B
    //   65: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   68: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   71: areturn
    //   72: astore_2
    //   73: aload_2
    //   74: invokevirtual printStackTrace : ()V
    //   77: aconst_null
    //   78: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	79	0	lllllllllllllllllIlIllllIllIlIIl	Ljava/lang/String;
    //   0	79	3	lllllllllllllllllIlIllllIllIIlII	S
    //   73	4	2	lllllllllllllllllIlIllllIllIlIlI	Ljava/lang/Exception;
    //   33	39	3	lllllllllllllllllIlIllllIllIlIll	Ljavax/crypto/Cipher;
    //   0	79	1	lllllllllllllllllIlIllllIllIIllI	D
    //   0	79	1	lllllllllllllllllIlIllllIllIlIII	Ljava/lang/String;
    //   26	46	2	lllllllllllllllllIlIllllIllIllII	Ljavax/crypto/spec/SecretKeySpec;
    //   0	79	2	lllllllllllllllllIlIllllIllIIlIl	Ljava/lang/Exception;
    //   0	79	0	lllllllllllllllllIlIllllIllIIlll	F
    // Exception table:
    //   from	to	target	type
    //   0	71	72	java/lang/Exception
  }
  
  private static void lllIIllII() {
    lIIllIll = new String[lIIlllII[llIIlIIIll[25]]];
    lIIllIll[lIIlllII[llIIlIIIll[1]]] = lllIIlIlI(llIIlIIIIl[llIIlIIIll[30]], llIIlIIIIl[llIIlIIIll[31]]);
    lIIllIll[lIIlllII[llIIlIIIll[17]]] = lllIIlIlI(llIIlIIIIl[llIIlIIIll[32]], llIIlIIIIl[llIIlIIIll[33]]);
    lIIllIll[lIIlllII[llIIlIIIll[18]]] = lllIIlIll(llIIlIIIIl[llIIlIIIll[34]], llIIlIIIIl[llIIlIIIll[35]]);
  }
  
  private static boolean lIlIllIllIIl(String lllllllllllllllllIlIllllIlIIllll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\database\cache\tops\Top.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */