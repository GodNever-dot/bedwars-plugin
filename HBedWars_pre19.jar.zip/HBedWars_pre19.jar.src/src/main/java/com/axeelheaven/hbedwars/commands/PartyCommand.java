package com.axeelheaven.hbedwars.commands;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.database.profile.HData;
import com.axeelheaven.hbedwars.languague.LanguageProvider;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PartyCommand implements CommandExecutor {
  private static boolean lIIIlllIIIIlI(String llllllllllllllllIIIllIlllIIlIIII, float llllllllllllllllIIIllIlllIIIllll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIIIlllIIlllI(short llllllllllllllllIIIllIlllIIIIIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static void lIIIllIlIlllI() {
    lIIIlllIIll = new String[lIIIlllllll[164]];
    lIIIlllIIll[lIIIlllllll[2]] = lIIIlIlllllIl("fTsoAp9sEjH7Z0ToLknUJQ==", "fnXiP");
    lIIIlllIIll[lIIIlllllll[1]] = lIIIllIIIIIIl("QvU3EIlEVVk=", "rJTvf");
    lIIIlllIIll[lIIIlllllll[3]] = lIIIllIIIIIIl("iUIp8Thcu1v5mRXuyfHmKQ==", "IhJyC");
    lIIIlllIIll[lIIIlllllll[4]] = lIIIlIlllllIl("4jybOk2hkow=", "qMzvi");
    lIIIlllIIll[lIIIlllllll[5]] = lIIIllIIIIIIl("HrXAhcrqM+/vbsktXrWgkw==", "PadFm");
    lIIIlllIIll[lIIIlllllll[6]] = lIIIllIIIIIlI("IRItPDg=", "pfCQL");
    lIIIlllIIll[lIIIlllllll[7]] = lIIIllIIIIIIl("usKfqnaBoUpnHqO7/MG8UVFhE1pfxmRMPhfNcYkDs05Glrq0cZMAYg==", "FFmip");
    lIIIlllIIll[lIIIlllllll[8]] = lIIIllIIIIIIl("8i2+zfP96qI=", "orRMT");
    lIIIlllIIll[lIIIlllllll[9]] = lIIIlIlllllIl("wdxRAO8Ah1K5qEpTSVLtWQ==", "TWSoN");
    lIIIlllIIll[lIIIlllllll[10]] = lIIIllIIIIIlI("EgYJBww=", "evemi");
    lIIIlllIIll[lIIIlllllll[11]] = lIIIlIlllllIl("j7WBPATZrF6m+qpewnqJzg==", "VawLB");
    lIIIlllIIll[lIIIlllllll[12]] = lIIIllIIIIIlI("JgQDEA4=", "smKTe");
    lIIIlllIIll[lIIIlllllll[13]] = lIIIllIIIIIIl("m4Z9Od+UobgSjwrvDoWOag==", "YlChb");
    lIIIlllIIll[lIIIlllllll[14]] = lIIIllIIIIIIl("wgsoJE8fw+Y=", "HsZVq");
    lIIIlllIIll[lIIIlllllll[15]] = lIIIllIIIIIIl("8JWjDysDscjDAdD4GNU7xg==", "weToy");
    lIIIlllIIll[lIIIlllllll[16]] = lIIIllIIIIIlI("MzAZJAI=", "KRUqS");
    lIIIlllIIll[lIIIlllllll[17]] = lIIIllIIIIIIl("TOL7ZsYCcXmtVy3BQwKTvI3/gZsqKvtrhOXDcu/QSG8=", "gCHgT");
    lIIIlllIIll[lIIIlllllll[18]] = lIIIllIIIIIIl("UGBBAo8lHbc=", "KWmXJ");
    lIIIlllIIll[lIIIlllllll[19]] = lIIIllIIIIIIl("Dcg3EbwrK1MMpEbCxtO9yQ==", "BYcns");
    lIIIlllIIll[lIIIlllllll[20]] = lIIIlIlllllIl("Uf+u4vmts38=", "owtfF");
    lIIIlllIIll[lIIIlllllll[21]] = lIIIllIIIIIlI("EDEeFQQ1fT8ZOyB2", "qKlLr");
    lIIIlllIIll[lIIIlllllll[22]] = lIIIllIIIIIIl("KFcXpkOR8gk=", "TrmEM");
    lIIIlllIIll[lIIIlllllll[23]] = lIIIllIIIIIlI("ekYzPSUIMBRiWRsYNy0GejtAOA4lESsEAh0RJzUeaAw=", "QvqWj");
    lIIIlllIIll[lIIIlllllll[24]] = lIIIlIlllllIl("PimfKRhwlBo=", "AOjsC");
    lIIIlllIIll[lIIIlllllll[25]] = lIIIlIlllllIl("j3kaWpMb5ITvvhMhYGiBNg==", "hZMNG");
    lIIIlllIIll[lIIIlllllll[0]] = lIIIllIIIIIIl("c92eoAlkTps=", "kvjMW");
    lIIIlllIIll[lIIIlllllll[26]] = lIIIlIlllllIl("6Dw9Eu1YcEJFIrAaS9RtMg==", "ZGBIn");
    lIIIlllIIll[lIIIlllllll[27]] = lIIIlIlllllIl("KggTorUEDi4=", "jwbOb");
    lIIIlllIIll[lIIIlllllll[28]] = lIIIllIIIIIlI("KAENagEZPhAedjxx", "qLBXN");
    lIIIlllIIll[lIIIlllllll[29]] = lIIIllIIIIIlI("FDw6Jzg=", "fWKKj");
    lIIIlllIIll[lIIIlllllll[30]] = lIIIlIlllllIl("53xOz5Y2MCbEwfXhkt7SfeSI1D3WQWh/F/rbssdLppM=", "eQXEg");
    lIIIlllIIll[lIIIlllllll[31]] = lIIIlIlllllIl("MbOh+C63Ni8=", "BbTdU");
    lIIIlllIIll[lIIIlllllll[32]] = lIIIllIIIIIlI("NDwjFjI0Fxo=", "gEPBs");
    lIIIlllIIll[lIIIlllllll[33]] = lIIIllIIIIIlI("FRUTJjE=", "bPaJp");
    lIIIlllIIll[lIIIlllllll[34]] = lIIIllIIIIIIl("TEO1A6Ii/iaU46Z7BKv0Zw==", "AQCpb");
    lIIIlllIIll[lIIIlllllll[35]] = lIIIlIlllllIl("ekkey7wF2Kw=", "GcnhK");
    lIIIlllIIll[lIIIlllllll[36]] = lIIIlIlllllIl("SvNJoYdLA3gA3dXVlAnJsQ==", "qYlAw");
    lIIIlllIIll[lIIIlllllll[37]] = lIIIllIIIIIlI("BAsFMTc=", "AcMbf");
    lIIIlllIIll[lIIIlllllll[38]] = lIIIlIlllllIl("eJP8EFLOJi2eCh0ofRyqCjMvhzcGGmRKtRJgGx4pQaU=", "WzRWW");
    lIIIlllIIll[lIIIlllllll[39]] = lIIIllIIIIIlI("FwYcLCk=", "RAIOC");
    lIIIlllIIll[lIIIlllllll[40]] = lIIIllIIIIIIl("lx5TgRB7ZlVbrEukU8sTSA==", "UDrgp");
    lIIIlllIIll[lIIIlllllll[41]] = lIIIllIIIIIlI("NSssLjw=", "gHYCh");
    lIIIlllIIll[lIIIlllllll[42]] = lIIIllIIIIIIl("uQB3QqaD+/mn/S8V9H/njQ==", "nPDtc");
    lIIIlllIIll[lIIIlllllll[43]] = lIIIllIIIIIIl("6MhoEZtTlyY=", "PTzld");
    lIIIlllIIll[lIIIlllllll[44]] = lIIIlIlllllIl("W5iH7qg9/HpaUcscmOk6kQ==", "ApRUD");
    lIIIlllIIll[lIIIlllllll[45]] = lIIIllIIIIIlI("HzwMNSo=", "iDuOx");
    lIIIlllIIll[lIIIlllllll[46]] = lIIIllIIIIIIl("gCaLhdrhkFDWdiPzfUvuuA==", "NIZQU");
    lIIIlllIIll[lIIIlllllll[47]] = lIIIllIIIIIlI("ASY1Bjg=", "EMBuI");
    lIIIlllIIll[lIIIlllllll[48]] = lIIIllIIIIIlI("CXdAYxlhBxkAP3p8", "JAtVm");
    lIIIlllIIll[lIIIlllllll[49]] = lIIIllIIIIIIl("nv5hPXcTBQ0=", "jNmVc");
    lIIIlllIIll[lIIIlllllll[50]] = lIIIlIlllllIl("e0rSkaD1KEg=", "fnRXN");
    lIIIlllIIll[lIIIlllllll[51]] = lIIIllIIIIIIl("ugx3fHjxhI4=", "nmUKv");
    lIIIlllIIll[lIIIlllllll[52]] = lIIIlIlllllIl("bnN2PXjPcn8=", "jMaef");
    lIIIlllIIll[lIIIlllllll[53]] = lIIIllIIIIIIl("IKjLtrtWe18=", "zIzYn");
    lIIIlllIIll[lIIIlllllll[54]] = lIIIlIlllllIl("qVjsQsYU0K4=", "rQtMo");
    lIIIlllIIll[lIIIlllllll[55]] = lIIIllIIIIIlI("AxQW", "GQEnU");
    lIIIlllIIll[lIIIlllllll[56]] = lIIIllIIIIIIl("cHEnhVZ1yuI=", "zFRWL");
    lIIIlllIIll[lIIIlllllll[66]] = lIIIlIlllllIl("+0lZKjpM8XU=", "Zfetr");
    lIIIlllIIll[lIIIlllllll[67]] = lIIIllIIIIIIl("5dSl41JzrDw=", "knGPZ");
    lIIIlllIIll[lIIIlllllll[68]] = lIIIllIIIIIIl("XipCh3eau+w=", "mRXUa");
    lIIIlllIIll[lIIIlllllll[96]] = lIIIllIIIIIlI("Yg==", "BwvxN");
    lIIIlllIIll[lIIIlllllll[98]] = lIIIlIlllllIl("i6Q6rVhvZ5E=", "VPtYR");
    lIIIlllIIll[lIIIlllllll[99]] = lIIIllIIIIIIl("Yp20jtFrWR4=", "QIHyz");
    lIIIlllIIll[lIIIlllllll[102]] = lIIIlIlllllIl("+4yIpMjaeCM=", "hegdp");
    lIIIlllIIll[lIIIlllllll[110]] = lIIIlIlllllIl("bVrhtRFZ7aM=", "vxjQi");
    lIIIlllIIll[lIIIlllllll[76]] = lIIIllIIIIIIl("2PS3RCzSEnw=", "hCcAi");
    lIIIlllIIll[lIIIlllllll[111]] = lIIIlIlllllIl("xDN8uFY8xi8=", "dUuta");
    lIIIlllIIll[lIIIlllllll[93]] = lIIIlIlllllIl("hbwXrOw5iMU=", "LyGzL");
    lIIIlllIIll[lIIIlllllll[62]] = lIIIllIIIIIIl("MY7bX6LWgpc=", "jzqez");
    lIIIlllIIll[lIIIlllllll[114]] = lIIIllIIIIIlI("", "Ycjro");
    lIIIlllIIll[lIIIlllllll[115]] = lIIIlIlllllIl("+/iqwiY7wbM=", "cAuIu");
    lIIIlllIIll[lIIIlllllll[101]] = lIIIllIIIIIIl("FTaMihybh8Q=", "pfHCF");
    lIIIlllIIll[lIIIlllllll[78]] = lIIIllIIIIIIl("98pvoBDZUQo=", "XNnyu");
    lIIIlllIIll[lIIIlllllll[126]] = lIIIllIIIIIlI("dg==", "VWHKL");
    lIIIlllIIll[lIIIlllllll[90]] = lIIIlIlllllIl("iqNrZftean8=", "YGIrZ");
    lIIIlllIIll[lIIIlllllll[119]] = lIIIlIlllllIl("L+0PCjAIlB4=", "kfGnG");
    lIIIlllIIll[lIIIlllllll[77]] = lIIIllIIIIIIl("mu30WNcm9QU=", "ioCpO");
    lIIIlllIIll[lIIIlllllll[135]] = lIIIllIIIIIIl("dE0jAcCqx8g=", "rxFsS");
    lIIIlllIIll[lIIIlllllll[136]] = lIIIllIIIIIIl("HbnIPPR7W14=", "fiXbi");
    lIIIlllIIll[lIIIlllllll[142]] = lIIIlIlllllIl("Ji+vulcOvg4=", "PcHfj");
    lIIIlllIIll[lIIIlllllll[91]] = lIIIlIlllllIl("5DprZf395PM=", "xjwBt");
    lIIIlllIIll[lIIIlllllll[134]] = lIIIllIIIIIIl("YCDmC5zsLEw=", "kiyCs");
    lIIIlllIIll[lIIIlllllll[147]] = lIIIlIlllllIl("F7Yyblwfr9M=", "KTano");
    lIIIlllIIll[lIIIlllllll[148]] = lIIIlIlllllIl("hYPIRdYZAz8=", "zLzEH");
    lIIIlllIIll[lIIIlllllll[100]] = lIIIlIlllllIl("5SxoIzn2IHk=", "OILDF");
    lIIIlllIIll[lIIIlllllll[103]] = lIIIllIIIIIIl("RgpozFNpdZQ=", "GISuh");
    lIIIlllIIll[lIIIlllllll[156]] = lIIIlIlllllIl("J2gCEiFxr14=", "HZDwY");
    lIIIlllIIll[lIIIlllllll[92]] = lIIIllIIIIIIl("tcrZolH31DU=", "zjSyg");
    lIIIlllIIll[lIIIlllllll[160]] = lIIIllIIIIIlI("", "fIkmN");
    lIIIlllIIll[lIIIlllllll[85]] = lIIIllIIIIIlI("", "JFHPe");
    lIIIlllIIll[lIIIlllllll[57]] = lIIIllIIIIIIl("s++rfiJhwaQ=", "Eojzc");
    lIIIlllIIll[lIIIlllllll[161]] = lIIIllIIIIIIl("FcjGKaw4cas=", "KIXDA");
    lIIIlllIIll[lIIIlllllll[162]] = lIIIllIIIIIIl("bJmgOdSO1kM=", "fnhQu");
    lIIIlllIIll[lIIIlllllll[117]] = lIIIllIIIIIIl("KGHOvxN2++BYlNiTSRmM1Q==", "PtCWz");
    lIIIlllIIll[lIIIlllllll[163]] = lIIIlIlllllIl("Qs9g46N7S7d/tjgA/wMvfA==", "pqZTn");
  }
  
  private static boolean lIIIllIllllIl(byte llllllllllllllllIIIllIllIlllllll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < null);
  }
  
  private static String llIIIlllIlI(short llllllllllllllllIIIllIllllIlIlIl, boolean llllllllllllllllIIIllIllllIllllI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   10: sipush #162
    //   13: iaload
    //   14: aaload
    //   15: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   18: aload_1
    //   19: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   22: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   25: invokevirtual digest : ([B)[B
    //   28: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   31: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   34: bipush #117
    //   36: iaload
    //   37: aaload
    //   38: invokespecial <init> : ([BLjava/lang/String;)V
    //   41: astore_2
    //   42: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   45: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   48: sipush #163
    //   51: iaload
    //   52: aaload
    //   53: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   56: astore_3
    //   57: aload_3
    //   58: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   61: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   64: iconst_3
    //   65: iaload
    //   66: iaload
    //   67: aload_2
    //   68: invokevirtual init : (ILjava/security/Key;)V
    //   71: new java/lang/String
    //   74: dup
    //   75: aload_3
    //   76: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   79: aload_0
    //   80: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   83: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   86: invokevirtual decode : ([B)[B
    //   89: invokevirtual doFinal : ([B)[B
    //   92: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   95: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   98: areturn
    //   99: astore_2
    //   100: aload_2
    //   101: invokevirtual printStackTrace : ()V
    //   104: aconst_null
    //   105: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	106	2	llllllllllllllllIIIllIllllIlIIll	Z
    //   0	106	0	llllllllllllllllIIIllIllllIllIII	S
    //   0	106	2	llllllllllllllllIIIllIllllIllIIl	Ljava/lang/String;
    //   0	106	3	llllllllllllllllIIIllIllllIlIIlI	C
    //   42	57	2	llllllllllllllllIIIllIllllIlIlll	Ljavax/crypto/spec/SecretKeySpec;
    //   0	106	3	llllllllllllllllIIIllIllllIllIll	F
    //   0	106	1	llllllllllllllllIIIllIllllIllIlI	Ljava/lang/String;
    //   100	4	2	llllllllllllllllIIIllIllllIlIllI	Ljava/lang/Exception;
    //   0	106	0	llllllllllllllllIIIllIllllIlIlIl	S
    //   0	106	1	llllllllllllllllIIIllIllllIllllI	Z
    //   57	42	3	llllllllllllllllIIIllIllllIlllII	Ljavax/crypto/Cipher;
    //   0	106	0	llllllllllllllllIIIllIllllIlllIl	Ljava/lang/String;
    //   0	106	1	llllllllllllllllIIIllIllllIlIlII	B
    // Exception table:
    //   from	to	target	type
    //   0	98	99	java/lang/Exception
  }
  
  private static boolean llIIlIIIIll(float llllllllllllllllIIIllIllllIIlIlI) {
    if (lIIIlllIIlIll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ("   ".length() <= 0)
        return (0x50 ^ 0x54 ^ 0xFB ^ 0xB7) & (0x48 ^ 0x3D ^ 0x74 ^ 0x49 ^ -" ".length()); 
    } else {
    
    } 
    return lIIIlllllll[2];
  }
  
  private static boolean lIIIllIllllII(float llllllllllllllllIIIllIlllIIIIlIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean llIIlIIIIIl(byte llllllllllllllllIIIlllIIlIlIIIll) {
    if (lIIIllIllllII(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (("  ".length() & ("  ".length() ^ -" ".length())) > 0)
        return (25 + 107 - 88 + 88 ^ 138 + 125 - 105 + 34) & (0x6B ^ 0x4E ^ 0xE3 ^ 0x82 ^ -" ".length()); 
    } else {
    
    } 
    return lIIIlllllll[2];
  }
  
  public PartyCommand(char llllllllllllllllIIIlllIIlIIlIlII) {
    this.plugin = llllllllllllllllIIIlllIIlIIlIlII;
  }
  
  private static boolean llIIlIIIIII(boolean llllllllllllllllIIIlllIIIIIlllIl, boolean llllllllllllllllIIIlllIIIIIlllII) {
    if (lIIIlllIIIIlI(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if ("  ".length() >= "   ".length())
        return (0x79 ^ 0x1F ^ 0x52 ^ 0x55) & (197 + 165 - 252 + 137 ^ 49 + 64 - 110 + 147 ^ -" ".length()); 
    } else {
    
    } 
    return lIIIlllllll[2];
  }
  
  private static void lIIIllIlllIll() {
    lIIIlllllll = new int[165];
    lIIIlllllll[0] = 0x67 ^ 0x7E;
    lIIIlllllll[1] = " ".length();
    lIIIlllllll[2] = (0x36 ^ 0x20) & (0x75 ^ 0x63 ^ 0xFFFFFFFF);
    lIIIlllllll[3] = "  ".length();
    lIIIlllllll[4] = "   ".length();
    lIIIlllllll[5] = 0x9D ^ 0x99;
    lIIIlllllll[6] = 0x44 ^ 0x39 ^ 0x4A ^ 0x32;
    lIIIlllllll[7] = 0x30 ^ 0x36;
    lIIIlllllll[8] = 0x3A ^ 0x3D;
    lIIIlllllll[9] = 0x28 ^ 0x52 ^ 0xE ^ 0x7C;
    lIIIlllllll[10] = 0x72 ^ 0x7B;
    lIIIlllllll[11] = 0x1 ^ 0xB;
    lIIIlllllll[12] = 0x5B ^ 0x50;
    lIIIlllllll[13] = 34 + 150 - 155 + 122 ^ 121 + 6 - 16 + 44;
    lIIIlllllll[14] = 0xA0 ^ 0xAD;
    lIIIlllllll[15] = 0x6B ^ 0x20 ^ 0xE1 ^ 0xA4;
    lIIIlllllll[16] = 0xB2 ^ 0xBD;
    lIIIlllllll[17] = 51 + 106 - 152 + 122 ^ 0x10 ^ 0x7F;
    lIIIlllllll[18] = 0x29 ^ 0x38;
    lIIIlllllll[19] = 0x2F ^ 0x0 ^ 0x8E ^ 0xB3;
    lIIIlllllll[20] = 22 + 25 - -42 + 51 ^ 140 + 146 - 245 + 118;
    lIIIlllllll[21] = 0x4D ^ 0x59;
    lIIIlllllll[22] = 0x74 ^ 0x3E ^ 0xDA ^ 0x85;
    lIIIlllllll[23] = 1 + 51 - 23 + 111 ^ 109 + 1 - 106 + 150;
    lIIIlllllll[24] = 0xE6 ^ 0x9B ^ 0xFF ^ 0x95;
    lIIIlllllll[25] = 0x27 ^ 0x3F;
    lIIIlllllll[26] = 134 + 78 - 21 + 29 ^ 12 + 75 - 32 + 143;
    lIIIlllllll[27] = 0x46 ^ 0x1B ^ 0x71 ^ 0x37;
    lIIIlllllll[28] = 0x1E ^ 0x38 ^ 0xFF ^ 0xC5;
    lIIIlllllll[29] = 0x14 ^ 0x9;
    lIIIlllllll[30] = 0x15 ^ 0xB;
    lIIIlllllll[31] = 0x3F ^ 0x20;
    lIIIlllllll[32] = 161 + 77 - 61 + 5 ^ 77 + 50 - 16 + 39;
    lIIIlllllll[33] = 0x9C ^ 0xBD;
    lIIIlllllll[34] = 0xF9 ^ 0x96 ^ 0xCB ^ 0x86;
    lIIIlllllll[35] = 0x58 ^ 0x7B;
    lIIIlllllll[36] = 0x47 ^ 0x63;
    lIIIlllllll[37] = 0x47 ^ 0x62;
    lIIIlllllll[38] = 0xEC ^ 0x85 ^ 0x39 ^ 0x76;
    lIIIlllllll[39] = 35 + 179 - 103 + 78 ^ 36 + 22 - 45 + 141;
    lIIIlllllll[40] = 0xE8 ^ 0xC0;
    lIIIlllllll[41] = 0x67 ^ 0x4E;
    lIIIlllllll[42] = 0x73 ^ 0x59;
    lIIIlllllll[43] = 0x56 ^ 0x7D;
    lIIIlllllll[44] = 0xE9 ^ 0x9E ^ 0x1F ^ 0x44;
    lIIIlllllll[45] = 0x35 ^ 0x18;
    lIIIlllllll[46] = 0x3B ^ 0x7E ^ 0xC0 ^ 0xAB;
    lIIIlllllll[47] = 0x37 ^ 0x18;
    lIIIlllllll[48] = 61 + 19 - -10 + 55 ^ 35 + 126 - 44 + 44;
    lIIIlllllll[49] = 0x81 ^ 0xB0;
    lIIIlllllll[50] = 53 + 95 - -13 + 10 ^ 68 + 46 - 0 + 39;
    lIIIlllllll[51] = 0xF4 ^ 0xC7;
    lIIIlllllll[52] = 0x53 ^ 0x67;
    lIIIlllllll[53] = 0x15 ^ 0x20;
    lIIIlllllll[54] = 51 + 151 - 177 + 222 ^ 24 + 47 - -115 + 7;
    lIIIlllllll[55] = 0x4C ^ 0x7B;
    lIIIlllllll[56] = 0x74 ^ 0x4C;
    lIIIlllllll[57] = 0x38 ^ 0x2E ^ 0xE0 ^ 0xAC;
    lIIIlllllll[58] = 57 + 40 - 14 + 115;
    lIIIlllllll[59] = 73 + 16 - 50 + 99 + (0x35 ^ 0x66) - 14 + 35 - -34 + 63 + (0xDA ^ 0x9C);
    lIIIlllllll[60] = 84 + 95 - 107 + 85;
    lIIIlllllll[61] = 172 + 65 - 178 + 121;
    lIIIlllllll[62] = 214 + 18 - 97 + 84 ^ 105 + 52 - 63 + 65;
    lIIIlllllll[63] = 119 + 63 - 73 + 122;
    lIIIlllllll[64] = (0xEB ^ 0xB0) + (0xA9 ^ 0xBD) - (0x17 ^ 0x19) + (0x85 ^ 0xC5);
    lIIIlllllll[65] = -" ".length();
    lIIIlllllll[66] = 0x1 ^ 0x38;
    lIIIlllllll[67] = 0x11 ^ 0x64 ^ 0xE0 ^ 0xAF;
    lIIIlllllll[68] = 0x13 ^ 0x28;
    lIIIlllllll[69] = 28 + 29 - -33 + 47;
    lIIIlllllll[70] = 23 + 47 - 2 + 62 + (0x14 ^ 0x7) - (0x27 ^ 0x3F) + (0x9F ^ 0x90);
    lIIIlllllll[71] = 0x77 ^ 0x2;
    lIIIlllllll[72] = 0xC ^ 0x7F;
    lIIIlllllll[73] = (0xD4 ^ 0xC1) + 146 + 101 - 122 + 69 - 173 + 4 - 118 + 122 + 177 + 140 - 122 + 25;
    lIIIlllllll[74] = (0x93 ^ 0x82) + 134 + 156 - 150 + 22 - (0xB ^ 0x72) + (0xE5 ^ 0x97);
    lIIIlllllll[75] = 70 + 52 - 107 + 121;
    lIIIlllllll[76] = 0x1C ^ 0x23 ^ 0x6B ^ 0x15;
    lIIIlllllll[77] = 0x3A ^ 0x76;
    lIIIlllllll[78] = 0x3D ^ 0x5D ^ 0x55 ^ 0x7D;
    lIIIlllllll[79] = 123 + 117 - 223 + 125;
    lIIIlllllll[80] = 14 + 108 - 71 + 131;
    lIIIlllllll[81] = 5 + 27 - -68 + 91;
    lIIIlllllll[82] = 51 + 2 - 43 + 152;
    lIIIlllllll[83] = 0x56 ^ 0xF ^ 0x9D ^ 0xA9;
    lIIIlllllll[84] = 0x45 ^ 0x13 ^ 0xBD ^ 0x90;
    lIIIlllllll[85] = 0xE9 ^ 0xA4 ^ 0x88 ^ 0x9C;
    lIIIlllllll[86] = 87 + 84 - 96 + 52;
    lIIIlllllll[87] = (0xF3 ^ 0xB9) + (0x88 ^ 0x93) - (0xDE ^ 0xC2) + (0x19 ^ 0x2E);
    lIIIlllllll[88] = 94 + 147 - 144 + 65 + 35 + 122 - 70 + 68 - 92 + 26 - -30 + 102 + 127 + 53 - 144 + 110;
    lIIIlllllll[89] = 1 + 39 - -7 + 109;
    lIIIlllllll[90] = 0x25 ^ 0x5 ^ 0x7D ^ 0x17;
    lIIIlllllll[91] = 0x45 ^ 0x15;
    lIIIlllllll[92] = 0xC6 ^ 0xC2 ^ 0xC1 ^ 0x92;
    lIIIlllllll[93] = 0x31 ^ 0x72;
    lIIIlllllll[94] = (0x5C ^ 0x8) + (0xA ^ 0x56) - (0xD4 ^ 0xB5) + (0x19 ^ 0x70);
    lIIIlllllll[95] = 105 + 109 - 213 + 131;
    lIIIlllllll[96] = 0x53 ^ 0x66 ^ 0x64 ^ 0x6D;
    lIIIlllllll[97] = 112 + 84 - 87 + 57;
    lIIIlllllll[98] = 0x5C ^ 0x61;
    lIIIlllllll[99] = 107 + 50 - 90 + 81 ^ 151 + 122 - 254 + 151;
    lIIIlllllll[100] = 77 + 61 - 61 + 124 ^ 138 + 133 - 191 + 77;
    lIIIlllllll[101] = 0x64 ^ 0x23;
    lIIIlllllll[102] = 0x87 ^ 0xB8;
    lIIIlllllll[103] = 0x5F ^ 0x21 ^ 0xA4 ^ 0x8F;
    lIIIlllllll[104] = 33 + 25 - -39 + 32;
    lIIIlllllll[105] = 89 + 99 - 111 + 86;
    lIIIlllllll[106] = 138 + 66 - 51 + 98;
    lIIIlllllll[107] = (0x7 ^ 0x2D) + (0x4E ^ 0x45) - -(0x46 ^ 0x67) + (0xE8 ^ 0x83);
    lIIIlllllll[108] = 0xC8 ^ 0xBA;
    lIIIlllllll[109] = 16 + 140 - 62 + 110 ^ 131 + 144 - 115 + 2;
    lIIIlllllll[110] = 0xEF ^ 0xB6 ^ 0x50 ^ 0x49;
    lIIIlllllll[111] = 0xEE ^ 0xAC;
    lIIIlllllll[112] = 97 + 17 - -46 + 26;
    lIIIlllllll[113] = 64 + 52 - 66 + 85;
    lIIIlllllll[114] = 61 + 197 - 113 + 100 ^ 172 + 165 - 211 + 50;
    lIIIlllllll[115] = 0x50 ^ 0x39 ^ 0x85 ^ 0xAA;
    lIIIlllllll[116] = 0x22 ^ 0x49;
    lIIIlllllll[117] = 0xCF ^ 0x92;
    lIIIlllllll[118] = -(0x74 ^ 0x4F ^ 0x9B ^ 0xBB);
    lIIIlllllll[119] = 0x8 ^ 0x43;
    lIIIlllllll[120] = -(0xA0 ^ 0xB1);
    lIIIlllllll[121] = -(0x3D ^ 0x1F ^ 0x9C ^ 0xB1);
    lIIIlllllll[122] = (0x8 ^ 0x2E) + 167 + 26 - 38 + 35 - (0x42 ^ 0x68) + (0x75 ^ 0x56);
    lIIIlllllll[123] = (0x35 ^ 0x45) + (0x77 ^ 0x0) - 20 + 146 - 36 + 70 + 94 + 102 - 171 + 138;
    lIIIlllllll[124] = 0x68 ^ 0x4B ^ 0xCB ^ 0x8B;
    lIIIlllllll[125] = 0x57 ^ 0x3 ^ 0xBF ^ 0x97;
    lIIIlllllll[126] = 0x3B ^ 0x72;
    lIIIlllllll[127] = 0xFD ^ 0x98;
    lIIIlllllll[128] = 183 + 184 - 215 + 87;
    lIIIlllllll[129] = 45 + 29 - 16 + 87 + (0x79 ^ 0x29) - 204 + 57 - 242 + 193 + 161 + 154 - 275 + 188;
    lIIIlllllll[130] = 11 + 9 - -15 + 124;
    lIIIlllllll[131] = 112 + 172 - 56 + 19;
    lIIIlllllll[132] = 0x71 ^ 0x6;
    lIIIlllllll[133] = 0x38 ^ 0x57;
    lIIIlllllll[134] = 0xFD ^ 0xAC;
    lIIIlllllll[135] = 0x58 ^ 0x15;
    lIIIlllllll[136] = 181 + 9 - 169 + 188 ^ 50 + 35 - 53 + 127;
    lIIIlllllll[137] = 29 + 8 - -85 + 32;
    lIIIlllllll[138] = 0x2A ^ 0x40;
    lIIIlllllll[139] = 51 + 55 - 12 + 47 + 146 + 99 - 104 + 29 - 183 + 148 - 136 + 53 + (0x35 ^ 0x4D);
    lIIIlllllll[140] = (0x8C ^ 0x8A) + (0xB4 ^ 0xC4) - "  ".length() + (0xFA ^ 0xC7);
    lIIIlllllll[141] = 155 + 91 - 77 + 30;
    lIIIlllllll[142] = 0 + 44 - 32 + 189 ^ 97 + 127 - 145 + 55;
    lIIIlllllll[143] = (0x7F ^ 0x5B) + (0xD ^ 0x8) - (0x2 ^ 0xD) + 32 + 38 - -10 + 91;
    lIIIlllllll[144] = 176 + 147 - 272 + 161;
    lIIIlllllll[145] = (0x7 ^ 0xD) + (0x59 ^ 0x2D) - (0x2F ^ 0x56) + (0x2 ^ 0x7F);
    lIIIlllllll[146] = 0xD9 ^ 0xA3;
    lIIIlllllll[147] = 0x9 ^ 0x5B;
    lIIIlllllll[148] = 0x66 ^ 0x35;
    lIIIlllllll[149] = 127 + 181 - 97 + 13;
    lIIIlllllll[150] = 14 + 17 - -109 + 38;
    lIIIlllllll[151] = 0x68 ^ 0x11;
    lIIIlllllll[152] = 0xFE ^ 0x8E;
    lIIIlllllll[153] = 5 + 199 - 26 + 56 ^ 118 + 120 - 106 + 2;
    lIIIlllllll[154] = -(84 + 25 - 22 + 70 ^ 9 + 48 - 4 + 114);
    lIIIlllllll[155] = 10 + 105 - 33 + 65 + 75 + 10 - -35 + 54 - (0xFFFFAF78 & 0x51BF) + 56 + 161 - 206 + 176;
    lIIIlllllll[156] = 200 + 82 - 110 + 63 ^ 69 + 187 - 242 + 175;
    lIIIlllllll[157] = 13 + 4 - -24 + 90;
    lIIIlllllll[158] = 165 + 8 - 31 + 33;
    lIIIlllllll[159] = 47 + 47 - 76 + 209 ^ 2 + 25 - -68 + 62;
    lIIIlllllll[160] = 0x9 ^ 0x51;
    lIIIlllllll[161] = 56 + 167 - 205 + 178 ^ 52 + 151 - 89 + 45;
    lIIIlllllll[162] = 0x6F ^ 0x33;
    lIIIlllllll[163] = 0xE5 ^ 0xBB;
    lIIIlllllll[164] = 0xB ^ 0x7D ^ 0x7D ^ 0x54;
  }
  
  private static boolean lIIIlllIIlIll(Exception llllllllllllllllIIIllIlllIIIlIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean lIIIlllIIlIII(short llllllllllllllllIIIllIllIllllIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > null);
  }
  
  private static String llIIIllllII(byte llllllllllllllllIIIlllIIIlIIllll, String llllllllllllllllIIIlllIIIlIlIIIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   10: bipush #53
    //   12: iaload
    //   13: aaload
    //   14: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   17: aload_1
    //   18: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   21: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   24: invokevirtual digest : ([B)[B
    //   27: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   30: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   33: bipush #9
    //   35: iaload
    //   36: iaload
    //   37: invokestatic copyOf : ([BI)[B
    //   40: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   43: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   46: bipush #54
    //   48: iaload
    //   49: aaload
    //   50: invokespecial <init> : ([BLjava/lang/String;)V
    //   53: astore_2
    //   54: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   57: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   60: bipush #55
    //   62: iaload
    //   63: aaload
    //   64: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   67: astore_3
    //   68: aload_3
    //   69: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   72: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   75: iconst_3
    //   76: iaload
    //   77: iaload
    //   78: aload_2
    //   79: invokevirtual init : (ILjava/security/Key;)V
    //   82: new java/lang/String
    //   85: dup
    //   86: aload_3
    //   87: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   90: aload_0
    //   91: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   94: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   97: invokevirtual decode : ([B)[B
    //   100: invokevirtual doFinal : ([B)[B
    //   103: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   106: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   109: areturn
    //   110: astore_2
    //   111: aload_2
    //   112: invokevirtual printStackTrace : ()V
    //   115: aconst_null
    //   116: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	117	1	llllllllllllllllIIIlllIIIlIllIll	D
    //   0	117	1	llllllllllllllllIIIlllIIIlIlIIIl	Ljava/lang/String;
    //   0	117	3	llllllllllllllllIIIlllIIIlIIlllI	D
    //   0	117	2	llllllllllllllllIIIlllIIIlIIlIIl	D
    //   54	56	2	llllllllllllllllIIIlllIIIlIllIII	Ljavax/crypto/spec/SecretKeySpec;
    //   111	4	2	llllllllllllllllIIIlllIIIlIlIllI	Ljava/lang/Exception;
    //   0	117	0	llllllllllllllllIIIlllIIIlIIllII	F
    //   0	117	2	llllllllllllllllIIIlllIIIlIllIIl	S
    //   68	42	3	llllllllllllllllIIIlllIIIlIlIlII	Ljavax/crypto/Cipher;
    //   0	117	0	llllllllllllllllIIIlllIIIlIIllll	B
    //   0	117	1	llllllllllllllllIIIlllIIIlIIlIll	Ljava/lang/Exception;
    //   0	117	3	llllllllllllllllIIIlllIIIlIIlIII	Ljava/lang/Exception;
    //   0	117	0	llllllllllllllllIIIlllIIIlIlIIll	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	109	110	java/lang/Exception
  }
  
  private static String lIIIllIIIIIlI(String llllllllllllllllIIIllIlllIlIllII, Exception llllllllllllllllIIIllIlllIlIlIll) {
    llllllllllllllllIIIllIlllIllIIIl = new String(Base64.getDecoder().decode(llllllllllllllllIIIllIlllIlIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIIIllIlllIlIllll = new StringBuilder();
    char[] llllllllllllllllIIIllIlllIlIlllI = llllllllllllllllIIIllIlllIlIlIll.toCharArray();
    int llllllllllllllllIIIllIlllIlIllIl = lIIIlllllll[2];
    char[] arrayOfChar1 = llllllllllllllllIIIllIlllIllIIIl.toCharArray();
    int i = arrayOfChar1.length;
    llllllllllllllllIIIllIlllIlIIlIl = lIIIlllllll[2];
    while (lIIIlllIIIIlI(llllllllllllllllIIIllIlllIlIIlIl, i)) {
      char llllllllllllllllIIIllIlllIllIIlI = arrayOfChar1[llllllllllllllllIIIllIlllIlIIlIl];
      "".length();
      llllllllllllllllIIIllIlllIlIllIl++;
      llllllllllllllllIIIllIlllIlIIlIl++;
      "".length();
      if ((0x75 ^ 0x71) <= -" ".length())
        return null; 
    } 
    return String.valueOf(llllllllllllllllIIIllIlllIlIllll);
  }
  
  private static String lIIIlIlllllIl(double llllllllllllllllIIIllIlllIllllll, int llllllllllllllllIIIllIlllIllllIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: ldc_w 'Blowfish'
    //   23: invokespecial <init> : ([BLjava/lang/String;)V
    //   26: astore_2
    //   27: ldc_w 'Blowfish'
    //   30: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   33: astore_3
    //   34: aload_3
    //   35: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   38: iconst_3
    //   39: iaload
    //   40: aload_2
    //   41: invokevirtual init : (ILjava/security/Key;)V
    //   44: new java/lang/String
    //   47: dup
    //   48: aload_3
    //   49: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   52: aload_0
    //   53: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   56: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   59: invokevirtual decode : ([B)[B
    //   62: invokevirtual doFinal : ([B)[B
    //   65: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   68: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   71: areturn
    //   72: astore_2
    //   73: aload_2
    //   74: invokevirtual printStackTrace : ()V
    //   77: aconst_null
    //   78: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   34	38	3	llllllllllllllllIIIllIllllIIIIll	Ljavax/crypto/Cipher;
    //   0	79	1	llllllllllllllllIIIllIlllIlllllI	Ljava/lang/Exception;
    //   73	4	2	llllllllllllllllIIIllIllllIIIIlI	Ljava/lang/Exception;
    //   0	79	2	llllllllllllllllIIIllIlllIllllIl	I
    //   0	79	0	llllllllllllllllIIIllIllllIIIIIl	Ljava/lang/String;
    //   0	79	0	llllllllllllllllIIIllIlllIllllll	D
    //   0	79	3	llllllllllllllllIIIllIlllIllllII	Z
    //   27	45	2	llllllllllllllllIIIllIllllIIIlII	Ljavax/crypto/spec/SecretKeySpec;
    //   0	79	1	llllllllllllllllIIIllIllllIIIIII	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	71	72	java/lang/Exception
  }
  
  private static String llIIIlllIll(boolean llllllllllllllllIIIlllIIIllllIII, String llllllllllllllllIIIlllIIlIIIIlII) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   40: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   43: iconst_1
    //   44: iaload
    //   45: iaload
    //   46: istore #4
    //   48: aload_0
    //   49: invokevirtual toCharArray : ()[C
    //   52: astore #5
    //   54: aload #5
    //   56: arraylength
    //   57: istore #6
    //   59: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   62: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   65: iconst_1
    //   66: iaload
    //   67: iaload
    //   68: istore #7
    //   70: iload #7
    //   72: iload #6
    //   74: invokestatic llIIlIIIIII : (II)Z
    //   77: invokestatic lIIIllIllllII : (I)Z
    //   80: ifeq -> 166
    //   83: aload #5
    //   85: iload #7
    //   87: caload
    //   88: istore #8
    //   90: aload_2
    //   91: iload #8
    //   93: aload_3
    //   94: iload #4
    //   96: aload_3
    //   97: arraylength
    //   98: irem
    //   99: caload
    //   100: ixor
    //   101: i2c
    //   102: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   105: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   108: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   111: bipush #50
    //   113: iaload
    //   114: aaload
    //   115: invokevirtual length : ()I
    //   118: pop2
    //   119: iinc #4, 1
    //   122: iinc #7, 1
    //   125: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   128: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   131: bipush #51
    //   133: iaload
    //   134: aaload
    //   135: invokevirtual length : ()I
    //   138: ldc_w ''
    //   141: invokevirtual length : ()I
    //   144: pop2
    //   145: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   148: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   151: bipush #52
    //   153: iaload
    //   154: aaload
    //   155: invokevirtual length : ()I
    //   158: invokestatic lIIIllIllllIl : (I)Z
    //   161: ifeq -> 70
    //   164: aconst_null
    //   165: areturn
    //   166: aload_2
    //   167: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   170: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	171	1	llllllllllllllllIIIlllIIIlllIlII	Ljava/lang/Exception;
    //   0	171	2	llllllllllllllllIIIlllIIlIIIIlIl	C
    //   0	171	3	llllllllllllllllIIIlllIIIlllIIII	Ljava/lang/String;
    //   0	171	0	llllllllllllllllIIIlllIIlIIIIllI	Ljava/lang/String;
    //   0	171	2	llllllllllllllllIIIlllIIIlllIIlI	F
    //   0	171	1	llllllllllllllllIIIlllIIlIIIIlII	Ljava/lang/String;
    //   0	171	0	llllllllllllllllIIIlllIIIllllIII	Z
    //   0	171	6	llllllllllllllllIIIlllIIlIIIlIII	B
    //   0	171	3	llllllllllllllllIIIlllIIlIIIIIlI	S
    //   0	171	5	llllllllllllllllIIIlllIIIllIllII	D
    //   48	123	4	llllllllllllllllIIIlllIIIlllllll	I
    //   0	171	7	llllllllllllllllIIIlllIIIllIlIlI	Z
    //   0	171	8	llllllllllllllllIIIlllIIIllIlIII	F
    //   90	32	8	llllllllllllllllIIIlllIIIllllIlI	C
    //   0	171	1	llllllllllllllllIIIlllIIlIIIIIII	I
    //   0	171	4	llllllllllllllllIIIlllIIIllIlllI	J
    //   0	171	5	llllllllllllllllIIIlllIIIlllIllI	D
    //   0	171	7	llllllllllllllllIIIlllIIlIIIIIll	F
    //   37	134	3	llllllllllllllllIIIlllIIlIIIIlll	[C
    //   32	139	2	llllllllllllllllIIIlllIIIllllllI	Ljava/lang/StringBuilder;
    //   0	171	6	llllllllllllllllIIIlllIIIllIlIll	S
    //   0	171	0	llllllllllllllllIIIlllIIIlllIlIl	Ljava/lang/Exception;
    //   0	171	4	llllllllllllllllIIIlllIIIlllllII	S
    //   0	171	8	llllllllllllllllIIIlllIIlIIIIIIl	B
  }
  
  private static boolean lIIIlllIIllll(double llllllllllllllllIIIllIlllIIIIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static boolean lIIIlllIIllII(int llllllllllllllllIIIllIlllIIlIlII, long llllllllllllllllIIIllIlllIIlIIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static String lIIIllIIIIIIl(float llllllllllllllllIIIllIlllIIllIlI, String llllllllllllllllIIIllIlllIIllIll) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   23: bipush #9
    //   25: iaload
    //   26: invokestatic copyOf : ([BI)[B
    //   29: ldc_w 'DES'
    //   32: invokespecial <init> : ([BLjava/lang/String;)V
    //   35: astore_2
    //   36: ldc_w 'DES'
    //   39: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   42: astore_3
    //   43: aload_3
    //   44: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   47: iconst_3
    //   48: iaload
    //   49: aload_2
    //   50: invokevirtual init : (ILjava/security/Key;)V
    //   53: new java/lang/String
    //   56: dup
    //   57: aload_3
    //   58: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   61: aload_0
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   68: invokevirtual decode : ([B)[B
    //   71: invokevirtual doFinal : ([B)[B
    //   74: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   77: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   80: areturn
    //   81: astore_2
    //   82: aload_2
    //   83: invokevirtual printStackTrace : ()V
    //   86: aconst_null
    //   87: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	88	1	llllllllllllllllIIIllIlllIIllIIl	Ljava/lang/Exception;
    //   0	88	0	llllllllllllllllIIIllIlllIIlllII	Ljava/lang/String;
    //   36	45	2	llllllllllllllllIIIllIlllIIlllll	Ljavax/crypto/spec/SecretKeySpec;
    //   82	4	2	llllllllllllllllIIIllIlllIIlllIl	Ljava/lang/Exception;
    //   0	88	2	llllllllllllllllIIIllIlllIIllIII	I
    //   43	38	3	llllllllllllllllIIIllIlllIIllllI	Ljavax/crypto/Cipher;
    //   0	88	3	llllllllllllllllIIIllIlllIIlIlll	J
    //   0	88	0	llllllllllllllllIIIllIlllIIllIlI	F
    //   0	88	1	llllllllllllllllIIIllIlllIIllIll	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	80	81	java/lang/Exception
  }
  
  public boolean onCommand(long llllllllllllllllIIIllIlllllIllII, long llllllllllllllllIIIllIlllllIlIll, boolean llllllllllllllllIIIlllIIIIIIIlII, int llllllllllllllllIIIlllIIIIIIlIIl) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof org/bukkit/entity/Player
    //   4: invokestatic llIIIllllll : (I)Z
    //   7: invokestatic lIIIllIllllII : (I)Z
    //   10: ifeq -> 23
    //   13: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   16: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   19: iconst_2
    //   20: iaload
    //   21: iaload
    //   22: ireturn
    //   23: aload_1
    //   24: checkcast org/bukkit/entity/Player
    //   27: astore #5
    //   29: aload_0
    //   30: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   33: invokevirtual getGameManager : ()Lcom/axeelheaven/hbedwars/GameManager;
    //   36: aload #5
    //   38: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   43: invokevirtual getData : (Ljava/util/UUID;)Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   46: astore #6
    //   48: aload_0
    //   49: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   52: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   55: aload #6
    //   57: invokevirtual getLanguage : ()Ljava/lang/String;
    //   60: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   63: astore #7
    //   65: aload #4
    //   67: arraylength
    //   68: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   71: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   74: iconst_2
    //   75: iaload
    //   76: iaload
    //   77: invokestatic llIIlIIIIII : (II)Z
    //   80: invokestatic lIIIllIllllII : (I)Z
    //   83: ifeq -> 118
    //   86: aload #7
    //   88: aload #5
    //   90: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_HELP : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   93: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   96: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   99: iconst_1
    //   100: iaload
    //   101: iaload
    //   102: anewarray java/lang/String
    //   105: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   108: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   111: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   114: iconst_2
    //   115: iaload
    //   116: iaload
    //   117: ireturn
    //   118: aload #4
    //   120: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   123: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   126: iconst_1
    //   127: iaload
    //   128: iaload
    //   129: aaload
    //   130: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   133: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   136: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   139: iconst_1
    //   140: iaload
    //   141: iaload
    //   142: aaload
    //   143: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   146: invokestatic llIIlIIIIIl : (I)Z
    //   149: invokestatic lIIIllIllllII : (I)Z
    //   152: ifeq -> 187
    //   155: aload #7
    //   157: aload #5
    //   159: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_HELP : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   162: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   165: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   168: iconst_1
    //   169: iaload
    //   170: iaload
    //   171: anewarray java/lang/String
    //   174: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   177: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   180: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   183: iconst_2
    //   184: iaload
    //   185: iaload
    //   186: ireturn
    //   187: aload #4
    //   189: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   192: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   195: iconst_1
    //   196: iaload
    //   197: iaload
    //   198: aaload
    //   199: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   202: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   205: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   208: iconst_2
    //   209: iaload
    //   210: iaload
    //   211: aaload
    //   212: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   215: invokestatic llIIlIIIIIl : (I)Z
    //   218: invokestatic lIIIllIllllII : (I)Z
    //   221: ifeq -> 1213
    //   224: aload #4
    //   226: arraylength
    //   227: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   230: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   233: iconst_3
    //   234: iaload
    //   235: iaload
    //   236: invokestatic llIIlIIIIII : (II)Z
    //   239: invokestatic lIIIllIllllII : (I)Z
    //   242: ifeq -> 314
    //   245: aload #5
    //   247: new java/lang/StringBuilder
    //   250: dup
    //   251: invokespecial <init> : ()V
    //   254: getstatic org/bukkit/ChatColor.RED : Lorg/bukkit/ChatColor;
    //   257: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   260: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   263: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   266: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   269: iconst_3
    //   270: iaload
    //   271: iaload
    //   272: aaload
    //   273: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   276: aload_3
    //   277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   280: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   283: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   286: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   289: iconst_4
    //   290: iaload
    //   291: iaload
    //   292: aaload
    //   293: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   296: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   299: invokeinterface sendMessage : (Ljava/lang/String;)V
    //   304: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   307: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   310: iconst_2
    //   311: iaload
    //   312: iaload
    //   313: ireturn
    //   314: aconst_null
    //   315: astore #8
    //   317: invokestatic getOnlinePlayers : ()Ljava/util/Collection;
    //   320: invokeinterface iterator : ()Ljava/util/Iterator;
    //   325: astore #9
    //   327: aload #9
    //   329: invokeinterface hasNext : ()Z
    //   334: invokestatic llIIlIIIIIl : (I)Z
    //   337: invokestatic lIIIllIllllII : (I)Z
    //   340: ifeq -> 561
    //   343: aload #9
    //   345: invokeinterface next : ()Ljava/lang/Object;
    //   350: checkcast org/bukkit/entity/Player
    //   353: astore #10
    //   355: aload #10
    //   357: invokeinterface getName : ()Ljava/lang/String;
    //   362: aload #4
    //   364: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   367: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   370: iconst_2
    //   371: iaload
    //   372: iaload
    //   373: aaload
    //   374: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   377: invokestatic llIIlIIIIIl : (I)Z
    //   380: invokestatic lIIIllIllllII : (I)Z
    //   383: ifeq -> 486
    //   386: aload #10
    //   388: astore #8
    //   390: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   393: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   396: bipush #102
    //   398: iaload
    //   399: aaload
    //   400: invokevirtual length : ()I
    //   403: ldc_w ''
    //   406: invokevirtual length : ()I
    //   409: pop2
    //   410: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   413: bipush #108
    //   415: iaload
    //   416: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   419: bipush #109
    //   421: iaload
    //   422: ixor
    //   423: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   426: bipush #21
    //   428: iaload
    //   429: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   432: bipush #14
    //   434: iaload
    //   435: ixor
    //   436: ixor
    //   437: invokestatic lIIIlllIIIlll : (I)Z
    //   440: ifeq -> 561
    //   443: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   446: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   449: bipush #110
    //   451: iaload
    //   452: aaload
    //   453: invokevirtual length : ()I
    //   456: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   459: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   462: bipush #76
    //   464: iaload
    //   465: aaload
    //   466: invokevirtual length : ()I
    //   469: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   472: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   475: bipush #111
    //   477: iaload
    //   478: aaload
    //   479: invokevirtual length : ()I
    //   482: ineg
    //   483: ixor
    //   484: iand
    //   485: ireturn
    //   486: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   489: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   492: bipush #93
    //   494: iaload
    //   495: aaload
    //   496: invokevirtual length : ()I
    //   499: ldc_w ''
    //   502: invokevirtual length : ()I
    //   505: pop2
    //   506: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   509: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   512: bipush #62
    //   514: iaload
    //   515: aaload
    //   516: invokevirtual length : ()I
    //   519: ineg
    //   520: invokestatic lIIIlllIIlIII : (I)Z
    //   523: ifeq -> 327
    //   526: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   529: bipush #31
    //   531: iaload
    //   532: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   535: bipush #34
    //   537: iaload
    //   538: ixor
    //   539: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   542: bipush #112
    //   544: iaload
    //   545: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   548: bipush #113
    //   550: iaload
    //   551: ixor
    //   552: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   555: bipush #65
    //   557: iaload
    //   558: ixor
    //   559: iand
    //   560: ireturn
    //   561: aload #8
    //   563: invokestatic llIIlIIIIlI : (Ljava/lang/Object;)Z
    //   566: invokestatic lIIIllIllllII : (I)Z
    //   569: ifeq -> 604
    //   572: aload #7
    //   574: aload #5
    //   576: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_NO_ONLINE : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   579: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   582: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   585: iconst_1
    //   586: iaload
    //   587: iaload
    //   588: anewarray java/lang/String
    //   591: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   594: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   597: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   600: iconst_2
    //   601: iaload
    //   602: iaload
    //   603: ireturn
    //   604: aload #5
    //   606: aload #8
    //   608: invokevirtual equals : (Ljava/lang/Object;)Z
    //   611: invokestatic llIIlIIIIIl : (I)Z
    //   614: invokestatic lIIIllIllllII : (I)Z
    //   617: ifeq -> 630
    //   620: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   623: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   626: iconst_2
    //   627: iaload
    //   628: iaload
    //   629: ireturn
    //   630: aload_0
    //   631: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   634: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   637: aload #8
    //   639: aload #5
    //   641: invokeinterface getName : ()Ljava/lang/String;
    //   646: invokevirtual hasInvitedFrom : (Lorg/bukkit/entity/Player;Ljava/lang/String;)Z
    //   649: invokestatic llIIlIIIIIl : (I)Z
    //   652: invokestatic lIIIllIllllII : (I)Z
    //   655: ifeq -> 727
    //   658: aload_0
    //   659: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   662: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   665: aload #8
    //   667: aload #5
    //   669: invokeinterface getName : ()Ljava/lang/String;
    //   674: invokevirtual getPartyInvited : (Lorg/bukkit/entity/Player;Ljava/lang/String;)Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   677: astore #9
    //   679: aload #9
    //   681: aload #8
    //   683: invokevirtual hasExpired : (Lorg/bukkit/entity/Player;)Z
    //   686: invokestatic llIIIllllll : (I)Z
    //   689: invokestatic lIIIllIllllII : (I)Z
    //   692: ifeq -> 727
    //   695: aload #7
    //   697: aload #5
    //   699: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_INVITE_ALREADY : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   702: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   705: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   708: iconst_1
    //   709: iaload
    //   710: iaload
    //   711: anewarray java/lang/String
    //   714: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   717: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   720: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   723: iconst_2
    //   724: iaload
    //   725: iaload
    //   726: ireturn
    //   727: aload_0
    //   728: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   731: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   734: aload #5
    //   736: invokevirtual hasParty : (Lorg/bukkit/entity/Player;)Z
    //   739: invokestatic llIIlIIIIIl : (I)Z
    //   742: invokestatic lIIIllIllllII : (I)Z
    //   745: ifeq -> 974
    //   748: aload_0
    //   749: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   752: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   755: aload #5
    //   757: invokevirtual getParty : (Lorg/bukkit/entity/Player;)Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   760: astore #9
    //   762: aload #9
    //   764: aload #5
    //   766: invokevirtual hasLeader : (Lorg/bukkit/entity/Player;)Z
    //   769: invokestatic llIIIllllll : (I)Z
    //   772: invokestatic lIIIllIllllII : (I)Z
    //   775: ifeq -> 810
    //   778: aload #7
    //   780: aload #5
    //   782: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_ONLY_LEADER : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   785: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   788: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   791: iconst_1
    //   792: iaload
    //   793: iaload
    //   794: anewarray java/lang/String
    //   797: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   800: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   803: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   806: iconst_2
    //   807: iaload
    //   808: iaload
    //   809: ireturn
    //   810: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   813: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   816: bipush #114
    //   818: iaload
    //   819: aaload
    //   820: invokevirtual length : ()I
    //   823: ldc_w ''
    //   826: invokevirtual length : ()I
    //   829: pop2
    //   830: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   833: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   836: bipush #115
    //   838: iaload
    //   839: aaload
    //   840: invokevirtual length : ()I
    //   843: ineg
    //   844: invokestatic lIIIlllIIlIIl : (I)Z
    //   847: ifeq -> 1008
    //   850: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   853: bipush #116
    //   855: iaload
    //   856: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   859: iconst_2
    //   860: iaload
    //   861: iadd
    //   862: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   865: bipush #24
    //   867: iaload
    //   868: isub
    //   869: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   872: bipush #54
    //   874: iaload
    //   875: iadd
    //   876: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   879: iconst_5
    //   880: iaload
    //   881: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   884: bipush #117
    //   886: iaload
    //   887: iadd
    //   888: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   891: bipush #118
    //   893: iaload
    //   894: isub
    //   895: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   898: bipush #52
    //   900: iaload
    //   901: iadd
    //   902: ixor
    //   903: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   906: bipush #119
    //   908: iaload
    //   909: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   912: bipush #54
    //   914: iaload
    //   915: iadd
    //   916: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   919: bipush #120
    //   921: iaload
    //   922: isub
    //   923: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   926: iconst_5
    //   927: iaload
    //   928: iadd
    //   929: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   932: bipush #117
    //   934: iaload
    //   935: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   938: bipush #52
    //   940: iaload
    //   941: iadd
    //   942: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   945: bipush #121
    //   947: iaload
    //   948: isub
    //   949: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   952: bipush #13
    //   954: iaload
    //   955: iadd
    //   956: ixor
    //   957: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   960: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   963: bipush #101
    //   965: iaload
    //   966: aaload
    //   967: invokevirtual length : ()I
    //   970: ineg
    //   971: ixor
    //   972: iand
    //   973: ireturn
    //   974: aload_0
    //   975: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   978: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   981: aload #5
    //   983: invokevirtual create : (Lorg/bukkit/entity/Player;)V
    //   986: aload #7
    //   988: aload #5
    //   990: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_CREATED : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   993: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   996: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   999: iconst_1
    //   1000: iaload
    //   1001: iaload
    //   1002: anewarray java/lang/String
    //   1005: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   1008: aload_0
    //   1009: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1012: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   1015: aload #5
    //   1017: invokevirtual getParty : (Lorg/bukkit/entity/Player;)Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   1020: astore #9
    //   1022: aload #9
    //   1024: aload #8
    //   1026: invokevirtual invite : (Lorg/bukkit/entity/Player;)V
    //   1029: aload #7
    //   1031: aload #5
    //   1033: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_INVITE_SENDER : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   1036: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1039: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1042: iconst_3
    //   1043: iaload
    //   1044: iaload
    //   1045: anewarray java/lang/String
    //   1048: dup
    //   1049: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1052: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1055: iconst_1
    //   1056: iaload
    //   1057: iaload
    //   1058: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   1061: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1064: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1067: iconst_5
    //   1068: iaload
    //   1069: iaload
    //   1070: aaload
    //   1071: aastore
    //   1072: dup
    //   1073: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1076: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1079: iconst_2
    //   1080: iaload
    //   1081: iaload
    //   1082: aload #8
    //   1084: invokeinterface getName : ()Ljava/lang/String;
    //   1089: aastore
    //   1090: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   1093: aload_0
    //   1094: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1097: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   1100: aload_0
    //   1101: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1104: invokevirtual getGameManager : ()Lcom/axeelheaven/hbedwars/GameManager;
    //   1107: aload #8
    //   1109: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   1114: invokevirtual getData : (Ljava/util/UUID;)Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   1117: invokevirtual getLanguage : ()Ljava/lang/String;
    //   1120: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   1123: aload #8
    //   1125: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_INVITE_INVITED : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   1128: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1131: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1134: iconst_3
    //   1135: iaload
    //   1136: iaload
    //   1137: anewarray java/lang/String
    //   1140: dup
    //   1141: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1144: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1147: iconst_1
    //   1148: iaload
    //   1149: iaload
    //   1150: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   1153: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1156: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1159: bipush #6
    //   1161: iaload
    //   1162: iaload
    //   1163: aaload
    //   1164: aastore
    //   1165: dup
    //   1166: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1169: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1172: iconst_2
    //   1173: iaload
    //   1174: iaload
    //   1175: aload #9
    //   1177: invokevirtual getName : ()Ljava/lang/String;
    //   1180: aastore
    //   1181: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   1184: invokestatic getPluginManager : ()Lorg/bukkit/plugin/PluginManager;
    //   1187: new com/axeelheaven/hbedwars/api/events/party/BedWarsPartyInviteEvent
    //   1190: dup
    //   1191: aload #8
    //   1193: aload #9
    //   1195: invokespecial <init> : (Lorg/bukkit/entity/Player;Lcom/axeelheaven/hbedwars/custom/party/Party;)V
    //   1198: invokeinterface callEvent : (Lorg/bukkit/event/Event;)V
    //   1203: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1206: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1209: iconst_2
    //   1210: iaload
    //   1211: iaload
    //   1212: ireturn
    //   1213: aload #4
    //   1215: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1218: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1221: iconst_1
    //   1222: iaload
    //   1223: iaload
    //   1224: aaload
    //   1225: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   1228: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1231: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1234: bipush #7
    //   1236: iaload
    //   1237: iaload
    //   1238: aaload
    //   1239: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1242: invokestatic llIIlIIIIIl : (I)Z
    //   1245: invokestatic lIIIllIllllII : (I)Z
    //   1248: ifeq -> 1583
    //   1251: aload_0
    //   1252: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1255: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   1258: aload #5
    //   1260: invokevirtual hasParty : (Lorg/bukkit/entity/Player;)Z
    //   1263: invokestatic llIIIllllll : (I)Z
    //   1266: invokestatic lIIIllIllllII : (I)Z
    //   1269: ifeq -> 1304
    //   1272: aload #7
    //   1274: aload #5
    //   1276: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_NOT_IN_PARTY : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   1279: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1282: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1285: iconst_1
    //   1286: iaload
    //   1287: iaload
    //   1288: anewarray java/lang/String
    //   1291: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   1294: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1297: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1300: iconst_2
    //   1301: iaload
    //   1302: iaload
    //   1303: ireturn
    //   1304: aload_0
    //   1305: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1308: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   1311: aload #5
    //   1313: invokevirtual getParty : (Lorg/bukkit/entity/Player;)Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   1316: astore #8
    //   1318: aload #8
    //   1320: aload #5
    //   1322: invokevirtual hasLeader : (Lorg/bukkit/entity/Player;)Z
    //   1325: invokestatic llIIlIIIIIl : (I)Z
    //   1328: invokestatic lIIIllIllllII : (I)Z
    //   1331: ifeq -> 1505
    //   1334: aload #5
    //   1336: new java/lang/StringBuilder
    //   1339: dup
    //   1340: invokespecial <init> : ()V
    //   1343: getstatic org/bukkit/ChatColor.RED : Lorg/bukkit/ChatColor;
    //   1346: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1349: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   1352: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1355: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1358: bipush #8
    //   1360: iaload
    //   1361: iaload
    //   1362: aaload
    //   1363: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1366: aload_3
    //   1367: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1370: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   1373: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1376: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1379: bipush #9
    //   1381: iaload
    //   1382: iaload
    //   1383: aaload
    //   1384: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1387: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   1390: invokeinterface sendMessage : (Ljava/lang/String;)V
    //   1395: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   1398: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1401: bipush #78
    //   1403: iaload
    //   1404: aaload
    //   1405: invokevirtual length : ()I
    //   1408: ldc_w ''
    //   1411: invokevirtual length : ()I
    //   1414: pop2
    //   1415: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1418: bipush #122
    //   1420: iaload
    //   1421: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1424: bipush #123
    //   1426: iaload
    //   1427: ixor
    //   1428: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1431: bipush #124
    //   1433: iaload
    //   1434: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1437: bipush #125
    //   1439: iaload
    //   1440: ixor
    //   1441: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1444: bipush #65
    //   1446: iaload
    //   1447: ixor
    //   1448: iand
    //   1449: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   1452: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1455: bipush #126
    //   1457: iaload
    //   1458: aaload
    //   1459: invokevirtual length : ()I
    //   1462: ineg
    //   1463: invokestatic lIIIlllIIIIlI : (II)Z
    //   1466: ifeq -> 1573
    //   1469: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1472: bipush #127
    //   1474: iaload
    //   1475: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1478: bipush #48
    //   1480: iaload
    //   1481: ixor
    //   1482: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1485: sipush #128
    //   1488: iaload
    //   1489: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1492: bipush #112
    //   1494: iaload
    //   1495: ixor
    //   1496: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1499: bipush #65
    //   1501: iaload
    //   1502: ixor
    //   1503: iand
    //   1504: ireturn
    //   1505: aload #8
    //   1507: invokevirtual getPlayers : ()Ljava/util/List;
    //   1510: aload_0
    //   1511: aload #5
    //   1513: <illegal opcode> accept : (Lcom/axeelheaven/hbedwars/commands/PartyCommand;Lorg/bukkit/entity/Player;)Ljava/util/function/Consumer;
    //   1518: invokeinterface forEach : (Ljava/util/function/Consumer;)V
    //   1523: aload #8
    //   1525: invokevirtual getPlayers : ()Ljava/util/List;
    //   1528: aload #5
    //   1530: invokeinterface getName : ()Ljava/lang/String;
    //   1535: invokeinterface remove : (Ljava/lang/Object;)Z
    //   1540: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   1543: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1546: bipush #90
    //   1548: iaload
    //   1549: aaload
    //   1550: invokevirtual length : ()I
    //   1553: pop2
    //   1554: invokestatic getPluginManager : ()Lorg/bukkit/plugin/PluginManager;
    //   1557: new com/axeelheaven/hbedwars/api/events/party/BedWarsPartyLeaveEvent
    //   1560: dup
    //   1561: aload #5
    //   1563: aload #8
    //   1565: invokespecial <init> : (Lorg/bukkit/entity/Player;Lcom/axeelheaven/hbedwars/custom/party/Party;)V
    //   1568: invokeinterface callEvent : (Lorg/bukkit/event/Event;)V
    //   1573: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1576: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1579: iconst_2
    //   1580: iaload
    //   1581: iaload
    //   1582: ireturn
    //   1583: aload #4
    //   1585: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1588: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1591: iconst_1
    //   1592: iaload
    //   1593: iaload
    //   1594: aaload
    //   1595: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   1598: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1601: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1604: bipush #10
    //   1606: iaload
    //   1607: iaload
    //   1608: aaload
    //   1609: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1612: invokestatic llIIlIIIIIl : (I)Z
    //   1615: invokestatic lIIIllIllllII : (I)Z
    //   1618: ifeq -> 2651
    //   1621: aload #4
    //   1623: arraylength
    //   1624: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1627: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1630: iconst_3
    //   1631: iaload
    //   1632: iaload
    //   1633: invokestatic llIIlIIIIII : (II)Z
    //   1636: invokestatic lIIIllIllllII : (I)Z
    //   1639: ifeq -> 1713
    //   1642: aload #5
    //   1644: new java/lang/StringBuilder
    //   1647: dup
    //   1648: invokespecial <init> : ()V
    //   1651: getstatic org/bukkit/ChatColor.RED : Lorg/bukkit/ChatColor;
    //   1654: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1657: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   1660: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1663: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1666: bipush #11
    //   1668: iaload
    //   1669: iaload
    //   1670: aaload
    //   1671: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1674: aload_3
    //   1675: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1678: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   1681: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1684: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1687: bipush #12
    //   1689: iaload
    //   1690: iaload
    //   1691: aaload
    //   1692: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1695: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   1698: invokeinterface sendMessage : (Ljava/lang/String;)V
    //   1703: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1706: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1709: iconst_2
    //   1710: iaload
    //   1711: iaload
    //   1712: ireturn
    //   1713: aload_0
    //   1714: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1717: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   1720: aload #5
    //   1722: invokevirtual hasParty : (Lorg/bukkit/entity/Player;)Z
    //   1725: invokestatic llIIIllllll : (I)Z
    //   1728: invokestatic lIIIllIllllII : (I)Z
    //   1731: ifeq -> 1766
    //   1734: aload #7
    //   1736: aload #5
    //   1738: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_NOT_IN_PARTY : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   1741: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1744: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1747: iconst_1
    //   1748: iaload
    //   1749: iaload
    //   1750: anewarray java/lang/String
    //   1753: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   1756: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1759: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1762: iconst_2
    //   1763: iaload
    //   1764: iaload
    //   1765: ireturn
    //   1766: aload_0
    //   1767: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1770: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   1773: aload #5
    //   1775: invokevirtual getParty : (Lorg/bukkit/entity/Player;)Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   1778: astore #8
    //   1780: aload #8
    //   1782: aload #5
    //   1784: invokevirtual hasLeader : (Lorg/bukkit/entity/Player;)Z
    //   1787: invokestatic llIIIllllll : (I)Z
    //   1790: invokestatic lIIIllIllllII : (I)Z
    //   1793: ifeq -> 1828
    //   1796: aload #7
    //   1798: aload #5
    //   1800: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_ONLY_LEADER : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   1803: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1806: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1809: iconst_1
    //   1810: iaload
    //   1811: iaload
    //   1812: anewarray java/lang/String
    //   1815: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   1818: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1821: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1824: iconst_2
    //   1825: iaload
    //   1826: iaload
    //   1827: ireturn
    //   1828: aload #5
    //   1830: invokeinterface getName : ()Ljava/lang/String;
    //   1835: aload #4
    //   1837: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1840: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1843: iconst_2
    //   1844: iaload
    //   1845: iaload
    //   1846: aaload
    //   1847: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1850: invokestatic llIIlIIIIIl : (I)Z
    //   1853: invokestatic lIIIllIllllII : (I)Z
    //   1856: ifeq -> 1869
    //   1859: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1862: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1865: iconst_2
    //   1866: iaload
    //   1867: iaload
    //   1868: ireturn
    //   1869: aconst_null
    //   1870: astore #9
    //   1872: invokestatic getOnlinePlayers : ()Ljava/util/Collection;
    //   1875: invokeinterface iterator : ()Ljava/util/Iterator;
    //   1880: astore #10
    //   1882: aload #10
    //   1884: invokeinterface hasNext : ()Z
    //   1889: invokestatic llIIlIIIIIl : (I)Z
    //   1892: invokestatic lIIIllIllllII : (I)Z
    //   1895: ifeq -> 2297
    //   1898: aload #10
    //   1900: invokeinterface next : ()Ljava/lang/Object;
    //   1905: checkcast org/bukkit/entity/Player
    //   1908: astore #11
    //   1910: aload #11
    //   1912: invokeinterface getName : ()Ljava/lang/String;
    //   1917: aload #4
    //   1919: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   1922: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1925: iconst_2
    //   1926: iaload
    //   1927: iaload
    //   1928: aaload
    //   1929: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1932: invokestatic llIIlIIIIIl : (I)Z
    //   1935: invokestatic lIIIllIllllII : (I)Z
    //   1938: ifeq -> 2049
    //   1941: aload #11
    //   1943: astore #9
    //   1945: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   1948: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1951: bipush #119
    //   1953: iaload
    //   1954: aaload
    //   1955: invokevirtual length : ()I
    //   1958: ldc_w ''
    //   1961: invokevirtual length : ()I
    //   1964: pop2
    //   1965: aconst_null
    //   1966: invokestatic lIIIlllIIlIll : (Ljava/lang/Object;)Z
    //   1969: ifeq -> 2297
    //   1972: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1975: sipush #129
    //   1978: iaload
    //   1979: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1982: sipush #130
    //   1985: iaload
    //   1986: ixor
    //   1987: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1990: sipush #131
    //   1993: iaload
    //   1994: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   1997: bipush #107
    //   1999: iaload
    //   2000: ixor
    //   2001: ixor
    //   2002: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2005: sipush #132
    //   2008: iaload
    //   2009: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2012: sipush #133
    //   2015: iaload
    //   2016: ixor
    //   2017: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2020: bipush #18
    //   2022: iaload
    //   2023: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2026: sipush #134
    //   2029: iaload
    //   2030: ixor
    //   2031: ixor
    //   2032: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   2035: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2038: bipush #77
    //   2040: iaload
    //   2041: aaload
    //   2042: invokevirtual length : ()I
    //   2045: ineg
    //   2046: ixor
    //   2047: iand
    //   2048: ireturn
    //   2049: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   2052: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2055: sipush #135
    //   2058: iaload
    //   2059: aaload
    //   2060: invokevirtual length : ()I
    //   2063: ldc_w ''
    //   2066: invokevirtual length : ()I
    //   2069: pop2
    //   2070: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   2073: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2076: sipush #136
    //   2079: iaload
    //   2080: aaload
    //   2081: invokevirtual length : ()I
    //   2084: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2087: bipush #36
    //   2089: iaload
    //   2090: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2093: sipush #137
    //   2096: iaload
    //   2097: iadd
    //   2098: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2101: sipush #138
    //   2104: iaload
    //   2105: isub
    //   2106: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2109: bipush #71
    //   2111: iaload
    //   2112: iadd
    //   2113: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2116: bipush #45
    //   2118: iaload
    //   2119: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2122: bipush #38
    //   2124: iaload
    //   2125: iadd
    //   2126: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2129: bipush #78
    //   2131: iaload
    //   2132: isub
    //   2133: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2136: bipush #69
    //   2138: iaload
    //   2139: iadd
    //   2140: ixor
    //   2141: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2144: sipush #139
    //   2147: iaload
    //   2148: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2151: sipush #140
    //   2154: iaload
    //   2155: ixor
    //   2156: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2159: bipush #89
    //   2161: iaload
    //   2162: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2165: sipush #141
    //   2168: iaload
    //   2169: ixor
    //   2170: ixor
    //   2171: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   2174: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2177: sipush #142
    //   2180: iaload
    //   2181: aaload
    //   2182: invokevirtual length : ()I
    //   2185: ineg
    //   2186: ixor
    //   2187: iand
    //   2188: invokestatic lIIIlllIIllII : (II)Z
    //   2191: ifeq -> 1882
    //   2194: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2197: bipush #64
    //   2199: iaload
    //   2200: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2203: bipush #89
    //   2205: iaload
    //   2206: ixor
    //   2207: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2210: sipush #143
    //   2213: iaload
    //   2214: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2217: bipush #64
    //   2219: iaload
    //   2220: ixor
    //   2221: ixor
    //   2222: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2225: bipush #70
    //   2227: iaload
    //   2228: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2231: sipush #144
    //   2234: iaload
    //   2235: iadd
    //   2236: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2239: sipush #145
    //   2242: iaload
    //   2243: isub
    //   2244: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2247: bipush #19
    //   2249: iaload
    //   2250: iadd
    //   2251: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2254: bipush #21
    //   2256: iaload
    //   2257: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2260: bipush #100
    //   2262: iaload
    //   2263: iadd
    //   2264: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2267: bipush #66
    //   2269: iaload
    //   2270: isub
    //   2271: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2274: sipush #146
    //   2277: iaload
    //   2278: iadd
    //   2279: ixor
    //   2280: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   2283: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2286: bipush #91
    //   2288: iaload
    //   2289: aaload
    //   2290: invokevirtual length : ()I
    //   2293: ineg
    //   2294: ixor
    //   2295: iand
    //   2296: ireturn
    //   2297: aload #9
    //   2299: invokestatic llIIlIIIIlI : (Ljava/lang/Object;)Z
    //   2302: invokestatic lIIIllIllllII : (I)Z
    //   2305: ifeq -> 2340
    //   2308: aload #7
    //   2310: aload #5
    //   2312: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_NO_ONLINE : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   2315: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2318: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2321: iconst_1
    //   2322: iaload
    //   2323: iaload
    //   2324: anewarray java/lang/String
    //   2327: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   2330: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2333: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2336: iconst_2
    //   2337: iaload
    //   2338: iaload
    //   2339: ireturn
    //   2340: aload #8
    //   2342: invokevirtual getPlayers : ()Ljava/util/List;
    //   2345: aload #9
    //   2347: invokeinterface getName : ()Ljava/lang/String;
    //   2352: invokeinterface contains : (Ljava/lang/Object;)Z
    //   2357: invokestatic llIIIllllll : (I)Z
    //   2360: invokestatic lIIIllIllllII : (I)Z
    //   2363: ifeq -> 2398
    //   2366: aload #7
    //   2368: aload #5
    //   2370: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_PROMOTE_NO_IN_PARTY : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   2373: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2376: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2379: iconst_1
    //   2380: iaload
    //   2381: iaload
    //   2382: anewarray java/lang/String
    //   2385: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   2388: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2391: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2394: iconst_2
    //   2395: iaload
    //   2396: iaload
    //   2397: ireturn
    //   2398: aload_0
    //   2399: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2402: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   2405: invokevirtual getParties : ()Ljava/util/HashMap;
    //   2408: aload #5
    //   2410: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   2415: new com/axeelheaven/hbedwars/custom/party/Party
    //   2418: dup
    //   2419: aload_0
    //   2420: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2423: aload #9
    //   2425: invokeinterface getName : ()Ljava/lang/String;
    //   2430: invokespecial <init> : (Lcom/axeelheaven/hbedwars/BedWars;Ljava/lang/String;)V
    //   2433: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2436: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   2439: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2442: sipush #134
    //   2445: iaload
    //   2446: aaload
    //   2447: invokevirtual length : ()I
    //   2450: pop2
    //   2451: aload_0
    //   2452: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2455: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   2458: aload #9
    //   2460: invokevirtual getParty : (Lorg/bukkit/entity/Player;)Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   2463: invokevirtual getPlayers : ()Ljava/util/List;
    //   2466: aload #8
    //   2468: invokevirtual getPlayers : ()Ljava/util/List;
    //   2471: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   2476: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   2479: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2482: sipush #147
    //   2485: iaload
    //   2486: aaload
    //   2487: invokevirtual length : ()I
    //   2490: pop2
    //   2491: aload_0
    //   2492: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2495: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   2498: aload #9
    //   2500: invokevirtual getParty : (Lorg/bukkit/entity/Player;)Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   2503: invokevirtual getInvite : ()Ljava/util/HashMap;
    //   2506: aload #8
    //   2508: invokevirtual getInvite : ()Ljava/util/HashMap;
    //   2511: invokevirtual putAll : (Ljava/util/Map;)V
    //   2514: aload_0
    //   2515: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2518: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   2521: aload #5
    //   2523: invokevirtual delete : (Lorg/bukkit/entity/Player;)V
    //   2526: aload #7
    //   2528: aload #5
    //   2530: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_PROMOTE_SENDER : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   2533: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2536: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2539: iconst_3
    //   2540: iaload
    //   2541: iaload
    //   2542: anewarray java/lang/String
    //   2545: dup
    //   2546: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2549: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2552: iconst_1
    //   2553: iaload
    //   2554: iaload
    //   2555: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   2558: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2561: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2564: bipush #13
    //   2566: iaload
    //   2567: iaload
    //   2568: aaload
    //   2569: aastore
    //   2570: dup
    //   2571: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2574: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2577: iconst_2
    //   2578: iaload
    //   2579: iaload
    //   2580: aload #9
    //   2582: invokeinterface getName : ()Ljava/lang/String;
    //   2587: aastore
    //   2588: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   2591: aload_0
    //   2592: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2595: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   2598: aload_0
    //   2599: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2602: invokevirtual getGameManager : ()Lcom/axeelheaven/hbedwars/GameManager;
    //   2605: aload #9
    //   2607: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   2612: invokevirtual getData : (Ljava/util/UUID;)Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   2615: invokevirtual getLanguage : ()Ljava/lang/String;
    //   2618: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   2621: aload #9
    //   2623: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_PROMOTE_PROMOTED : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   2626: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2629: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2632: iconst_1
    //   2633: iaload
    //   2634: iaload
    //   2635: anewarray java/lang/String
    //   2638: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   2641: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2644: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2647: iconst_2
    //   2648: iaload
    //   2649: iaload
    //   2650: ireturn
    //   2651: aload #4
    //   2653: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2656: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2659: iconst_1
    //   2660: iaload
    //   2661: iaload
    //   2662: aaload
    //   2663: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   2666: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2669: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2672: bipush #14
    //   2674: iaload
    //   2675: iaload
    //   2676: aaload
    //   2677: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   2680: invokestatic llIIlIIIIIl : (I)Z
    //   2683: invokestatic lIIIllIllllII : (I)Z
    //   2686: ifeq -> 3559
    //   2689: aload #4
    //   2691: arraylength
    //   2692: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2695: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2698: iconst_3
    //   2699: iaload
    //   2700: iaload
    //   2701: invokestatic llIIlIIIIII : (II)Z
    //   2704: invokestatic lIIIllIllllII : (I)Z
    //   2707: ifeq -> 2781
    //   2710: aload #5
    //   2712: new java/lang/StringBuilder
    //   2715: dup
    //   2716: invokespecial <init> : ()V
    //   2719: getstatic org/bukkit/ChatColor.RED : Lorg/bukkit/ChatColor;
    //   2722: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2725: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   2728: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2731: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2734: bipush #15
    //   2736: iaload
    //   2737: iaload
    //   2738: aaload
    //   2739: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2742: aload_3
    //   2743: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2746: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   2749: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2752: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2755: bipush #16
    //   2757: iaload
    //   2758: iaload
    //   2759: aaload
    //   2760: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2763: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   2766: invokeinterface sendMessage : (Ljava/lang/String;)V
    //   2771: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2774: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2777: iconst_2
    //   2778: iaload
    //   2779: iaload
    //   2780: ireturn
    //   2781: aload_0
    //   2782: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2785: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   2788: aload #5
    //   2790: invokevirtual hasParty : (Lorg/bukkit/entity/Player;)Z
    //   2793: invokestatic llIIIllllll : (I)Z
    //   2796: invokestatic lIIIllIllllII : (I)Z
    //   2799: ifeq -> 2834
    //   2802: aload #7
    //   2804: aload #5
    //   2806: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_NOT_IN_PARTY : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   2809: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2812: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2815: iconst_1
    //   2816: iaload
    //   2817: iaload
    //   2818: anewarray java/lang/String
    //   2821: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   2824: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2827: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2830: iconst_2
    //   2831: iaload
    //   2832: iaload
    //   2833: ireturn
    //   2834: aload_0
    //   2835: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2838: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   2841: aload #5
    //   2843: invokevirtual getParty : (Lorg/bukkit/entity/Player;)Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   2846: astore #8
    //   2848: aload #8
    //   2850: aload #5
    //   2852: invokevirtual hasLeader : (Lorg/bukkit/entity/Player;)Z
    //   2855: invokestatic llIIIllllll : (I)Z
    //   2858: invokestatic lIIIllIllllII : (I)Z
    //   2861: ifeq -> 2896
    //   2864: aload #7
    //   2866: aload #5
    //   2868: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_ONLY_LEADER : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   2871: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2874: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2877: iconst_1
    //   2878: iaload
    //   2879: iaload
    //   2880: anewarray java/lang/String
    //   2883: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   2886: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2889: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2892: iconst_2
    //   2893: iaload
    //   2894: iaload
    //   2895: ireturn
    //   2896: aload #5
    //   2898: invokeinterface getName : ()Ljava/lang/String;
    //   2903: aload #4
    //   2905: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2908: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2911: iconst_2
    //   2912: iaload
    //   2913: iaload
    //   2914: aaload
    //   2915: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   2918: invokestatic llIIlIIIIIl : (I)Z
    //   2921: invokestatic lIIIllIllllII : (I)Z
    //   2924: ifeq -> 2937
    //   2927: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2930: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2933: iconst_2
    //   2934: iaload
    //   2935: iaload
    //   2936: ireturn
    //   2937: aconst_null
    //   2938: astore #9
    //   2940: invokestatic getOnlinePlayers : ()Ljava/util/Collection;
    //   2943: invokeinterface iterator : ()Ljava/util/Iterator;
    //   2948: astore #10
    //   2950: aload #10
    //   2952: invokeinterface hasNext : ()Z
    //   2957: invokestatic llIIlIIIIIl : (I)Z
    //   2960: invokestatic lIIIllIllllII : (I)Z
    //   2963: ifeq -> 3359
    //   2966: aload #10
    //   2968: invokeinterface next : ()Ljava/lang/Object;
    //   2973: checkcast org/bukkit/entity/Player
    //   2976: astore #11
    //   2978: aload #11
    //   2980: invokeinterface getName : ()Ljava/lang/String;
    //   2985: aload #4
    //   2987: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   2990: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   2993: iconst_2
    //   2994: iaload
    //   2995: iaload
    //   2996: aaload
    //   2997: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   3000: invokestatic llIIlIIIIIl : (I)Z
    //   3003: invokestatic lIIIllIllllII : (I)Z
    //   3006: ifeq -> 3260
    //   3009: aload #11
    //   3011: astore #9
    //   3013: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   3016: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3019: sipush #148
    //   3022: iaload
    //   3023: aaload
    //   3024: invokevirtual length : ()I
    //   3027: ldc_w ''
    //   3030: invokevirtual length : ()I
    //   3033: pop2
    //   3034: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   3037: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3040: bipush #100
    //   3042: iaload
    //   3043: aaload
    //   3044: invokevirtual length : ()I
    //   3047: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3050: sipush #149
    //   3053: iaload
    //   3054: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3057: sipush #150
    //   3060: iaload
    //   3061: ixor
    //   3062: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3065: sipush #151
    //   3068: iaload
    //   3069: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3072: bipush #67
    //   3074: iaload
    //   3075: ixor
    //   3076: ixor
    //   3077: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3080: bipush #29
    //   3082: iaload
    //   3083: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3086: bipush #83
    //   3088: iaload
    //   3089: iadd
    //   3090: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3093: sipush #152
    //   3096: iaload
    //   3097: isub
    //   3098: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3101: sipush #153
    //   3104: iaload
    //   3105: iadd
    //   3106: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3109: sipush #136
    //   3112: iaload
    //   3113: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3116: sipush #153
    //   3119: iaload
    //   3120: iadd
    //   3121: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3124: bipush #38
    //   3126: iaload
    //   3127: isub
    //   3128: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3131: iconst_4
    //   3132: iaload
    //   3133: iadd
    //   3134: ixor
    //   3135: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   3138: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3141: bipush #103
    //   3143: iaload
    //   3144: aaload
    //   3145: invokevirtual length : ()I
    //   3148: ineg
    //   3149: ixor
    //   3150: iand
    //   3151: invokestatic lIIIlllIIllIl : (II)Z
    //   3154: ifeq -> 3359
    //   3157: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3160: bipush #70
    //   3162: iaload
    //   3163: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3166: bipush #25
    //   3168: iaload
    //   3169: iadd
    //   3170: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3173: sipush #147
    //   3176: iaload
    //   3177: isub
    //   3178: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3181: bipush #96
    //   3183: iaload
    //   3184: iadd
    //   3185: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3188: bipush #55
    //   3190: iaload
    //   3191: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3194: bipush #35
    //   3196: iaload
    //   3197: iadd
    //   3198: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3201: sipush #154
    //   3204: iaload
    //   3205: isub
    //   3206: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3209: iconst_2
    //   3210: iaload
    //   3211: iadd
    //   3212: ixor
    //   3213: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3216: bipush #82
    //   3218: iaload
    //   3219: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3222: sipush #155
    //   3225: iaload
    //   3226: ixor
    //   3227: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3230: bipush #50
    //   3232: iaload
    //   3233: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3236: sipush #136
    //   3239: iaload
    //   3240: ixor
    //   3241: ixor
    //   3242: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   3245: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3248: sipush #156
    //   3251: iaload
    //   3252: aaload
    //   3253: invokevirtual length : ()I
    //   3256: ineg
    //   3257: ixor
    //   3258: iand
    //   3259: ireturn
    //   3260: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   3263: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3266: bipush #92
    //   3268: iaload
    //   3269: aaload
    //   3270: invokevirtual length : ()I
    //   3273: ldc_w ''
    //   3276: invokevirtual length : ()I
    //   3279: pop2
    //   3280: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3283: bipush #111
    //   3285: iaload
    //   3286: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3289: bipush #109
    //   3291: iaload
    //   3292: ixor
    //   3293: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3296: sipush #157
    //   3299: iaload
    //   3300: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3303: sipush #158
    //   3306: iaload
    //   3307: ixor
    //   3308: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3311: bipush #65
    //   3313: iaload
    //   3314: ixor
    //   3315: iand
    //   3316: invokestatic lIIIllIllllII : (I)Z
    //   3319: ifeq -> 2950
    //   3322: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3325: bipush #82
    //   3327: iaload
    //   3328: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3331: sipush #139
    //   3334: iaload
    //   3335: ixor
    //   3336: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3339: sipush #159
    //   3342: iaload
    //   3343: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3346: bipush #116
    //   3348: iaload
    //   3349: ixor
    //   3350: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3353: bipush #65
    //   3355: iaload
    //   3356: ixor
    //   3357: iand
    //   3358: ireturn
    //   3359: aload #9
    //   3361: invokestatic llIIlIIIIlI : (Ljava/lang/Object;)Z
    //   3364: invokestatic lIIIllIllllII : (I)Z
    //   3367: ifeq -> 3402
    //   3370: aload #7
    //   3372: aload #5
    //   3374: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_NO_ONLINE : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   3377: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3380: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3383: iconst_1
    //   3384: iaload
    //   3385: iaload
    //   3386: anewarray java/lang/String
    //   3389: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   3392: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3395: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3398: iconst_2
    //   3399: iaload
    //   3400: iaload
    //   3401: ireturn
    //   3402: aload #8
    //   3404: invokevirtual getPlayers : ()Ljava/util/List;
    //   3407: aload #9
    //   3409: invokeinterface getName : ()Ljava/lang/String;
    //   3414: invokeinterface remove : (Ljava/lang/Object;)Z
    //   3419: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   3422: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3425: sipush #160
    //   3428: iaload
    //   3429: aaload
    //   3430: invokevirtual length : ()I
    //   3433: pop2
    //   3434: aload #7
    //   3436: aload #5
    //   3438: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_LEAVE_SENDER : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   3441: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3444: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3447: iconst_3
    //   3448: iaload
    //   3449: iaload
    //   3450: anewarray java/lang/String
    //   3453: dup
    //   3454: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3457: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3460: iconst_1
    //   3461: iaload
    //   3462: iaload
    //   3463: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   3466: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3469: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3472: bipush #17
    //   3474: iaload
    //   3475: iaload
    //   3476: aaload
    //   3477: aastore
    //   3478: dup
    //   3479: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3482: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3485: iconst_2
    //   3486: iaload
    //   3487: iaload
    //   3488: aload #9
    //   3490: invokeinterface getName : ()Ljava/lang/String;
    //   3495: aastore
    //   3496: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   3499: aload_0
    //   3500: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3503: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   3506: aload_0
    //   3507: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3510: invokevirtual getGameManager : ()Lcom/axeelheaven/hbedwars/GameManager;
    //   3513: aload #9
    //   3515: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   3520: invokevirtual getData : (Ljava/util/UUID;)Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   3523: invokevirtual getLanguage : ()Ljava/lang/String;
    //   3526: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   3529: aload #9
    //   3531: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_LEAVE_REMOVED : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   3534: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3537: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3540: iconst_1
    //   3541: iaload
    //   3542: iaload
    //   3543: anewarray java/lang/String
    //   3546: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   3549: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3552: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3555: iconst_2
    //   3556: iaload
    //   3557: iaload
    //   3558: ireturn
    //   3559: aload #4
    //   3561: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3564: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3567: iconst_1
    //   3568: iaload
    //   3569: iaload
    //   3570: aaload
    //   3571: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   3574: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3577: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3580: bipush #18
    //   3582: iaload
    //   3583: iaload
    //   3584: aaload
    //   3585: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   3588: invokestatic llIIlIIIIIl : (I)Z
    //   3591: invokestatic lIIIllIllllII : (I)Z
    //   3594: ifeq -> 3916
    //   3597: aload #4
    //   3599: arraylength
    //   3600: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3603: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3606: iconst_3
    //   3607: iaload
    //   3608: iaload
    //   3609: invokestatic llIIlIIIIII : (II)Z
    //   3612: invokestatic lIIIllIllllII : (I)Z
    //   3615: ifeq -> 3689
    //   3618: aload #5
    //   3620: new java/lang/StringBuilder
    //   3623: dup
    //   3624: invokespecial <init> : ()V
    //   3627: getstatic org/bukkit/ChatColor.RED : Lorg/bukkit/ChatColor;
    //   3630: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   3633: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   3636: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3639: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3642: bipush #19
    //   3644: iaload
    //   3645: iaload
    //   3646: aaload
    //   3647: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3650: aload_3
    //   3651: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3654: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   3657: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3660: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3663: bipush #20
    //   3665: iaload
    //   3666: iaload
    //   3667: aaload
    //   3668: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3671: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   3674: invokeinterface sendMessage : (Ljava/lang/String;)V
    //   3679: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3682: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3685: iconst_2
    //   3686: iaload
    //   3687: iaload
    //   3688: ireturn
    //   3689: aload_0
    //   3690: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3693: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   3696: aload #5
    //   3698: aload #4
    //   3700: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3703: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3706: iconst_2
    //   3707: iaload
    //   3708: iaload
    //   3709: aaload
    //   3710: invokevirtual hasInvitedFrom : (Lorg/bukkit/entity/Player;Ljava/lang/String;)Z
    //   3713: invokestatic llIIIllllll : (I)Z
    //   3716: invokestatic lIIIllIllllII : (I)Z
    //   3719: ifeq -> 3754
    //   3722: aload #7
    //   3724: aload #5
    //   3726: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_INVITE_NO_INVITATION : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   3729: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3732: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3735: iconst_1
    //   3736: iaload
    //   3737: iaload
    //   3738: anewarray java/lang/String
    //   3741: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   3744: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3747: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3750: iconst_2
    //   3751: iaload
    //   3752: iaload
    //   3753: ireturn
    //   3754: aload_0
    //   3755: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3758: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   3761: aload #5
    //   3763: aload #4
    //   3765: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3768: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3771: iconst_2
    //   3772: iaload
    //   3773: iaload
    //   3774: aaload
    //   3775: invokevirtual getPartyInvited : (Lorg/bukkit/entity/Player;Ljava/lang/String;)Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   3778: astore #8
    //   3780: aload #8
    //   3782: aload #5
    //   3784: invokevirtual hasExpired : (Lorg/bukkit/entity/Player;)Z
    //   3787: invokestatic llIIlIIIIIl : (I)Z
    //   3790: invokestatic lIIIllIllllII : (I)Z
    //   3793: ifeq -> 3828
    //   3796: aload #7
    //   3798: aload #5
    //   3800: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_INVITE_EXPIRED : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   3803: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3806: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3809: iconst_1
    //   3810: iaload
    //   3811: iaload
    //   3812: anewarray java/lang/String
    //   3815: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   3818: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3821: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3824: iconst_2
    //   3825: iaload
    //   3826: iaload
    //   3827: ireturn
    //   3828: aload #8
    //   3830: invokevirtual getInvite : ()Ljava/util/HashMap;
    //   3833: aload #5
    //   3835: invokeinterface getName : ()Ljava/lang/String;
    //   3840: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   3843: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   3846: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3849: bipush #85
    //   3851: iaload
    //   3852: aaload
    //   3853: invokevirtual length : ()I
    //   3856: pop2
    //   3857: aload #8
    //   3859: invokevirtual getPlayers : ()Ljava/util/List;
    //   3862: aload #5
    //   3864: invokeinterface getName : ()Ljava/lang/String;
    //   3869: invokeinterface add : (Ljava/lang/Object;)Z
    //   3874: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   3877: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3880: bipush #57
    //   3882: iaload
    //   3883: aaload
    //   3884: invokevirtual length : ()I
    //   3887: pop2
    //   3888: aload #8
    //   3890: invokevirtual getPlayers : ()Ljava/util/List;
    //   3893: aload_0
    //   3894: aload #5
    //   3896: <illegal opcode> accept : (Lcom/axeelheaven/hbedwars/commands/PartyCommand;Lorg/bukkit/entity/Player;)Ljava/util/function/Consumer;
    //   3901: invokeinterface forEach : (Ljava/util/function/Consumer;)V
    //   3906: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3909: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3912: iconst_2
    //   3913: iaload
    //   3914: iaload
    //   3915: ireturn
    //   3916: aload #4
    //   3918: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3921: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3924: iconst_1
    //   3925: iaload
    //   3926: iaload
    //   3927: aaload
    //   3928: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   3931: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3934: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3937: bipush #21
    //   3939: iaload
    //   3940: iaload
    //   3941: aaload
    //   3942: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   3945: invokestatic llIIlIIIIIl : (I)Z
    //   3948: invokestatic lIIIllIllllII : (I)Z
    //   3951: ifeq -> 4153
    //   3954: aload_0
    //   3955: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3958: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   3961: aload #5
    //   3963: invokevirtual hasParty : (Lorg/bukkit/entity/Player;)Z
    //   3966: invokestatic llIIIllllll : (I)Z
    //   3969: invokestatic lIIIllIllllII : (I)Z
    //   3972: ifeq -> 4007
    //   3975: aload #7
    //   3977: aload #5
    //   3979: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_NOT_IN_PARTY : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   3982: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   3985: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   3988: iconst_1
    //   3989: iaload
    //   3990: iaload
    //   3991: anewarray java/lang/String
    //   3994: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   3997: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   4000: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   4003: iconst_2
    //   4004: iaload
    //   4005: iaload
    //   4006: ireturn
    //   4007: aload_0
    //   4008: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4011: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   4014: aload #5
    //   4016: invokevirtual getParty : (Lorg/bukkit/entity/Player;)Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   4019: astore #8
    //   4021: aload #8
    //   4023: aload #5
    //   4025: invokevirtual hasLeader : (Lorg/bukkit/entity/Player;)Z
    //   4028: invokestatic llIIIllllll : (I)Z
    //   4031: invokestatic lIIIllIllllII : (I)Z
    //   4034: ifeq -> 4069
    //   4037: aload #7
    //   4039: aload #5
    //   4041: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_ONLY_LEADER : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   4044: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   4047: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   4050: iconst_1
    //   4051: iaload
    //   4052: iaload
    //   4053: anewarray java/lang/String
    //   4056: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   4059: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   4062: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   4065: iconst_2
    //   4066: iaload
    //   4067: iaload
    //   4068: ireturn
    //   4069: aload_0
    //   4070: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4073: invokevirtual getPartyManager : ()Lcom/axeelheaven/hbedwars/custom/party/PartyManager;
    //   4076: invokevirtual getParties : ()Ljava/util/HashMap;
    //   4079: aload #5
    //   4081: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   4086: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   4089: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllIIll : [Ljava/lang/String;
    //   4092: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   4095: sipush #161
    //   4098: iaload
    //   4099: aaload
    //   4100: invokevirtual length : ()I
    //   4103: pop2
    //   4104: invokestatic getPluginManager : ()Lorg/bukkit/plugin/PluginManager;
    //   4107: new com/axeelheaven/hbedwars/api/events/party/BedWarsPartyDestroyEvent
    //   4110: dup
    //   4111: aload #8
    //   4113: invokespecial <init> : (Lcom/axeelheaven/hbedwars/custom/party/Party;)V
    //   4116: invokeinterface callEvent : (Lorg/bukkit/event/Event;)V
    //   4121: aload #7
    //   4123: aload #5
    //   4125: getstatic com/axeelheaven/hbedwars/languague/LanguageProvider.PARTY_DISBAND : Lcom/axeelheaven/hbedwars/languague/LanguageProvider;
    //   4128: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   4131: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   4134: iconst_1
    //   4135: iaload
    //   4136: iaload
    //   4137: anewarray java/lang/String
    //   4140: invokevirtual send : (Lorg/bukkit/command/CommandSender;Lcom/axeelheaven/hbedwars/languague/LanguageProvider;[Ljava/lang/String;)V
    //   4143: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   4146: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   4149: iconst_2
    //   4150: iaload
    //   4151: iaload
    //   4152: ireturn
    //   4153: aload #5
    //   4155: new java/lang/StringBuilder
    //   4158: dup
    //   4159: invokespecial <init> : ()V
    //   4162: getstatic org/bukkit/ChatColor.RED : Lorg/bukkit/ChatColor;
    //   4165: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   4168: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   4171: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   4174: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   4177: bipush #22
    //   4179: iaload
    //   4180: iaload
    //   4181: aaload
    //   4182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   4185: aload_3
    //   4186: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   4189: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.llllIllll : [Ljava/lang/String;
    //   4192: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   4195: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   4198: bipush #23
    //   4200: iaload
    //   4201: iaload
    //   4202: aaload
    //   4203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   4206: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   4209: invokeinterface sendMessage : (Ljava/lang/String;)V
    //   4214: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lllllIIII : [I
    //   4217: getstatic com/axeelheaven/hbedwars/commands/PartyCommand.lIIIlllllll : [I
    //   4220: iconst_1
    //   4221: iaload
    //   4222: iaload
    //   4223: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	4224	0	llllllllllllllllIIIllIllllllIIlI	S
    //   0	4224	7	llllllllllllllllIIIllIlllllIIlll	S
    //   0	4224	6	llllllllllllllllIIIlllIIIIIIlIIl	I
    //   2978	282	11	llllllllllllllllIIIllIllllllllII	Lorg/bukkit/entity/Player;
    //   4021	132	8	llllllllllllllllIIIlllIIIIIIllII	Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   762	48	9	llllllllllllllllIIIllIllllllIlIl	Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   0	4224	11	llllllllllllllllIIIllIlllllIIIll	D
    //   679	48	9	llllllllllllllllIIIllIlllllllIll	Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   0	4224	11	llllllllllllllllIIIllIllllllIlll	I
    //   0	4224	7	llllllllllllllllIIIllIllllllIIll	C
    //   0	4224	4	llllllllllllllllIIIllIlllllIlllI	[Ljava/lang/String;
    //   0	4224	1	llllllllllllllllIIIllIlllllIllll	D
    //   0	4224	1	llllllllllllllllIIIllIlllllIllII	J
    //   65	4159	7	llllllllllllllllIIIllIllllllIIIl	Lcom/axeelheaven/hbedwars/languague/Language;
    //   1872	779	9	llllllllllllllllIIIlllIIIIIIlIII	Lorg/bukkit/entity/Player;
    //   0	4224	10	llllllllllllllllIIIllIllllllllIl	Ljava/lang/String;
    //   0	4224	3	llllllllllllllllIIIllIllllllIllI	I
    //   0	4224	5	llllllllllllllllIIIlllIIIIIIIlII	Z
    //   0	4224	10	llllllllllllllllIIIllIlllllIIlII	S
    //   48	4176	6	llllllllllllllllIIIlllIIIIIIllIl	Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   0	4224	4	llllllllllllllllIIIllIlllllIlIlI	C
    //   355	131	10	llllllllllllllllIIIllIlllllllIII	Lorg/bukkit/entity/Player;
    //   2940	619	9	llllllllllllllllIIIllIllllllllll	Lorg/bukkit/entity/Player;
    //   29	4195	5	llllllllllllllllIIIlllIIIIIIIlll	Lorg/bukkit/entity/Player;
    //   0	4224	0	llllllllllllllllIIIlllIIIIIIIIlI	Lcom/axeelheaven/hbedwars/commands/PartyCommand;
    //   0	4224	9	llllllllllllllllIIIllIlllllIIlIl	D
    //   0	4224	8	llllllllllllllllIIIllIlllllIIllI	I
    //   1022	191	9	llllllllllllllllIIIllIllllllIIII	Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   317	896	8	llllllllllllllllIIIllIllllllIlII	Lorg/bukkit/entity/Player;
    //   1910	139	11	llllllllllllllllIIIlllIIIIIIlIlI	Lorg/bukkit/entity/Player;
    //   0	4224	8	llllllllllllllllIIIlllIIIIIIIlIl	D
    //   0	4224	2	llllllllllllllllIIIlllIIIIIIIIll	Lorg/bukkit/command/Command;
    //   1318	265	8	llllllllllllllllIIIllIlllllllllI	Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   0	4224	0	llllllllllllllllIIIllIlllllIllIl	I
    //   0	4224	5	llllllllllllllllIIIllIlllllIlIIl	Ljava/lang/String;
    //   2848	711	8	llllllllllllllllIIIlllIIIIIIIllI	Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   0	4224	4	llllllllllllllllIIIllIlllllllIIl	D
    //   3780	136	8	llllllllllllllllIIIlllIIIIIIlIll	Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   0	4224	9	llllllllllllllllIIIlllIIIIIIIIII	S
    //   0	4224	3	llllllllllllllllIIIllIlllllIlIll	J
    //   0	4224	1	llllllllllllllllIIIlllIIIIIIlllI	Lorg/bukkit/command/CommandSender;
    //   0	4224	6	llllllllllllllllIIIllIlllllIlIII	J
    //   1780	871	8	llllllllllllllllIIIllIlllllllIlI	Lcom/axeelheaven/hbedwars/custom/party/Party;
    //   0	4224	3	llllllllllllllllIIIlllIIIIIIIIIl	Ljava/lang/String;
  }
  
  private static boolean lIIIlllIIllIl(String llllllllllllllllIIIllIlllIIIllII, short llllllllllllllllIIIllIlllIIIlIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 <= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lIIIlllIIlIIl(String llllllllllllllllIIIllIlllIIIIIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= null);
  }
  
  static {
    lIIIllIlllIll();
    lIIIllIlIlllI();
    llIIIlllllI();
    llIIIllllIl();
  }
  
  private static void llIIIllllIl() {
    llllIllll = new String[lllllIIII[lIIIlllllll[0]]];
    llllIllll[lllllIIII[lIIIlllllll[1]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[2]], lIIIlllIIll[lIIIlllllll[1]]);
    llllIllll[lllllIIII[lIIIlllllll[2]]] = llIIIlllIll(lIIIlllIIll[lIIIlllllll[3]], lIIIlllIIll[lIIIlllllll[4]]);
    llllIllll[lllllIIII[lIIIlllllll[3]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[5]], lIIIlllIIll[lIIIlllllll[6]]);
    llllIllll[lllllIIII[lIIIlllllll[4]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[7]], lIIIlllIIll[lIIIlllllll[8]]);
    llllIllll[lllllIIII[lIIIlllllll[5]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[9]], lIIIlllIIll[lIIIlllllll[10]]);
    llllIllll[lllllIIII[lIIIlllllll[6]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[11]], lIIIlllIIll[lIIIlllllll[12]]);
    llllIllll[lllllIIII[lIIIlllllll[7]]] = llIIIlllIll(lIIIlllIIll[lIIIlllllll[13]], lIIIlllIIll[lIIIlllllll[14]]);
    llllIllll[lllllIIII[lIIIlllllll[8]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[15]], lIIIlllIIll[lIIIlllllll[16]]);
    llllIllll[lllllIIII[lIIIlllllll[9]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[17]], lIIIlllIIll[lIIIlllllll[18]]);
    llllIllll[lllllIIII[lIIIlllllll[10]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[19]], lIIIlllIIll[lIIIlllllll[20]]);
    llllIllll[lllllIIII[lIIIlllllll[11]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[21]], lIIIlllIIll[lIIIlllllll[22]]);
    llllIllll[lllllIIII[lIIIlllllll[12]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[23]], lIIIlllIIll[lIIIlllllll[24]]);
    llllIllll[lllllIIII[lIIIlllllll[13]]] = llIIIlllIll(lIIIlllIIll[lIIIlllllll[25]], lIIIlllIIll[lIIIlllllll[0]]);
    llllIllll[lllllIIII[lIIIlllllll[14]]] = llIIIlllIll(lIIIlllIIll[lIIIlllllll[26]], lIIIlllIIll[lIIIlllllll[27]]);
    llllIllll[lllllIIII[lIIIlllllll[15]]] = llIIIllllII(lIIIlllIIll[lIIIlllllll[28]], lIIIlllIIll[lIIIlllllll[29]]);
    llllIllll[lllllIIII[lIIIlllllll[16]]] = llIIIlllIll(lIIIlllIIll[lIIIlllllll[30]], lIIIlllIIll[lIIIlllllll[31]]);
    llllIllll[lllllIIII[lIIIlllllll[17]]] = llIIIlllIll(lIIIlllIIll[lIIIlllllll[32]], lIIIlllIIll[lIIIlllllll[33]]);
    llllIllll[lllllIIII[lIIIlllllll[18]]] = llIIIlllIll(lIIIlllIIll[lIIIlllllll[34]], lIIIlllIIll[lIIIlllllll[35]]);
    llllIllll[lllllIIII[lIIIlllllll[19]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[36]], lIIIlllIIll[lIIIlllllll[37]]);
    llllIllll[lllllIIII[lIIIlllllll[20]]] = llIIIlllIll(lIIIlllIIll[lIIIlllllll[38]], lIIIlllIIll[lIIIlllllll[39]]);
    llllIllll[lllllIIII[lIIIlllllll[21]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[40]], lIIIlllIIll[lIIIlllllll[41]]);
    llllIllll[lllllIIII[lIIIlllllll[22]]] = llIIIllllII(lIIIlllIIll[lIIIlllllll[42]], lIIIlllIIll[lIIIlllllll[43]]);
    llllIllll[lllllIIII[lIIIlllllll[23]]] = llIIIlllIll(lIIIlllIIll[lIIIlllllll[44]], lIIIlllIIll[lIIIlllllll[45]]);
    llllIllll[lllllIIII[lIIIlllllll[24]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[46]], lIIIlllIIll[lIIIlllllll[47]]);
    llllIllll[lllllIIII[lIIIlllllll[25]]] = llIIIlllIlI(lIIIlllIIll[lIIIlllllll[48]], lIIIlllIIll[lIIIlllllll[49]]);
  }
  
  private static boolean lIIIlllIIIlll(String llllllllllllllllIIIllIllIlllllIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 <= null);
  }
  
  private static boolean llIIlIIIIlI(Exception llllllllllllllllIIIllIllllIIllIl) {
    if (lIIIlllIIllll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (((0x14 ^ 0x36) & (0x19 ^ 0x3B ^ 0xFFFFFFFF)) == "  ".length())
        return (0x4B ^ 0x9) & (0x24 ^ 0x66 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIIIlllllll[2];
  }
  
  private static boolean llIIIllllll(short llllllllllllllllIIIllIllllIIllll) {
    if (lIIIlllIIlllI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ((0x31 ^ 0x3D ^ 0xF ^ 0x6) <= 0)
        return (162 + 103 - 232 + 133 ^ 80 + 4 - -44 + 3) & (0xF7 ^ 0xA7 ^ 0x71 ^ 0x4 ^ -" ".length()); 
    } else {
    
    } 
    return lIIIlllllll[2];
  }
  
  private static void llIIIlllllI() {
    lllllIIII = new int[lIIIlllllll[26]];
    lllllIIII[lIIIlllllll[2]] = lIIIlllIIll[lIIIlllllll[56]].length();
    lllllIIII[lIIIlllllll[1]] = (lIIIlllllll[36] ^ lIIIlllllll[57] ^ lIIIlllllll[58] ^ lIIIlllllll[59]) & (lIIIlllllll[60] ^ lIIIlllllll[61] ^ (lIIIlllllll[3] ^ lIIIlllllll[62]) & (lIIIlllllll[63] ^ lIIIlllllll[64] ^ lIIIlllllll[65]) ^ -lIIIlllIIll[lIIIlllllll[66]].length());
    lllllIIII[lIIIlllllll[3]] = lIIIlllIIll[lIIIlllllll[67]].length();
    lllllIIII[lIIIlllllll[4]] = lIIIlllIIll[lIIIlllllll[68]].length();
    lllllIIII[lIIIlllllll[5]] = lIIIlllllll[13] ^ lIIIlllllll[9];
    lllllIIII[lIIIlllllll[6]] = lIIIlllllll[69] ^ lIIIlllllll[70];
    lllllIIII[lIIIlllllll[7]] = lIIIlllllll[71] ^ lIIIlllllll[72];
    lllllIIII[lIIIlllllll[8]] = lIIIlllllll[32] ^ lIIIlllllll[71] ^ lIIIlllllll[73] ^ lIIIlllllll[74];
    lllllIIII[lIIIlllllll[9]] = lIIIlllllll[75] + lIIIlllllll[57] - lIIIlllllll[76] + lIIIlllllll[11] ^ lIIIlllllll[77] + lIIIlllllll[18] - lIIIlllllll[78] + lIIIlllllll[79];
    lllllIIII[lIIIlllllll[10]] = lIIIlllllll[80] ^ lIIIlllllll[81] ^ (lIIIlllllll[61] ^ lIIIlllllll[82]) & (lIIIlllllll[83] ^ lIIIlllllll[84] ^ lIIIlllllll[65]);
    lllllIIII[lIIIlllllll[11]] = lIIIlllllll[85] ^ lIIIlllllll[86] ^ lIIIlllllll[74] ^ lIIIlllllll[87];
    lllllIIII[lIIIlllllll[12]] = lIIIlllllll[88] ^ lIIIlllllll[89] ^ lIIIlllllll[90] ^ lIIIlllllll[9];
    lllllIIII[lIIIlllllll[13]] = lIIIlllllll[0] ^ lIIIlllllll[22];
    lllllIIII[lIIIlllllll[14]] = lIIIlllllll[91] + lIIIlllllll[4] - lIIIlllllll[54] + lIIIlllllll[86] ^ lIIIlllllll[12] + lIIIlllllll[92] - lIIIlllllll[21] + lIIIlllllll[93];
    lllllIIII[lIIIlllllll[15]] = lIIIlllllll[94] ^ lIIIlllllll[95] ^ lIIIlllllll[18] ^ lIIIlllllll[35];
    lllllIIII[lIIIlllllll[16]] = lIIIlllIIll[lIIIlllllll[96]].length() ^ lIIIlllllll[79] ^ lIIIlllllll[87];
    lllllIIII[lIIIlllllll[17]] = lIIIlllllll[80] ^ lIIIlllllll[97];
    lllllIIII[lIIIlllllll[18]] = lIIIlllllll[78] ^ lIIIlllllll[57] ^ lIIIlllIIll[lIIIlllllll[98]].length();
    lllllIIII[lIIIlllllll[19]] = lIIIlllllll[96] ^ lIIIlllllll[45] ^ lIIIlllIIll[lIIIlllllll[99]].length();
    lllllIIII[lIIIlllllll[20]] = lIIIlllllll[100] ^ lIIIlllllll[101];
    lllllIIII[lIIIlllllll[21]] = lIIIlllllll[43] ^ lIIIlllllll[102];
    lllllIIII[lIIIlllllll[22]] = lIIIlllllll[54] ^ lIIIlllllll[35];
    lllllIIII[lIIIlllllll[23]] = lIIIlllllll[103] ^ lIIIlllllll[93];
    lllllIIII[lIIIlllllll[24]] = lIIIlllllll[93] ^ lIIIlllllll[100];
    lllllIIII[lIIIlllllll[25]] = lIIIlllllll[104] ^ lIIIlllllll[105] ^ lIIIlllllll[106] ^ lIIIlllllll[107];
    lllllIIII[lIIIlllllll[0]] = lIIIlllllll[67] ^ lIIIlllllll[35];
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\commands\PartyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */