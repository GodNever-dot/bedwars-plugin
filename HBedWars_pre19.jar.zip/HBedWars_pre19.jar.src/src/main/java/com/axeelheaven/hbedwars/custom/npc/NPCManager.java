package com.axeelheaven.hbedwars.custom.npc;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.libs.json.simple.JSONObject;
import com.axeelheaven.hbedwars.libs.json.simple.parser.JSONParser;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.logging.Level;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDeathEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public class NPCManager implements Listener {
    private final BedWars plugin;
    private final HashMap<Location, NPC> npcs;
    private final File skinFile;
    private int npcId;
    
    public NPCManager(BedWars plugin) {
        this.plugin = plugin;
        this.npcs = new HashMap<>();
        this.skinFile = new File(plugin.getDataFolder(), "skins.json");
        this.npcId = 0;
    }
    
    public NPC create(Location location) {
        return create(location, "Steve");
    }
    
    public NPC create(Location location, String skinName) {
        NPCProperty property = getSkinProperty(skinName);
        NPC npc = new NPC(plugin, location, npcId++, property);
        npcs.put(location, npc);
        return npc;
    }
    
    public void delete(Location location) {
        NPC npc = npcs.remove(location);
        if (npc != null) {
            npc.destroy();
        }
    }
    
    public void delete(Player player) {
        npcs.values().forEach(npc -> npc.destroy(player));
    }
    
    @EventHandler
    public void onTeleport(PlayerTeleportEvent event) {
        delete(event.getPlayer());
    }
    
    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        delete(event.getEntity());
    }
    
    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        delete(event.getPlayer());
    }
    
    public NPCProperty getSkinProperty(String name) {
        try {
            URL url = new URL("https://api.mojang.com/users/profiles/minecraft/" + name);
            InputStreamReader reader = new InputStreamReader(url.openStream());
            JSONObject profile = (JSONObject) new JSONParser().parse(reader);
            
            String uuid = (String) profile.get("id");
            url = new URL("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid);
            reader = new InputStreamReader(url.openStream());
            profile = (JSONObject) new JSONParser().parse(reader);
            
            return new NPCProperty(profile);
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Failed to get skin property for " + name, e);
            return null;
        }
    }
    
    public HashMap<Location, NPC> getNpcs() {
        return npcs;
    }
    
    public File getSkinFile() {
        return skinFile;
    }
    
    public int getNpcId() {
        return npcId;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\npc\NPCManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */