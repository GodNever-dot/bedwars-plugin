/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Builder;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.BuilderFactory;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandObject;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Connection;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.providers.ConnectionProvider;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphCommandObjects
/*     */ {
/*     */   private final RedisGraphCommands graph;
/*     */   private final Connection connection;
/*     */   private final ConnectionProvider provider;
/*  25 */   private final ConcurrentHashMap<String, Builder<ResultSet>> builders = new ConcurrentHashMap<>();
/*     */   
/*     */   public GraphCommandObjects(RedisGraphCommands graphCommands) {
/*  28 */     this.graph = graphCommands;
/*  29 */     this.connection = null;
/*  30 */     this.provider = null;
/*     */   }
/*     */   
/*     */   public GraphCommandObjects(Connection connection) {
/*  34 */     this.connection = connection;
/*  35 */     this.provider = null;
/*  36 */     this.graph = null;
/*     */   }
/*     */   
/*     */   public GraphCommandObjects(ConnectionProvider provider) {
/*  40 */     this.provider = provider;
/*  41 */     this.connection = null;
/*  42 */     this.graph = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final CommandObject<ResultSet> graphQuery(String name, String query) {
/*  47 */     return new CommandObject((new CommandArguments(GraphProtocol.GraphCommand.QUERY)).key(name).add(query).add(GraphProtocol.GraphKeyword.__COMPACT), getBuilder(name));
/*     */   }
/*     */   
/*     */   public final CommandObject<ResultSet> graphReadonlyQuery(String name, String query) {
/*  51 */     return new CommandObject((new CommandArguments(GraphProtocol.GraphCommand.RO_QUERY)).key(name).add(query).add(GraphProtocol.GraphKeyword.__COMPACT), getBuilder(name));
/*     */   }
/*     */   
/*     */   public final CommandObject<ResultSet> graphQuery(String name, String query, long timeout) {
/*  55 */     return graphQuery(name, GraphQueryParams.queryParams(query).timeout(timeout));
/*     */   }
/*     */   
/*     */   public final CommandObject<ResultSet> graphReadonlyQuery(String name, String query, long timeout) {
/*  59 */     return graphQuery(name, GraphQueryParams.queryParams().readonly().query(query).timeout(timeout));
/*     */   }
/*     */   
/*     */   public final CommandObject<ResultSet> graphQuery(String name, String query, Map<String, Object> params) {
/*  63 */     return graphQuery(name, GraphQueryParams.queryParams(query).params(params));
/*     */   }
/*     */   
/*     */   public final CommandObject<ResultSet> graphReadonlyQuery(String name, String query, Map<String, Object> params) {
/*  67 */     return graphQuery(name, GraphQueryParams.queryParams().readonly().query(query).params(params));
/*     */   }
/*     */   
/*     */   public final CommandObject<ResultSet> graphQuery(String name, String query, Map<String, Object> params, long timeout) {
/*  71 */     return graphQuery(name, GraphQueryParams.queryParams(query).params(params).timeout(timeout));
/*     */   }
/*     */   
/*     */   public final CommandObject<ResultSet> graphReadonlyQuery(String name, String query, Map<String, Object> params, long timeout) {
/*  75 */     return graphQuery(name, GraphQueryParams.queryParams().readonly().query(query).params(params).timeout(timeout));
/*     */   }
/*     */   
/*     */   private CommandObject<ResultSet> graphQuery(String name, GraphQueryParams params) {
/*  79 */     return new CommandObject(params.getArguments(name), getBuilder(name));
/*     */   }
/*     */   
/*     */   public final CommandObject<String> graphDelete(String name) {
/*  83 */     return new CommandObject((new CommandArguments(GraphProtocol.GraphCommand.DELETE)).key(name), BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   
/*     */   private Builder<ResultSet> getBuilder(String graphName) {
/*  88 */     if (!this.builders.containsKey(graphName)) {
/*  89 */       createBuilder(graphName);
/*     */     }
/*  91 */     return this.builders.get(graphName);
/*     */   }
/*     */   
/*     */   private void createBuilder(String graphName) {
/*  95 */     synchronized (this.builders) {
/*  96 */       this.builders.putIfAbsent(graphName, new ResultSetBuilder(new GraphCacheImpl(graphName)));
/*     */     } 
/*     */   }
/*     */   
/*     */   private class GraphCacheImpl
/*     */     implements GraphCache {
/*     */     private final GraphCommandObjects.GraphCacheList labels;
/*     */     private final GraphCommandObjects.GraphCacheList propertyNames;
/*     */     private final GraphCommandObjects.GraphCacheList relationshipTypes;
/*     */     
/*     */     public GraphCacheImpl(String graphName) {
/* 107 */       this.labels = new GraphCommandObjects.GraphCacheList(graphName, "db.labels");
/* 108 */       this.propertyNames = new GraphCommandObjects.GraphCacheList(graphName, "db.propertyKeys");
/* 109 */       this.relationshipTypes = new GraphCommandObjects.GraphCacheList(graphName, "db.relationshipTypes");
/*     */     }
/*     */ 
/*     */     
/*     */     public String getLabel(int index) {
/* 114 */       return this.labels.getCachedData(index);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getRelationshipType(int index) {
/* 119 */       return this.relationshipTypes.getCachedData(index);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPropertyName(int index) {
/* 124 */       return this.propertyNames.getCachedData(index);
/*     */     }
/*     */   }
/*     */   
/*     */   private class GraphCacheList
/*     */   {
/*     */     private final String name;
/*     */     private final String query;
/* 132 */     private final List<String> data = new CopyOnWriteArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GraphCacheList(String name, String procedure) {
/* 140 */       this.name = name;
/* 141 */       this.query = "CALL " + procedure + "()";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getCachedData(int index) {
/* 152 */       if (index >= this.data.size()) {
/* 153 */         synchronized (this.data) {
/* 154 */           if (index >= this.data.size()) {
/* 155 */             getProcedureInfo();
/*     */           }
/*     */         } 
/*     */       }
/* 159 */       return this.data.get(index);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void getProcedureInfo() {
/* 167 */       ResultSet resultSet = callProcedure();
/* 168 */       Iterator<Record> it = resultSet.iterator();
/* 169 */       List<String> newData = new ArrayList<>();
/* 170 */       int i = 0;
/* 171 */       while (it.hasNext()) {
/* 172 */         Record record = it.next();
/* 173 */         if (i >= this.data.size()) {
/* 174 */           newData.add(record.getString(0));
/*     */         }
/* 176 */         i++;
/*     */       } 
/* 178 */       this.data.addAll(newData);
/*     */     }
/*     */ 
/*     */     
/*     */     private ResultSet callProcedure() {
/* 183 */       if (GraphCommandObjects.this.graph != null) {
/* 184 */         return GraphCommandObjects.this.graph.graphQuery(this.name, this.query);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       CommandObject<ResultSet> commandObject = new CommandObject((new CommandArguments(GraphProtocol.GraphCommand.QUERY)).key(this.name).add(this.query).add(GraphProtocol.GraphKeyword.__COMPACT), GraphCommandObjects.this.getBuilder(this.name));
/*     */       
/* 192 */       if (GraphCommandObjects.this.connection != null) {
/* 193 */         return (ResultSet)GraphCommandObjects.this.connection.executeCommand(commandObject);
/*     */       }
/* 195 */       try (Connection provided = GraphCommandObjects.this.provider.getConnection(commandObject.getArguments())) {
/* 196 */         return (ResultSet)provided.executeCommand(commandObject);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\GraphCommandObjects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */