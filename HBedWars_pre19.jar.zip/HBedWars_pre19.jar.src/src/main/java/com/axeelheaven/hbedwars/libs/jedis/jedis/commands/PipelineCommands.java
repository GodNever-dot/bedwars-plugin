package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

public interface PipelineCommands extends KeyPipelineCommands, StringPipelineCommands, ListPipelineCommands, HashPipelineCommands, SetPipelineCommands, SortedSetPipelineCommands, GeoPipelineCommands, HyperLogLogPipelineCommands, StreamPipelineCommands, ScriptingKeyPipelineCommands, SampleKeyedPipelineCommands, FunctionPipelineCommands {}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\PipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */