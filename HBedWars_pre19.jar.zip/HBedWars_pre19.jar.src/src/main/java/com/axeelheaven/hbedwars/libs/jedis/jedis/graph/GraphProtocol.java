/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.Rawable;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.commands.ProtocolCommand;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ 
/*    */ public class GraphProtocol
/*    */ {
/*    */   public enum GraphCommand
/*    */     implements ProtocolCommand {
/* 11 */     QUERY,
/* 12 */     RO_QUERY,
/* 13 */     DELETE;
/*    */     
/*    */     private final byte[] raw;
/*    */     
/*    */     GraphCommand() {
/* 18 */       this.raw = SafeEncoder.encode("GRAPH." + name());
/*    */     }
/*    */ 
/*    */     
/*    */     public byte[] getRaw() {
/* 23 */       return this.raw;
/*    */     }
/*    */   }
/*    */   
/*    */   public enum GraphKeyword
/*    */     implements Rawable {
/* 29 */     CYPHER,
/* 30 */     TIMEOUT,
/* 31 */     __COMPACT("--COMPACT");
/*    */     
/*    */     private final byte[] raw;
/*    */     
/*    */     GraphKeyword() {
/* 36 */       this.raw = SafeEncoder.encode(name());
/*    */     }
/*    */     
/*    */     GraphKeyword(String alt) {
/* 40 */       this.raw = SafeEncoder.encode(alt);
/*    */     }
/*    */ 
/*    */     
/*    */     public byte[] getRaw() {
/* 45 */       return this.raw;
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\GraphProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */