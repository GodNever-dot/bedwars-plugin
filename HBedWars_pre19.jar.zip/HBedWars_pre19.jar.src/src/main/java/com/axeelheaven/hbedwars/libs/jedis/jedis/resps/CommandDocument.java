/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Builder;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.BuilderFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class CommandDocument
/*    */ {
/*    */   private final String summary;
/*    */   private final String since;
/*    */   private final String group;
/*    */   private final String complexity;
/*    */   private final List<String> history;
/*    */   
/*    */   public CommandDocument(String summary, String since, String group, String complexity, List<String> history) {
/* 18 */     this.summary = summary;
/* 19 */     this.since = since;
/* 20 */     this.group = group;
/* 21 */     this.complexity = complexity;
/* 22 */     this.history = history;
/*    */   }
/*    */   
/*    */   public String getSummary() {
/* 26 */     return this.summary;
/*    */   }
/*    */   
/*    */   public String getSince() {
/* 30 */     return this.since;
/*    */   }
/*    */   
/*    */   public String getGroup() {
/* 34 */     return this.group;
/*    */   }
/*    */   
/*    */   public String getComplexity() {
/* 38 */     return this.complexity;
/*    */   }
/*    */   
/*    */   public List<String> getHistory() {
/* 42 */     return this.history;
/*    */   }
/*    */   
/* 45 */   public static final Builder<CommandDocument> COMMAND_DOCUMENT_BUILDER = new Builder<CommandDocument>()
/*    */     {
/*    */       public CommandDocument build(Object data) {
/* 48 */         List<Object> commandData = (List<Object>)data;
/* 49 */         String summary = (String)BuilderFactory.STRING.build(commandData.get(1));
/* 50 */         String since = (String)BuilderFactory.STRING.build(commandData.get(3));
/* 51 */         String group = (String)BuilderFactory.STRING.build(commandData.get(5));
/* 52 */         String complexity = (String)BuilderFactory.STRING.build(commandData.get(7));
/* 53 */         List<String> history = null;
/* 54 */         if (((String)BuilderFactory.STRING.build(commandData.get(8))).equals("history")) {
/* 55 */           List<List<Object>> rawHistory = (List<List<Object>>)commandData.get(9);
/* 56 */           history = new ArrayList<>(rawHistory.size());
/* 57 */           for (List<Object> timePoint : rawHistory) {
/* 58 */             history.add((String)BuilderFactory.STRING.build(timePoint.get(0)) + ": " + (String)BuilderFactory.STRING.build(timePoint.get(1)));
/*    */           }
/*    */         } 
/* 61 */         return new CommandDocument(summary, since, group, complexity, history);
/*    */       }
/*    */     };
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\CommandDocument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */