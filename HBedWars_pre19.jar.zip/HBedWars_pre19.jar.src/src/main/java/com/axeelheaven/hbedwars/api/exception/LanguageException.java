package com.axeelheaven.hbedwars.api.exception;

public class LanguageException extends Exception {
  static {
  
  }
  
  public LanguageException(float lllllllllllllllllIIlIlIlIlIlllll) {
    super(lllllllllllllllllIIlIlIlIlIlllll);
  }
  
  public LanguageException(String lllllllllllllllllIIlIlIlIllIlIlI, double lllllllllllllllllIIlIlIlIllIIlII) {
    super(lllllllllllllllllIIlIlIlIllIlIlI, lllllllllllllllllIIlIlIlIllIIlII);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\exception\LanguageException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */