/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*    */ 
/*    */ public class Module
/*    */ {
/*    */   private final String name;
/*    */   private final int version;
/*    */   
/*    */   public Module(String name, int version) {
/*  9 */     this.name = name;
/* 10 */     this.version = version;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 14 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getVersion() {
/* 18 */     return this.version;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 23 */     if (o == null) return false; 
/* 24 */     if (o == this) return true; 
/* 25 */     if (!(o instanceof Module)) return false;
/*    */     
/* 27 */     Module module = (Module)o;
/*    */     
/* 29 */     if (this.version != module.version) return false; 
/* 30 */     if ((this.name != null) ? !this.name.equals(module.name) : (module.name != null)) return false;
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 36 */     int result = (this.name != null) ? this.name.hashCode() : 0;
/* 37 */     result = 31 * result + this.version;
/* 38 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\Module.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */