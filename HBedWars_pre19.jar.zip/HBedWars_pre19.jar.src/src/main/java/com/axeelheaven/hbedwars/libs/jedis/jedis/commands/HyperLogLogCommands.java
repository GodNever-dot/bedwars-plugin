package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

public interface HyperLogLogCommands {
  long pfadd(String paramString, String... paramVarArgs);
  
  String pfmerge(String paramString, String... paramVarArgs);
  
  long pfcount(String paramString);
  
  long pfcount(String... paramVarArgs);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\HyperLogLogCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */