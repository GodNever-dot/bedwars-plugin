package com.axeelheaven.hbedwars.cosmetics.windances;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.api.arena.Arena;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public abstract class WinDance {
    private final String name;
    private final int cost;
    private final boolean purchasable;
    private final String id;
    
    public WinDance(String name, int cost, boolean purchasable) {
        this.name = name;
        this.cost = cost;
        this.purchasable = purchasable;
        this.id = name.toLowerCase().replace(" ", "_");
    }
    
    public String getName() {
        return name;
    }
    
    public int getCost() {
        return cost;
    }
    
    public boolean isPurchasable() {
        return purchasable;
    }
    
    public String getId() {
        return id;
    }
    
    public abstract void play(Player player, Location location);
    
    public abstract void execute(Player player, Arena arena);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\windances\WinDance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */