package com.axeelheaven.hbedwars.arena.task;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.api.arena.Arena;
import com.axeelheaven.hbedwars.api.arena.GameState;
import com.axeelheaven.hbedwars.arena.ArenaTeam;
import com.axeelheaven.hbedwars.arena.generator.Generator;
import java.util.Iterator;
import org.bukkit.entity.ArmorStand;

public class GeneratorTask implements Runnable {
  private static String llIllIIIlIlI(String llllllllllllllllIllllIIlIIIIIlII, byte llllllllllllllllIllllIIlIIIIIIIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc 'Blowfish'
    //   21: invokespecial <init> : ([BLjava/lang/String;)V
    //   24: astore_2
    //   25: ldc 'Blowfish'
    //   27: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   30: astore_3
    //   31: aload_3
    //   32: getstatic com/axeelheaven/hbedwars/arena/task/GeneratorTask.lllIllIlIl : [I
    //   35: iconst_2
    //   36: iaload
    //   37: aload_2
    //   38: invokevirtual init : (ILjava/security/Key;)V
    //   41: new java/lang/String
    //   44: dup
    //   45: aload_3
    //   46: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   49: aload_0
    //   50: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   53: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   56: invokevirtual decode : ([B)[B
    //   59: invokevirtual doFinal : ([B)[B
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   68: areturn
    //   69: astore_2
    //   70: aload_2
    //   71: invokevirtual printStackTrace : ()V
    //   74: aconst_null
    //   75: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	76	1	llllllllllllllllIllllIIlIIIIIIll	Ljava/lang/String;
    //   25	44	2	llllllllllllllllIllllIIlIIIIIlll	Ljavax/crypto/spec/SecretKeySpec;
    //   0	76	1	llllllllllllllllIllllIIlIIIIIIIl	B
    //   0	76	2	llllllllllllllllIllllIIlIIIIIIII	I
    //   0	76	0	llllllllllllllllIllllIIlIIIIIIlI	S
    //   31	38	3	llllllllllllllllIllllIIlIIIIIllI	Ljavax/crypto/Cipher;
    //   70	4	2	llllllllllllllllIllllIIlIIIIIlIl	Ljava/lang/Exception;
    //   0	76	3	llllllllllllllllIllllIIIllllllll	C
    //   0	76	0	llllllllllllllllIllllIIlIIIIIlII	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	68	69	java/lang/Exception
  }
  
  private static String llIllIIIlIll(byte llllllllllllllllIllllIIIllllIlIl, String llllllllllllllllIllllIIIllllIllI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: getstatic com/axeelheaven/hbedwars/arena/task/GeneratorTask.lllIllIlIl : [I
    //   22: bipush #7
    //   24: iaload
    //   25: invokestatic copyOf : ([BI)[B
    //   28: ldc 'DES'
    //   30: invokespecial <init> : ([BLjava/lang/String;)V
    //   33: astore_2
    //   34: ldc 'DES'
    //   36: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   39: astore_3
    //   40: aload_3
    //   41: getstatic com/axeelheaven/hbedwars/arena/task/GeneratorTask.lllIllIlIl : [I
    //   44: iconst_2
    //   45: iaload
    //   46: aload_2
    //   47: invokevirtual init : (ILjava/security/Key;)V
    //   50: new java/lang/String
    //   53: dup
    //   54: aload_3
    //   55: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   58: aload_0
    //   59: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   62: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   65: invokevirtual decode : ([B)[B
    //   68: invokevirtual doFinal : ([B)[B
    //   71: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   74: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   77: areturn
    //   78: astore_2
    //   79: aload_2
    //   80: invokevirtual printStackTrace : ()V
    //   83: aconst_null
    //   84: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	85	1	llllllllllllllllIllllIIIllllIlII	B
    //   0	85	3	llllllllllllllllIllllIIIllllIIlI	F
    //   0	85	0	llllllllllllllllIllllIIIllllIlll	Ljava/lang/String;
    //   0	85	1	llllllllllllllllIllllIIIllllIllI	Ljava/lang/String;
    //   0	85	2	llllllllllllllllIllllIIIllllIIll	I
    //   40	38	3	llllllllllllllllIllllIIIlllllIIl	Ljavax/crypto/Cipher;
    //   34	44	2	llllllllllllllllIllllIIIlllllIlI	Ljavax/crypto/spec/SecretKeySpec;
    //   0	85	0	llllllllllllllllIllllIIIllllIlIl	B
    //   79	4	2	llllllllllllllllIllllIIIlllllIII	Ljava/lang/Exception;
    // Exception table:
    //   from	to	target	type
    //   0	77	78	java/lang/Exception
  }
  
  static {
    llIllIIIllIl();
    llIllIIIllII();
  }
  
  private static boolean llIllIIlIIIl(byte llllllllllllllllIllllIIIlllIllll, char llllllllllllllllIllllIIIlllIlllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public GeneratorTask(long llllllllllllllllIllllIIlIIlIlIII) {
    this.plugin = llllllllllllllllIllllIIlIIlIlIII;
  }
  
  private static void llIllIIIllII() {
    lllIllIIll = new String[lllIllIlIl[6]];
    lllIllIIll[lllIllIlIl[1]] = llIllIIIlIIl("", "yJrdU");
    lllIllIIll[lllIllIlIl[0]] = llIllIIIlIlI("VaA3Ss4t+i0=", "JUvhK");
    lllIllIIll[lllIllIlIl[2]] = llIllIIIlIIl("", "RSdMg");
    lllIllIIll[lllIllIlIl[3]] = llIllIIIlIll("qxFbD7z6LIA=", "oYSrm");
  }
  
  private static String llIllIIIlIIl(byte llllllllllllllllIllllIIlIIIlIlII, String llllllllllllllllIllllIIlIIIllIII) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/arena/task/GeneratorTask.lllIllIlIl : [I
    //   40: iconst_1
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/arena/task/GeneratorTask.lllIllIlIl : [I
    //   58: iconst_1
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic llIllIIlIIIl : (II)Z
    //   69: ifeq -> 127
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: ldc '   '
    //   114: invokevirtual length : ()I
    //   117: ldc ' '
    //   119: invokevirtual length : ()I
    //   122: if_icmpgt -> 62
    //   125: aconst_null
    //   126: areturn
    //   127: aload_2
    //   128: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   131: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   37	95	3	llllllllllllllllIllllIIlIIIlIllI	[C
    //   0	132	8	llllllllllllllllIllllIIlIIIIllII	F
    //   32	100	2	llllllllllllllllIllllIIlIIIlIlll	Ljava/lang/StringBuilder;
    //   0	132	0	llllllllllllllllIllllIIlIIIllIIl	Ljava/lang/String;
    //   0	132	5	llllllllllllllllIllllIIlIIIIllll	Ljava/lang/String;
    //   0	132	1	llllllllllllllllIllllIIlIIIlIIll	Z
    //   0	132	0	llllllllllllllllIllllIIlIIIlIlII	B
    //   44	88	4	llllllllllllllllIllllIIlIIIlIlIl	I
    //   0	132	3	llllllllllllllllIllllIIlIIIlIIIl	Ljava/lang/String;
    //   0	132	7	llllllllllllllllIllllIIlIIIIllIl	F
    //   0	132	2	llllllllllllllllIllllIIlIIIlIIlI	Z
    //   79	24	8	llllllllllllllllIllllIIlIIIllIlI	C
    //   0	132	4	llllllllllllllllIllllIIlIIIlIIII	S
    //   0	132	6	llllllllllllllllIllllIIlIIIIlllI	J
    //   0	132	1	llllllllllllllllIllllIIlIIIllIII	Ljava/lang/String;
  }
  
  private static boolean llIllIIIllll(double llllllllllllllllIllllIIIlllIllII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean llIllIIlIIII(boolean llllllllllllllllIllllIIIlllIlIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < null);
  }
  
  private static void llIllIIIllIl() {
    lllIllIlIl = new int[8];
    lllIllIlIl[0] = " ".length();
    lllIllIlIl[1] = (0x12 ^ 0x4D) & (0x1B ^ 0x44 ^ 0xFFFFFFFF);
    lllIllIlIl[2] = "  ".length();
    lllIllIlIl[3] = "   ".length();
    lllIllIlIl[4] = (0xBB ^ 0x8E) + 12 + 120 - 71 + 69 - (0xD9 ^ 0xB3) + (0x27 ^ 0x1F);
    lllIllIlIl[5] = (0xDE ^ 0x95) + (0x97 ^ 0xB8) - (0x9C ^ 0x86) + (0xF ^ 0x2E);
    lllIllIlIl[6] = 0xBC ^ 0xB8;
    lllIllIlIl[7] = 0x9C ^ 0x94;
  }
  
  private static boolean lllIlIIlII(double llllllllllllllllIllllIIlIlIlIIll) {
    if (llIllIIIllll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ("  ".length() == 0)
        return (0xC7 ^ 0xA4) & (0xC2 ^ 0xA1 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lllIllIlIl[1];
  }
  
  private static boolean llIllIIIlllI(float llllllllllllllllIllllIIIlllIlIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean lllIlIIIll(char llllllllllllllllIllllIIlIlIlIlll) {
    if (llIllIIIlllI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (-" ".length() >= "  ".length())
        return (0x1C ^ 0x4F ^ 0xEC ^ 0xB5) & (0x42 ^ 0xB ^ 0x1A ^ 0x59 ^ -" ".length()); 
    } else {
    
    } 
    return lllIllIlIl[1];
  }
  
  public void run() {
    Iterator<Arena> iterator = this.plugin.getArenaManager().getGames().values().iterator();
    while (llIllIIIlllI(lllIlIIIll(iterator.hasNext()))) {
      Arena llllllllllllllllIllllIIlIIllIlll = iterator.next();
      if (llIllIIIlllI(lllIlIIIll(llllllllllllllllIllllIIlIIllIlll.isGameState(GameState.GAME)))) {
        llllllllllllllllIllllIIlIIllIlll.getGenerators().values().forEach(llllllllllllllllIllllIIlIlIIlIll -> {
              // Byte code:
              //   0: aload_1
              //   1: invokevirtual values : ()Ljava/util/Collection;
              //   4: aload_0
              //   5: <illegal opcode> accept : (Lcom/axeelheaven/hbedwars/arena/task/GeneratorTask;)Ljava/util/function/Consumer;
              //   10: invokeinterface forEach : (Ljava/util/function/Consumer;)V
              //   15: return
              // Local variable table:
              //   start	length	slot	name	descriptor
              //   0	16	1	llllllllllllllllIllllIIlIlIIlllI	Ljava/util/HashMap;
              //   0	16	1	llllllllllllllllIllllIIlIlIIlIll	Z
              //   0	16	0	llllllllllllllllIllllIIlIlIIllII	B
              //   0	16	0	llllllllllllllllIllllIIlIlIIllll	Lcom/axeelheaven/hbedwars/arena/task/GeneratorTask;
              //   0	16	0	llllllllllllllllIllllIIlIlIIllIl	Ljava/lang/String;
              //   0	16	1	llllllllllllllllIllllIIlIlIlIIII	I
            });
        lllIllIIll[lllIllIlIl[2]].length();
      } 
      "".length();
      if (llIllIIlIIII(lllIllIlIl[4] ^ lllIllIlIl[5]))
        return; 
    } 
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\arena\task\GeneratorTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */