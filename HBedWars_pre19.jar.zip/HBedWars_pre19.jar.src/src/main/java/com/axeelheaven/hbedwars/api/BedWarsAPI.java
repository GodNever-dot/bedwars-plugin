/*    */ package com.axeelheaven.hbedwars.api;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.BedWars;
/*    */ import com.axeelheaven.hbedwars.cosmetics.beddestroys.BedDestroy;
/*    */ import com.axeelheaven.hbedwars.cosmetics.killeffects.KillEffect;
/*    */ import com.axeelheaven.hbedwars.cosmetics.windances.WinDance;
/*    */ import com.axeelheaven.hbedwars.database.economy.Economy;
/*    */ import com.axeelheaven.hbedwars.database.profile.HData;
/*    */ import com.axeelheaven.hbedwars.languague.Language;
/*    */ import java.util.UUID;
/*    */ import java.util.logging.Level;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class BedWarsAPI
/*    */ {
/*    */   private final BedWars plugin;
/*    */   private static BedWarsAPI instance;
/*    */   
/*    */   public static BedWarsAPI getInstance() {
/* 20 */     return instance;
/*    */   }
/*    */   
/*    */   public BedWarsAPI(BedWars plugin) {
/* 24 */     this.plugin = plugin;
/* 25 */     instance = this;
/*    */   }
/*    */   
/*    */   public void setEconomy(Economy economy) {
/*    */     try {
/* 30 */       this.plugin.getEconomyManager().setEconomy(economy);
/* 31 */     } catch (Exception exception) {
/* 32 */       this.plugin.getLogger().log(Level.SEVERE, "Failed to load economy: " + exception.getMessage());
/*    */     } 
/*    */   }
/*    */   
/*    */   public void addBedDestroy(BedDestroy bedDestroy) {
/*    */     try {
/* 38 */       this.plugin.getBedDestroyManager().getBedDestroys().put(bedDestroy.getId(), bedDestroy);
/* 39 */     } catch (Exception exception) {
/* 40 */       this.plugin.getLogger().log(Level.SEVERE, "Could not load bed destroy: " + exception.getMessage());
/*    */     } 
/*    */   }
/*    */   
/*    */   public void addKillEffect(KillEffect killEffect) {
/*    */     try {
/* 46 */       this.plugin.getKillEffectManager().getKillEffects().put(killEffect.getId(), killEffect);
/* 47 */     } catch (Exception exception) {
/* 48 */       this.plugin.getLogger().log(Level.SEVERE, "Could not load kill effect: " + exception.getMessage());
/*    */     } 
/*    */   }
/*    */   
/*    */   public void addWinDance(WinDance winDance) {
/*    */     try {
/* 54 */       this.plugin.getWinDanceManager().getWinDances().put(winDance.getId(), winDance);
/* 55 */     } catch (Exception exception) {
/* 56 */       this.plugin.getLogger().log(Level.SEVERE, "Could not load win dance: " + exception.getMessage());
/*    */     } 
/*    */   }
/*    */   
/*    */   public HData getData(UUID uuid) {
/* 61 */     return this.plugin.getGameManager().getData(uuid);
/*    */   }
/*    */   
/*    */   public HData getData(Player player) {
/* 65 */     return getData(player.getUniqueId());
/*    */   }
/*    */   
/*    */   public String replace(Player player, String text) {
/* 69 */     return this.plugin.text(player, text);
/*    */   }
/*    */   
/*    */   public Language getLanguage(String language) {
/* 73 */     return this.plugin.getLanguageManager().getLanguage(language);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\BedWarsAPI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */