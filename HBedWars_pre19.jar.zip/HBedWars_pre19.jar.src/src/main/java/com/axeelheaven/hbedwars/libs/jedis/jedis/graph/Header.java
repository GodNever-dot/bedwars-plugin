package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;

import java.util.List;

public interface Header {
  List<ResultSet.ColumnType> getSchemaTypes();
  
  List<String> getSchemaNames();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\Header.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */