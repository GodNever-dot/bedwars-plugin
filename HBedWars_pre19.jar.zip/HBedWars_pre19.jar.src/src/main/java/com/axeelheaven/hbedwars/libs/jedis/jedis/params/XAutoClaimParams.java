/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XAutoClaimParams
/*    */   implements IParams
/*    */ {
/*    */   private Integer count;
/*    */   
/*    */   public static XAutoClaimParams xAutoClaimParams() {
/* 15 */     return new XAutoClaimParams();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public XAutoClaimParams count(int count) {
/* 24 */     this.count = Integer.valueOf(count);
/* 25 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 30 */     if (this.count != null)
/* 31 */       args.add(Protocol.Keyword.COUNT.getRaw()).add(this.count); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\XAutoClaimParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */