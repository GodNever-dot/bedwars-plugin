package com.axeelheaven.hbedwars.bungeemode.redis;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.custom.redis.JedisResult;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class RedisMessenger {
    private final BedWars plugin;
    private final JedisPool pool;
    
    public RedisMessenger(BedWars plugin, JedisPool pool) {
        this.plugin = plugin;
        this.pool = pool;
    }
    
    public void publish(String channel, String message, JedisResult result) {
        try (Jedis jedis = pool.getResource()) {
            jedis.publish(channel, message);
            result.onSuccess();
        } catch (Exception e) {
            result.onFailure(e);
        }
    }
    
    public void close() {
        if (pool != null) {
            pool.close();
        }
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\bungeemode\redis\RedisMessenger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */