/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ClientType;
/*    */ 
/*    */ public class ClientKillParams
/*    */   extends Params {
/*    */   private static final String ID = "ID";
/*    */   private static final String TYPE = "TYPE";
/*    */   private static final String ADDR = "ADDR";
/*    */   private static final String SKIPME = "SKIPME";
/*    */   private static final String USER = "USER";
/*    */   private static final String LADDR = "LADDR";
/*    */   
/*    */   public enum SkipMe {
/* 15 */     YES, NO;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ClientKillParams clientKillParams() {
/* 22 */     return new ClientKillParams();
/*    */   }
/*    */   
/*    */   public ClientKillParams id(String clientId) {
/* 26 */     addParam("ID", clientId);
/* 27 */     return this;
/*    */   }
/*    */   
/*    */   public ClientKillParams id(byte[] clientId) {
/* 31 */     addParam("ID", clientId);
/* 32 */     return this;
/*    */   }
/*    */   
/*    */   public ClientKillParams type(ClientType type) {
/* 36 */     addParam("TYPE", type);
/* 37 */     return this;
/*    */   }
/*    */   
/*    */   public ClientKillParams addr(String ipPort) {
/* 41 */     addParam("ADDR", ipPort);
/* 42 */     return this;
/*    */   }
/*    */   
/*    */   public ClientKillParams addr(byte[] ipPort) {
/* 46 */     addParam("ADDR", ipPort);
/* 47 */     return this;
/*    */   }
/*    */   
/*    */   public ClientKillParams addr(String ip, int port) {
/* 51 */     addParam("ADDR", ip + ':' + port);
/* 52 */     return this;
/*    */   }
/*    */   
/*    */   public ClientKillParams skipMe(SkipMe skipMe) {
/* 56 */     addParam("SKIPME", skipMe);
/* 57 */     return this;
/*    */   }
/*    */   
/*    */   public ClientKillParams user(String username) {
/* 61 */     addParam("USER", username);
/* 62 */     return this;
/*    */   }
/*    */   
/*    */   public ClientKillParams laddr(String ipPort) {
/* 66 */     addParam("LADDR", ipPort);
/* 67 */     return this;
/*    */   }
/*    */   
/*    */   public ClientKillParams laddr(String ip, int port) {
/* 71 */     addParam("LADDR", ip + ':' + port);
/* 72 */     return this;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\ClientKillParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */