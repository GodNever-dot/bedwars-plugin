/*      */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ExpiryOption;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.GeoUnit;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ListDirection;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.SortedSetOption;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.commands.ProtocolCommand;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoRadiusParam;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoRadiusStoreParam;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.GeoSearchParam;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.MigrateParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ScanParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.SortingParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.StrAlgoLCSParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XAutoClaimParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XClaimParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ZAddParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ZParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ZRangeParams;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.GeoRadiusResponse;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.KeyedListElement;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LCSMatchResult;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LibraryInfo;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.ScanResult;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamEntry;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.Tuple;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.JedisURIHelper;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.KeyValue;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*      */ import java.net.URI;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.net.ssl.HostnameVerifier;
/*      */ import javax.net.ssl.SSLParameters;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ 
/*      */ public class Jedis implements ServerCommands, DatabaseCommands, JedisCommands, JedisBinaryCommands, ControlCommands, ControlBinaryCommands, ClusterCommands, ModuleCommands, GenericControlCommands, SentinelCommands, Closeable {
/*   39 */   private final CommandObjects commandObjects = new CommandObjects(); protected final Connection connection;
/*   40 */   private int db = 0;
/*   41 */   private Transaction transaction = null;
/*      */   private boolean isInMulti = false;
/*      */   private boolean isInWatch = false;
/*   44 */   private Pipeline pipeline = null;
/*   45 */   protected static final byte[][] DUMMY_ARRAY = new byte[0][];
/*      */   
/*   47 */   private Pool<Jedis> dataSource = null;
/*      */   
/*      */   public Jedis() {
/*   50 */     this.connection = new Connection();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Jedis(String url) {
/*   59 */     this(URI.create(url));
/*      */   }
/*      */   
/*      */   public Jedis(HostAndPort hp) {
/*   63 */     this.connection = new Connection(hp);
/*      */   }
/*      */   
/*      */   public Jedis(String host, int port) {
/*   67 */     this.connection = new Connection(host, port);
/*      */   }
/*      */   
/*      */   public Jedis(String host, int port, JedisClientConfig config) {
/*   71 */     this(new HostAndPort(host, port), config);
/*      */   }
/*      */   
/*      */   public Jedis(HostAndPort hostPort, JedisClientConfig config) {
/*   75 */     this.connection = new Connection(hostPort, config);
/*      */   }
/*      */   
/*      */   public Jedis(String host, int port, boolean ssl) {
/*   79 */     this(host, port, DefaultJedisClientConfig.builder().ssl(ssl).build());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Jedis(String host, int port, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*   85 */     this(host, port, DefaultJedisClientConfig.builder().ssl(ssl)
/*   86 */         .sslSocketFactory(sslSocketFactory).sslParameters(sslParameters)
/*   87 */         .hostnameVerifier(hostnameVerifier).build());
/*      */   }
/*      */   
/*      */   public Jedis(String host, int port, int timeout) {
/*   91 */     this(host, port, timeout, timeout);
/*      */   }
/*      */   
/*      */   public Jedis(String host, int port, int timeout, boolean ssl) {
/*   95 */     this(host, port, timeout, timeout, ssl);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Jedis(String host, int port, int timeout, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  101 */     this(host, port, timeout, timeout, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*      */   }
/*      */ 
/*      */   
/*      */   public Jedis(String host, int port, int connectionTimeout, int soTimeout) {
/*  106 */     this(host, port, DefaultJedisClientConfig.builder()
/*  107 */         .connectionTimeoutMillis(connectionTimeout).socketTimeoutMillis(soTimeout).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public Jedis(String host, int port, int connectionTimeout, int soTimeout, int infiniteSoTimeout) {
/*  112 */     this(host, port, DefaultJedisClientConfig.builder()
/*  113 */         .connectionTimeoutMillis(connectionTimeout).socketTimeoutMillis(soTimeout)
/*  114 */         .blockingSocketTimeoutMillis(infiniteSoTimeout).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public Jedis(String host, int port, int connectionTimeout, int soTimeout, boolean ssl) {
/*  119 */     this(host, port, DefaultJedisClientConfig.builder()
/*  120 */         .connectionTimeoutMillis(connectionTimeout).socketTimeoutMillis(soTimeout).ssl(ssl)
/*  121 */         .build());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Jedis(String host, int port, int connectionTimeout, int soTimeout, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  127 */     this(host, port, DefaultJedisClientConfig.builder()
/*  128 */         .connectionTimeoutMillis(connectionTimeout).socketTimeoutMillis(soTimeout).ssl(ssl)
/*  129 */         .sslSocketFactory(sslSocketFactory).sslParameters(sslParameters)
/*  130 */         .hostnameVerifier(hostnameVerifier).build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Jedis(String host, int port, int connectionTimeout, int soTimeout, int infiniteSoTimeout, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  137 */     this(host, port, DefaultJedisClientConfig.builder()
/*  138 */         .connectionTimeoutMillis(connectionTimeout).socketTimeoutMillis(soTimeout)
/*  139 */         .blockingSocketTimeoutMillis(infiniteSoTimeout).ssl(ssl)
/*  140 */         .sslSocketFactory(sslSocketFactory).sslParameters(sslParameters)
/*  141 */         .hostnameVerifier(hostnameVerifier).build());
/*      */   }
/*      */   
/*      */   public Jedis(URI uri) {
/*  145 */     if (!JedisURIHelper.isValid(uri)) {
/*  146 */       throw new InvalidURIException(String.format("Cannot open Redis connection due invalid URI \"%s\".", new Object[] { uri
/*  147 */               .toString() }));
/*      */     }
/*  149 */     this
/*      */ 
/*      */       
/*  152 */       .connection = new Connection(new HostAndPort(uri.getHost(), uri.getPort()), DefaultJedisClientConfig.builder().user(JedisURIHelper.getUser(uri)).password(JedisURIHelper.getPassword(uri)).database(JedisURIHelper.getDBIndex(uri)).ssl(JedisURIHelper.isRedisSSLScheme(uri)).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public Jedis(URI uri, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  157 */     this(uri, DefaultJedisClientConfig.builder().sslSocketFactory(sslSocketFactory)
/*  158 */         .sslParameters(sslParameters).hostnameVerifier(hostnameVerifier).build());
/*      */   }
/*      */   
/*      */   public Jedis(URI uri, int timeout) {
/*  162 */     this(uri, timeout, timeout);
/*      */   }
/*      */ 
/*      */   
/*      */   public Jedis(URI uri, int timeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  167 */     this(uri, timeout, timeout, sslSocketFactory, sslParameters, hostnameVerifier);
/*      */   }
/*      */   
/*      */   public Jedis(URI uri, int connectionTimeout, int soTimeout) {
/*  171 */     this(uri, DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout)
/*  172 */         .socketTimeoutMillis(soTimeout).build());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Jedis(URI uri, int connectionTimeout, int soTimeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  178 */     this(uri, DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout)
/*  179 */         .socketTimeoutMillis(soTimeout).sslSocketFactory(sslSocketFactory)
/*  180 */         .sslParameters(sslParameters).hostnameVerifier(hostnameVerifier).build());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Jedis(URI uri, int connectionTimeout, int soTimeout, int infiniteSoTimeout, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  186 */     this(uri, DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout)
/*  187 */         .socketTimeoutMillis(soTimeout).blockingSocketTimeoutMillis(infiniteSoTimeout)
/*  188 */         .sslSocketFactory(sslSocketFactory).sslParameters(sslParameters)
/*  189 */         .hostnameVerifier(hostnameVerifier).build());
/*      */   }
/*      */   
/*      */   public Jedis(URI uri, JedisClientConfig config) {
/*  193 */     if (!JedisURIHelper.isValid(uri)) {
/*  194 */       throw new InvalidURIException(String.format("Cannot open Redis connection due invalid URI \"%s\".", new Object[] { uri
/*  195 */               .toString() }));
/*      */     }
/*  197 */     this
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  206 */       .connection = new Connection(new HostAndPort(uri.getHost(), uri.getPort()), DefaultJedisClientConfig.builder().connectionTimeoutMillis(config.getConnectionTimeoutMillis()).socketTimeoutMillis(config.getSocketTimeoutMillis()).blockingSocketTimeoutMillis(config.getBlockingSocketTimeoutMillis()).user(JedisURIHelper.getUser(uri)).password(JedisURIHelper.getPassword(uri)).database(JedisURIHelper.getDBIndex(uri)).clientName(config.getClientName()).ssl(JedisURIHelper.isRedisSSLScheme(uri)).sslSocketFactory(config.getSslSocketFactory()).sslParameters(config.getSslParameters()).hostnameVerifier(config.getHostnameVerifier()).build());
/*      */   }
/*      */   
/*      */   public Jedis(JedisSocketFactory jedisSocketFactory) {
/*  210 */     this.connection = new Connection(jedisSocketFactory);
/*      */   }
/*      */   
/*      */   public Jedis(JedisSocketFactory jedisSocketFactory, JedisClientConfig clientConfig) {
/*  214 */     this.connection = new Connection(jedisSocketFactory, clientConfig);
/*      */   }
/*      */   
/*      */   public Jedis(Connection connection) {
/*  218 */     this.connection = connection;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  223 */     return "Jedis{" + this.connection + '}';
/*      */   }
/*      */ 
/*      */   
/*      */   public Connection getClient() {
/*  228 */     return getConnection();
/*      */   }
/*      */   
/*      */   public Connection getConnection() {
/*  232 */     return this.connection;
/*      */   }
/*      */ 
/*      */   
/*      */   public void connect() {
/*  237 */     this.connection.connect();
/*      */   }
/*      */ 
/*      */   
/*      */   public void disconnect() {
/*  242 */     this.connection.disconnect();
/*      */   }
/*      */   
/*      */   public boolean isConnected() {
/*  246 */     return this.connection.isConnected();
/*      */   }
/*      */   
/*      */   public boolean isBroken() {
/*  250 */     return this.connection.isBroken();
/*      */   }
/*      */   
/*      */   public void resetState() {
/*  254 */     if (isConnected()) {
/*  255 */       if (this.transaction != null) {
/*  256 */         this.transaction.close();
/*      */       }
/*      */       
/*  259 */       if (this.pipeline != null) {
/*  260 */         this.pipeline.close();
/*      */       }
/*      */ 
/*      */       
/*  264 */       if (this.isInWatch) {
/*  265 */         this.connection.sendCommand(Protocol.Command.UNWATCH);
/*  266 */         this.connection.getStatusCodeReply();
/*  267 */         this.isInWatch = false;
/*      */       } 
/*      */     } 
/*      */     
/*  271 */     this.transaction = null;
/*  272 */     this.pipeline = null;
/*      */   }
/*      */   
/*      */   protected void setDataSource(Pool<Jedis> jedisPool) {
/*  276 */     this.dataSource = jedisPool;
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() {
/*  281 */     if (this.dataSource != null) {
/*  282 */       Pool<Jedis> pool = this.dataSource;
/*  283 */       this.dataSource = null;
/*  284 */       if (isBroken()) {
/*  285 */         pool.returnBrokenResource(this);
/*      */       } else {
/*  287 */         pool.returnResource(this);
/*      */       } 
/*      */     } else {
/*  290 */       this.connection.close();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Transaction multi() {
/*  296 */     this.transaction = new Transaction(this);
/*  297 */     return this.transaction;
/*      */   }
/*      */ 
/*      */   
/*      */   public Pipeline pipelined() {
/*  302 */     this.pipeline = new Pipeline(this);
/*  303 */     return this.pipeline;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkIsInMultiOrPipeline() {
/*  309 */     if (this.transaction != null) {
/*  310 */       throw new IllegalStateException("Cannot use Jedis when in Multi. Please use Transaction or reset jedis state.");
/*      */     }
/*  312 */     if (this.pipeline != null && this.pipeline.hasPipelinedResponse()) {
/*  313 */       throw new IllegalStateException("Cannot use Jedis when in Pipeline. Please use Pipeline or reset jedis state.");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDB() {
/*  319 */     return this.db;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean copy(byte[] srcKey, byte[] dstKey, int db, boolean replace) {
/*  332 */     checkIsInMultiOrPipeline();
/*  333 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.copy(srcKey, dstKey, db, replace))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean copy(byte[] srcKey, byte[] dstKey, boolean replace) {
/*  345 */     checkIsInMultiOrPipeline();
/*  346 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.copy(srcKey, dstKey, replace))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String ping() {
/*  354 */     checkIsInMultiOrPipeline();
/*  355 */     this.connection.sendCommand(Protocol.Command.PING);
/*  356 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] ping(byte[] message) {
/*  365 */     checkIsInMultiOrPipeline();
/*  366 */     this.connection.sendCommand(Protocol.Command.PING, new byte[][] { message });
/*  367 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String set(byte[] key, byte[] value) {
/*  381 */     checkIsInMultiOrPipeline();
/*  382 */     return this.connection.<String>executeCommand(this.commandObjects.set(key, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String set(byte[] key, byte[] value, SetParams params) {
/*  395 */     checkIsInMultiOrPipeline();
/*  396 */     return this.connection.<String>executeCommand(this.commandObjects.set(key, value, params));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] get(byte[] key) {
/*  410 */     checkIsInMultiOrPipeline();
/*  411 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.get(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getDel(byte[] key) {
/*  424 */     checkIsInMultiOrPipeline();
/*  425 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.getDel(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getEx(byte[] key, GetExParams params) {
/*  430 */     checkIsInMultiOrPipeline();
/*  431 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.getEx(key, params));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String quit() {
/*  439 */     checkIsInMultiOrPipeline();
/*  440 */     return this.connection.quit();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long exists(byte[]... keys) {
/*  451 */     checkIsInMultiOrPipeline();
/*  452 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.exists(keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean exists(byte[] key) {
/*  464 */     checkIsInMultiOrPipeline();
/*  465 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.exists(key))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long del(byte[]... keys) {
/*  476 */     checkIsInMultiOrPipeline();
/*  477 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.del(keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long del(byte[] key) {
/*  482 */     checkIsInMultiOrPipeline();
/*  483 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.del(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long unlink(byte[]... keys) {
/*  501 */     checkIsInMultiOrPipeline();
/*  502 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.unlink(keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long unlink(byte[] key) {
/*  507 */     checkIsInMultiOrPipeline();
/*  508 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.unlink(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String type(byte[] key) {
/*  521 */     checkIsInMultiOrPipeline();
/*  522 */     return this.connection.<String>executeCommand(this.commandObjects.type(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String flushDB() {
/*  531 */     checkIsInMultiOrPipeline();
/*  532 */     this.connection.sendCommand(Protocol.Command.FLUSHDB);
/*  533 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String flushDB(FlushMode flushMode) {
/*  543 */     checkIsInMultiOrPipeline();
/*  544 */     this.connection.sendCommand(Protocol.Command.FLUSHDB, new byte[][] { flushMode.getRaw() });
/*  545 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<byte[]> keys(byte[] pattern) {
/*  578 */     checkIsInMultiOrPipeline();
/*  579 */     return this.connection.<Set<byte[]>>executeCommand(this.commandObjects.keys(pattern));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] randomBinaryKey() {
/*  590 */     checkIsInMultiOrPipeline();
/*  591 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.randomBinaryKey());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String rename(byte[] oldkey, byte[] newkey) {
/*  605 */     checkIsInMultiOrPipeline();
/*  606 */     return this.connection.<String>executeCommand(this.commandObjects.rename(oldkey, newkey));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long renamenx(byte[] oldkey, byte[] newkey) {
/*  619 */     checkIsInMultiOrPipeline();
/*  620 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.renamenx(oldkey, newkey))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long dbSize() {
/*  629 */     checkIsInMultiOrPipeline();
/*  630 */     this.connection.sendCommand(Protocol.Command.DBSIZE);
/*  631 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long expire(byte[] key, long seconds) {
/*  657 */     checkIsInMultiOrPipeline();
/*  658 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.expire(key, seconds))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long expire(byte[] key, long seconds, ExpiryOption expiryOption) {
/*  663 */     checkIsInMultiOrPipeline();
/*  664 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.expire(key, seconds, expiryOption))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long pexpire(byte[] key, long milliseconds) {
/*  690 */     checkIsInMultiOrPipeline();
/*  691 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pexpire(key, milliseconds))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pexpire(byte[] key, long milliseconds, ExpiryOption expiryOption) {
/*  696 */     checkIsInMultiOrPipeline();
/*  697 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pexpire(key, milliseconds, expiryOption))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long expireTime(byte[] key) {
/*  702 */     checkIsInMultiOrPipeline();
/*  703 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.expireTime(key))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pexpireTime(byte[] key) {
/*  708 */     checkIsInMultiOrPipeline();
/*  709 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pexpireTime(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long expireAt(byte[] key, long unixTime) {
/*  738 */     checkIsInMultiOrPipeline();
/*  739 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.expireAt(key, unixTime))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long expireAt(byte[] key, long unixTime, ExpiryOption expiryOption) {
/*  744 */     checkIsInMultiOrPipeline();
/*  745 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.expireAt(key, unixTime, expiryOption))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pexpireAt(byte[] key, long millisecondsTimestamp) {
/*  750 */     checkIsInMultiOrPipeline();
/*  751 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pexpireAt(key, millisecondsTimestamp))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pexpireAt(byte[] key, long millisecondsTimestamp, ExpiryOption expiryOption) {
/*  756 */     checkIsInMultiOrPipeline();
/*  757 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pexpireAt(key, millisecondsTimestamp, expiryOption))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long ttl(byte[] key) {
/*  769 */     checkIsInMultiOrPipeline();
/*  770 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.ttl(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long touch(byte[]... keys) {
/*  781 */     checkIsInMultiOrPipeline();
/*  782 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.touch(keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long touch(byte[] key) {
/*  787 */     checkIsInMultiOrPipeline();
/*  788 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.touch(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String select(int index) {
/*  799 */     checkIsInMultiOrPipeline();
/*  800 */     this.connection.sendCommand(Protocol.Command.SELECT, new byte[][] { Protocol.toByteArray(index) });
/*  801 */     String statusCodeReply = this.connection.getStatusCodeReply();
/*  802 */     this.db = index;
/*  803 */     return statusCodeReply;
/*      */   }
/*      */ 
/*      */   
/*      */   public String swapDB(int index1, int index2) {
/*  808 */     checkIsInMultiOrPipeline();
/*  809 */     this.connection.sendCommand(Protocol.Command.SWAPDB, new byte[][] { Protocol.toByteArray(index1), Protocol.toByteArray(index2) });
/*  810 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long move(byte[] key, int dbIndex) {
/*  825 */     checkIsInMultiOrPipeline();
/*  826 */     this.connection.sendCommand(Protocol.Command.MOVE, new byte[][] { key, Protocol.toByteArray(dbIndex) });
/*  827 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String flushAll() {
/*  837 */     checkIsInMultiOrPipeline();
/*  838 */     this.connection.sendCommand(Protocol.Command.FLUSHALL);
/*  839 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String flushAll(FlushMode flushMode) {
/*  850 */     checkIsInMultiOrPipeline();
/*  851 */     this.connection.sendCommand(Protocol.Command.FLUSHALL, new byte[][] { flushMode.getRaw() });
/*  852 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getSet(byte[] key, byte[] value) {
/*  867 */     checkIsInMultiOrPipeline();
/*  868 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.getSet(key, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> mget(byte[]... keys) {
/*  882 */     checkIsInMultiOrPipeline();
/*  883 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.mget(keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long setnx(byte[] key, byte[] value) {
/*  897 */     checkIsInMultiOrPipeline();
/*  898 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.setnx(key, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String setex(byte[] key, long seconds, byte[] value) {
/*  914 */     checkIsInMultiOrPipeline();
/*  915 */     return this.connection.<String>executeCommand(this.commandObjects.setex(key, seconds, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String mset(byte[]... keysvalues) {
/*  936 */     checkIsInMultiOrPipeline();
/*  937 */     return this.connection.<String>executeCommand(this.commandObjects.mset(keysvalues));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long msetnx(byte[]... keysvalues) {
/*  959 */     checkIsInMultiOrPipeline();
/*  960 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.msetnx(keysvalues))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long decrBy(byte[] key, long decrement) {
/*  983 */     checkIsInMultiOrPipeline();
/*  984 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.decrBy(key, decrement))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long decr(byte[] key) {
/* 1006 */     checkIsInMultiOrPipeline();
/* 1007 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.decr(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long incrBy(byte[] key, long increment) {
/* 1030 */     checkIsInMultiOrPipeline();
/* 1031 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.incrBy(key, increment))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double incrByFloat(byte[] key, double increment) {
/* 1055 */     checkIsInMultiOrPipeline();
/* 1056 */     return ((Double)this.connection.<Double>executeCommand(this.commandObjects.incrByFloat(key, increment))).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long incr(byte[] key) {
/* 1078 */     checkIsInMultiOrPipeline();
/* 1079 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.incr(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long append(byte[] key, byte[] value) {
/* 1096 */     checkIsInMultiOrPipeline();
/* 1097 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.append(key, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] substr(byte[] key, int start, int end) {
/* 1118 */     checkIsInMultiOrPipeline();
/* 1119 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.substr(key, start, end));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long hset(byte[] key, byte[] field, byte[] value) {
/* 1136 */     checkIsInMultiOrPipeline();
/* 1137 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hset(key, field, value))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long hset(byte[] key, Map<byte[], byte[]> hash) {
/* 1142 */     checkIsInMultiOrPipeline();
/* 1143 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hset(key, hash))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] hget(byte[] key, byte[] field) {
/* 1158 */     checkIsInMultiOrPipeline();
/* 1159 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.hget(key, field));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long hsetnx(byte[] key, byte[] field, byte[] value) {
/* 1173 */     checkIsInMultiOrPipeline();
/* 1174 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hsetnx(key, field, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String hmset(byte[] key, Map<byte[], byte[]> hash) {
/* 1189 */     checkIsInMultiOrPipeline();
/* 1190 */     return this.connection.<String>executeCommand(this.commandObjects.hmset(key, hash));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> hmget(byte[] key, byte[]... fields) {
/* 1206 */     checkIsInMultiOrPipeline();
/* 1207 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.hmget(key, fields));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long hincrBy(byte[] key, byte[] field, long value) {
/* 1226 */     checkIsInMultiOrPipeline();
/* 1227 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hincrBy(key, field, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double hincrByFloat(byte[] key, byte[] field, double value) {
/* 1247 */     checkIsInMultiOrPipeline();
/* 1248 */     return ((Double)this.connection.<Double>executeCommand(this.commandObjects.hincrByFloat(key, field, value))).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hexists(byte[] key, byte[] field) {
/* 1260 */     checkIsInMultiOrPipeline();
/* 1261 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.hexists(key, field))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long hdel(byte[] key, byte[]... fields) {
/* 1275 */     checkIsInMultiOrPipeline();
/* 1276 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hdel(key, fields))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long hlen(byte[] key) {
/* 1289 */     checkIsInMultiOrPipeline();
/* 1290 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hlen(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<byte[]> hkeys(byte[] key) {
/* 1302 */     checkIsInMultiOrPipeline();
/* 1303 */     return this.connection.<Set<byte[]>>executeCommand(this.commandObjects.hkeys(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> hvals(byte[] key) {
/* 1315 */     checkIsInMultiOrPipeline();
/* 1316 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.hvals(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<byte[], byte[]> hgetAll(byte[] key) {
/* 1328 */     checkIsInMultiOrPipeline();
/* 1329 */     return this.connection.<Map<byte[], byte[]>>executeCommand(this.commandObjects.hgetAll(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] hrandfield(byte[] key) {
/* 1341 */     checkIsInMultiOrPipeline();
/* 1342 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.hrandfield(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> hrandfield(byte[] key, long count) {
/* 1354 */     checkIsInMultiOrPipeline();
/* 1355 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.hrandfield(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<byte[], byte[]> hrandfieldWithValues(byte[] key, long count) {
/* 1367 */     checkIsInMultiOrPipeline();
/* 1368 */     return this.connection.<Map<byte[], byte[]>>executeCommand(this.commandObjects.hrandfieldWithValues(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long rpush(byte[] key, byte[]... strings) {
/* 1383 */     checkIsInMultiOrPipeline();
/* 1384 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.rpush(key, strings))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long lpush(byte[] key, byte[]... strings) {
/* 1399 */     checkIsInMultiOrPipeline();
/* 1400 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.lpush(key, strings))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long llen(byte[] key) {
/* 1414 */     checkIsInMultiOrPipeline();
/* 1415 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.llen(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> lrange(byte[] key, long start, long stop) {
/* 1452 */     checkIsInMultiOrPipeline();
/* 1453 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.lrange(key, start, stop));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String ltrim(byte[] key, long start, long stop) {
/* 1488 */     checkIsInMultiOrPipeline();
/* 1489 */     return this.connection.<String>executeCommand(this.commandObjects.ltrim(key, start, stop));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] lindex(byte[] key, long index) {
/* 1510 */     checkIsInMultiOrPipeline();
/* 1511 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.lindex(key, index));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String lset(byte[] key, long index, byte[] value) {
/* 1535 */     checkIsInMultiOrPipeline();
/* 1536 */     return this.connection.<String>executeCommand(this.commandObjects.lset(key, index, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long lrem(byte[] key, long count, byte[] value) {
/* 1556 */     checkIsInMultiOrPipeline();
/* 1557 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.lrem(key, count, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] lpop(byte[] key) {
/* 1572 */     checkIsInMultiOrPipeline();
/* 1573 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.lpop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> lpop(byte[] key, int count) {
/* 1578 */     checkIsInMultiOrPipeline();
/* 1579 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.lpop(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Long lpos(byte[] key, byte[] element) {
/* 1596 */     checkIsInMultiOrPipeline();
/* 1597 */     return this.connection.<Long>executeCommand(this.commandObjects.lpos(key, element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Long lpos(byte[] key, byte[] element, LPosParams params) {
/* 1620 */     checkIsInMultiOrPipeline();
/* 1621 */     return this.connection.<Long>executeCommand(this.commandObjects.lpos(key, element, params));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Long> lpos(byte[] key, byte[] element, LPosParams params, long count) {
/* 1641 */     checkIsInMultiOrPipeline();
/* 1642 */     return this.connection.<List<Long>>executeCommand(this.commandObjects.lpos(key, element, params, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] rpop(byte[] key) {
/* 1657 */     checkIsInMultiOrPipeline();
/* 1658 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.rpop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> rpop(byte[] key, int count) {
/* 1663 */     checkIsInMultiOrPipeline();
/* 1664 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.rpop(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] rpoplpush(byte[] srckey, byte[] dstkey) {
/* 1684 */     checkIsInMultiOrPipeline();
/* 1685 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.rpoplpush(srckey, dstkey));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sadd(byte[] key, byte[]... members) {
/* 1701 */     checkIsInMultiOrPipeline();
/* 1702 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sadd(key, members))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<byte[]> smembers(byte[] key) {
/* 1715 */     checkIsInMultiOrPipeline();
/* 1716 */     return this.connection.<Set<byte[]>>executeCommand(this.commandObjects.smembers(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long srem(byte[] key, byte[]... members) {
/* 1730 */     checkIsInMultiOrPipeline();
/* 1731 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.srem(key, members))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] spop(byte[] key) {
/* 1747 */     checkIsInMultiOrPipeline();
/* 1748 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.spop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<byte[]> spop(byte[] key, long count) {
/* 1753 */     checkIsInMultiOrPipeline();
/* 1754 */     return this.connection.<Set<byte[]>>executeCommand(this.commandObjects.spop(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long smove(byte[] srckey, byte[] dstkey, byte[] member) {
/* 1777 */     checkIsInMultiOrPipeline();
/* 1778 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.smove(srckey, dstkey, member))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long scard(byte[] key) {
/* 1789 */     checkIsInMultiOrPipeline();
/* 1790 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.scard(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean sismember(byte[] key, byte[] member) {
/* 1803 */     checkIsInMultiOrPipeline();
/* 1804 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.sismember(key, member))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Boolean> smismember(byte[] key, byte[]... members) {
/* 1817 */     checkIsInMultiOrPipeline();
/* 1818 */     return this.connection.<List<Boolean>>executeCommand(this.commandObjects.smismember(key, members));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<byte[]> sinter(byte[]... keys) {
/* 1838 */     checkIsInMultiOrPipeline();
/* 1839 */     return this.connection.<Set<byte[]>>executeCommand(this.commandObjects.sinter(keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sinterstore(byte[] dstkey, byte[]... keys) {
/* 1854 */     checkIsInMultiOrPipeline();
/* 1855 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sinterstore(dstkey, keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sintercard(byte[]... keys) {
/* 1868 */     checkIsInMultiOrPipeline();
/* 1869 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sintercard(keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sintercard(int limit, byte[]... keys) {
/* 1884 */     checkIsInMultiOrPipeline();
/* 1885 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sintercard(limit, keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<byte[]> sunion(byte[]... keys) {
/* 1903 */     checkIsInMultiOrPipeline();
/* 1904 */     return this.connection.<Set<byte[]>>executeCommand(this.commandObjects.sunion(keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sunionstore(byte[] dstkey, byte[]... keys) {
/* 1919 */     checkIsInMultiOrPipeline();
/* 1920 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sunionstore(dstkey, keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<byte[]> sdiff(byte[]... keys) {
/* 1945 */     checkIsInMultiOrPipeline();
/* 1946 */     return this.connection.<Set<byte[]>>executeCommand(this.commandObjects.sdiff(keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sdiffstore(byte[] dstkey, byte[]... keys) {
/* 1958 */     checkIsInMultiOrPipeline();
/* 1959 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sdiffstore(dstkey, keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] srandmember(byte[] key) {
/* 1974 */     checkIsInMultiOrPipeline();
/* 1975 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.srandmember(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> srandmember(byte[] key, int count) {
/* 1980 */     checkIsInMultiOrPipeline();
/* 1981 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.srandmember(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zadd(byte[] key, double score, byte[] member) {
/* 2002 */     checkIsInMultiOrPipeline();
/* 2003 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zadd(key, score, member))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long zadd(byte[] key, double score, byte[] member, ZAddParams params) {
/* 2009 */     checkIsInMultiOrPipeline();
/* 2010 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zadd(key, score, member, params))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zadd(byte[] key, Map<byte[], Double> scoreMembers) {
/* 2015 */     checkIsInMultiOrPipeline();
/* 2016 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zadd(key, scoreMembers))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zadd(byte[] key, Map<byte[], Double> scoreMembers, ZAddParams params) {
/* 2021 */     checkIsInMultiOrPipeline();
/* 2022 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zadd(key, scoreMembers, params))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public Double zaddIncr(byte[] key, double score, byte[] member, ZAddParams params) {
/* 2027 */     checkIsInMultiOrPipeline();
/* 2028 */     return this.connection.<Double>executeCommand(this.commandObjects.zaddIncr(key, score, member, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> zrange(byte[] key, long start, long stop) {
/* 2033 */     checkIsInMultiOrPipeline();
/* 2034 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrange(key, start, stop));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zrem(byte[] key, byte[]... members) {
/* 2049 */     checkIsInMultiOrPipeline();
/* 2050 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zrem(key, members))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double zincrby(byte[] key, double increment, byte[] member) {
/* 2073 */     checkIsInMultiOrPipeline();
/* 2074 */     return ((Double)this.connection.<Double>executeCommand(this.commandObjects.zincrby(key, increment, member))).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Double zincrby(byte[] key, double increment, byte[] member, ZIncrByParams params) {
/* 2080 */     checkIsInMultiOrPipeline();
/* 2081 */     return this.connection.<Double>executeCommand(this.commandObjects.zincrby(key, increment, member, params));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Long zrank(byte[] key, byte[] member) {
/* 2101 */     checkIsInMultiOrPipeline();
/* 2102 */     return this.connection.<Long>executeCommand(this.commandObjects.zrank(key, member));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Long zrevrank(byte[] key, byte[] member) {
/* 2122 */     checkIsInMultiOrPipeline();
/* 2123 */     return this.connection.<Long>executeCommand(this.commandObjects.zrevrank(key, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> zrevrange(byte[] key, long start, long stop) {
/* 2128 */     checkIsInMultiOrPipeline();
/* 2129 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrevrange(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeWithScores(byte[] key, long start, long stop) {
/* 2134 */     checkIsInMultiOrPipeline();
/* 2135 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeWithScores(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrevrangeWithScores(byte[] key, long start, long stop) {
/* 2140 */     checkIsInMultiOrPipeline();
/* 2141 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrevrangeWithScores(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> zrange(byte[] key, ZRangeParams zRangeParams) {
/* 2146 */     checkIsInMultiOrPipeline();
/* 2147 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrange(key, zRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeWithScores(byte[] key, ZRangeParams zRangeParams) {
/* 2152 */     checkIsInMultiOrPipeline();
/* 2153 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeWithScores(key, zRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public long zrangestore(byte[] dest, byte[] src, ZRangeParams zRangeParams) {
/* 2158 */     checkIsInMultiOrPipeline();
/* 2159 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zrangestore(dest, src, zRangeParams))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] zrandmember(byte[] key) {
/* 2164 */     checkIsInMultiOrPipeline();
/* 2165 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.zrandmember(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> zrandmember(byte[] key, long count) {
/* 2170 */     checkIsInMultiOrPipeline();
/* 2171 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrandmember(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrandmemberWithScores(byte[] key, long count) {
/* 2176 */     checkIsInMultiOrPipeline();
/* 2177 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrandmemberWithScores(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zcard(byte[] key) {
/* 2190 */     checkIsInMultiOrPipeline();
/* 2191 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zcard(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Double zscore(byte[] key, byte[] member) {
/* 2206 */     checkIsInMultiOrPipeline();
/* 2207 */     return this.connection.<Double>executeCommand(this.commandObjects.zscore(key, member));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Double> zmscore(byte[] key, byte[]... members) {
/* 2221 */     checkIsInMultiOrPipeline();
/* 2222 */     return this.connection.<List<Double>>executeCommand(this.commandObjects.zmscore(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Tuple zpopmax(byte[] key) {
/* 2227 */     checkIsInMultiOrPipeline();
/* 2228 */     return this.connection.<Tuple>executeCommand(this.commandObjects.zpopmax(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zpopmax(byte[] key, int count) {
/* 2233 */     checkIsInMultiOrPipeline();
/* 2234 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zpopmax(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Tuple zpopmin(byte[] key) {
/* 2239 */     checkIsInMultiOrPipeline();
/* 2240 */     return this.connection.<Tuple>executeCommand(this.commandObjects.zpopmin(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zpopmin(byte[] key, int count) {
/* 2245 */     checkIsInMultiOrPipeline();
/* 2246 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zpopmin(key, count));
/*      */   }
/*      */   
/*      */   public String watch(byte[]... keys) {
/* 2250 */     checkIsInMultiOrPipeline();
/* 2251 */     this.connection.sendCommand(Protocol.Command.WATCH, keys);
/*      */     
/* 2253 */     String status = this.connection.getStatusCodeReply();
/* 2254 */     this.isInWatch = true;
/* 2255 */     return status;
/*      */   }
/*      */   
/*      */   public String unwatch() {
/* 2259 */     checkIsInMultiOrPipeline();
/* 2260 */     this.connection.sendCommand(Protocol.Command.UNWATCH);
/* 2261 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> sort(byte[] key) {
/* 2279 */     checkIsInMultiOrPipeline();
/* 2280 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.sort(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> sort(byte[] key, SortingParams sortingParams) {
/* 2359 */     checkIsInMultiOrPipeline();
/* 2360 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.sort(key, sortingParams));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sort(byte[] key, SortingParams sortingParams, byte[] dstkey) {
/* 2375 */     checkIsInMultiOrPipeline();
/* 2376 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sort(key, sortingParams, dstkey))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sort(byte[] key, byte[] dstkey) {
/* 2394 */     checkIsInMultiOrPipeline();
/* 2395 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sort(key, dstkey))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> sortReadonly(byte[] key, SortingParams sortingParams) {
/* 2400 */     checkIsInMultiOrPipeline();
/* 2401 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.sortReadonly(key, sortingParams));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] lmove(byte[] srcKey, byte[] dstKey, ListDirection from, ListDirection to) {
/* 2414 */     checkIsInMultiOrPipeline();
/* 2415 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.lmove(srcKey, dstKey, from, to));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] blmove(byte[] srcKey, byte[] dstKey, ListDirection from, ListDirection to, double timeout) {
/* 2429 */     checkIsInMultiOrPipeline();
/* 2430 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.blmove(srcKey, dstKey, from, to, timeout));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> blpop(int timeout, byte[]... keys) {
/* 2496 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.blpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> blpop(double timeout, byte[]... keys) {
/* 2501 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.blpop(timeout, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> brpop(int timeout, byte[]... keys) {
/* 2567 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.brpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> brpop(double timeout, byte[]... keys) {
/* 2572 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.brpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<byte[], List<byte[]>> lmpop(ListDirection direction, byte[]... keys) {
/* 2577 */     checkIsInMultiOrPipeline();
/* 2578 */     return this.connection.<KeyValue<byte[], List<byte[]>>>executeCommand(this.commandObjects.lmpop(direction, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<byte[], List<byte[]>> lmpop(ListDirection direction, int count, byte[]... keys) {
/* 2583 */     checkIsInMultiOrPipeline();
/* 2584 */     return this.connection.<KeyValue<byte[], List<byte[]>>>executeCommand(this.commandObjects.lmpop(direction, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<byte[], List<byte[]>> blmpop(long timeout, ListDirection direction, byte[]... keys) {
/* 2589 */     checkIsInMultiOrPipeline();
/* 2590 */     return this.connection.<KeyValue<byte[], List<byte[]>>>executeCommand(this.commandObjects.blmpop(timeout, direction, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<byte[], List<byte[]>> blmpop(long timeout, ListDirection direction, int count, byte[]... keys) {
/* 2595 */     checkIsInMultiOrPipeline();
/* 2596 */     return this.connection.<KeyValue<byte[], List<byte[]>>>executeCommand(this.commandObjects.blmpop(timeout, direction, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> bzpopmax(double timeout, byte[]... keys) {
/* 2601 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.bzpopmax(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> bzpopmin(double timeout, byte[]... keys) {
/* 2606 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.bzpopmin(timeout, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String auth(String password) {
/* 2623 */     checkIsInMultiOrPipeline();
/* 2624 */     this.connection.sendCommand(Protocol.Command.AUTH, new String[] { password });
/* 2625 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String auth(String user, String password) {
/* 2638 */     checkIsInMultiOrPipeline();
/* 2639 */     this.connection.sendCommand(Protocol.Command.AUTH, new String[] { user, password });
/* 2640 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zcount(byte[] key, double min, double max) {
/* 2645 */     checkIsInMultiOrPipeline();
/* 2646 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zcount(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zcount(byte[] key, byte[] min, byte[] max) {
/* 2651 */     checkIsInMultiOrPipeline();
/* 2652 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zcount(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<byte[]> zdiff(byte[]... keys) {
/* 2657 */     checkIsInMultiOrPipeline();
/* 2658 */     return this.connection.<Set<byte[]>>executeCommand(this.commandObjects.zdiff(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<Tuple> zdiffWithScores(byte[]... keys) {
/* 2663 */     checkIsInMultiOrPipeline();
/* 2664 */     return this.connection.<Set<Tuple>>executeCommand(this.commandObjects.zdiffWithScores(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public long zdiffStore(byte[] dstkey, byte[]... keys) {
/* 2669 */     checkIsInMultiOrPipeline();
/* 2670 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zdiffStore(dstkey, keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> zrangeByScore(byte[] key, double min, double max) {
/* 2722 */     checkIsInMultiOrPipeline();
/* 2723 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> zrangeByScore(byte[] key, byte[] min, byte[] max) {
/* 2728 */     checkIsInMultiOrPipeline();
/* 2729 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> zrangeByScore(byte[] key, double min, double max, int offset, int count) {
/* 2784 */     checkIsInMultiOrPipeline();
/* 2785 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrangeByScore(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> zrangeByScore(byte[] key, byte[] min, byte[] max, int offset, int count) {
/* 2791 */     checkIsInMultiOrPipeline();
/* 2792 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrangeByScore(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeByScoreWithScores(byte[] key, double min, double max) {
/* 2844 */     checkIsInMultiOrPipeline();
/* 2845 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max) {
/* 2850 */     checkIsInMultiOrPipeline();
/* 2851 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeByScoreWithScores(byte[] key, double min, double max, int offset, int count) {
/* 2906 */     checkIsInMultiOrPipeline();
/* 2907 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max, int offset, int count) {
/* 2913 */     checkIsInMultiOrPipeline();
/* 2914 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> zrevrangeByScore(byte[] key, double max, double min) {
/* 2919 */     checkIsInMultiOrPipeline();
/* 2920 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrevrangeByScore(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> zrevrangeByScore(byte[] key, byte[] max, byte[] min) {
/* 2925 */     checkIsInMultiOrPipeline();
/* 2926 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrevrangeByScore(key, max, min));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> zrevrangeByScore(byte[] key, double max, double min, int offset, int count) {
/* 2932 */     checkIsInMultiOrPipeline();
/* 2933 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrevrangeByScore(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> zrevrangeByScore(byte[] key, byte[] max, byte[] min, int offset, int count) {
/* 2939 */     checkIsInMultiOrPipeline();
/* 2940 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrevrangeByScore(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrevrangeByScoreWithScores(byte[] key, double max, double min) {
/* 2945 */     checkIsInMultiOrPipeline();
/* 2946 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Tuple> zrevrangeByScoreWithScores(byte[] key, double max, double min, int offset, int count) {
/* 2952 */     checkIsInMultiOrPipeline();
/* 2953 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min) {
/* 2958 */     checkIsInMultiOrPipeline();
/* 2959 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Tuple> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min, int offset, int count) {
/* 2965 */     checkIsInMultiOrPipeline();
/* 2966 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zremrangeByRank(byte[] key, long start, long stop) {
/* 2985 */     checkIsInMultiOrPipeline();
/* 2986 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zremrangeByRank(key, start, stop))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zremrangeByScore(byte[] key, double min, double max) {
/* 3004 */     checkIsInMultiOrPipeline();
/* 3005 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zremrangeByScore(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zremrangeByScore(byte[] key, byte[] min, byte[] max) {
/* 3010 */     checkIsInMultiOrPipeline();
/* 3011 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zremrangeByScore(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<byte[]> zunion(ZParams params, byte[]... keys) {
/* 3023 */     checkIsInMultiOrPipeline();
/* 3024 */     return this.connection.<Set<byte[]>>executeCommand(this.commandObjects.zunion(params, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Tuple> zunionWithScores(ZParams params, byte[]... keys) {
/* 3036 */     checkIsInMultiOrPipeline();
/* 3037 */     return this.connection.<Set<Tuple>>executeCommand(this.commandObjects.zunionWithScores(params, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zunionstore(byte[] dstkey, byte[]... sets) {
/* 3067 */     checkIsInMultiOrPipeline();
/* 3068 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zunionstore(dstkey, sets))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zunionstore(byte[] dstkey, ZParams params, byte[]... sets) {
/* 3100 */     checkIsInMultiOrPipeline();
/* 3101 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zunionstore(dstkey, params, sets))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<byte[]> zinter(ZParams params, byte[]... keys) {
/* 3113 */     checkIsInMultiOrPipeline();
/* 3114 */     return this.connection.<Set<byte[]>>executeCommand(this.commandObjects.zinter(params, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Tuple> zinterWithScores(ZParams params, byte[]... keys) {
/* 3126 */     checkIsInMultiOrPipeline();
/* 3127 */     return this.connection.<Set<Tuple>>executeCommand(this.commandObjects.zinterWithScores(params, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zinterstore(byte[] dstkey, byte[]... sets) {
/* 3158 */     checkIsInMultiOrPipeline();
/* 3159 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zinterstore(dstkey, sets))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zinterstore(byte[] dstkey, ZParams params, byte[]... sets) {
/* 3191 */     checkIsInMultiOrPipeline();
/* 3192 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zinterstore(dstkey, params, sets))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zintercard(byte[]... keys) {
/* 3197 */     checkIsInMultiOrPipeline();
/* 3198 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zintercard(keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zintercard(long limit, byte[]... keys) {
/* 3203 */     checkIsInMultiOrPipeline();
/* 3204 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zintercard(limit, keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zlexcount(byte[] key, byte[] min, byte[] max) {
/* 3209 */     checkIsInMultiOrPipeline();
/* 3210 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zlexcount(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> zrangeByLex(byte[] key, byte[] min, byte[] max) {
/* 3215 */     checkIsInMultiOrPipeline();
/* 3216 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrangeByLex(key, min, max));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> zrangeByLex(byte[] key, byte[] min, byte[] max, int offset, int count) {
/* 3222 */     checkIsInMultiOrPipeline();
/* 3223 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrangeByLex(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> zrevrangeByLex(byte[] key, byte[] max, byte[] min) {
/* 3228 */     checkIsInMultiOrPipeline();
/* 3229 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrevrangeByLex(key, max, min));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> zrevrangeByLex(byte[] key, byte[] max, byte[] min, int offset, int count) {
/* 3235 */     checkIsInMultiOrPipeline();
/* 3236 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.zrevrangeByLex(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public long zremrangeByLex(byte[] key, byte[] min, byte[] max) {
/* 3241 */     checkIsInMultiOrPipeline();
/* 3242 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zremrangeByLex(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<byte[], List<Tuple>> zmpop(SortedSetOption option, byte[]... keys) {
/* 3247 */     checkIsInMultiOrPipeline();
/* 3248 */     return this.connection.<KeyValue<byte[], List<Tuple>>>executeCommand(this.commandObjects.zmpop(option, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<byte[], List<Tuple>> zmpop(SortedSetOption option, int count, byte[]... keys) {
/* 3253 */     checkIsInMultiOrPipeline();
/* 3254 */     return this.connection.<KeyValue<byte[], List<Tuple>>>executeCommand(this.commandObjects.zmpop(option, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<byte[], List<Tuple>> bzmpop(long timeout, SortedSetOption option, byte[]... keys) {
/* 3259 */     checkIsInMultiOrPipeline();
/* 3260 */     return this.connection.<KeyValue<byte[], List<Tuple>>>executeCommand(this.commandObjects.bzmpop(timeout, option, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<byte[], List<Tuple>> bzmpop(long timeout, SortedSetOption option, int count, byte[]... keys) {
/* 3265 */     checkIsInMultiOrPipeline();
/* 3266 */     return this.connection.<KeyValue<byte[], List<Tuple>>>executeCommand(this.commandObjects.bzmpop(timeout, option, count, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String save() {
/* 3284 */     this.connection.sendCommand(Protocol.Command.SAVE);
/* 3285 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String bgsave() {
/* 3298 */     this.connection.sendCommand(Protocol.Command.BGSAVE);
/* 3299 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String bgsaveSchedule() {
/* 3304 */     this.connection.sendCommand(Protocol.Command.BGSAVE, Protocol.Keyword.SCHEDULE);
/* 3305 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String bgrewriteaof() {
/* 3324 */     this.connection.sendCommand(Protocol.Command.BGREWRITEAOF);
/* 3325 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long lastsave() {
/* 3338 */     this.connection.sendCommand(Protocol.Command.LASTSAVE);
/* 3339 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void shutdown() throws JedisException {
/* 3354 */     this.connection.sendCommand(Protocol.Command.SHUTDOWN);
/*      */     try {
/* 3356 */       throw new JedisException(this.connection.getStatusCodeReply());
/* 3357 */     } catch (JedisConnectionException jce) {
/*      */       
/* 3359 */       this.connection.setBroken();
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void shutdown(SaveMode saveMode) throws JedisException {
/* 3369 */     this.connection.sendCommand(Protocol.Command.SHUTDOWN, new byte[][] { saveMode.getRaw() });
/*      */     try {
/* 3371 */       throw new JedisException(this.connection.getStatusCodeReply());
/* 3372 */     } catch (JedisConnectionException jce) {
/*      */       
/* 3374 */       this.connection.setBroken();
/*      */       return;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void shutdown(ShutdownParams shutdownParams) throws JedisException {
/* 3380 */     this.connection.sendCommand((new CommandArguments(Protocol.Command.SHUTDOWN)).addParams((IParams)shutdownParams));
/*      */     try {
/* 3382 */       throw new JedisException(this.connection.getStatusCodeReply());
/* 3383 */     } catch (JedisConnectionException jce) {
/*      */       
/* 3385 */       this.connection.setBroken();
/*      */       return;
/*      */     } 
/*      */   }
/*      */   
/*      */   public String shutdownAbort() {
/* 3391 */     this.connection.sendCommand(Protocol.Command.SHUTDOWN, Protocol.Keyword.ABORT);
/* 3392 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String info() {
/* 3433 */     this.connection.sendCommand(Protocol.Command.INFO);
/* 3434 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String info(String section) {
/* 3439 */     this.connection.sendCommand(Protocol.Command.INFO, new String[] { section });
/* 3440 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void monitor(JedisMonitor jedisMonitor) {
/* 3453 */     this.connection.sendCommand(Protocol.Command.MONITOR);
/* 3454 */     this.connection.getStatusCodeReply();
/* 3455 */     jedisMonitor.proceed(this.connection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String slaveof(String host, int port) {
/* 3482 */     this.connection.sendCommand(Protocol.Command.SLAVEOF, new byte[][] { SafeEncoder.encode(host), Protocol.toByteArray(port) });
/* 3483 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String slaveofNoOne() {
/* 3492 */     this.connection.sendCommand(Protocol.Command.SLAVEOF, new byte[][] { Protocol.Keyword.NO.getRaw(), Protocol.Keyword.ONE.getRaw() });
/* 3493 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String replicaof(String host, int port) {
/* 3498 */     this.connection.sendCommand(Protocol.Command.REPLICAOF, new byte[][] { SafeEncoder.encode(host), Protocol.toByteArray(port) });
/* 3499 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String replicaofNoOne() {
/* 3504 */     this.connection.sendCommand(Protocol.Command.REPLICAOF, new byte[][] { Protocol.Keyword.NO.getRaw(), Protocol.Keyword.ONE.getRaw() });
/* 3505 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> roleBinary() {
/* 3510 */     checkIsInMultiOrPipeline();
/* 3511 */     this.connection.sendCommand(Protocol.Command.ROLE);
/* 3512 */     return BuilderFactory.RAW_OBJECT_LIST.build(this.connection.getOne());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> configGet(byte[] pattern) {
/* 3551 */     checkIsInMultiOrPipeline();
/* 3552 */     this.connection.sendCommand(Protocol.Command.CONFIG, new byte[][] { Protocol.Keyword.GET.getRaw(), pattern });
/* 3553 */     return this.connection.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> configGet(byte[]... patterns) {
/* 3558 */     checkIsInMultiOrPipeline();
/* 3559 */     this.connection.sendCommand(Protocol.Command.CONFIG, joinParameters(Protocol.Keyword.GET.getRaw(), patterns));
/* 3560 */     return this.connection.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String configResetStat() {
/* 3568 */     checkIsInMultiOrPipeline();
/* 3569 */     this.connection.sendCommand(Protocol.Command.CONFIG, Protocol.Keyword.RESETSTAT);
/* 3570 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String configRewrite() {
/* 3601 */     checkIsInMultiOrPipeline();
/* 3602 */     this.connection.sendCommand(Protocol.Command.CONFIG, Protocol.Keyword.REWRITE);
/* 3603 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String configSet(byte[] parameter, byte[] value) {
/* 3637 */     checkIsInMultiOrPipeline();
/* 3638 */     this.connection.sendCommand(Protocol.Command.CONFIG, new byte[][] { Protocol.Keyword.SET.getRaw(), parameter, value });
/* 3639 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String configSet(byte[]... parameterValues) {
/* 3644 */     checkIsInMultiOrPipeline();
/* 3645 */     this.connection.sendCommand(Protocol.Command.CONFIG, joinParameters(Protocol.Keyword.SET.getRaw(), parameterValues));
/* 3646 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public long strlen(byte[] key) {
/* 3651 */     checkIsInMultiOrPipeline();
/* 3652 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.strlen(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public LCSMatchResult strAlgoLCSKeys(byte[] keyA, byte[] keyB, StrAlgoLCSParams params) {
/* 3662 */     checkIsInMultiOrPipeline();
/* 3663 */     return this.connection.<LCSMatchResult>executeCommand(this.commandObjects.strAlgoLCSKeys(keyA, keyB, params));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public LCSMatchResult strAlgoLCSStrings(byte[] strA, byte[] strB, StrAlgoLCSParams params) {
/* 3671 */     checkIsInMultiOrPipeline();
/* 3672 */     return this.connection.<LCSMatchResult>executeCommand(this.commandObjects.strAlgoLCSStrings(strA, strB, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public LCSMatchResult lcs(byte[] keyA, byte[] keyB, LCSParams params) {
/* 3677 */     checkIsInMultiOrPipeline();
/* 3678 */     return this.connection.<LCSMatchResult>executeCommand(this.commandObjects.lcs(keyA, keyB, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public long lpushx(byte[] key, byte[]... strings) {
/* 3683 */     checkIsInMultiOrPipeline();
/* 3684 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.lpushx(key, strings))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long persist(byte[] key) {
/* 3696 */     checkIsInMultiOrPipeline();
/* 3697 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.persist(key))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long rpushx(byte[] key, byte[]... strings) {
/* 3702 */     checkIsInMultiOrPipeline();
/* 3703 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.rpushx(key, strings))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] echo(byte[] string) {
/* 3708 */     checkIsInMultiOrPipeline();
/* 3709 */     this.connection.sendCommand(Protocol.Command.ECHO, new byte[][] { string });
/* 3710 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long linsert(byte[] key, ListPosition where, byte[] pivot, byte[] value) {
/* 3716 */     checkIsInMultiOrPipeline();
/* 3717 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.linsert(key, where, pivot, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] brpoplpush(byte[] source, byte[] destination, int timeout) {
/* 3725 */     checkIsInMultiOrPipeline();
/* 3726 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.brpoplpush(source, destination, timeout));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setbit(byte[] key, long offset, boolean value) {
/* 3734 */     checkIsInMultiOrPipeline();
/* 3735 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.setbit(key, offset, value))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getbit(byte[] key, long offset) {
/* 3743 */     checkIsInMultiOrPipeline();
/* 3744 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.getbit(key, offset))).booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitpos(byte[] key, boolean value) {
/* 3749 */     return bitpos(key, value, new BitPosParams());
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitpos(byte[] key, boolean value, BitPosParams params) {
/* 3754 */     checkIsInMultiOrPipeline();
/* 3755 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitpos(key, value, params))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long setrange(byte[] key, long offset, byte[] value) {
/* 3760 */     checkIsInMultiOrPipeline();
/* 3761 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.setrange(key, offset, value))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getrange(byte[] key, long startOffset, long endOffset) {
/* 3766 */     checkIsInMultiOrPipeline();
/* 3767 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.getrange(key, startOffset, endOffset));
/*      */   }
/*      */   
/*      */   public long publish(byte[] channel, byte[] message) {
/* 3771 */     checkIsInMultiOrPipeline();
/* 3772 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.publish(channel, message))).longValue();
/*      */   }
/*      */   
/*      */   public void subscribe(BinaryJedisPubSub jedisPubSub, byte[]... channels) {
/* 3776 */     jedisPubSub.proceed(this.connection, channels);
/*      */   }
/*      */   
/*      */   public void psubscribe(BinaryJedisPubSub jedisPubSub, byte[]... patterns) {
/* 3780 */     jedisPubSub.proceedWithPatterns(this.connection, patterns);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object eval(byte[] script, List<byte[]> keys, List<byte[]> args) {
/* 3792 */     checkIsInMultiOrPipeline();
/* 3793 */     return this.connection.executeCommand(this.commandObjects.eval(script, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object evalReadonly(byte[] script, List<byte[]> keys, List<byte[]> args) {
/* 3798 */     checkIsInMultiOrPipeline();
/* 3799 */     return this.connection.executeCommand(this.commandObjects.evalReadonly(script, keys, args));
/*      */   }
/*      */   
/*      */   protected static byte[][] getParamsWithBinary(List<byte[]> keys, List<byte[]> args) {
/* 3803 */     int keyCount = keys.size();
/* 3804 */     int argCount = args.size();
/* 3805 */     byte[][] params = new byte[keyCount + argCount][];
/*      */     int i;
/* 3807 */     for (i = 0; i < keyCount; i++) {
/* 3808 */       params[i] = keys.get(i);
/*      */     }
/* 3810 */     for (i = 0; i < argCount; i++) {
/* 3811 */       params[keyCount + i] = args.get(i);
/*      */     }
/* 3813 */     return params;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object eval(byte[] script, int keyCount, byte[]... params) {
/* 3818 */     checkIsInMultiOrPipeline();
/* 3819 */     return this.connection.executeCommand(this.commandObjects.eval(script, keyCount, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object eval(byte[] script) {
/* 3824 */     checkIsInMultiOrPipeline();
/* 3825 */     return this.connection.executeCommand(this.commandObjects.eval(script));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object evalsha(byte[] sha1) {
/* 3830 */     checkIsInMultiOrPipeline();
/* 3831 */     return this.connection.executeCommand(this.commandObjects.evalsha(sha1));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object evalsha(byte[] sha1, List<byte[]> keys, List<byte[]> args) {
/* 3836 */     checkIsInMultiOrPipeline();
/* 3837 */     return this.connection.executeCommand(this.commandObjects.evalsha(sha1, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object evalshaReadonly(byte[] sha1, List<byte[]> keys, List<byte[]> args) {
/* 3842 */     checkIsInMultiOrPipeline();
/* 3843 */     return this.connection.executeCommand(this.commandObjects.evalshaReadonly(sha1, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object evalsha(byte[] sha1, int keyCount, byte[]... params) {
/* 3848 */     checkIsInMultiOrPipeline();
/* 3849 */     return this.connection.executeCommand(this.commandObjects.evalsha(sha1, keyCount, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public String scriptFlush() {
/* 3854 */     this.connection.sendCommand(Protocol.Command.SCRIPT, Protocol.Keyword.FLUSH);
/* 3855 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String scriptFlush(FlushMode flushMode) {
/* 3860 */     this.connection.sendCommand(Protocol.Command.SCRIPT, new byte[][] { Protocol.Keyword.FLUSH.getRaw(), flushMode.getRaw() });
/* 3861 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean scriptExists(byte[] sha1) {
/* 3866 */     byte[][] a = new byte[1][];
/* 3867 */     a[0] = sha1;
/* 3868 */     return scriptExists(a).get(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Boolean> scriptExists(byte[]... sha1) {
/* 3873 */     this.connection.sendCommand(Protocol.Command.SCRIPT, joinParameters(Protocol.Keyword.EXISTS.getRaw(), sha1));
/* 3874 */     return BuilderFactory.BOOLEAN_LIST.build(this.connection.getOne());
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] scriptLoad(byte[] script) {
/* 3879 */     this.connection.sendCommand(Protocol.Command.SCRIPT, new byte[][] { Protocol.Keyword.LOAD.getRaw(), script });
/* 3880 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String scriptKill() {
/* 3885 */     this.connection.sendCommand(Protocol.Command.SCRIPT, Protocol.Keyword.KILL);
/* 3886 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String slowlogReset() {
/* 3891 */     this.connection.sendCommand(Protocol.Command.SLOWLOG, Protocol.Keyword.RESET);
/* 3892 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public long slowlogLen() {
/* 3897 */     this.connection.sendCommand(Protocol.Command.SLOWLOG, Protocol.Keyword.LEN);
/* 3898 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> slowlogGetBinary() {
/* 3903 */     this.connection.sendCommand(Protocol.Command.SLOWLOG, Protocol.Keyword.GET);
/* 3904 */     return this.connection.getObjectMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> slowlogGetBinary(long entries) {
/* 3909 */     this.connection.sendCommand(Protocol.Command.SLOWLOG, new byte[][] { Protocol.Keyword.GET.getRaw(), Protocol.toByteArray(entries) });
/* 3910 */     return this.connection.getObjectMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Long objectRefcount(byte[] key) {
/* 3915 */     this.connection.sendCommand(Protocol.Command.OBJECT, new byte[][] { Protocol.Keyword.REFCOUNT.getRaw(), key });
/* 3916 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] objectEncoding(byte[] key) {
/* 3921 */     this.connection.sendCommand(Protocol.Command.OBJECT, new byte[][] { Protocol.Keyword.ENCODING.getRaw(), key });
/* 3922 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Long objectIdletime(byte[] key) {
/* 3927 */     this.connection.sendCommand(Protocol.Command.OBJECT, new byte[][] { Protocol.Keyword.IDLETIME.getRaw(), key });
/* 3928 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> objectHelpBinary() {
/* 3933 */     this.connection.sendCommand(Protocol.Command.OBJECT, Protocol.Keyword.HELP);
/* 3934 */     return this.connection.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Long objectFreq(byte[] key) {
/* 3939 */     this.connection.sendCommand(Protocol.Command.OBJECT, new byte[][] { Protocol.Keyword.FREQ.getRaw(), key });
/* 3940 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitcount(byte[] key) {
/* 3945 */     checkIsInMultiOrPipeline();
/* 3946 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitcount(key))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitcount(byte[] key, long start, long end) {
/* 3951 */     checkIsInMultiOrPipeline();
/* 3952 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitcount(key, start, end))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitcount(byte[] key, long start, long end, BitCountOption option) {
/* 3957 */     checkIsInMultiOrPipeline();
/* 3958 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitcount(key, start, end, option))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitop(BitOP op, byte[] destKey, byte[]... srcKeys) {
/* 3963 */     checkIsInMultiOrPipeline();
/* 3964 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitop(op, destKey, srcKeys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] dump(byte[] key) {
/* 3969 */     checkIsInMultiOrPipeline();
/* 3970 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.dump(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public String restore(byte[] key, long ttl, byte[] serializedValue) {
/* 3975 */     checkIsInMultiOrPipeline();
/* 3976 */     return this.connection.<String>executeCommand(this.commandObjects.restore(key, ttl, serializedValue));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String restore(byte[] key, long ttl, byte[] serializedValue, RestoreParams params) {
/* 3982 */     checkIsInMultiOrPipeline();
/* 3983 */     return this.connection.<String>executeCommand(this.commandObjects.restore(key, ttl, serializedValue, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public long pttl(byte[] key) {
/* 3988 */     checkIsInMultiOrPipeline();
/* 3989 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pttl(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String psetex(byte[] key, long milliseconds, byte[] value) {
/* 4002 */     checkIsInMultiOrPipeline();
/* 4003 */     return this.connection.<String>executeCommand(this.commandObjects.psetex(key, milliseconds, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] memoryDoctorBinary() {
/* 4008 */     checkIsInMultiOrPipeline();
/* 4009 */     this.connection.sendCommand(Protocol.Command.MEMORY, Protocol.Keyword.DOCTOR);
/* 4010 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Long memoryUsage(byte[] key) {
/* 4015 */     checkIsInMultiOrPipeline();
/* 4016 */     this.connection.sendCommand(Protocol.Command.MEMORY, new byte[][] { Protocol.Keyword.USAGE.getRaw(), key });
/* 4017 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Long memoryUsage(byte[] key, int samples) {
/* 4022 */     checkIsInMultiOrPipeline();
/* 4023 */     this.connection.sendCommand(Protocol.Command.MEMORY, new byte[][] { Protocol.Keyword.USAGE.getRaw(), key, Protocol.Keyword.SAMPLES.getRaw(), Protocol.toByteArray(samples) });
/* 4024 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String failover() {
/* 4029 */     checkIsInMultiOrPipeline();
/* 4030 */     this.connection.sendCommand(Protocol.Command.FAILOVER);
/* 4031 */     this.connection.setTimeoutInfinite();
/*      */     try {
/* 4033 */       return this.connection.getStatusCodeReply();
/*      */     } finally {
/* 4035 */       this.connection.rollbackTimeout();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String failover(FailoverParams failoverParams) {
/* 4041 */     checkIsInMultiOrPipeline();
/* 4042 */     CommandArguments args = (new ClusterCommandArguments(Protocol.Command.FAILOVER)).addParams((IParams)failoverParams);
/* 4043 */     this.connection.sendCommand(args);
/* 4044 */     this.connection.setTimeoutInfinite();
/*      */     try {
/* 4046 */       return this.connection.getStatusCodeReply();
/*      */     } finally {
/* 4048 */       this.connection.rollbackTimeout();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String failoverAbort() {
/* 4054 */     checkIsInMultiOrPipeline();
/* 4055 */     this.connection.sendCommand(Protocol.Command.FAILOVER, Protocol.Keyword.ABORT);
/* 4056 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] aclWhoAmIBinary() {
/* 4061 */     checkIsInMultiOrPipeline();
/* 4062 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.WHOAMI);
/* 4063 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] aclGenPassBinary() {
/* 4068 */     checkIsInMultiOrPipeline();
/* 4069 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.GENPASS);
/* 4070 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] aclGenPassBinary(int bits) {
/* 4075 */     checkIsInMultiOrPipeline();
/* 4076 */     this.connection.sendCommand(Protocol.Command.ACL, new byte[][] { Protocol.Keyword.GENPASS.getRaw(), Protocol.toByteArray(bits) });
/* 4077 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> aclListBinary() {
/* 4082 */     checkIsInMultiOrPipeline();
/* 4083 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.LIST);
/* 4084 */     return this.connection.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> aclUsersBinary() {
/* 4089 */     checkIsInMultiOrPipeline();
/* 4090 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.USERS);
/* 4091 */     return this.connection.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public AccessControlUser aclGetUser(byte[] name) {
/* 4096 */     checkIsInMultiOrPipeline();
/* 4097 */     this.connection.sendCommand(Protocol.Command.ACL, new byte[][] { Protocol.Keyword.GETUSER.getRaw(), name });
/* 4098 */     return BuilderFactory.ACCESS_CONTROL_USER.build(this.connection.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclSetUser(byte[] name) {
/* 4103 */     checkIsInMultiOrPipeline();
/* 4104 */     this.connection.sendCommand(Protocol.Command.ACL, new byte[][] { Protocol.Keyword.SETUSER.getRaw(), name });
/* 4105 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclSetUser(byte[] name, byte[]... keys) {
/* 4110 */     checkIsInMultiOrPipeline();
/* 4111 */     this.connection.sendCommand(Protocol.Command.ACL, joinParameters(Protocol.Keyword.SETUSER.getRaw(), name, keys));
/* 4112 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public long aclDelUser(byte[] name) {
/* 4117 */     checkIsInMultiOrPipeline();
/* 4118 */     this.connection.sendCommand(Protocol.Command.ACL, new byte[][] { Protocol.Keyword.DELUSER.getRaw(), name });
/* 4119 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long aclDelUser(byte[] name, byte[]... names) {
/* 4124 */     checkIsInMultiOrPipeline();
/* 4125 */     this.connection.sendCommand(Protocol.Command.ACL, joinParameters(Protocol.Keyword.DELUSER.getRaw(), name, names));
/* 4126 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> aclCatBinary() {
/* 4131 */     checkIsInMultiOrPipeline();
/* 4132 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.CAT);
/* 4133 */     return this.connection.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> aclCat(byte[] category) {
/* 4138 */     checkIsInMultiOrPipeline();
/* 4139 */     this.connection.sendCommand(Protocol.Command.ACL, new byte[][] { Protocol.Keyword.CAT.getRaw(), category });
/* 4140 */     return this.connection.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> aclLogBinary() {
/* 4145 */     checkIsInMultiOrPipeline();
/* 4146 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.LOG);
/* 4147 */     return this.connection.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> aclLogBinary(int limit) {
/* 4152 */     checkIsInMultiOrPipeline();
/* 4153 */     this.connection.sendCommand(Protocol.Command.ACL, new byte[][] { Protocol.Keyword.LOG.getRaw(), Protocol.toByteArray(limit) });
/* 4154 */     return this.connection.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclLogReset() {
/* 4159 */     checkIsInMultiOrPipeline();
/* 4160 */     this.connection.sendCommand(Protocol.Command.ACL, new byte[][] { Protocol.Keyword.LOG.getRaw(), Protocol.Keyword.RESET.getRaw() });
/* 4161 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientKill(byte[] ipPort) {
/* 4166 */     checkIsInMultiOrPipeline();
/* 4167 */     this.connection.sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.KILL.getRaw(), ipPort });
/* 4168 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientKill(String ip, int port) {
/* 4173 */     return clientKill(ip + ':' + port);
/*      */   }
/*      */ 
/*      */   
/*      */   public long clientKill(ClientKillParams params) {
/* 4178 */     checkIsInMultiOrPipeline();
/* 4179 */     this.connection.sendCommand(Protocol.Command.CLIENT, joinParameters(Protocol.Keyword.KILL.getRaw(), params.getByteParams()));
/* 4180 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] clientGetnameBinary() {
/* 4185 */     checkIsInMultiOrPipeline();
/* 4186 */     this.connection.sendCommand(Protocol.Command.CLIENT, Protocol.Keyword.GETNAME);
/* 4187 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] clientListBinary() {
/* 4192 */     checkIsInMultiOrPipeline();
/* 4193 */     this.connection.sendCommand(Protocol.Command.CLIENT, Protocol.Keyword.LIST);
/* 4194 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] clientListBinary(ClientType type) {
/* 4199 */     checkIsInMultiOrPipeline();
/* 4200 */     this.connection.sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.LIST.getRaw(), type.getRaw() });
/* 4201 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] clientListBinary(long... clientIds) {
/* 4206 */     checkIsInMultiOrPipeline();
/* 4207 */     this.connection.sendCommand(Protocol.Command.CLIENT, clientListParams(clientIds));
/* 4208 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */   
/*      */   private byte[][] clientListParams(long... clientIds) {
/* 4212 */     byte[][] params = new byte[2 + clientIds.length][];
/* 4213 */     int index = 0;
/* 4214 */     params[index++] = Protocol.Keyword.LIST.getRaw();
/* 4215 */     params[index++] = Protocol.Keyword.ID.getRaw();
/* 4216 */     for (long clientId : clientIds) {
/* 4217 */       params[index++] = Protocol.toByteArray(clientId);
/*      */     }
/* 4219 */     return params;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] clientInfoBinary() {
/* 4224 */     checkIsInMultiOrPipeline();
/* 4225 */     this.connection.sendCommand(Protocol.Command.CLIENT, Protocol.Keyword.INFO);
/* 4226 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientSetname(byte[] name) {
/* 4231 */     checkIsInMultiOrPipeline();
/* 4232 */     this.connection.sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.SETNAME.getRaw(), name });
/* 4233 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public long clientId() {
/* 4238 */     checkIsInMultiOrPipeline();
/* 4239 */     this.connection.sendCommand(Protocol.Command.CLIENT, Protocol.Keyword.ID);
/* 4240 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long clientUnblock(long clientId) {
/* 4249 */     checkIsInMultiOrPipeline();
/* 4250 */     this.connection.sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.UNBLOCK.getRaw(), Protocol.toByteArray(clientId) });
/* 4251 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long clientUnblock(long clientId, UnblockType unblockType) {
/* 4261 */     checkIsInMultiOrPipeline();
/* 4262 */     this.connection.sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.UNBLOCK.getRaw(), Protocol.toByteArray(clientId), unblockType.getRaw() });
/* 4263 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientPause(long timeout) {
/* 4268 */     checkIsInMultiOrPipeline();
/* 4269 */     this.connection.sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.PAUSE.getRaw(), Protocol.toByteArray(timeout) });
/* 4270 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientPause(long timeout, ClientPauseMode mode) {
/* 4275 */     checkIsInMultiOrPipeline();
/* 4276 */     this.connection.sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.PAUSE.getRaw(), Protocol.toByteArray(timeout), mode.getRaw() });
/* 4277 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientNoEvictOn() {
/* 4282 */     checkIsInMultiOrPipeline();
/* 4283 */     this.connection.sendCommand(Protocol.Command.CLIENT, new String[] { "NO-EVICT", "ON" });
/* 4284 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientNoEvictOff() {
/* 4289 */     checkIsInMultiOrPipeline();
/* 4290 */     this.connection.sendCommand(Protocol.Command.CLIENT, new String[] { "NO-EVICT", "OFF" });
/* 4291 */     return this.connection.getBulkReply();
/*      */   }
/*      */   
/*      */   public List<String> time() {
/* 4295 */     checkIsInMultiOrPipeline();
/* 4296 */     this.connection.sendCommand(Protocol.Command.TIME);
/* 4297 */     return this.connection.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String migrate(String host, int port, byte[] key, int destinationDb, int timeout) {
/* 4303 */     checkIsInMultiOrPipeline();
/* 4304 */     return this.connection.<String>executeCommand(this.commandObjects.migrate(host, port, key, destinationDb, timeout));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String migrate(String host, int port, int destinationDB, int timeout, MigrateParams params, byte[]... keys) {
/* 4310 */     checkIsInMultiOrPipeline();
/* 4311 */     return this.connection.<String>executeCommand(this.commandObjects.migrate(host, port, destinationDB, timeout, params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public String migrate(String host, int port, byte[] key, int timeout) {
/* 4316 */     checkIsInMultiOrPipeline();
/* 4317 */     return this.connection.<String>executeCommand(this.commandObjects.migrate(host, port, key, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public String migrate(String host, int port, int timeout, MigrateParams params, byte[]... keys) {
/* 4322 */     checkIsInMultiOrPipeline();
/* 4323 */     return this.connection.<String>executeCommand(this.commandObjects.migrate(host, port, timeout, params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public long waitReplicas(int replicas, long timeout) {
/* 4328 */     checkIsInMultiOrPipeline();
/* 4329 */     this.connection.sendCommand(Protocol.Command.WAIT, new byte[][] { Protocol.toByteArray(replicas), Protocol.toByteArray(timeout) });
/* 4330 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pfadd(byte[] key, byte[]... elements) {
/* 4335 */     checkIsInMultiOrPipeline();
/* 4336 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pfadd(key, elements))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pfcount(byte[] key) {
/* 4341 */     checkIsInMultiOrPipeline();
/* 4342 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pfcount(key))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String pfmerge(byte[] destkey, byte[]... sourcekeys) {
/* 4347 */     checkIsInMultiOrPipeline();
/* 4348 */     return this.connection.<String>executeCommand(this.commandObjects.pfmerge(destkey, sourcekeys));
/*      */   }
/*      */ 
/*      */   
/*      */   public long pfcount(byte[]... keys) {
/* 4353 */     checkIsInMultiOrPipeline();
/* 4354 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pfcount(keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<byte[]> scan(byte[] cursor) {
/* 4359 */     checkIsInMultiOrPipeline();
/* 4360 */     return this.connection.<ScanResult<byte[]>>executeCommand(this.commandObjects.scan(cursor));
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<byte[]> scan(byte[] cursor, ScanParams params) {
/* 4365 */     checkIsInMultiOrPipeline();
/* 4366 */     return this.connection.<ScanResult<byte[]>>executeCommand(this.commandObjects.scan(cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<byte[]> scan(byte[] cursor, ScanParams params, byte[] type) {
/* 4371 */     checkIsInMultiOrPipeline();
/* 4372 */     return this.connection.<ScanResult<byte[]>>executeCommand(this.commandObjects.scan(cursor, params, type));
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<Map.Entry<byte[], byte[]>> hscan(byte[] key, byte[] cursor) {
/* 4377 */     return hscan(key, cursor, new ScanParams());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ScanResult<Map.Entry<byte[], byte[]>> hscan(byte[] key, byte[] cursor, ScanParams params) {
/* 4383 */     checkIsInMultiOrPipeline();
/* 4384 */     return this.connection.<ScanResult<Map.Entry<byte[], byte[]>>>executeCommand(this.commandObjects.hscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<byte[]> sscan(byte[] key, byte[] cursor) {
/* 4389 */     return sscan(key, cursor, new ScanParams());
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<byte[]> sscan(byte[] key, byte[] cursor, ScanParams params) {
/* 4394 */     checkIsInMultiOrPipeline();
/* 4395 */     return this.connection.<ScanResult<byte[]>>executeCommand(this.commandObjects.sscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<Tuple> zscan(byte[] key, byte[] cursor) {
/* 4400 */     return zscan(key, cursor, new ScanParams());
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<Tuple> zscan(byte[] key, byte[] cursor, ScanParams params) {
/* 4405 */     checkIsInMultiOrPipeline();
/* 4406 */     return this.connection.<ScanResult<Tuple>>executeCommand(this.commandObjects.zscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long geoadd(byte[] key, double longitude, double latitude, byte[] member) {
/* 4412 */     checkIsInMultiOrPipeline();
/* 4413 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geoadd(key, longitude, latitude, member))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geoadd(byte[] key, Map<byte[], GeoCoordinate> memberCoordinateMap) {
/* 4418 */     checkIsInMultiOrPipeline();
/* 4419 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geoadd(key, memberCoordinateMap))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geoadd(byte[] key, GeoAddParams params, Map<byte[], GeoCoordinate> memberCoordinateMap) {
/* 4424 */     checkIsInMultiOrPipeline();
/* 4425 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geoadd(key, params, memberCoordinateMap))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public Double geodist(byte[] key, byte[] member1, byte[] member2) {
/* 4430 */     checkIsInMultiOrPipeline();
/* 4431 */     return this.connection.<Double>executeCommand(this.commandObjects.geodist(key, member1, member2));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Double geodist(byte[] key, byte[] member1, byte[] member2, GeoUnit unit) {
/* 4437 */     checkIsInMultiOrPipeline();
/* 4438 */     return this.connection.<Double>executeCommand(this.commandObjects.geodist(key, member1, member2, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> geohash(byte[] key, byte[]... members) {
/* 4443 */     checkIsInMultiOrPipeline();
/* 4444 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.geohash(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoCoordinate> geopos(byte[] key, byte[]... members) {
/* 4449 */     checkIsInMultiOrPipeline();
/* 4450 */     return this.connection.<List<GeoCoordinate>>executeCommand(this.commandObjects.geopos(key, members));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadius(byte[] key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 4456 */     checkIsInMultiOrPipeline();
/* 4457 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadius(key, longitude, latitude, radius, unit));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusReadonly(byte[] key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 4463 */     checkIsInMultiOrPipeline();
/* 4464 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusReadonly(key, longitude, latitude, radius, unit));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadius(byte[] key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 4470 */     checkIsInMultiOrPipeline();
/* 4471 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadius(key, longitude, latitude, radius, unit, param));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long georadiusStore(byte[] key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 4478 */     checkIsInMultiOrPipeline();
/* 4479 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.georadiusStore(key, longitude, latitude, radius, unit, param, storeParam))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusReadonly(byte[] key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 4485 */     checkIsInMultiOrPipeline();
/* 4486 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusReadonly(key, longitude, latitude, radius, unit, param));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusByMember(byte[] key, byte[] member, double radius, GeoUnit unit) {
/* 4492 */     checkIsInMultiOrPipeline();
/* 4493 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusByMember(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusByMemberReadonly(byte[] key, byte[] member, double radius, GeoUnit unit) {
/* 4499 */     checkIsInMultiOrPipeline();
/* 4500 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusByMemberReadonly(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusByMember(byte[] key, byte[] member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 4506 */     checkIsInMultiOrPipeline();
/* 4507 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusByMember(key, member, radius, unit, param));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long georadiusByMemberStore(byte[] key, byte[] member, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 4513 */     checkIsInMultiOrPipeline();
/* 4514 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.georadiusByMemberStore(key, member, radius, unit, param, storeParam))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> geosearch(byte[] key, byte[] member, double radius, GeoUnit unit) {
/* 4519 */     checkIsInMultiOrPipeline();
/* 4520 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.geosearch(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> geosearch(byte[] key, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 4525 */     checkIsInMultiOrPipeline();
/* 4526 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.geosearch(key, coord, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> geosearch(byte[] key, byte[] member, double width, double height, GeoUnit unit) {
/* 4531 */     checkIsInMultiOrPipeline();
/* 4532 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.geosearch(key, member, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> geosearch(byte[] key, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 4537 */     checkIsInMultiOrPipeline();
/* 4538 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.geosearch(key, coord, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> geosearch(byte[] key, GeoSearchParam params) {
/* 4543 */     checkIsInMultiOrPipeline();
/* 4544 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.geosearch(key, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStore(byte[] dest, byte[] src, byte[] member, double radius, GeoUnit unit) {
/* 4549 */     checkIsInMultiOrPipeline();
/* 4550 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStore(dest, src, member, radius, unit))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStore(byte[] dest, byte[] src, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 4555 */     checkIsInMultiOrPipeline();
/* 4556 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStore(dest, src, coord, radius, unit))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStore(byte[] dest, byte[] src, byte[] member, double width, double height, GeoUnit unit) {
/* 4561 */     checkIsInMultiOrPipeline();
/* 4562 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStore(dest, src, member, width, height, unit))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStore(byte[] dest, byte[] src, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 4567 */     checkIsInMultiOrPipeline();
/* 4568 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStore(dest, src, coord, width, height, unit))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStore(byte[] dest, byte[] src, GeoSearchParam params) {
/* 4573 */     checkIsInMultiOrPipeline();
/* 4574 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStore(dest, src, params))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStoreStoreDist(byte[] dest, byte[] src, GeoSearchParam params) {
/* 4579 */     checkIsInMultiOrPipeline();
/* 4580 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStoreStoreDist(dest, src, params))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusByMemberReadonly(byte[] key, byte[] member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 4586 */     checkIsInMultiOrPipeline();
/* 4587 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusByMemberReadonly(key, member, radius, unit, param));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Long> bitfield(byte[] key, byte[]... arguments) {
/* 4592 */     checkIsInMultiOrPipeline();
/* 4593 */     return this.connection.<List<Long>>executeCommand(this.commandObjects.bitfield(key, arguments));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Long> bitfieldReadonly(byte[] key, byte[]... arguments) {
/* 4598 */     checkIsInMultiOrPipeline();
/* 4599 */     return this.connection.<List<Long>>executeCommand(this.commandObjects.bitfieldReadonly(key, arguments));
/*      */   }
/*      */ 
/*      */   
/*      */   public long hstrlen(byte[] key, byte[] field) {
/* 4604 */     checkIsInMultiOrPipeline();
/* 4605 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hstrlen(key, field))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> xread(XReadParams xReadParams, Map.Entry<byte[], byte[]>... streams) {
/* 4610 */     checkIsInMultiOrPipeline();
/* 4611 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.xread(xReadParams, streams));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> xreadGroup(byte[] groupName, byte[] consumer, XReadGroupParams xReadGroupParams, Map.Entry<byte[], byte[]>... streams) {
/* 4617 */     checkIsInMultiOrPipeline();
/* 4618 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.xreadGroup(groupName, consumer, xReadGroupParams, streams));
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] xadd(byte[] key, XAddParams params, Map<byte[], byte[]> hash) {
/* 4623 */     checkIsInMultiOrPipeline();
/* 4624 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.xadd(key, params, hash));
/*      */   }
/*      */ 
/*      */   
/*      */   public long xlen(byte[] key) {
/* 4629 */     checkIsInMultiOrPipeline();
/* 4630 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xlen(key))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> xrange(byte[] key, byte[] start, byte[] end) {
/* 4635 */     checkIsInMultiOrPipeline();
/* 4636 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.xrange(key, start, end));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> xrange(byte[] key, byte[] start, byte[] end, int count) {
/* 4641 */     checkIsInMultiOrPipeline();
/* 4642 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.xrange(key, start, end, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> xrevrange(byte[] key, byte[] end, byte[] start) {
/* 4647 */     checkIsInMultiOrPipeline();
/* 4648 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.xrevrange(key, end, start));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> xrevrange(byte[] key, byte[] end, byte[] start, int count) {
/* 4653 */     checkIsInMultiOrPipeline();
/* 4654 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.xrevrange(key, end, start, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public long xack(byte[] key, byte[] group, byte[]... ids) {
/* 4659 */     checkIsInMultiOrPipeline();
/* 4660 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xack(key, group, ids))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String xgroupCreate(byte[] key, byte[] consumer, byte[] id, boolean makeStream) {
/* 4665 */     checkIsInMultiOrPipeline();
/* 4666 */     return this.connection.<String>executeCommand(this.commandObjects.xgroupCreate(key, consumer, id, makeStream));
/*      */   }
/*      */ 
/*      */   
/*      */   public String xgroupSetID(byte[] key, byte[] consumer, byte[] id) {
/* 4671 */     checkIsInMultiOrPipeline();
/* 4672 */     return this.connection.<String>executeCommand(this.commandObjects.xgroupSetID(key, consumer, id));
/*      */   }
/*      */ 
/*      */   
/*      */   public long xgroupDestroy(byte[] key, byte[] consumer) {
/* 4677 */     checkIsInMultiOrPipeline();
/* 4678 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xgroupDestroy(key, consumer))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean xgroupCreateConsumer(byte[] key, byte[] groupName, byte[] consumerName) {
/* 4683 */     checkIsInMultiOrPipeline();
/* 4684 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.xgroupCreateConsumer(key, groupName, consumerName))).booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long xgroupDelConsumer(byte[] key, byte[] groupName, byte[] consumerName) {
/* 4689 */     checkIsInMultiOrPipeline();
/* 4690 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xgroupDelConsumer(key, groupName, consumerName))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long xdel(byte[] key, byte[]... ids) {
/* 4695 */     checkIsInMultiOrPipeline();
/* 4696 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xdel(key, ids))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long xtrim(byte[] key, long maxLen, boolean approximateLength) {
/* 4701 */     checkIsInMultiOrPipeline();
/* 4702 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xtrim(key, maxLen, approximateLength))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long xtrim(byte[] key, XTrimParams params) {
/* 4707 */     checkIsInMultiOrPipeline();
/* 4708 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xtrim(key, params))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<Object> xpending(byte[] key, byte[] groupName, byte[] start, byte[] end, int count, byte[] consumerName) {
/* 4718 */     checkIsInMultiOrPipeline();
/* 4719 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.xpending(key, groupName, start, end, count, consumerName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object xpending(byte[] key, byte[] groupName) {
/* 4724 */     checkIsInMultiOrPipeline();
/* 4725 */     return this.connection.executeCommand(this.commandObjects.xpending(key, groupName));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> xpending(byte[] key, byte[] groupName, XPendingParams params) {
/* 4730 */     checkIsInMultiOrPipeline();
/* 4731 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.xpending(key, groupName, params));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> xclaim(byte[] key, byte[] group, byte[] consumerName, long minIdleTime, XClaimParams params, byte[]... ids) {
/* 4737 */     checkIsInMultiOrPipeline();
/* 4738 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.xclaim(key, group, consumerName, minIdleTime, params, ids));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<byte[]> xclaimJustId(byte[] key, byte[] group, byte[] consumerName, long minIdleTime, XClaimParams params, byte[]... ids) {
/* 4744 */     checkIsInMultiOrPipeline();
/* 4745 */     return this.connection.<List<byte[]>>executeCommand(this.commandObjects.xclaimJustId(key, group, consumerName, minIdleTime, params, ids));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Object> xautoclaim(byte[] key, byte[] groupName, byte[] consumerName, long minIdleTime, byte[] start, XAutoClaimParams params) {
/* 4751 */     checkIsInMultiOrPipeline();
/* 4752 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.xautoclaim(key, groupName, consumerName, minIdleTime, start, params));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Object> xautoclaimJustId(byte[] key, byte[] groupName, byte[] consumerName, long minIdleTime, byte[] start, XAutoClaimParams params) {
/* 4758 */     checkIsInMultiOrPipeline();
/* 4759 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.xautoclaimJustId(key, groupName, consumerName, minIdleTime, start, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object xinfoStream(byte[] key) {
/* 4764 */     checkIsInMultiOrPipeline();
/* 4765 */     return this.connection.executeCommand(this.commandObjects.xinfoStream(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object xinfoStreamFull(byte[] key) {
/* 4770 */     checkIsInMultiOrPipeline();
/* 4771 */     return this.connection.executeCommand(this.commandObjects.xinfoStreamFull(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object xinfoStreamFull(byte[] key, int count) {
/* 4776 */     checkIsInMultiOrPipeline();
/* 4777 */     return this.connection.executeCommand(this.commandObjects.xinfoStreamFull(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<Object> xinfoGroup(byte[] key) {
/* 4783 */     checkIsInMultiOrPipeline();
/* 4784 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.xinfoGroup(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> xinfoGroups(byte[] key) {
/* 4789 */     checkIsInMultiOrPipeline();
/* 4790 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.xinfoGroups(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> xinfoConsumers(byte[] key, byte[] group) {
/* 4795 */     checkIsInMultiOrPipeline();
/* 4796 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.xinfoConsumers(key, group));
/*      */   }
/*      */   
/*      */   public Object sendCommand(ProtocolCommand cmd, byte[]... args) {
/* 4800 */     checkIsInMultiOrPipeline();
/* 4801 */     this.connection.sendCommand(cmd, args);
/* 4802 */     return this.connection.getOne();
/*      */   }
/*      */   
/*      */   public Object sendBlockingCommand(ProtocolCommand cmd, byte[]... args) {
/* 4806 */     checkIsInMultiOrPipeline();
/* 4807 */     this.connection.sendCommand(cmd, args);
/* 4808 */     this.connection.setTimeoutInfinite();
/*      */     try {
/* 4810 */       return this.connection.getOne();
/*      */     } finally {
/* 4812 */       this.connection.rollbackTimeout();
/*      */     } 
/*      */   }
/*      */   
/*      */   public Object sendCommand(ProtocolCommand cmd) {
/* 4817 */     return sendCommand(cmd, DUMMY_ARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean copy(String srcKey, String dstKey, int db, boolean replace) {
/* 4830 */     checkIsInMultiOrPipeline();
/* 4831 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.copy(srcKey, dstKey, db, replace))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean copy(String srcKey, String dstKey, boolean replace) {
/* 4843 */     checkIsInMultiOrPipeline();
/* 4844 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.copy(srcKey, dstKey, replace))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String ping(String message) {
/* 4854 */     checkIsInMultiOrPipeline();
/* 4855 */     this.connection.sendCommand(Protocol.Command.PING, new String[] { message });
/* 4856 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String set(String key, String value) {
/* 4870 */     checkIsInMultiOrPipeline();
/* 4871 */     return this.connection.<String>executeCommand(this.commandObjects.set(key, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String set(String key, String value, SetParams params) {
/* 4885 */     checkIsInMultiOrPipeline();
/* 4886 */     return this.connection.<String>executeCommand(this.commandObjects.set(key, value, params));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String get(String key) {
/* 4900 */     checkIsInMultiOrPipeline();
/* 4901 */     return this.connection.<String>executeCommand(this.commandObjects.get(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDel(String key) {
/* 4914 */     checkIsInMultiOrPipeline();
/* 4915 */     return this.connection.<String>executeCommand(this.commandObjects.getDel(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public String getEx(String key, GetExParams params) {
/* 4920 */     checkIsInMultiOrPipeline();
/* 4921 */     return this.connection.<String>executeCommand(this.commandObjects.getEx(key, params));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long exists(String... keys) {
/* 4932 */     checkIsInMultiOrPipeline();
/* 4933 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.exists(keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean exists(String key) {
/* 4945 */     checkIsInMultiOrPipeline();
/* 4946 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.exists(key))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long del(String... keys) {
/* 4957 */     checkIsInMultiOrPipeline();
/* 4958 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.del(keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long del(String key) {
/* 4963 */     checkIsInMultiOrPipeline();
/* 4964 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.del(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long unlink(String... keys) {
/* 4982 */     checkIsInMultiOrPipeline();
/* 4983 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.unlink(keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long unlink(String key) {
/* 4988 */     checkIsInMultiOrPipeline();
/* 4989 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.unlink(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String type(String key) {
/* 5002 */     checkIsInMultiOrPipeline();
/* 5003 */     return this.connection.<String>executeCommand(this.commandObjects.type(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> keys(String pattern) {
/* 5008 */     checkIsInMultiOrPipeline();
/* 5009 */     return this.connection.<Set<String>>executeCommand(this.commandObjects.keys(pattern));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String randomKey() {
/* 5020 */     checkIsInMultiOrPipeline();
/* 5021 */     return this.connection.<String>executeCommand(this.commandObjects.randomKey());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String rename(String oldkey, String newkey) {
/* 5035 */     checkIsInMultiOrPipeline();
/* 5036 */     return this.connection.<String>executeCommand(this.commandObjects.rename(oldkey, newkey));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long renamenx(String oldkey, String newkey) {
/* 5049 */     checkIsInMultiOrPipeline();
/* 5050 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.renamenx(oldkey, newkey))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long expire(String key, long seconds) {
/* 5076 */     checkIsInMultiOrPipeline();
/* 5077 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.expire(key, seconds))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long expire(String key, long seconds, ExpiryOption expiryOption) {
/* 5092 */     checkIsInMultiOrPipeline();
/* 5093 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.expire(key, seconds, expiryOption))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pexpire(String key, long milliseconds) {
/* 5098 */     checkIsInMultiOrPipeline();
/* 5099 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pexpire(key, milliseconds))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pexpire(String key, long milliseconds, ExpiryOption expiryOption) {
/* 5104 */     checkIsInMultiOrPipeline();
/* 5105 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pexpire(key, milliseconds, expiryOption))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long expireTime(String key) {
/* 5120 */     checkIsInMultiOrPipeline();
/* 5121 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.expireTime(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long pexpireTime(String key) {
/* 5136 */     checkIsInMultiOrPipeline();
/* 5137 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pexpireTime(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long expireAt(String key, long unixTime) {
/* 5165 */     checkIsInMultiOrPipeline();
/* 5166 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.expireAt(key, unixTime))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long expireAt(String key, long unixTime, ExpiryOption expiryOption) {
/* 5180 */     checkIsInMultiOrPipeline();
/* 5181 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.expireAt(key, unixTime, expiryOption))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long pexpireAt(String key, long millisecondsTimestamp) {
/* 5196 */     checkIsInMultiOrPipeline();
/* 5197 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pexpireAt(key, millisecondsTimestamp))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long pexpireAt(String key, long millisecondsTimestamp, ExpiryOption expiryOption) {
/* 5212 */     checkIsInMultiOrPipeline();
/* 5213 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pexpireAt(key, millisecondsTimestamp, expiryOption))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long ttl(String key) {
/* 5226 */     checkIsInMultiOrPipeline();
/* 5227 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.ttl(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long touch(String... keys) {
/* 5238 */     checkIsInMultiOrPipeline();
/* 5239 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.touch(keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long touch(String key) {
/* 5244 */     checkIsInMultiOrPipeline();
/* 5245 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.touch(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long move(String key, int dbIndex) {
/* 5260 */     checkIsInMultiOrPipeline();
/* 5261 */     this.connection.sendCommand(Protocol.Command.MOVE, new byte[][] { SafeEncoder.encode(key), Protocol.toByteArray(dbIndex) });
/* 5262 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSet(String key, String value) {
/* 5277 */     checkIsInMultiOrPipeline();
/* 5278 */     return this.connection.<String>executeCommand(this.commandObjects.getSet(key, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> mget(String... keys) {
/* 5292 */     checkIsInMultiOrPipeline();
/* 5293 */     return this.connection.<List<String>>executeCommand(this.commandObjects.mget(keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long setnx(String key, String value) {
/* 5307 */     checkIsInMultiOrPipeline();
/* 5308 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.setnx(key, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String setex(String key, long seconds, String value) {
/* 5324 */     checkIsInMultiOrPipeline();
/* 5325 */     return this.connection.<String>executeCommand(this.commandObjects.setex(key, seconds, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String mset(String... keysvalues) {
/* 5346 */     checkIsInMultiOrPipeline();
/* 5347 */     return this.connection.<String>executeCommand(this.commandObjects.mset(keysvalues));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long msetnx(String... keysvalues) {
/* 5368 */     checkIsInMultiOrPipeline();
/* 5369 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.msetnx(keysvalues))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long decrBy(String key, long decrement) {
/* 5392 */     checkIsInMultiOrPipeline();
/* 5393 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.decrBy(key, decrement))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long decr(String key) {
/* 5415 */     checkIsInMultiOrPipeline();
/* 5416 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.decr(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long incrBy(String key, long increment) {
/* 5439 */     checkIsInMultiOrPipeline();
/* 5440 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.incrBy(key, increment))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double incrByFloat(String key, double increment) {
/* 5460 */     checkIsInMultiOrPipeline();
/* 5461 */     return ((Double)this.connection.<Double>executeCommand(this.commandObjects.incrByFloat(key, increment))).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long incr(String key) {
/* 5483 */     checkIsInMultiOrPipeline();
/* 5484 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.incr(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long append(String key, String value) {
/* 5501 */     checkIsInMultiOrPipeline();
/* 5502 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.append(key, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String substr(String key, int start, int end) {
/* 5523 */     checkIsInMultiOrPipeline();
/* 5524 */     return this.connection.<String>executeCommand(this.commandObjects.substr(key, start, end));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long hset(String key, String field, String value) {
/* 5541 */     checkIsInMultiOrPipeline();
/* 5542 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hset(key, field, value))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long hset(String key, Map<String, String> hash) {
/* 5547 */     checkIsInMultiOrPipeline();
/* 5548 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hset(key, hash))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String hget(String key, String field) {
/* 5563 */     checkIsInMultiOrPipeline();
/* 5564 */     return this.connection.<String>executeCommand(this.commandObjects.hget(key, field));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long hsetnx(String key, String field, String value) {
/* 5578 */     checkIsInMultiOrPipeline();
/* 5579 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hsetnx(key, field, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String hmset(String key, Map<String, String> hash) {
/* 5594 */     checkIsInMultiOrPipeline();
/* 5595 */     return this.connection.<String>executeCommand(this.commandObjects.hmset(key, hash));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> hmget(String key, String... fields) {
/* 5611 */     checkIsInMultiOrPipeline();
/* 5612 */     return this.connection.<List<String>>executeCommand(this.commandObjects.hmget(key, fields));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long hincrBy(String key, String field, long value) {
/* 5631 */     checkIsInMultiOrPipeline();
/* 5632 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hincrBy(key, field, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double hincrByFloat(String key, String field, double value) {
/* 5652 */     checkIsInMultiOrPipeline();
/* 5653 */     return ((Double)this.connection.<Double>executeCommand(this.commandObjects.hincrByFloat(key, field, value))).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hexists(String key, String field) {
/* 5665 */     checkIsInMultiOrPipeline();
/* 5666 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.hexists(key, field))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long hdel(String key, String... fields) {
/* 5680 */     checkIsInMultiOrPipeline();
/* 5681 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hdel(key, fields))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long hlen(String key) {
/* 5694 */     checkIsInMultiOrPipeline();
/* 5695 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hlen(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> hkeys(String key) {
/* 5707 */     checkIsInMultiOrPipeline();
/* 5708 */     return this.connection.<Set<String>>executeCommand(this.commandObjects.hkeys(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> hvals(String key) {
/* 5720 */     checkIsInMultiOrPipeline();
/* 5721 */     return this.connection.<List<String>>executeCommand(this.commandObjects.hvals(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String> hgetAll(String key) {
/* 5733 */     checkIsInMultiOrPipeline();
/* 5734 */     return this.connection.<Map<String, String>>executeCommand(this.commandObjects.hgetAll(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String hrandfield(String key) {
/* 5746 */     checkIsInMultiOrPipeline();
/* 5747 */     return this.connection.<String>executeCommand(this.commandObjects.hrandfield(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> hrandfield(String key, long count) {
/* 5760 */     checkIsInMultiOrPipeline();
/* 5761 */     return this.connection.<List<String>>executeCommand(this.commandObjects.hrandfield(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String> hrandfieldWithValues(String key, long count) {
/* 5774 */     checkIsInMultiOrPipeline();
/* 5775 */     return this.connection.<Map<String, String>>executeCommand(this.commandObjects.hrandfieldWithValues(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long rpush(String key, String... strings) {
/* 5790 */     checkIsInMultiOrPipeline();
/* 5791 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.rpush(key, strings))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long lpush(String key, String... strings) {
/* 5806 */     checkIsInMultiOrPipeline();
/* 5807 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.lpush(key, strings))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long llen(String key) {
/* 5821 */     checkIsInMultiOrPipeline();
/* 5822 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.llen(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> lrange(String key, long start, long stop) {
/* 5859 */     checkIsInMultiOrPipeline();
/* 5860 */     return this.connection.<List<String>>executeCommand(this.commandObjects.lrange(key, start, stop));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String ltrim(String key, long start, long stop) {
/* 5895 */     checkIsInMultiOrPipeline();
/* 5896 */     return this.connection.<String>executeCommand(this.commandObjects.ltrim(key, start, stop));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String lindex(String key, long index) {
/* 5917 */     checkIsInMultiOrPipeline();
/* 5918 */     return this.connection.<String>executeCommand(this.commandObjects.lindex(key, index));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String lset(String key, long index, String value) {
/* 5942 */     checkIsInMultiOrPipeline();
/* 5943 */     return this.connection.<String>executeCommand(this.commandObjects.lset(key, index, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long lrem(String key, long count, String value) {
/* 5963 */     checkIsInMultiOrPipeline();
/* 5964 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.lrem(key, count, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String lpop(String key) {
/* 5979 */     checkIsInMultiOrPipeline();
/* 5980 */     return this.connection.<String>executeCommand(this.commandObjects.lpop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> lpop(String key, int count) {
/* 5985 */     checkIsInMultiOrPipeline();
/* 5986 */     return this.connection.<List<String>>executeCommand(this.commandObjects.lpop(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Long lpos(String key, String element) {
/* 5991 */     checkIsInMultiOrPipeline();
/* 5992 */     return this.connection.<Long>executeCommand(this.commandObjects.lpos(key, element));
/*      */   }
/*      */ 
/*      */   
/*      */   public Long lpos(String key, String element, LPosParams params) {
/* 5997 */     checkIsInMultiOrPipeline();
/* 5998 */     return this.connection.<Long>executeCommand(this.commandObjects.lpos(key, element, params));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Long> lpos(String key, String element, LPosParams params, long count) {
/* 6004 */     checkIsInMultiOrPipeline();
/* 6005 */     return this.connection.<List<Long>>executeCommand(this.commandObjects.lpos(key, element, params, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String rpop(String key) {
/* 6020 */     checkIsInMultiOrPipeline();
/* 6021 */     return this.connection.<String>executeCommand(this.commandObjects.rpop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> rpop(String key, int count) {
/* 6026 */     checkIsInMultiOrPipeline();
/* 6027 */     return this.connection.<List<String>>executeCommand(this.commandObjects.rpop(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String rpoplpush(String srckey, String dstkey) {
/* 6047 */     checkIsInMultiOrPipeline();
/* 6048 */     return this.connection.<String>executeCommand(this.commandObjects.rpoplpush(srckey, dstkey));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sadd(String key, String... members) {
/* 6063 */     checkIsInMultiOrPipeline();
/* 6064 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sadd(key, members))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> smembers(String key) {
/* 6077 */     checkIsInMultiOrPipeline();
/* 6078 */     return this.connection.<Set<String>>executeCommand(this.commandObjects.smembers(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long srem(String key, String... members) {
/* 6092 */     checkIsInMultiOrPipeline();
/* 6093 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.srem(key, members))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String spop(String key) {
/* 6109 */     checkIsInMultiOrPipeline();
/* 6110 */     return this.connection.<String>executeCommand(this.commandObjects.spop(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> spop(String key, long count) {
/* 6115 */     checkIsInMultiOrPipeline();
/* 6116 */     return this.connection.<Set<String>>executeCommand(this.commandObjects.spop(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long smove(String srckey, String dstkey, String member) {
/* 6140 */     checkIsInMultiOrPipeline();
/* 6141 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.smove(srckey, dstkey, member))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long scard(String key) {
/* 6152 */     checkIsInMultiOrPipeline();
/* 6153 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.scard(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean sismember(String key, String member) {
/* 6166 */     checkIsInMultiOrPipeline();
/* 6167 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.sismember(key, member))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Boolean> smismember(String key, String... members) {
/* 6180 */     checkIsInMultiOrPipeline();
/* 6181 */     return this.connection.<List<Boolean>>executeCommand(this.commandObjects.smismember(key, members));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> sinter(String... keys) {
/* 6201 */     checkIsInMultiOrPipeline();
/* 6202 */     return this.connection.<Set<String>>executeCommand(this.commandObjects.sinter(keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sinterstore(String dstkey, String... keys) {
/* 6217 */     checkIsInMultiOrPipeline();
/* 6218 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sinterstore(dstkey, keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sintercard(String... keys) {
/* 6231 */     checkIsInMultiOrPipeline();
/* 6232 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sintercard(keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sintercard(int limit, String... keys) {
/* 6247 */     checkIsInMultiOrPipeline();
/* 6248 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sintercard(limit, keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> sunion(String... keys) {
/* 6266 */     checkIsInMultiOrPipeline();
/* 6267 */     return this.connection.<Set<String>>executeCommand(this.commandObjects.sunion(keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sunionstore(String dstkey, String... keys) {
/* 6282 */     checkIsInMultiOrPipeline();
/* 6283 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sunionstore(dstkey, keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> sdiff(String... keys) {
/* 6308 */     checkIsInMultiOrPipeline();
/* 6309 */     return this.connection.<Set<String>>executeCommand(this.commandObjects.sdiff(keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sdiffstore(String dstkey, String... keys) {
/* 6321 */     checkIsInMultiOrPipeline();
/* 6322 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sdiffstore(dstkey, keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String srandmember(String key) {
/* 6337 */     checkIsInMultiOrPipeline();
/* 6338 */     return this.connection.<String>executeCommand(this.commandObjects.srandmember(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> srandmember(String key, int count) {
/* 6356 */     checkIsInMultiOrPipeline();
/* 6357 */     return this.connection.<List<String>>executeCommand(this.commandObjects.srandmember(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zadd(String key, double score, String member) {
/* 6378 */     checkIsInMultiOrPipeline();
/* 6379 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zadd(key, score, member))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long zadd(String key, double score, String member, ZAddParams params) {
/* 6385 */     checkIsInMultiOrPipeline();
/* 6386 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zadd(key, score, member, params))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zadd(String key, Map<String, Double> scoreMembers) {
/* 6391 */     checkIsInMultiOrPipeline();
/* 6392 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zadd(key, scoreMembers))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zadd(String key, Map<String, Double> scoreMembers, ZAddParams params) {
/* 6397 */     checkIsInMultiOrPipeline();
/* 6398 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zadd(key, scoreMembers, params))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public Double zaddIncr(String key, double score, String member, ZAddParams params) {
/* 6403 */     checkIsInMultiOrPipeline();
/* 6404 */     return this.connection.<Double>executeCommand(this.commandObjects.zaddIncr(key, score, member, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> zdiff(String... keys) {
/* 6409 */     checkIsInMultiOrPipeline();
/* 6410 */     return this.connection.<Set<String>>executeCommand(this.commandObjects.zdiff(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<Tuple> zdiffWithScores(String... keys) {
/* 6415 */     checkIsInMultiOrPipeline();
/* 6416 */     return this.connection.<Set<Tuple>>executeCommand(this.commandObjects.zdiffWithScores(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public long zdiffStore(String dstkey, String... keys) {
/* 6421 */     checkIsInMultiOrPipeline();
/* 6422 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zdiffStore(dstkey, keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> zrange(String key, long start, long stop) {
/* 6427 */     checkIsInMultiOrPipeline();
/* 6428 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrange(key, start, stop));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zrem(String key, String... members) {
/* 6442 */     checkIsInMultiOrPipeline();
/* 6443 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zrem(key, members))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double zincrby(String key, double increment, String member) {
/* 6466 */     checkIsInMultiOrPipeline();
/* 6467 */     return ((Double)this.connection.<Double>executeCommand(this.commandObjects.zincrby(key, increment, member))).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Double zincrby(String key, double increment, String member, ZIncrByParams params) {
/* 6473 */     checkIsInMultiOrPipeline();
/* 6474 */     return this.connection.<Double>executeCommand(this.commandObjects.zincrby(key, increment, member, params));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Long zrank(String key, String member) {
/* 6494 */     checkIsInMultiOrPipeline();
/* 6495 */     return this.connection.<Long>executeCommand(this.commandObjects.zrank(key, member));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Long zrevrank(String key, String member) {
/* 6515 */     checkIsInMultiOrPipeline();
/* 6516 */     return this.connection.<Long>executeCommand(this.commandObjects.zrevrank(key, member));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> zrevrange(String key, long start, long stop) {
/* 6521 */     checkIsInMultiOrPipeline();
/* 6522 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrevrange(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeWithScores(String key, long start, long stop) {
/* 6527 */     checkIsInMultiOrPipeline();
/* 6528 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeWithScores(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrevrangeWithScores(String key, long start, long stop) {
/* 6533 */     checkIsInMultiOrPipeline();
/* 6534 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrevrangeWithScores(key, start, stop));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> zrange(String key, ZRangeParams zRangeParams) {
/* 6539 */     checkIsInMultiOrPipeline();
/* 6540 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrange(key, zRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeWithScores(String key, ZRangeParams zRangeParams) {
/* 6545 */     checkIsInMultiOrPipeline();
/* 6546 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeWithScores(key, zRangeParams));
/*      */   }
/*      */ 
/*      */   
/*      */   public long zrangestore(String dest, String src, ZRangeParams zRangeParams) {
/* 6551 */     checkIsInMultiOrPipeline();
/* 6552 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zrangestore(dest, src, zRangeParams))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String zrandmember(String key) {
/* 6557 */     checkIsInMultiOrPipeline();
/* 6558 */     return this.connection.<String>executeCommand(this.commandObjects.zrandmember(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> zrandmember(String key, long count) {
/* 6563 */     checkIsInMultiOrPipeline();
/* 6564 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrandmember(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrandmemberWithScores(String key, long count) {
/* 6569 */     checkIsInMultiOrPipeline();
/* 6570 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrandmemberWithScores(key, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zcard(String key) {
/* 6583 */     checkIsInMultiOrPipeline();
/* 6584 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zcard(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Double zscore(String key, String member) {
/* 6599 */     checkIsInMultiOrPipeline();
/* 6600 */     return this.connection.<Double>executeCommand(this.commandObjects.zscore(key, member));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Double> zmscore(String key, String... members) {
/* 6614 */     checkIsInMultiOrPipeline();
/* 6615 */     return this.connection.<List<Double>>executeCommand(this.commandObjects.zmscore(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public Tuple zpopmax(String key) {
/* 6620 */     checkIsInMultiOrPipeline();
/* 6621 */     return this.connection.<Tuple>executeCommand(this.commandObjects.zpopmax(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zpopmax(String key, int count) {
/* 6626 */     checkIsInMultiOrPipeline();
/* 6627 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zpopmax(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public Tuple zpopmin(String key) {
/* 6632 */     checkIsInMultiOrPipeline();
/* 6633 */     return this.connection.<Tuple>executeCommand(this.commandObjects.zpopmin(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zpopmin(String key, int count) {
/* 6638 */     checkIsInMultiOrPipeline();
/* 6639 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zpopmin(key, count));
/*      */   }
/*      */   
/*      */   public String watch(String... keys) {
/* 6643 */     checkIsInMultiOrPipeline();
/* 6644 */     this.connection.sendCommand(Protocol.Command.WATCH, keys);
/*      */     
/* 6646 */     String status = this.connection.getStatusCodeReply();
/* 6647 */     this.isInWatch = true;
/* 6648 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> sort(String key) {
/* 6666 */     checkIsInMultiOrPipeline();
/* 6667 */     return this.connection.<List<String>>executeCommand(this.commandObjects.sort(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> sort(String key, SortingParams sortingParams) {
/* 6746 */     checkIsInMultiOrPipeline();
/* 6747 */     return this.connection.<List<String>>executeCommand(this.commandObjects.sort(key, sortingParams));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sort(String key, SortingParams sortingParams, String dstkey) {
/* 6762 */     checkIsInMultiOrPipeline();
/* 6763 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sort(key, sortingParams, dstkey))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> sortReadonly(String key, SortingParams sortingParams) {
/* 6768 */     checkIsInMultiOrPipeline();
/* 6769 */     return this.connection.<List<String>>executeCommand(this.commandObjects.sortReadonly(key, sortingParams));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long sort(String key, String dstkey) {
/* 6787 */     checkIsInMultiOrPipeline();
/* 6788 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.sort(key, dstkey))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String lmove(String srcKey, String dstKey, ListDirection from, ListDirection to) {
/* 6794 */     checkIsInMultiOrPipeline();
/* 6795 */     return this.connection.<String>executeCommand(this.commandObjects.lmove(srcKey, dstKey, from, to));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String blmove(String srcKey, String dstKey, ListDirection from, ListDirection to, double timeout) {
/* 6801 */     checkIsInMultiOrPipeline();
/* 6802 */     return this.connection.<String>executeCommand(this.commandObjects.blmove(srcKey, dstKey, from, to, timeout));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> blpop(int timeout, String... keys) {
/* 6869 */     checkIsInMultiOrPipeline();
/* 6870 */     return this.connection.<List<String>>executeCommand(this.commandObjects.blpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyedListElement blpop(double timeout, String... keys) {
/* 6875 */     checkIsInMultiOrPipeline();
/* 6876 */     return this.connection.<KeyedListElement>executeCommand(this.commandObjects.blpop(timeout, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> brpop(int timeout, String... keys) {
/* 6943 */     checkIsInMultiOrPipeline();
/* 6944 */     return this.connection.<List<String>>executeCommand(this.commandObjects.brpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyedListElement brpop(double timeout, String... keys) {
/* 6949 */     checkIsInMultiOrPipeline();
/* 6950 */     return this.connection.<KeyedListElement>executeCommand(this.commandObjects.brpop(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<String, List<String>> lmpop(ListDirection direction, String... keys) {
/* 6955 */     checkIsInMultiOrPipeline();
/* 6956 */     return this.connection.<KeyValue<String, List<String>>>executeCommand(this.commandObjects.lmpop(direction, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<String, List<String>> lmpop(ListDirection direction, int count, String... keys) {
/* 6961 */     checkIsInMultiOrPipeline();
/* 6962 */     return this.connection.<KeyValue<String, List<String>>>executeCommand(this.commandObjects.lmpop(direction, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<String, List<String>> blmpop(long timeout, ListDirection direction, String... keys) {
/* 6967 */     checkIsInMultiOrPipeline();
/* 6968 */     return this.connection.<KeyValue<String, List<String>>>executeCommand(this.commandObjects.blmpop(timeout, direction, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<String, List<String>> blmpop(long timeout, ListDirection direction, int count, String... keys) {
/* 6973 */     checkIsInMultiOrPipeline();
/* 6974 */     return this.connection.<KeyValue<String, List<String>>>executeCommand(this.commandObjects.blmpop(timeout, direction, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyedZSetElement bzpopmax(double timeout, String... keys) {
/* 6979 */     checkIsInMultiOrPipeline();
/* 6980 */     return this.connection.<KeyedZSetElement>executeCommand(this.commandObjects.bzpopmax(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyedZSetElement bzpopmin(double timeout, String... keys) {
/* 6985 */     checkIsInMultiOrPipeline();
/* 6986 */     return this.connection.<KeyedZSetElement>executeCommand(this.commandObjects.bzpopmin(timeout, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> blpop(int timeout, String key) {
/* 6991 */     checkIsInMultiOrPipeline();
/* 6992 */     return this.connection.<List<String>>executeCommand(this.commandObjects.blpop(timeout, key));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyedListElement blpop(double timeout, String key) {
/* 6997 */     checkIsInMultiOrPipeline();
/* 6998 */     return this.connection.<KeyedListElement>executeCommand(this.commandObjects.blpop(timeout, key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> brpop(int timeout, String key) {
/* 7003 */     checkIsInMultiOrPipeline();
/* 7004 */     return this.connection.<List<String>>executeCommand(this.commandObjects.brpop(timeout, key));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyedListElement brpop(double timeout, String key) {
/* 7009 */     checkIsInMultiOrPipeline();
/* 7010 */     return this.connection.<KeyedListElement>executeCommand(this.commandObjects.brpop(timeout, key));
/*      */   }
/*      */ 
/*      */   
/*      */   public long zcount(String key, double min, double max) {
/* 7015 */     checkIsInMultiOrPipeline();
/* 7016 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zcount(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zcount(String key, String min, String max) {
/* 7021 */     checkIsInMultiOrPipeline();
/* 7022 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zcount(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> zrangeByScore(String key, double min, double max) {
/* 7075 */     checkIsInMultiOrPipeline();
/* 7076 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> zrangeByScore(String key, String min, String max) {
/* 7081 */     checkIsInMultiOrPipeline();
/* 7082 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrangeByScore(key, min, max));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> zrangeByScore(String key, double min, double max, int offset, int count) {
/* 7137 */     checkIsInMultiOrPipeline();
/* 7138 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrangeByScore(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> zrangeByScore(String key, String min, String max, int offset, int count) {
/* 7144 */     checkIsInMultiOrPipeline();
/* 7145 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrangeByScore(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeByScoreWithScores(String key, double min, double max) {
/* 7197 */     checkIsInMultiOrPipeline();
/* 7198 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeByScoreWithScores(String key, String min, String max) {
/* 7203 */     checkIsInMultiOrPipeline();
/* 7204 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeByScoreWithScores(String key, double min, double max, int offset, int count) {
/* 7259 */     checkIsInMultiOrPipeline();
/* 7260 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Tuple> zrangeByScoreWithScores(String key, String min, String max, int offset, int count) {
/* 7266 */     checkIsInMultiOrPipeline();
/* 7267 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrangeByScoreWithScores(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> zrevrangeByScore(String key, double max, double min) {
/* 7272 */     checkIsInMultiOrPipeline();
/* 7273 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrevrangeByScore(key, max, min));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> zrevrangeByScore(String key, String max, String min) {
/* 7278 */     checkIsInMultiOrPipeline();
/* 7279 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrevrangeByScore(key, max, min));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> zrevrangeByScore(String key, double max, double min, int offset, int count) {
/* 7285 */     checkIsInMultiOrPipeline();
/* 7286 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrevrangeByScore(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrevrangeByScoreWithScores(String key, double max, double min) {
/* 7291 */     checkIsInMultiOrPipeline();
/* 7292 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Tuple> zrevrangeByScoreWithScores(String key, double max, double min, int offset, int count) {
/* 7298 */     checkIsInMultiOrPipeline();
/* 7299 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Tuple> zrevrangeByScoreWithScores(String key, String max, String min, int offset, int count) {
/* 7305 */     checkIsInMultiOrPipeline();
/* 7306 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> zrevrangeByScore(String key, String max, String min, int offset, int count) {
/* 7312 */     checkIsInMultiOrPipeline();
/* 7313 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrevrangeByScore(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Tuple> zrevrangeByScoreWithScores(String key, String max, String min) {
/* 7318 */     checkIsInMultiOrPipeline();
/* 7319 */     return this.connection.<List<Tuple>>executeCommand(this.commandObjects.zrevrangeByScoreWithScores(key, max, min));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zremrangeByRank(String key, long start, long stop) {
/* 7337 */     checkIsInMultiOrPipeline();
/* 7338 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zremrangeByRank(key, start, stop))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zremrangeByScore(String key, double min, double max) {
/* 7356 */     checkIsInMultiOrPipeline();
/* 7357 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zremrangeByScore(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zremrangeByScore(String key, String min, String max) {
/* 7362 */     checkIsInMultiOrPipeline();
/* 7363 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zremrangeByScore(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> zunion(ZParams params, String... keys) {
/* 7375 */     checkIsInMultiOrPipeline();
/* 7376 */     return this.connection.<Set<String>>executeCommand(this.commandObjects.zunion(params, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Tuple> zunionWithScores(ZParams params, String... keys) {
/* 7388 */     checkIsInMultiOrPipeline();
/* 7389 */     return this.connection.<Set<Tuple>>executeCommand(this.commandObjects.zunionWithScores(params, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zunionstore(String dstkey, String... sets) {
/* 7424 */     checkIsInMultiOrPipeline();
/* 7425 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zunionstore(dstkey, sets))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zunionstore(String dstkey, ZParams params, String... sets) {
/* 7461 */     checkIsInMultiOrPipeline();
/* 7462 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zunionstore(dstkey, params, sets))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> zinter(ZParams params, String... keys) {
/* 7474 */     checkIsInMultiOrPipeline();
/* 7475 */     return this.connection.<Set<String>>executeCommand(this.commandObjects.zinter(params, keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Tuple> zinterWithScores(ZParams params, String... keys) {
/* 7487 */     checkIsInMultiOrPipeline();
/* 7488 */     return this.connection.<Set<Tuple>>executeCommand(this.commandObjects.zinterWithScores(params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public long zintercard(String... keys) {
/* 7493 */     checkIsInMultiOrPipeline();
/* 7494 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zintercard(keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zintercard(long limit, String... keys) {
/* 7499 */     checkIsInMultiOrPipeline();
/* 7500 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zintercard(limit, keys))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zinterstore(String dstkey, String... sets) {
/* 7535 */     checkIsInMultiOrPipeline();
/* 7536 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zinterstore(dstkey, sets))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long zinterstore(String dstkey, ZParams params, String... sets) {
/* 7572 */     checkIsInMultiOrPipeline();
/* 7573 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zinterstore(dstkey, params, sets))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long zlexcount(String key, String min, String max) {
/* 7578 */     checkIsInMultiOrPipeline();
/* 7579 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zlexcount(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> zrangeByLex(String key, String min, String max) {
/* 7584 */     checkIsInMultiOrPipeline();
/* 7585 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrangeByLex(key, min, max));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> zrangeByLex(String key, String min, String max, int offset, int count) {
/* 7591 */     checkIsInMultiOrPipeline();
/* 7592 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrangeByLex(key, min, max, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> zrevrangeByLex(String key, String max, String min) {
/* 7597 */     checkIsInMultiOrPipeline();
/* 7598 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrevrangeByLex(key, max, min));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> zrevrangeByLex(String key, String max, String min, int offset, int count) {
/* 7604 */     checkIsInMultiOrPipeline();
/* 7605 */     return this.connection.<List<String>>executeCommand(this.commandObjects.zrevrangeByLex(key, max, min, offset, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public long zremrangeByLex(String key, String min, String max) {
/* 7610 */     checkIsInMultiOrPipeline();
/* 7611 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.zremrangeByLex(key, min, max))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<String, List<Tuple>> zmpop(SortedSetOption option, String... keys) {
/* 7616 */     checkIsInMultiOrPipeline();
/* 7617 */     return this.connection.<KeyValue<String, List<Tuple>>>executeCommand(this.commandObjects.zmpop(option, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<String, List<Tuple>> zmpop(SortedSetOption option, int count, String... keys) {
/* 7622 */     checkIsInMultiOrPipeline();
/* 7623 */     return this.connection.<KeyValue<String, List<Tuple>>>executeCommand(this.commandObjects.zmpop(option, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<String, List<Tuple>> bzmpop(long timeout, SortedSetOption option, String... keys) {
/* 7628 */     checkIsInMultiOrPipeline();
/* 7629 */     return this.connection.<KeyValue<String, List<Tuple>>>executeCommand(this.commandObjects.bzmpop(timeout, option, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public KeyValue<String, List<Tuple>> bzmpop(long timeout, SortedSetOption option, int count, String... keys) {
/* 7634 */     checkIsInMultiOrPipeline();
/* 7635 */     return this.connection.<KeyValue<String, List<Tuple>>>executeCommand(this.commandObjects.bzmpop(timeout, option, count, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public long strlen(String key) {
/* 7640 */     checkIsInMultiOrPipeline();
/* 7641 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.strlen(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public LCSMatchResult strAlgoLCSKeys(String keyA, String keyB, StrAlgoLCSParams params) {
/* 7656 */     checkIsInMultiOrPipeline();
/* 7657 */     return this.connection.<LCSMatchResult>executeCommand(this.commandObjects.strAlgoLCSKeys(keyA, keyB, params));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public LCSMatchResult strAlgoLCSStrings(String strA, String strB, StrAlgoLCSParams params) {
/* 7670 */     checkIsInMultiOrPipeline();
/* 7671 */     return this.connection.<LCSMatchResult>executeCommand(this.commandObjects.strAlgoLCSStrings(strA, strB, params));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LCSMatchResult lcs(String keyA, String keyB, LCSParams params) {
/* 7683 */     checkIsInMultiOrPipeline();
/* 7684 */     return this.connection.<LCSMatchResult>executeCommand(this.commandObjects.lcs(keyA, keyB, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public long lpushx(String key, String... strings) {
/* 7689 */     checkIsInMultiOrPipeline();
/* 7690 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.lpushx(key, strings))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long persist(String key) {
/* 7702 */     checkIsInMultiOrPipeline();
/* 7703 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.persist(key))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long rpushx(String key, String... strings) {
/* 7708 */     checkIsInMultiOrPipeline();
/* 7709 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.rpushx(key, strings))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String echo(String string) {
/* 7714 */     checkIsInMultiOrPipeline();
/* 7715 */     this.connection.sendCommand(Protocol.Command.ECHO, new String[] { string });
/* 7716 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long linsert(String key, ListPosition where, String pivot, String value) {
/* 7722 */     checkIsInMultiOrPipeline();
/* 7723 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.linsert(key, where, pivot, value))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String brpoplpush(String source, String destination, int timeout) {
/* 7735 */     checkIsInMultiOrPipeline();
/* 7736 */     return this.connection.<String>executeCommand(this.commandObjects.brpoplpush(source, destination, timeout));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setbit(String key, long offset, boolean value) {
/* 7747 */     checkIsInMultiOrPipeline();
/* 7748 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.setbit(key, offset, value))).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getbit(String key, long offset) {
/* 7758 */     checkIsInMultiOrPipeline();
/* 7759 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.getbit(key, offset))).booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long setrange(String key, long offset, String value) {
/* 7764 */     checkIsInMultiOrPipeline();
/* 7765 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.setrange(key, offset, value))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getrange(String key, long startOffset, long endOffset) {
/* 7770 */     checkIsInMultiOrPipeline();
/* 7771 */     return this.connection.<String>executeCommand(this.commandObjects.getrange(key, startOffset, endOffset));
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitpos(String key, boolean value) {
/* 7776 */     checkIsInMultiOrPipeline();
/* 7777 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitpos(key, value))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitpos(String key, boolean value, BitPosParams params) {
/* 7782 */     checkIsInMultiOrPipeline();
/* 7783 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitpos(key, value, params))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> role() {
/* 7788 */     checkIsInMultiOrPipeline();
/* 7789 */     this.connection.sendCommand(Protocol.Command.ROLE);
/* 7790 */     return BuilderFactory.ENCODED_OBJECT_LIST.build(this.connection.getOne());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> configGet(String pattern) {
/* 7829 */     checkIsInMultiOrPipeline();
/* 7830 */     this.connection.sendCommand(Protocol.Command.CONFIG, new String[] { Protocol.Keyword.GET.name(), pattern });
/* 7831 */     return this.connection.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> configGet(String... patterns) {
/* 7836 */     checkIsInMultiOrPipeline();
/* 7837 */     this.connection.sendCommand(Protocol.Command.CONFIG, joinParameters(Protocol.Keyword.GET.name(), patterns));
/* 7838 */     return this.connection.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String configSet(String parameter, String value) {
/* 7872 */     checkIsInMultiOrPipeline();
/* 7873 */     this.connection.sendCommand(Protocol.Command.CONFIG, new String[] { Protocol.Keyword.SET.name(), parameter, value });
/* 7874 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String configSet(String... parameterValues) {
/* 7879 */     checkIsInMultiOrPipeline();
/* 7880 */     this.connection.sendCommand(Protocol.Command.CONFIG, joinParameters(Protocol.Keyword.SET.name(), parameterValues));
/* 7881 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */   
/*      */   public long publish(String channel, String message) {
/* 7885 */     checkIsInMultiOrPipeline();
/* 7886 */     this.connection.sendCommand(Protocol.Command.PUBLISH, new String[] { channel, message });
/* 7887 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */   
/*      */   public void subscribe(JedisPubSub jedisPubSub, String... channels) {
/* 7891 */     jedisPubSub.proceed(this.connection, channels);
/*      */   }
/*      */   
/*      */   public void psubscribe(JedisPubSub jedisPubSub, String... patterns) {
/* 7895 */     jedisPubSub.proceedWithPatterns(this.connection, patterns);
/*      */   }
/*      */   
/*      */   public List<String> pubsubChannels() {
/* 7899 */     checkIsInMultiOrPipeline();
/* 7900 */     this.connection.sendCommand(Protocol.Command.PUBSUB, Protocol.Keyword.CHANNELS);
/* 7901 */     return this.connection.getMultiBulkReply();
/*      */   }
/*      */   
/*      */   public List<String> pubsubChannels(String pattern) {
/* 7905 */     checkIsInMultiOrPipeline();
/* 7906 */     this.connection.sendCommand(Protocol.Command.PUBSUB, new String[] { Protocol.Keyword.CHANNELS.name(), pattern });
/* 7907 */     return this.connection.getMultiBulkReply();
/*      */   }
/*      */   
/*      */   public Long pubsubNumPat() {
/* 7911 */     checkIsInMultiOrPipeline();
/* 7912 */     this.connection.sendCommand(Protocol.Command.PUBSUB, Protocol.Keyword.NUMPAT);
/* 7913 */     return this.connection.getIntegerReply();
/*      */   }
/*      */   
/*      */   public Map<String, Long> pubsubNumSub(String... channels) {
/* 7917 */     checkIsInMultiOrPipeline();
/* 7918 */     this.connection.sendCommand(Protocol.Command.PUBSUB, joinParameters(Protocol.Keyword.NUMSUB.name(), channels));
/* 7919 */     return BuilderFactory.PUBSUB_NUMSUB_MAP.build(this.connection.getOne());
/*      */   }
/*      */ 
/*      */   
/*      */   public Object eval(String script, int keyCount, String... params) {
/* 7924 */     checkIsInMultiOrPipeline();
/* 7925 */     return this.connection.executeCommand(this.commandObjects.eval(script, keyCount, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object eval(String script, List<String> keys, List<String> args) {
/* 7930 */     checkIsInMultiOrPipeline();
/* 7931 */     return this.connection.executeCommand(this.commandObjects.eval(script, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object evalReadonly(String script, List<String> keys, List<String> args) {
/* 7936 */     checkIsInMultiOrPipeline();
/* 7937 */     return this.connection.executeCommand(this.commandObjects.evalReadonly(script, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object eval(String script) {
/* 7942 */     checkIsInMultiOrPipeline();
/* 7943 */     return this.connection.executeCommand(this.commandObjects.eval(script));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object evalsha(String sha1) {
/* 7948 */     checkIsInMultiOrPipeline();
/* 7949 */     return this.connection.executeCommand(this.commandObjects.evalsha(sha1));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object evalsha(String sha1, List<String> keys, List<String> args) {
/* 7954 */     checkIsInMultiOrPipeline();
/* 7955 */     return this.connection.executeCommand(this.commandObjects.evalsha(sha1, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object evalshaReadonly(String sha1, List<String> keys, List<String> args) {
/* 7960 */     checkIsInMultiOrPipeline();
/* 7961 */     return this.connection.executeCommand(this.commandObjects.evalshaReadonly(sha1, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object evalsha(String sha1, int keyCount, String... params) {
/* 7966 */     checkIsInMultiOrPipeline();
/* 7967 */     return this.connection.executeCommand(this.commandObjects.evalsha(sha1, keyCount, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean scriptExists(String sha1) {
/* 7972 */     String[] a = new String[1];
/* 7973 */     a[0] = sha1;
/* 7974 */     return scriptExists(a).get(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Boolean> scriptExists(String... sha1) {
/* 7979 */     this.connection.sendCommand(Protocol.Command.SCRIPT, joinParameters(Protocol.Keyword.EXISTS.name(), sha1));
/* 7980 */     return BuilderFactory.BOOLEAN_LIST.build(this.connection.getOne());
/*      */   }
/*      */ 
/*      */   
/*      */   public String scriptLoad(String script) {
/* 7985 */     this.connection.sendCommand(Protocol.Command.SCRIPT, new String[] { Protocol.Keyword.LOAD.name(), script });
/* 7986 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Slowlog> slowlogGet() {
/* 7991 */     this.connection.sendCommand(Protocol.Command.SLOWLOG, Protocol.Keyword.GET);
/* 7992 */     return Slowlog.from(this.connection.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Slowlog> slowlogGet(long entries) {
/* 7997 */     this.connection.sendCommand(Protocol.Command.SLOWLOG, new byte[][] { Protocol.Keyword.GET.getRaw(), Protocol.toByteArray(entries) });
/* 7998 */     return Slowlog.from(this.connection.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   
/*      */   public Long objectRefcount(String key) {
/* 8003 */     this.connection.sendCommand(Protocol.Command.OBJECT, new String[] { Protocol.Keyword.REFCOUNT.name(), key });
/* 8004 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String objectEncoding(String key) {
/* 8009 */     this.connection.sendCommand(Protocol.Command.OBJECT, new String[] { Protocol.Keyword.ENCODING.name(), key });
/* 8010 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Long objectIdletime(String key) {
/* 8015 */     this.connection.sendCommand(Protocol.Command.OBJECT, new String[] { Protocol.Keyword.IDLETIME.name(), key });
/* 8016 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> objectHelp() {
/* 8021 */     this.connection.sendCommand(Protocol.Command.OBJECT, Protocol.Keyword.HELP);
/* 8022 */     return this.connection.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Long objectFreq(String key) {
/* 8027 */     this.connection.sendCommand(Protocol.Command.OBJECT, new String[] { Protocol.Keyword.FREQ.name(), key });
/* 8028 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitcount(String key) {
/* 8033 */     checkIsInMultiOrPipeline();
/* 8034 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitcount(key))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitcount(String key, long start, long end) {
/* 8039 */     checkIsInMultiOrPipeline();
/* 8040 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitcount(key, start, end))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitcount(String key, long start, long end, BitCountOption option) {
/* 8045 */     checkIsInMultiOrPipeline();
/* 8046 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitcount(key, start, end, option))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long bitop(BitOP op, String destKey, String... srcKeys) {
/* 8051 */     checkIsInMultiOrPipeline();
/* 8052 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.bitop(op, destKey, srcKeys))).longValue();
/*      */   }
/*      */   
/*      */   public long commandCount() {
/* 8056 */     checkIsInMultiOrPipeline();
/* 8057 */     this.connection.sendCommand(Protocol.Command.COMMAND, Protocol.Keyword.COUNT);
/* 8058 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */   
/*      */   public Map<String, CommandDocument> commandDocs(String... commands) {
/* 8062 */     checkIsInMultiOrPipeline();
/* 8063 */     this.connection.sendCommand(Protocol.Command.COMMAND, joinParameters(Protocol.Keyword.DOCS.name(), commands));
/* 8064 */     return BuilderFactory.COMMAND_DOCS_RESPONSE.build(this.connection.getOne());
/*      */   }
/*      */   
/*      */   public List<String> commandGetKeys(String... command) {
/* 8068 */     checkIsInMultiOrPipeline();
/* 8069 */     this.connection.sendCommand(Protocol.Command.COMMAND, joinParameters(Protocol.Keyword.GETKEYS.name(), command));
/* 8070 */     return BuilderFactory.STRING_LIST.build(this.connection.getOne());
/*      */   }
/*      */   
/*      */   public List<KeyValue<String, List<String>>> commandGetKeysAndFlags(String... command) {
/* 8074 */     checkIsInMultiOrPipeline();
/* 8075 */     this.connection.sendCommand(Protocol.Command.COMMAND, joinParameters(Protocol.Keyword.GETKEYSANDFLAGS.name(), command));
/* 8076 */     return BuilderFactory.KEYED_STRING_LIST_LIST.build(this.connection.getOne());
/*      */   }
/*      */   
/*      */   public Map<String, CommandInfo> commandInfo(String... commands) {
/* 8080 */     checkIsInMultiOrPipeline();
/* 8081 */     this.connection.sendCommand(Protocol.Command.COMMAND, joinParameters(Protocol.Keyword.INFO.name(), commands));
/* 8082 */     return BuilderFactory.COMMAND_INFO_RESPONSE.build(this.connection.getOne());
/*      */   }
/*      */   
/*      */   public List<String> commandList() {
/* 8086 */     checkIsInMultiOrPipeline();
/* 8087 */     this.connection.sendCommand(Protocol.Command.COMMAND, Protocol.Keyword.LIST);
/* 8088 */     return BuilderFactory.STRING_LIST.build(this.connection.getOne());
/*      */   }
/*      */   
/*      */   public List<String> commandListFilterBy(CommandListFilterByParams filterByParams) {
/* 8092 */     checkIsInMultiOrPipeline();
/* 8093 */     CommandArguments args = (new CommandArguments(Protocol.Command.COMMAND)).add(Protocol.Keyword.LIST).addParams((IParams)filterByParams);
/* 8094 */     this.connection.sendCommand(args);
/* 8095 */     return BuilderFactory.STRING_LIST.build(this.connection.getOne());
/*      */   }
/*      */ 
/*      */   
/*      */   public String sentinelMyId() {
/* 8100 */     this.connection.sendCommand(Protocol.Command.SENTINEL, Protocol.SentinelKeyword.MYID);
/* 8101 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Map<String, String>> sentinelMasters() {
/* 8136 */     this.connection.sendCommand(Protocol.Command.SENTINEL, Protocol.SentinelKeyword.MASTERS);
/* 8137 */     return (List<Map<String, String>>)this.connection.getObjectMultiBulkReply().stream()
/* 8138 */       .map(BuilderFactory.STRING_MAP::build).collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, String> sentinelMaster(String masterName) {
/* 8143 */     this.connection.sendCommand(Protocol.Command.SENTINEL, new String[] { Protocol.SentinelKeyword.MASTER.name(), masterName });
/* 8144 */     return BuilderFactory.STRING_MAP.build(this.connection.getOne());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Map<String, String>> sentinelSentinels(String masterName) {
/* 8149 */     this.connection.sendCommand(Protocol.Command.SENTINEL, new String[] { Protocol.SentinelKeyword.SENTINELS.name(), masterName });
/* 8150 */     return (List<Map<String, String>>)this.connection.getObjectMultiBulkReply().stream()
/* 8151 */       .map(BuilderFactory.STRING_MAP::build).collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> sentinelGetMasterAddrByName(String masterName) {
/* 8165 */     this.connection.sendCommand(Protocol.Command.SENTINEL, new byte[][] { Protocol.SentinelKeyword.GET_MASTER_ADDR_BY_NAME.getRaw(), SafeEncoder.encode(masterName) });
/* 8166 */     return this.connection.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Long sentinelReset(String pattern) {
/* 8178 */     this.connection.sendCommand(Protocol.Command.SENTINEL, new String[] { Protocol.SentinelKeyword.RESET.name(), pattern });
/* 8179 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<Map<String, String>> sentinelSlaves(String masterName) {
/* 8219 */     this.connection.sendCommand(Protocol.Command.SENTINEL, new String[] { Protocol.SentinelKeyword.SLAVES.name(), masterName });
/* 8220 */     return (List<Map<String, String>>)this.connection.getObjectMultiBulkReply().stream()
/* 8221 */       .map(BuilderFactory.STRING_MAP::build).collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Map<String, String>> sentinelReplicas(String masterName) {
/* 8226 */     this.connection.sendCommand(Protocol.Command.SENTINEL, new String[] { Protocol.SentinelKeyword.REPLICAS.name(), masterName });
/* 8227 */     return (List<Map<String, String>>)this.connection.getObjectMultiBulkReply().stream()
/* 8228 */       .map(BuilderFactory.STRING_MAP::build).collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */   
/*      */   public String sentinelFailover(String masterName) {
/* 8233 */     this.connection.sendCommand(Protocol.Command.SENTINEL, new String[] { Protocol.SentinelKeyword.FAILOVER.name(), masterName });
/* 8234 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String sentinelMonitor(String masterName, String ip, int port, int quorum) {
/* 8240 */     CommandArguments args = (new CommandArguments(Protocol.Command.SENTINEL)).add(Protocol.SentinelKeyword.MONITOR).add(masterName).add(ip).add(Integer.valueOf(port)).add(Integer.valueOf(quorum));
/* 8241 */     this.connection.sendCommand(args);
/* 8242 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String sentinelRemove(String masterName) {
/* 8247 */     this.connection.sendCommand(Protocol.Command.SENTINEL, new String[] { Protocol.SentinelKeyword.REMOVE.name(), masterName });
/* 8248 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String sentinelSet(String masterName, Map<String, String> parameterMap) {
/* 8253 */     CommandArguments args = (new CommandArguments(Protocol.Command.SENTINEL)).add(Protocol.SentinelKeyword.SET).add(masterName);
/* 8254 */     parameterMap.entrySet().forEach(entry -> args.add(entry.getKey()).add(entry.getValue()));
/* 8255 */     this.connection.sendCommand(args);
/* 8256 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] dump(String key) {
/* 8261 */     checkIsInMultiOrPipeline();
/* 8262 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.dump(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public String restore(String key, long ttl, byte[] serializedValue) {
/* 8267 */     checkIsInMultiOrPipeline();
/* 8268 */     return this.connection.<String>executeCommand(this.commandObjects.restore(key, ttl, serializedValue));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String restore(String key, long ttl, byte[] serializedValue, RestoreParams params) {
/* 8274 */     checkIsInMultiOrPipeline();
/* 8275 */     return this.connection.<String>executeCommand(this.commandObjects.restore(key, ttl, serializedValue, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public long pttl(String key) {
/* 8280 */     checkIsInMultiOrPipeline();
/* 8281 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pttl(key))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String psetex(String key, long milliseconds, String value) {
/* 8294 */     checkIsInMultiOrPipeline();
/* 8295 */     return this.connection.<String>executeCommand(this.commandObjects.psetex(key, milliseconds, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclSetUser(String name) {
/* 8300 */     checkIsInMultiOrPipeline();
/* 8301 */     this.connection.sendCommand(Protocol.Command.ACL, new String[] { Protocol.Keyword.SETUSER.name(), name });
/* 8302 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclSetUser(String name, String... params) {
/* 8307 */     checkIsInMultiOrPipeline();
/* 8308 */     this.connection.sendCommand(Protocol.Command.ACL, joinParameters(Protocol.Keyword.SETUSER.name(), name, params));
/* 8309 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public long aclDelUser(String name) {
/* 8314 */     checkIsInMultiOrPipeline();
/* 8315 */     this.connection.sendCommand(Protocol.Command.ACL, new String[] { Protocol.Keyword.DELUSER.name(), name });
/* 8316 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long aclDelUser(String name, String... names) {
/* 8321 */     checkIsInMultiOrPipeline();
/* 8322 */     this.connection.sendCommand(Protocol.Command.ACL, joinParameters(Protocol.Keyword.DELUSER.name(), name, names));
/* 8323 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public AccessControlUser aclGetUser(String name) {
/* 8328 */     checkIsInMultiOrPipeline();
/* 8329 */     this.connection.sendCommand(Protocol.Command.ACL, new String[] { Protocol.Keyword.GETUSER.name(), name });
/* 8330 */     return BuilderFactory.ACCESS_CONTROL_USER.build(this.connection.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> aclUsers() {
/* 8335 */     checkIsInMultiOrPipeline();
/* 8336 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.USERS);
/* 8337 */     return BuilderFactory.STRING_LIST.build(this.connection.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> aclList() {
/* 8342 */     checkIsInMultiOrPipeline();
/* 8343 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.LIST);
/* 8344 */     return this.connection.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclWhoAmI() {
/* 8349 */     checkIsInMultiOrPipeline();
/* 8350 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.WHOAMI);
/* 8351 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> aclCat() {
/* 8356 */     checkIsInMultiOrPipeline();
/* 8357 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.CAT);
/* 8358 */     return BuilderFactory.STRING_LIST.build(this.connection.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> aclCat(String category) {
/* 8363 */     checkIsInMultiOrPipeline();
/* 8364 */     this.connection.sendCommand(Protocol.Command.ACL, new String[] { Protocol.Keyword.CAT.name(), category });
/* 8365 */     return BuilderFactory.STRING_LIST.build(this.connection.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<AccessControlLogEntry> aclLog() {
/* 8370 */     checkIsInMultiOrPipeline();
/* 8371 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.LOG);
/* 8372 */     return BuilderFactory.ACCESS_CONTROL_LOG_ENTRY_LIST.build(this.connection.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<AccessControlLogEntry> aclLog(int limit) {
/* 8377 */     checkIsInMultiOrPipeline();
/* 8378 */     this.connection.sendCommand(Protocol.Command.ACL, new byte[][] { Protocol.Keyword.LOG.getRaw(), Protocol.toByteArray(limit) });
/* 8379 */     return BuilderFactory.ACCESS_CONTROL_LOG_ENTRY_LIST.build(this.connection.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclLoad() {
/* 8384 */     checkIsInMultiOrPipeline();
/* 8385 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.LOAD);
/* 8386 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclSave() {
/* 8391 */     checkIsInMultiOrPipeline();
/* 8392 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.SAVE);
/* 8393 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclGenPass() {
/* 8398 */     this.connection.sendCommand(Protocol.Command.ACL, Protocol.Keyword.GENPASS);
/* 8399 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclGenPass(int bits) {
/* 8404 */     checkIsInMultiOrPipeline();
/* 8405 */     this.connection.sendCommand(Protocol.Command.ACL, new byte[][] { Protocol.Keyword.GENPASS.getRaw(), Protocol.toByteArray(bits) });
/* 8406 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclDryRun(String username, String command, String... args) {
/* 8411 */     checkIsInMultiOrPipeline();
/* 8412 */     String[] allArgs = new String[3 + args.length];
/* 8413 */     allArgs[0] = Protocol.Keyword.DRYRUN.name();
/* 8414 */     allArgs[1] = username;
/* 8415 */     allArgs[2] = command;
/* 8416 */     System.arraycopy(args, 0, allArgs, 3, args.length);
/* 8417 */     this.connection.sendCommand(Protocol.Command.ACL, allArgs);
/* 8418 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String aclDryRun(String username, CommandArguments commandArgs) {
/* 8423 */     checkIsInMultiOrPipeline();
/* 8424 */     CommandArguments allArgs = (new CommandArguments(Protocol.Command.ACL)).add(Protocol.Keyword.DRYRUN).add(username);
/* 8425 */     Iterator<Rawable> it = commandArgs.iterator();
/* 8426 */     for (; it.hasNext(); allArgs.add(it.next()));
/* 8427 */     this.connection.sendCommand(allArgs);
/* 8428 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] aclDryRunBinary(byte[] username, byte[] command, byte[]... args) {
/* 8433 */     checkIsInMultiOrPipeline();
/* 8434 */     byte[][] allArgs = new byte[3 + args.length][];
/* 8435 */     allArgs[0] = Protocol.Keyword.DRYRUN.getRaw();
/* 8436 */     allArgs[1] = username;
/* 8437 */     allArgs[2] = command;
/* 8438 */     System.arraycopy(args, 0, allArgs, 3, args.length);
/* 8439 */     this.connection.sendCommand(Protocol.Command.ACL, allArgs);
/* 8440 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] aclDryRunBinary(byte[] username, CommandArguments commandArgs) {
/* 8445 */     checkIsInMultiOrPipeline();
/* 8446 */     CommandArguments allArgs = (new CommandArguments(Protocol.Command.ACL)).add(Protocol.Keyword.DRYRUN).add(username);
/* 8447 */     Iterator<Rawable> it = commandArgs.iterator();
/* 8448 */     for (; it.hasNext(); allArgs.add(it.next()));
/* 8449 */     this.connection.sendCommand(allArgs);
/* 8450 */     return this.connection.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientKill(String ipPort) {
/* 8455 */     checkIsInMultiOrPipeline();
/* 8456 */     this.connection.sendCommand(Protocol.Command.CLIENT, new String[] { Protocol.Keyword.KILL.name(), ipPort });
/* 8457 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientGetname() {
/* 8462 */     checkIsInMultiOrPipeline();
/* 8463 */     this.connection.sendCommand(Protocol.Command.CLIENT, Protocol.Keyword.GETNAME);
/* 8464 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientList() {
/* 8469 */     checkIsInMultiOrPipeline();
/* 8470 */     this.connection.sendCommand(Protocol.Command.CLIENT, Protocol.Keyword.LIST);
/* 8471 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientList(ClientType type) {
/* 8476 */     checkIsInMultiOrPipeline();
/* 8477 */     this.connection.sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.LIST.getRaw(), Protocol.Keyword.TYPE.getRaw(), type.getRaw() });
/* 8478 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientList(long... clientIds) {
/* 8483 */     checkIsInMultiOrPipeline();
/* 8484 */     this.connection.sendCommand(Protocol.Command.CLIENT, clientListParams(clientIds));
/* 8485 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientInfo() {
/* 8490 */     checkIsInMultiOrPipeline();
/* 8491 */     this.connection.sendCommand(Protocol.Command.CLIENT, Protocol.Keyword.INFO);
/* 8492 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clientSetname(String name) {
/* 8497 */     checkIsInMultiOrPipeline();
/* 8498 */     this.connection.sendCommand(Protocol.Command.CLIENT, new String[] { Protocol.Keyword.SETNAME.name(), name });
/* 8499 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String migrate(String host, int port, String key, int destinationDb, int timeout) {
/* 8505 */     checkIsInMultiOrPipeline();
/* 8506 */     return this.connection.<String>executeCommand(this.commandObjects.migrate(host, port, key, destinationDb, timeout));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String migrate(String host, int port, int destinationDB, int timeout, MigrateParams params, String... keys) {
/* 8512 */     checkIsInMultiOrPipeline();
/* 8513 */     return this.connection.<String>executeCommand(this.commandObjects.migrate(host, port, destinationDB, timeout, params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public String migrate(String host, int port, String key, int timeout) {
/* 8518 */     checkIsInMultiOrPipeline();
/* 8519 */     return this.connection.<String>executeCommand(this.commandObjects.migrate(host, port, key, timeout));
/*      */   }
/*      */ 
/*      */   
/*      */   public String migrate(String host, int port, int timeout, MigrateParams params, String... keys) {
/* 8524 */     checkIsInMultiOrPipeline();
/* 8525 */     return this.connection.<String>executeCommand(this.commandObjects.migrate(host, port, timeout, params, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<String> scan(String cursor) {
/* 8530 */     return this.connection.<ScanResult<String>>executeCommand(this.commandObjects.scan(cursor));
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<String> scan(String cursor, ScanParams params) {
/* 8535 */     return this.connection.<ScanResult<String>>executeCommand(this.commandObjects.scan(cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<String> scan(String cursor, ScanParams params, String type) {
/* 8540 */     checkIsInMultiOrPipeline();
/* 8541 */     return this.connection.<ScanResult<String>>executeCommand(this.commandObjects.scan(cursor, params, type));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ScanResult<Map.Entry<String, String>> hscan(String key, String cursor, ScanParams params) {
/* 8547 */     checkIsInMultiOrPipeline();
/* 8548 */     return this.connection.<ScanResult<Map.Entry<String, String>>>executeCommand(this.commandObjects.hscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<String> sscan(String key, String cursor, ScanParams params) {
/* 8553 */     checkIsInMultiOrPipeline();
/* 8554 */     return this.connection.<ScanResult<String>>executeCommand(this.commandObjects.sscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public ScanResult<Tuple> zscan(String key, String cursor, ScanParams params) {
/* 8559 */     checkIsInMultiOrPipeline();
/* 8560 */     return this.connection.<ScanResult<Tuple>>executeCommand(this.commandObjects.zscan(key, cursor, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public String readonly() {
/* 8565 */     checkIsInMultiOrPipeline();
/* 8566 */     this.connection.sendCommand(Protocol.Command.READONLY);
/* 8567 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String readwrite() {
/* 8572 */     checkIsInMultiOrPipeline();
/* 8573 */     this.connection.sendCommand(Protocol.Command.READWRITE);
/* 8574 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterNodes() {
/* 8579 */     checkIsInMultiOrPipeline();
/* 8580 */     this.connection.sendCommand(Protocol.Command.CLUSTER, Protocol.ClusterKeyword.NODES);
/* 8581 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterReplicas(String nodeId) {
/* 8586 */     checkIsInMultiOrPipeline();
/* 8587 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new String[] { Protocol.ClusterKeyword.REPLICAS.name(), nodeId });
/* 8588 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterMeet(String ip, int port) {
/* 8593 */     checkIsInMultiOrPipeline();
/* 8594 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new String[] { Protocol.ClusterKeyword.MEET.name(), ip, Integer.toString(port) });
/* 8595 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterReset() {
/* 8600 */     checkIsInMultiOrPipeline();
/* 8601 */     this.connection.sendCommand(Protocol.Command.CLUSTER, Protocol.ClusterKeyword.RESET);
/* 8602 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterReset(ClusterResetType resetType) {
/* 8607 */     checkIsInMultiOrPipeline();
/* 8608 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new byte[][] { Protocol.ClusterKeyword.RESET.getRaw(), resetType.getRaw() });
/* 8609 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterAddSlots(int... slots) {
/* 8614 */     checkIsInMultiOrPipeline();
/* 8615 */     this.connection.sendCommand(Protocol.Command.CLUSTER, joinParameters(Protocol.ClusterKeyword.ADDSLOTS.getRaw(), joinParameters(slots)));
/* 8616 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterDelSlots(int... slots) {
/* 8621 */     checkIsInMultiOrPipeline();
/* 8622 */     this.connection.sendCommand(Protocol.Command.CLUSTER, joinParameters(Protocol.ClusterKeyword.DELSLOTS.getRaw(), joinParameters(slots)));
/* 8623 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterInfo() {
/* 8628 */     checkIsInMultiOrPipeline();
/* 8629 */     this.connection.sendCommand(Protocol.Command.CLUSTER, Protocol.ClusterKeyword.INFO);
/* 8630 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> clusterGetKeysInSlot(int slot, int count) {
/* 8635 */     checkIsInMultiOrPipeline();
/* 8636 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new byte[][] { Protocol.ClusterKeyword.GETKEYSINSLOT.getRaw(), Protocol.toByteArray(slot), Protocol.toByteArray(count) });
/* 8637 */     return this.connection.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<byte[]> clusterGetKeysInSlotBinary(int slot, int count) {
/* 8642 */     checkIsInMultiOrPipeline();
/* 8643 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new byte[][] { Protocol.ClusterKeyword.GETKEYSINSLOT.getRaw(), Protocol.toByteArray(slot), Protocol.toByteArray(count) });
/* 8644 */     return this.connection.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterSetSlotNode(int slot, String nodeId) {
/* 8649 */     checkIsInMultiOrPipeline();
/* 8650 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new byte[][] { Protocol.ClusterKeyword.SETSLOT.getRaw(), Protocol.toByteArray(slot), Protocol.ClusterKeyword.NODE.getRaw(), SafeEncoder.encode(nodeId) });
/* 8651 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterSetSlotMigrating(int slot, String nodeId) {
/* 8656 */     checkIsInMultiOrPipeline();
/* 8657 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new byte[][] { Protocol.ClusterKeyword.SETSLOT.getRaw(), Protocol.toByteArray(slot), Protocol.ClusterKeyword.MIGRATING.getRaw(), SafeEncoder.encode(nodeId) });
/* 8658 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterSetSlotImporting(int slot, String nodeId) {
/* 8663 */     checkIsInMultiOrPipeline();
/* 8664 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new byte[][] { Protocol.ClusterKeyword.SETSLOT.getRaw(), Protocol.toByteArray(slot), Protocol.ClusterKeyword.IMPORTING.getRaw(), SafeEncoder.encode(nodeId) });
/* 8665 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterSetSlotStable(int slot) {
/* 8670 */     checkIsInMultiOrPipeline();
/* 8671 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new byte[][] { Protocol.ClusterKeyword.SETSLOT.getRaw(), Protocol.toByteArray(slot), Protocol.ClusterKeyword.STABLE.getRaw() });
/* 8672 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterForget(String nodeId) {
/* 8677 */     checkIsInMultiOrPipeline();
/* 8678 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new String[] { Protocol.ClusterKeyword.FORGET.name(), nodeId });
/* 8679 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterFlushSlots() {
/* 8684 */     checkIsInMultiOrPipeline();
/* 8685 */     this.connection.sendCommand(Protocol.Command.CLUSTER, Protocol.ClusterKeyword.FLUSHSLOTS);
/* 8686 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public long clusterKeySlot(String key) {
/* 8691 */     checkIsInMultiOrPipeline();
/* 8692 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new String[] { Protocol.ClusterKeyword.KEYSLOT.name(), key });
/* 8693 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long clusterCountFailureReports(String nodeId) {
/* 8698 */     checkIsInMultiOrPipeline();
/* 8699 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new String[] { "COUNT-FAILURE-REPORTS", nodeId });
/* 8700 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long clusterCountKeysInSlot(int slot) {
/* 8705 */     checkIsInMultiOrPipeline();
/* 8706 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new byte[][] { Protocol.ClusterKeyword.COUNTKEYSINSLOT.getRaw(), Protocol.toByteArray(slot) });
/* 8707 */     return this.connection.getIntegerReply().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterSaveConfig() {
/* 8712 */     checkIsInMultiOrPipeline();
/* 8713 */     this.connection.sendCommand(Protocol.Command.CLUSTER, Protocol.ClusterKeyword.SAVECONFIG);
/* 8714 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterSetConfigEpoch(long configEpoch) {
/* 8719 */     checkIsInMultiOrPipeline();
/* 8720 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new String[] { "SET-CONFIG-EPOCH", Long.toString(configEpoch) });
/* 8721 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterBumpEpoch() {
/* 8726 */     checkIsInMultiOrPipeline();
/* 8727 */     this.connection.sendCommand(Protocol.Command.CLUSTER, Protocol.ClusterKeyword.BUMPEPOCH);
/* 8728 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterReplicate(String nodeId) {
/* 8733 */     checkIsInMultiOrPipeline();
/* 8734 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new String[] { Protocol.ClusterKeyword.REPLICATE.name(), nodeId });
/* 8735 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<String> clusterSlaves(String nodeId) {
/* 8741 */     checkIsInMultiOrPipeline();
/* 8742 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new String[] { Protocol.ClusterKeyword.SLAVES.name(), nodeId });
/* 8743 */     return this.connection.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterFailover() {
/* 8748 */     checkIsInMultiOrPipeline();
/* 8749 */     this.connection.sendCommand(Protocol.Command.CLUSTER, Protocol.ClusterKeyword.FAILOVER);
/* 8750 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterFailover(ClusterFailoverOption failoverOption) {
/* 8755 */     checkIsInMultiOrPipeline();
/* 8756 */     this.connection.sendCommand(Protocol.Command.CLUSTER, new byte[][] { Protocol.ClusterKeyword.FAILOVER.getRaw(), failoverOption.getRaw() });
/* 8757 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> clusterSlots() {
/* 8762 */     checkIsInMultiOrPipeline();
/* 8763 */     this.connection.sendCommand(Protocol.Command.CLUSTER, Protocol.ClusterKeyword.SLOTS);
/* 8764 */     return this.connection.getObjectMultiBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterMyId() {
/* 8769 */     checkIsInMultiOrPipeline();
/* 8770 */     this.connection.sendCommand(Protocol.Command.CLUSTER, Protocol.ClusterKeyword.MYID);
/* 8771 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Map<String, Object>> clusterLinks() {
/* 8776 */     checkIsInMultiOrPipeline();
/* 8777 */     this.connection.sendCommand(Protocol.Command.CLUSTER, Protocol.ClusterKeyword.LINKS);
/* 8778 */     return (List<Map<String, Object>>)this.connection.getObjectMultiBulkReply().stream()
/* 8779 */       .map(BuilderFactory.ENCODED_OBJECT_MAP::build).collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterAddSlotsRange(int... ranges) {
/* 8784 */     checkIsInMultiOrPipeline();
/* 8785 */     this.connection.sendCommand(Protocol.Command.CLUSTER, 
/* 8786 */         joinParameters(Protocol.ClusterKeyword.ADDSLOTSRANGE.getRaw(), joinParameters(ranges)));
/* 8787 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String clusterDelSlotsRange(int... ranges) {
/* 8792 */     checkIsInMultiOrPipeline();
/* 8793 */     this.connection.sendCommand(Protocol.Command.CLUSTER, 
/* 8794 */         joinParameters(Protocol.ClusterKeyword.DELSLOTSRANGE.getRaw(), joinParameters(ranges)));
/* 8795 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String asking() {
/* 8800 */     checkIsInMultiOrPipeline();
/* 8801 */     this.connection.sendCommand(Protocol.Command.ASKING);
/* 8802 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pfadd(String key, String... elements) {
/* 8807 */     checkIsInMultiOrPipeline();
/* 8808 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pfadd(key, elements))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pfcount(String key) {
/* 8813 */     checkIsInMultiOrPipeline();
/* 8814 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pfcount(key))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long pfcount(String... keys) {
/* 8819 */     checkIsInMultiOrPipeline();
/* 8820 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.pfcount(keys))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String pfmerge(String destkey, String... sourcekeys) {
/* 8825 */     checkIsInMultiOrPipeline();
/* 8826 */     return this.connection.<String>executeCommand(this.commandObjects.pfmerge(destkey, sourcekeys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object fcall(String name, List<String> keys, List<String> args) {
/* 8831 */     return this.connection.executeCommand(this.commandObjects.fcall(name, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object fcallReadonly(String name, List<String> keys, List<String> args) {
/* 8836 */     return this.connection.executeCommand(this.commandObjects.fcallReadonly(name, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionDelete(String libraryName) {
/* 8841 */     checkIsInMultiOrPipeline();
/* 8842 */     return this.connection.<String>executeCommand(this.commandObjects.functionDelete(libraryName));
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionLoad(String engineName, String libraryName, String functionCode) {
/* 8847 */     checkIsInMultiOrPipeline();
/* 8848 */     return this.connection.<String>executeCommand(this.commandObjects.functionLoad(engineName, libraryName, functionCode));
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionLoad(String engineName, String libraryName, FunctionLoadParams params, String functionCode) {
/* 8853 */     checkIsInMultiOrPipeline();
/* 8854 */     return this.connection.<String>executeCommand(this.commandObjects.functionLoad(engineName, libraryName, params, functionCode));
/*      */   }
/*      */ 
/*      */   
/*      */   public FunctionStats functionStats() {
/* 8859 */     checkIsInMultiOrPipeline();
/* 8860 */     return this.connection.<FunctionStats>executeCommand(this.commandObjects.functionStats());
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionFlush() {
/* 8865 */     checkIsInMultiOrPipeline();
/* 8866 */     return this.connection.<String>executeCommand(this.commandObjects.functionFlush());
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionFlush(FlushMode mode) {
/* 8871 */     checkIsInMultiOrPipeline();
/* 8872 */     return this.connection.<String>executeCommand(this.commandObjects.functionFlush(mode));
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionKill() {
/* 8877 */     checkIsInMultiOrPipeline();
/* 8878 */     return this.connection.<String>executeCommand(this.commandObjects.functionKill());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<LibraryInfo> functionList() {
/* 8883 */     checkIsInMultiOrPipeline();
/* 8884 */     return this.connection.<List<LibraryInfo>>executeCommand(this.commandObjects.functionList());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<LibraryInfo> functionList(String libraryNamePattern) {
/* 8889 */     checkIsInMultiOrPipeline();
/* 8890 */     return this.connection.<List<LibraryInfo>>executeCommand(this.commandObjects.functionList(libraryNamePattern));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<LibraryInfo> functionListWithCode() {
/* 8895 */     checkIsInMultiOrPipeline();
/* 8896 */     return this.connection.<List<LibraryInfo>>executeCommand(this.commandObjects.functionListWithCode());
/*      */   }
/*      */   
/*      */   public List<LibraryInfo> functionListWithCode(String libraryNamePattern) {
/* 8900 */     checkIsInMultiOrPipeline();
/* 8901 */     return this.connection.<List<LibraryInfo>>executeCommand(this.commandObjects.functionListWithCode(libraryNamePattern));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long geoadd(String key, double longitude, double latitude, String member) {
/* 8907 */     checkIsInMultiOrPipeline();
/* 8908 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geoadd(key, longitude, latitude, member))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geoadd(String key, Map<String, GeoCoordinate> memberCoordinateMap) {
/* 8913 */     checkIsInMultiOrPipeline();
/* 8914 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geoadd(key, memberCoordinateMap))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geoadd(String key, GeoAddParams params, Map<String, GeoCoordinate> memberCoordinateMap) {
/* 8919 */     checkIsInMultiOrPipeline();
/* 8920 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geoadd(key, params, memberCoordinateMap))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public Double geodist(String key, String member1, String member2) {
/* 8925 */     checkIsInMultiOrPipeline();
/* 8926 */     return this.connection.<Double>executeCommand(this.commandObjects.geodist(key, member1, member2));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Double geodist(String key, String member1, String member2, GeoUnit unit) {
/* 8932 */     checkIsInMultiOrPipeline();
/* 8933 */     return this.connection.<Double>executeCommand(this.commandObjects.geodist(key, member1, member2, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> geohash(String key, String... members) {
/* 8938 */     checkIsInMultiOrPipeline();
/* 8939 */     return this.connection.<List<String>>executeCommand(this.commandObjects.geohash(key, members));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoCoordinate> geopos(String key, String... members) {
/* 8944 */     checkIsInMultiOrPipeline();
/* 8945 */     return this.connection.<List<GeoCoordinate>>executeCommand(this.commandObjects.geopos(key, members));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadius(String key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 8951 */     checkIsInMultiOrPipeline();
/* 8952 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadius(key, longitude, latitude, radius, unit));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusReadonly(String key, double longitude, double latitude, double radius, GeoUnit unit) {
/* 8958 */     checkIsInMultiOrPipeline();
/* 8959 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusReadonly(key, longitude, latitude, radius, unit));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadius(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 8965 */     checkIsInMultiOrPipeline();
/* 8966 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadius(key, longitude, latitude, radius, unit, param));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long georadiusStore(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 8972 */     checkIsInMultiOrPipeline();
/* 8973 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.georadiusStore(key, longitude, latitude, radius, unit, param, storeParam))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusReadonly(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 8979 */     checkIsInMultiOrPipeline();
/* 8980 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusReadonly(key, longitude, latitude, radius, unit, param));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusByMember(String key, String member, double radius, GeoUnit unit) {
/* 8986 */     checkIsInMultiOrPipeline();
/* 8987 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusByMember(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusByMemberReadonly(String key, String member, double radius, GeoUnit unit) {
/* 8993 */     checkIsInMultiOrPipeline();
/* 8994 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusByMemberReadonly(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusByMember(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 9000 */     checkIsInMultiOrPipeline();
/* 9001 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusByMember(key, member, radius, unit, param));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long georadiusByMemberStore(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param, GeoRadiusStoreParam storeParam) {
/* 9007 */     checkIsInMultiOrPipeline();
/* 9008 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.georadiusByMemberStore(key, member, radius, unit, param, storeParam))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> georadiusByMemberReadonly(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param) {
/* 9014 */     checkIsInMultiOrPipeline();
/* 9015 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.georadiusByMemberReadonly(key, member, radius, unit, param));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> geosearch(String key, String member, double radius, GeoUnit unit) {
/* 9020 */     checkIsInMultiOrPipeline();
/* 9021 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.geosearch(key, member, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> geosearch(String key, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 9026 */     checkIsInMultiOrPipeline();
/* 9027 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.geosearch(key, coord, radius, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> geosearch(String key, String member, double width, double height, GeoUnit unit) {
/* 9032 */     checkIsInMultiOrPipeline();
/* 9033 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.geosearch(key, member, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> geosearch(String key, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 9038 */     checkIsInMultiOrPipeline();
/* 9039 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.geosearch(key, coord, width, height, unit));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<GeoRadiusResponse> geosearch(String key, GeoSearchParam params) {
/* 9044 */     checkIsInMultiOrPipeline();
/* 9045 */     return this.connection.<List<GeoRadiusResponse>>executeCommand(this.commandObjects.geosearch(key, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStore(String dest, String src, String member, double radius, GeoUnit unit) {
/* 9050 */     checkIsInMultiOrPipeline();
/* 9051 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStore(dest, src, member, radius, unit))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStore(String dest, String src, GeoCoordinate coord, double radius, GeoUnit unit) {
/* 9056 */     checkIsInMultiOrPipeline();
/* 9057 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStore(dest, src, coord, radius, unit))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStore(String dest, String src, String member, double width, double height, GeoUnit unit) {
/* 9062 */     checkIsInMultiOrPipeline();
/* 9063 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStore(dest, src, member, width, height, unit))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStore(String dest, String src, GeoCoordinate coord, double width, double height, GeoUnit unit) {
/* 9068 */     checkIsInMultiOrPipeline();
/* 9069 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStore(dest, src, coord, width, height, unit))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStore(String dest, String src, GeoSearchParam params) {
/* 9074 */     checkIsInMultiOrPipeline();
/* 9075 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStore(dest, src, params))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long geosearchStoreStoreDist(String dest, String src, GeoSearchParam params) {
/* 9080 */     checkIsInMultiOrPipeline();
/* 9081 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.geosearchStoreStoreDist(dest, src, params))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String moduleLoad(String path) {
/* 9086 */     checkIsInMultiOrPipeline();
/* 9087 */     this.connection.sendCommand(Protocol.Command.MODULE, new String[] { Protocol.Keyword.LOAD.name(), path });
/* 9088 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String moduleLoad(String path, String... args) {
/* 9093 */     checkIsInMultiOrPipeline();
/* 9094 */     this.connection.sendCommand(Protocol.Command.MODULE, joinParameters(Protocol.Keyword.LOAD.name(), path, args));
/* 9095 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String moduleUnload(String name) {
/* 9100 */     checkIsInMultiOrPipeline();
/* 9101 */     this.connection.sendCommand(Protocol.Command.MODULE, new String[] { Protocol.Keyword.UNLOAD.name(), name });
/* 9102 */     return this.connection.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Module> moduleList() {
/* 9107 */     checkIsInMultiOrPipeline();
/* 9108 */     this.connection.sendCommand(Protocol.Command.MODULE, Protocol.Keyword.LIST);
/* 9109 */     return BuilderFactory.MODULE_LIST.build(this.connection.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Long> bitfield(String key, String... arguments) {
/* 9114 */     checkIsInMultiOrPipeline();
/* 9115 */     return this.connection.<List<Long>>executeCommand(this.commandObjects.bitfield(key, arguments));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Long> bitfieldReadonly(String key, String... arguments) {
/* 9120 */     checkIsInMultiOrPipeline();
/* 9121 */     return this.connection.<List<Long>>executeCommand(this.commandObjects.bitfieldReadonly(key, arguments));
/*      */   }
/*      */ 
/*      */   
/*      */   public long hstrlen(String key, String field) {
/* 9126 */     checkIsInMultiOrPipeline();
/* 9127 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.hstrlen(key, field))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String memoryDoctor() {
/* 9132 */     checkIsInMultiOrPipeline();
/* 9133 */     this.connection.sendCommand(Protocol.Command.MEMORY, Protocol.Keyword.DOCTOR);
/* 9134 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Long memoryUsage(String key) {
/* 9139 */     checkIsInMultiOrPipeline();
/* 9140 */     this.connection.sendCommand(Protocol.Command.MEMORY, new String[] { Protocol.Keyword.USAGE.name(), key });
/* 9141 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Long memoryUsage(String key, int samples) {
/* 9146 */     checkIsInMultiOrPipeline();
/* 9147 */     this.connection.sendCommand(Protocol.Command.MEMORY, new byte[][] { Protocol.Keyword.USAGE.getRaw(), SafeEncoder.encode(key), Protocol.Keyword.SAMPLES.getRaw(), Protocol.toByteArray(samples) });
/* 9148 */     return this.connection.getIntegerReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String memoryPurge() {
/* 9153 */     checkIsInMultiOrPipeline();
/* 9154 */     this.connection.sendCommand(Protocol.Command.MEMORY, Protocol.Keyword.PURGE);
/* 9155 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, Object> memoryStats() {
/* 9160 */     checkIsInMultiOrPipeline();
/* 9161 */     this.connection.sendCommand(Protocol.Command.MEMORY, Protocol.Keyword.STATS);
/* 9162 */     return BuilderFactory.ENCODED_OBJECT_MAP.build(this.connection.getOne());
/*      */   }
/*      */ 
/*      */   
/*      */   public String lolwut() {
/* 9167 */     checkIsInMultiOrPipeline();
/* 9168 */     this.connection.sendCommand(Protocol.Command.LOLWUT);
/* 9169 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public String lolwut(LolwutParams lolwutParams) {
/* 9174 */     checkIsInMultiOrPipeline();
/* 9175 */     this.connection.sendCommand((new CommandArguments(Protocol.Command.LOLWUT)).addParams((IParams)lolwutParams));
/* 9176 */     return this.connection.getBulkReply();
/*      */   }
/*      */ 
/*      */   
/*      */   public StreamEntryID xadd(String key, StreamEntryID id, Map<String, String> hash) {
/* 9181 */     checkIsInMultiOrPipeline();
/* 9182 */     return this.connection.<StreamEntryID>executeCommand(this.commandObjects.xadd(key, id, hash));
/*      */   }
/*      */ 
/*      */   
/*      */   public StreamEntryID xadd(String key, XAddParams params, Map<String, String> hash) {
/* 9187 */     checkIsInMultiOrPipeline();
/* 9188 */     return this.connection.<StreamEntryID>executeCommand(this.commandObjects.xadd(key, params, hash));
/*      */   }
/*      */ 
/*      */   
/*      */   public long xlen(String key) {
/* 9193 */     checkIsInMultiOrPipeline();
/* 9194 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xlen(key))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<StreamEntry> xrange(String key, StreamEntryID start, StreamEntryID end) {
/* 9199 */     checkIsInMultiOrPipeline();
/* 9200 */     return this.connection.<List<StreamEntry>>executeCommand(this.commandObjects.xrange(key, start, end));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<StreamEntry> xrange(String key, StreamEntryID start, StreamEntryID end, int count) {
/* 9206 */     checkIsInMultiOrPipeline();
/* 9207 */     return this.connection.<List<StreamEntry>>executeCommand(this.commandObjects.xrange(key, start, end, count));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<StreamEntry> xrevrange(String key, StreamEntryID end, StreamEntryID start) {
/* 9213 */     checkIsInMultiOrPipeline();
/* 9214 */     return this.connection.<List<StreamEntry>>executeCommand(this.commandObjects.xrevrange(key, end, start));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<StreamEntry> xrevrange(String key, StreamEntryID end, StreamEntryID start, int count) {
/* 9220 */     checkIsInMultiOrPipeline();
/* 9221 */     return this.connection.<List<StreamEntry>>executeCommand(this.commandObjects.xrevrange(key, end, start, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<StreamEntry> xrange(String key, String start, String end) {
/* 9226 */     checkIsInMultiOrPipeline();
/* 9227 */     return this.connection.<List<StreamEntry>>executeCommand(this.commandObjects.xrange(key, start, end));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<StreamEntry> xrange(String key, String start, String end, int count) {
/* 9232 */     checkIsInMultiOrPipeline();
/* 9233 */     return this.connection.<List<StreamEntry>>executeCommand(this.commandObjects.xrange(key, start, end, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<StreamEntry> xrevrange(String key, String end, String start) {
/* 9238 */     checkIsInMultiOrPipeline();
/* 9239 */     return this.connection.<List<StreamEntry>>executeCommand(this.commandObjects.xrevrange(key, end, start));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<StreamEntry> xrevrange(String key, String end, String start, int count) {
/* 9244 */     checkIsInMultiOrPipeline();
/* 9245 */     return this.connection.<List<StreamEntry>>executeCommand(this.commandObjects.xrevrange(key, end, start, count));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Map.Entry<String, List<StreamEntry>>> xread(XReadParams xReadParams, Map<String, StreamEntryID> streams) {
/* 9250 */     checkIsInMultiOrPipeline();
/* 9251 */     return this.connection.<List<Map.Entry<String, List<StreamEntry>>>>executeCommand(this.commandObjects.xread(xReadParams, streams));
/*      */   }
/*      */ 
/*      */   
/*      */   public long xack(String key, String group, StreamEntryID... ids) {
/* 9256 */     checkIsInMultiOrPipeline();
/* 9257 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xack(key, group, ids))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String xgroupCreate(String key, String groupName, StreamEntryID id, boolean makeStream) {
/* 9263 */     checkIsInMultiOrPipeline();
/* 9264 */     return this.connection.<String>executeCommand(this.commandObjects.xgroupCreate(key, groupName, id, makeStream));
/*      */   }
/*      */ 
/*      */   
/*      */   public String xgroupSetID(String key, String groupName, StreamEntryID id) {
/* 9269 */     checkIsInMultiOrPipeline();
/* 9270 */     return this.connection.<String>executeCommand(this.commandObjects.xgroupSetID(key, groupName, id));
/*      */   }
/*      */ 
/*      */   
/*      */   public long xgroupDestroy(String key, String groupName) {
/* 9275 */     checkIsInMultiOrPipeline();
/* 9276 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xgroupDestroy(key, groupName))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean xgroupCreateConsumer(String key, String groupName, String consumerName) {
/* 9281 */     checkIsInMultiOrPipeline();
/* 9282 */     return ((Boolean)this.connection.<Boolean>executeCommand(this.commandObjects.xgroupCreateConsumer(key, groupName, consumerName))).booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long xgroupDelConsumer(String key, String groupName, String consumerName) {
/* 9287 */     checkIsInMultiOrPipeline();
/* 9288 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xgroupDelConsumer(key, groupName, consumerName))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long xdel(String key, StreamEntryID... ids) {
/* 9293 */     checkIsInMultiOrPipeline();
/* 9294 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xdel(key, ids))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long xtrim(String key, long maxLen, boolean approximateLength) {
/* 9299 */     checkIsInMultiOrPipeline();
/* 9300 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xtrim(key, maxLen, approximateLength))).longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public long xtrim(String key, XTrimParams params) {
/* 9305 */     checkIsInMultiOrPipeline();
/* 9306 */     return ((Long)this.connection.<Long>executeCommand(this.commandObjects.xtrim(key, params))).longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Map.Entry<String, List<StreamEntry>>> xreadGroup(String groupName, String consumer, XReadGroupParams xReadGroupParams, Map<String, StreamEntryID> streams) {
/* 9313 */     checkIsInMultiOrPipeline();
/* 9314 */     return this.connection.<List<Map.Entry<String, List<StreamEntry>>>>executeCommand(this.commandObjects.xreadGroup(groupName, consumer, xReadGroupParams, streams));
/*      */   }
/*      */ 
/*      */   
/*      */   public StreamPendingSummary xpending(String key, String groupName) {
/* 9319 */     checkIsInMultiOrPipeline();
/* 9320 */     return this.connection.<StreamPendingSummary>executeCommand(this.commandObjects.xpending(key, groupName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<StreamPendingEntry> xpending(String key, String groupName, StreamEntryID start, StreamEntryID end, int count, String consumerName) {
/* 9330 */     checkIsInMultiOrPipeline();
/* 9331 */     return this.connection.<List<StreamPendingEntry>>executeCommand(this.commandObjects.xpending(key, groupName, start, end, count, consumerName));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<StreamPendingEntry> xpending(String key, String groupName, XPendingParams params) {
/* 9336 */     checkIsInMultiOrPipeline();
/* 9337 */     return this.connection.<List<StreamPendingEntry>>executeCommand(this.commandObjects.xpending(key, groupName, params));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<StreamEntry> xclaim(String key, String group, String consumerName, long minIdleTime, XClaimParams params, StreamEntryID... ids) {
/* 9343 */     checkIsInMultiOrPipeline();
/* 9344 */     return this.connection.<List<StreamEntry>>executeCommand(this.commandObjects.xclaim(key, group, consumerName, minIdleTime, params, ids));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<StreamEntryID> xclaimJustId(String key, String group, String consumerName, long minIdleTime, XClaimParams params, StreamEntryID... ids) {
/* 9350 */     checkIsInMultiOrPipeline();
/* 9351 */     return this.connection.<List<StreamEntryID>>executeCommand(this.commandObjects.xclaimJustId(key, group, consumerName, minIdleTime, params, ids));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Map.Entry<StreamEntryID, List<StreamEntry>> xautoclaim(String key, String group, String consumerName, long minIdleTime, StreamEntryID start, XAutoClaimParams params) {
/* 9357 */     checkIsInMultiOrPipeline();
/* 9358 */     return this.connection.<Map.Entry<StreamEntryID, List<StreamEntry>>>executeCommand(this.commandObjects.xautoclaim(key, group, consumerName, minIdleTime, start, params));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Map.Entry<StreamEntryID, List<StreamEntryID>> xautoclaimJustId(String key, String group, String consumerName, long minIdleTime, StreamEntryID start, XAutoClaimParams params) {
/* 9364 */     checkIsInMultiOrPipeline();
/* 9365 */     return this.connection.<Map.Entry<StreamEntryID, List<StreamEntryID>>>executeCommand(this.commandObjects.xautoclaimJustId(key, group, consumerName, minIdleTime, start, params));
/*      */   }
/*      */ 
/*      */   
/*      */   public StreamInfo xinfoStream(String key) {
/* 9370 */     return this.connection.<StreamInfo>executeCommand(this.commandObjects.xinfoStream(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public StreamFullInfo xinfoStreamFull(String key) {
/* 9375 */     checkIsInMultiOrPipeline();
/* 9376 */     return this.connection.<StreamFullInfo>executeCommand(this.commandObjects.xinfoStreamFull(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public StreamFullInfo xinfoStreamFull(String key, int count) {
/* 9381 */     checkIsInMultiOrPipeline();
/* 9382 */     return this.connection.<StreamFullInfo>executeCommand(this.commandObjects.xinfoStreamFull(key, count));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<StreamGroupInfo> xinfoGroup(String key) {
/* 9388 */     return this.connection.<List<StreamGroupInfo>>executeCommand(this.commandObjects.xinfoGroup(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<StreamGroupInfo> xinfoGroups(String key) {
/* 9393 */     return this.connection.<List<StreamGroupInfo>>executeCommand(this.commandObjects.xinfoGroups(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<StreamConsumersInfo> xinfoConsumers(String key, String group) {
/* 9398 */     return this.connection.<List<StreamConsumersInfo>>executeCommand(this.commandObjects.xinfoConsumers(key, group));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object fcall(byte[] name, List<byte[]> keys, List<byte[]> args) {
/* 9403 */     checkIsInMultiOrPipeline();
/* 9404 */     return this.connection.executeCommand(this.commandObjects.fcall(name, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object fcallReadonly(byte[] name, List<byte[]> keys, List<byte[]> args) {
/* 9409 */     checkIsInMultiOrPipeline();
/* 9410 */     return this.connection.executeCommand(this.commandObjects.fcallReadonly(name, keys, args));
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionDelete(byte[] libraryName) {
/* 9415 */     checkIsInMultiOrPipeline();
/* 9416 */     return this.connection.<String>executeCommand(this.commandObjects.functionDelete(libraryName));
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] functionDump() {
/* 9421 */     checkIsInMultiOrPipeline();
/* 9422 */     return this.connection.<byte[]>executeCommand((CommandObject)this.commandObjects.functionDump());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> functionListBinary() {
/* 9427 */     checkIsInMultiOrPipeline();
/* 9428 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.functionListBinary());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> functionList(byte[] libraryNamePattern) {
/* 9433 */     checkIsInMultiOrPipeline();
/* 9434 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.functionList(libraryNamePattern));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> functionListWithCodeBinary() {
/* 9439 */     checkIsInMultiOrPipeline();
/* 9440 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.functionListWithCodeBinary());
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> functionListWithCode(byte[] libraryNamePattern) {
/* 9445 */     checkIsInMultiOrPipeline();
/* 9446 */     return this.connection.<List<Object>>executeCommand(this.commandObjects.functionListWithCode(libraryNamePattern));
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionLoad(byte[] engineName, byte[] libraryName, byte[] functionCode) {
/* 9451 */     checkIsInMultiOrPipeline();
/* 9452 */     return this.connection.<String>executeCommand(this.commandObjects.functionLoad(engineName, libraryName, functionCode));
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionLoad(byte[] engineName, byte[] libraryName, FunctionLoadParams params, byte[] functionCode) {
/* 9457 */     checkIsInMultiOrPipeline();
/* 9458 */     return this.connection.<String>executeCommand(this.commandObjects.functionLoad(engineName, libraryName, params, functionCode));
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionRestore(byte[] serializedValue) {
/* 9463 */     checkIsInMultiOrPipeline();
/* 9464 */     return this.connection.<String>executeCommand(this.commandObjects.functionRestore(serializedValue));
/*      */   }
/*      */ 
/*      */   
/*      */   public String functionRestore(byte[] serializedValue, FunctionRestorePolicy policy) {
/* 9469 */     checkIsInMultiOrPipeline();
/* 9470 */     return this.connection.<String>executeCommand(this.commandObjects.functionRestore(serializedValue, policy));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object functionStatsBinary() {
/* 9475 */     checkIsInMultiOrPipeline();
/* 9476 */     return this.connection.executeCommand(this.commandObjects.functionStatsBinary());
/*      */   }
/*      */   
/*      */   public Object sendCommand(ProtocolCommand cmd, String... args) {
/* 9480 */     checkIsInMultiOrPipeline();
/* 9481 */     this.connection.sendCommand(cmd, args);
/* 9482 */     return this.connection.getOne();
/*      */   }
/*      */   
/*      */   public Object sendBlockingCommand(ProtocolCommand cmd, String... args) {
/* 9486 */     checkIsInMultiOrPipeline();
/* 9487 */     this.connection.sendCommand(cmd, args);
/* 9488 */     this.connection.setTimeoutInfinite();
/*      */     try {
/* 9490 */       return this.connection.getOne();
/*      */     } finally {
/* 9492 */       this.connection.rollbackTimeout();
/*      */     } 
/*      */   }
/*      */   
/*      */   private static byte[][] joinParameters(int... params) {
/* 9497 */     byte[][] result = new byte[params.length][];
/* 9498 */     for (int i = 0; i < params.length; i++) {
/* 9499 */       result[i] = Protocol.toByteArray(params[i]);
/*      */     }
/* 9501 */     return result;
/*      */   }
/*      */   
/*      */   private static byte[][] joinParameters(byte[] first, byte[][] rest) {
/* 9505 */     byte[][] result = new byte[rest.length + 1][];
/* 9506 */     result[0] = first;
/* 9507 */     System.arraycopy(rest, 0, result, 1, rest.length);
/* 9508 */     return result;
/*      */   }
/*      */   
/*      */   private static byte[][] joinParameters(byte[] first, byte[] second, byte[][] rest) {
/* 9512 */     byte[][] result = new byte[rest.length + 2][];
/* 9513 */     result[0] = first;
/* 9514 */     result[1] = second;
/* 9515 */     System.arraycopy(rest, 0, result, 2, rest.length);
/* 9516 */     return result;
/*      */   }
/*      */   
/*      */   private static String[] joinParameters(String first, String[] rest) {
/* 9520 */     String[] result = new String[rest.length + 1];
/* 9521 */     result[0] = first;
/* 9522 */     System.arraycopy(rest, 0, result, 1, rest.length);
/* 9523 */     return result;
/*      */   }
/*      */   
/*      */   private static String[] joinParameters(String first, String second, String[] rest) {
/* 9527 */     String[] result = new String[rest.length + 2];
/* 9528 */     result[0] = first;
/* 9529 */     result[1] = second;
/* 9530 */     System.arraycopy(rest, 0, result, 2, rest.length);
/* 9531 */     return result;
/*      */   }
/*      */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\Jedis.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */