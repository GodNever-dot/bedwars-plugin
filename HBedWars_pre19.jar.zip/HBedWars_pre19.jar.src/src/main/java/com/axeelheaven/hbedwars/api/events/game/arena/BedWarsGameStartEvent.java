/*    */ package com.axeelheaven.hbedwars.api.events.game.arena;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.api.arena.Arena;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsGameStartEvent
/*    */   extends Event {
/*    */   private final Arena arena;
/* 10 */   private static final HandlerList handlerList = new HandlerList(); public Arena getArena() {
/* 11 */     return this.arena;
/*    */   }
/*    */   public BedWarsGameStartEvent(Arena arena) {
/* 14 */     this.arena = arena;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 19 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 23 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\game\arena\BedWarsGameStartEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */