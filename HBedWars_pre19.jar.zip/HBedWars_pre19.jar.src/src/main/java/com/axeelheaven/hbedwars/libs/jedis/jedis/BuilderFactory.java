/*      */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.AccessControlLogEntry;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.AccessControlUser;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.CommandDocument;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.CommandInfo;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.GeoRadiusResponse;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.LCSMatchResult;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.ScanResult;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamConsumerFullInfo;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamConsumersInfo;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamEntry;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamGroupInfo;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.Tuple;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.timeseries.TSElement;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.KeyValue;
/*      */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*      */ import com.axeelheaven.hbedwars.libs.json.JSONArray;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ public final class BuilderFactory {
/*   26 */   public static final Builder<Object> RAW_OBJECT = new Builder()
/*      */     {
/*      */       public Object build(Object data) {
/*   29 */         return data;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*   34 */         return "Object";
/*      */       }
/*      */     };
/*      */   
/*   38 */   public static final Builder<List<Object>> RAW_OBJECT_LIST = new Builder<List<Object>>()
/*      */     {
/*      */       public List<Object> build(Object data) {
/*   41 */         return (List<Object>)data;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*   46 */         return "List<Object>";
/*      */       }
/*      */     };
/*      */   
/*   50 */   public static final Builder<Object> ENCODED_OBJECT = new Builder()
/*      */     {
/*      */       public Object build(Object data) {
/*   53 */         return SafeEncoder.encodeObject(data);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*   58 */         return "Object";
/*      */       }
/*      */     };
/*      */   
/*   62 */   public static final Builder<List<Object>> ENCODED_OBJECT_LIST = new Builder<List<Object>>()
/*      */     {
/*      */       public List<Object> build(Object data) {
/*   65 */         return (List<Object>)SafeEncoder.encodeObject(data);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*   70 */         return "List<Object>";
/*      */       }
/*      */     };
/*      */   
/*   74 */   public static final Builder<Map<String, Object>> ENCODED_OBJECT_MAP = new Builder<Map<String, Object>>()
/*      */     {
/*      */       public Map<String, Object> build(Object data) {
/*   77 */         List list = (List)data;
/*   78 */         Map<String, Object> map = new HashMap<>(list.size() / 2, 1.0F);
/*   79 */         Iterator iterator = list.iterator();
/*   80 */         while (iterator.hasNext()) {
/*   81 */           map.put(BuilderFactory.STRING.build(iterator.next()), BuilderFactory.ENCODED_OBJECT.build(iterator.next()));
/*      */         }
/*   83 */         return map;
/*      */       }
/*      */     };
/*      */   
/*   87 */   public static final Builder<Long> LONG = new Builder<Long>()
/*      */     {
/*      */       public Long build(Object data) {
/*   90 */         return (Long)data;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*   95 */         return "Long";
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*  100 */   public static final Builder<List<Long>> LONG_LIST = new Builder<List<Long>>()
/*      */     {
/*      */       public List<Long> build(Object data)
/*      */       {
/*  104 */         if (null == data) {
/*  105 */           return null;
/*      */         }
/*  107 */         return (List<Long>)data;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  112 */         return "List<Long>";
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*  117 */   public static final Builder<Double> DOUBLE = new Builder<Double>()
/*      */     {
/*      */       public Double build(Object data) {
/*  120 */         String string = BuilderFactory.STRING.build(data);
/*  121 */         if (string == null) return null; 
/*      */         try {
/*  123 */           return Double.valueOf(string);
/*  124 */         } catch (NumberFormatException e) {
/*  125 */           if (string.equals("inf") || string.equals("+inf")) return Double.valueOf(Double.POSITIVE_INFINITY); 
/*  126 */           if (string.equals("-inf")) return Double.valueOf(Double.NEGATIVE_INFINITY); 
/*  127 */           throw e;
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  133 */         return "Double";
/*      */       }
/*      */     };
/*      */   
/*  137 */   public static final Builder<List<Double>> DOUBLE_LIST = new Builder<List<Double>>()
/*      */     {
/*      */       public List<Double> build(Object data)
/*      */       {
/*  141 */         if (null == data) {
/*  142 */           return null;
/*      */         }
/*  144 */         List<byte[]> values = (List<byte[]>)data;
/*  145 */         List<Double> doubles = new ArrayList<>(values.size());
/*  146 */         for (byte[] value : values) {
/*  147 */           doubles.add(BuilderFactory.DOUBLE.build(value));
/*      */         }
/*  149 */         return doubles;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  154 */         return "List<Double>";
/*      */       }
/*      */     };
/*      */   
/*  158 */   public static final Builder<Boolean> BOOLEAN = new Builder<Boolean>()
/*      */     {
/*      */       public Boolean build(Object data) {
/*  161 */         if (data == null) return null; 
/*  162 */         return Boolean.valueOf((((Long)data).longValue() == 1L));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  167 */         return "Boolean";
/*      */       }
/*      */     };
/*      */   
/*  171 */   public static final Builder<List<Boolean>> BOOLEAN_LIST = new Builder<List<Boolean>>()
/*      */     {
/*      */       public List<Boolean> build(Object data)
/*      */       {
/*  175 */         if (null == data) {
/*  176 */           return null;
/*      */         }
/*  178 */         List<Long> longs = (List<Long>)data;
/*  179 */         List<Boolean> booleans = new ArrayList<>(longs.size());
/*  180 */         for (Long value : longs) {
/*  181 */           booleans.add((value == null) ? null : Boolean.valueOf((value.longValue() == 1L)));
/*      */         }
/*  183 */         return booleans;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  188 */         return "List<Boolean>";
/*      */       }
/*      */     };
/*      */   
/*  192 */   public static final Builder<List<Boolean>> BOOLEAN_WITH_ERROR_LIST = new Builder<List<Boolean>>()
/*      */     {
/*      */       public List<Boolean> build(Object data)
/*      */       {
/*  196 */         if (null == data) {
/*  197 */           return null;
/*      */         }
/*  199 */         List<Object> longs = (List<Object>)data;
/*  200 */         List<Boolean> booleans = new ArrayList<>(longs.size());
/*  201 */         for (Object value : longs) {
/*  202 */           Boolean bool = null;
/*  203 */           if (value != null && value instanceof Long) {
/*  204 */             long longValue = ((Long)value).longValue();
/*  205 */             if (longValue == 1L) {
/*  206 */               bool = Boolean.TRUE;
/*  207 */             } else if (longValue == 0L) {
/*  208 */               bool = Boolean.FALSE;
/*      */             } 
/*      */           } 
/*  211 */           booleans.add(bool);
/*      */         } 
/*  213 */         return booleans;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  218 */         return "List<Boolean>";
/*      */       }
/*      */     };
/*      */   
/*  222 */   public static final Builder<byte[]> BYTE_ARRAY = new Builder<byte[]>()
/*      */     {
/*      */       public byte[] build(Object data) {
/*  225 */         return (byte[])data;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  230 */         return "byte[]";
/*      */       }
/*      */     };
/*      */   
/*  234 */   public static final Builder<List<byte[]>> BYTE_ARRAY_LIST = new Builder<List<byte[]>>()
/*      */     {
/*      */       public List<byte[]> build(Object data)
/*      */       {
/*  238 */         if (null == data) {
/*  239 */           return null;
/*      */         }
/*  241 */         return (List<byte[]>)data;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  246 */         return "List<byte[]>";
/*      */       }
/*      */     };
/*      */   
/*  250 */   public static final Builder<byte[]> BINARY = new Builder<byte[]>()
/*      */     {
/*      */       public byte[] build(Object data) {
/*  253 */         return (byte[])data;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  258 */         return "byte[]";
/*      */       }
/*      */     };
/*      */   
/*  262 */   public static final Builder<List<byte[]>> BINARY_LIST = new Builder<List<byte[]>>()
/*      */     {
/*      */       public List<byte[]> build(Object data)
/*      */       {
/*  266 */         return (List<byte[]>)data;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  271 */         return "List<byte[]>";
/*      */       }
/*      */     };
/*      */   
/*  275 */   public static final Builder<Set<byte[]>> BINARY_SET = new Builder<Set<byte[]>>()
/*      */     {
/*      */       public Set<byte[]> build(Object data)
/*      */       {
/*  279 */         if (null == data) {
/*  280 */           return null;
/*      */         }
/*  282 */         List<byte[]> l = BuilderFactory.BINARY_LIST.build(data);
/*  283 */         return (Set)BuilderFactory.SetFromList.of((List)l);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  288 */         return "Set<byte[]>";
/*      */       }
/*      */     };
/*      */   
/*  292 */   public static final Builder<Map<byte[], byte[]>> BINARY_MAP = new Builder<Map<byte[], byte[]>>()
/*      */     {
/*      */       public Map<byte[], byte[]> build(Object data)
/*      */       {
/*  296 */         List<byte[]> flatHash = (List<byte[]>)data;
/*  297 */         JedisByteHashMap jedisByteHashMap = new JedisByteHashMap();
/*  298 */         Iterator<byte[]> iterator = (Iterator)flatHash.iterator();
/*  299 */         while (iterator.hasNext()) {
/*  300 */           jedisByteHashMap.put(iterator.next(), iterator.next());
/*      */         }
/*      */         
/*  303 */         return (Map<byte[], byte[]>)jedisByteHashMap;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  308 */         return "Map<byte[], byte[]>";
/*      */       }
/*      */     };
/*      */   
/*  312 */   public static final Builder<String> STRING = new Builder<String>()
/*      */     {
/*      */       public String build(Object data) {
/*  315 */         return (data == null) ? null : SafeEncoder.encode((byte[])data);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  320 */         return "String";
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*  325 */   public static final Builder<List<String>> STRING_LIST = new Builder<List<String>>()
/*      */     {
/*      */       public List<String> build(Object data)
/*      */       {
/*  329 */         if (null == data) {
/*  330 */           return null;
/*      */         }
/*  332 */         List<byte[]> l = (List<byte[]>)data;
/*  333 */         ArrayList<String> result = new ArrayList<>(l.size());
/*  334 */         for (byte[] barray : l) {
/*  335 */           if (barray == null) {
/*  336 */             result.add(null); continue;
/*      */           } 
/*  338 */           result.add(SafeEncoder.encode(barray));
/*      */         } 
/*      */         
/*  341 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  346 */         return "List<String>";
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*  351 */   public static final Builder<Set<String>> STRING_SET = new Builder<Set<String>>()
/*      */     {
/*      */       public Set<String> build(Object data)
/*      */       {
/*  355 */         if (null == data) {
/*  356 */           return null;
/*      */         }
/*  358 */         List<byte[]> l = (List<byte[]>)data;
/*  359 */         Set<String> result = new HashSet<>(l.size(), 1.0F);
/*  360 */         for (byte[] barray : l) {
/*  361 */           if (barray == null) {
/*  362 */             result.add(null); continue;
/*      */           } 
/*  364 */           result.add(SafeEncoder.encode(barray));
/*      */         } 
/*      */         
/*  367 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  372 */         return "Set<String>";
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*  377 */   public static final Builder<Map<String, String>> STRING_MAP = new Builder<Map<String, String>>()
/*      */     {
/*      */       public Map<String, String> build(Object data)
/*      */       {
/*  381 */         List<byte[]> flatHash = (List<byte[]>)data;
/*  382 */         Map<String, String> hash = new HashMap<>(flatHash.size() / 2, 1.0F);
/*  383 */         Iterator<byte[]> iterator = (Iterator)flatHash.iterator();
/*  384 */         while (iterator.hasNext()) {
/*  385 */           hash.put(SafeEncoder.encode(iterator.next()), SafeEncoder.encode(iterator.next()));
/*      */         }
/*      */         
/*  388 */         return hash;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  393 */         return "Map<String, String>";
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*  398 */   public static final Builder<KeyedListElement> KEYED_LIST_ELEMENT = new Builder<KeyedListElement>()
/*      */     {
/*      */       public KeyedListElement build(Object data)
/*      */       {
/*  402 */         if (data == null) return null; 
/*  403 */         List<byte[]> l = (List<byte[]>)data;
/*  404 */         return new KeyedListElement(l.get(0), l.get(1));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  409 */         return "KeyedListElement";
/*      */       }
/*      */     };
/*      */   
/*  413 */   public static final Builder<KeyValue<String, List<String>>> KEYED_STRING_LIST = new Builder<KeyValue<String, List<String>>>()
/*      */     {
/*      */       
/*      */       public KeyValue<String, List<String>> build(Object data)
/*      */       {
/*  418 */         if (data == null) return null; 
/*  419 */         List<byte[]> l = (List<byte[]>)data;
/*  420 */         return new KeyValue(BuilderFactory.STRING.build(l.get(0)), BuilderFactory.STRING_LIST.build(l.get(1)));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  425 */         return "KeyValue<String, List<String>>";
/*      */       }
/*      */     };
/*      */   
/*  429 */   public static final Builder<List<KeyValue<String, List<String>>>> KEYED_STRING_LIST_LIST = new Builder<List<KeyValue<String, List<String>>>>()
/*      */     {
/*      */       public List<KeyValue<String, List<String>>> build(Object data)
/*      */       {
/*  433 */         List<Object> list = (List<Object>)data;
/*  434 */         return (List<KeyValue<String, List<String>>>)list.stream().map(BuilderFactory.KEYED_STRING_LIST::build).collect(Collectors.toList());
/*      */       }
/*      */     };
/*      */   
/*  438 */   public static final Builder<KeyValue<byte[], List<byte[]>>> KEYED_BINARY_LIST = new Builder<KeyValue<byte[], List<byte[]>>>()
/*      */     {
/*      */       
/*      */       public KeyValue<byte[], List<byte[]>> build(Object data)
/*      */       {
/*  443 */         if (data == null) return null; 
/*  444 */         List<byte[]> l = (List<byte[]>)data;
/*  445 */         return new KeyValue(BuilderFactory.BINARY.build(l.get(0)), BuilderFactory.BINARY_LIST.build(l.get(1)));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  450 */         return "KeyValue<byte[], List<byte[]>>";
/*      */       }
/*      */     };
/*      */   
/*  454 */   public static final Builder<Tuple> TUPLE = new Builder<Tuple>()
/*      */     {
/*      */       public Tuple build(Object data)
/*      */       {
/*  458 */         List<byte[]> l = (List<byte[]>)data;
/*  459 */         if (l.isEmpty()) {
/*  460 */           return null;
/*      */         }
/*  462 */         return new Tuple(l.get(0), BuilderFactory.DOUBLE.build(l.get(1)));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  467 */         return "Tuple";
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*  472 */   public static final Builder<KeyedZSetElement> KEYED_ZSET_ELEMENT = new Builder<KeyedZSetElement>()
/*      */     {
/*      */       public KeyedZSetElement build(Object data)
/*      */       {
/*  476 */         List<byte[]> l = (List<byte[]>)data;
/*  477 */         if (l.isEmpty()) {
/*  478 */           return null;
/*      */         }
/*  480 */         return new KeyedZSetElement(l.get(0), l.get(1), BuilderFactory.DOUBLE.build(l.get(2)));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  485 */         return "KeyedZSetElement";
/*      */       }
/*      */     };
/*      */   
/*  489 */   public static final Builder<List<Tuple>> TUPLE_LIST = new Builder<List<Tuple>>()
/*      */     {
/*      */       public List<Tuple> build(Object data)
/*      */       {
/*  493 */         if (null == data) {
/*  494 */           return null;
/*      */         }
/*  496 */         List<byte[]> l = (List<byte[]>)data;
/*  497 */         List<Tuple> result = new ArrayList<>(l.size() / 2);
/*  498 */         Iterator<byte[]> iterator = (Iterator)l.iterator();
/*  499 */         while (iterator.hasNext()) {
/*  500 */           result.add(new Tuple(iterator.next(), BuilderFactory.DOUBLE.build(iterator.next())));
/*      */         }
/*  502 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  507 */         return "List<Tuple>";
/*      */       }
/*      */     };
/*      */   
/*  511 */   public static final Builder<Set<Tuple>> TUPLE_ZSET = new Builder<Set<Tuple>>()
/*      */     {
/*      */       public Set<Tuple> build(Object data)
/*      */       {
/*  515 */         if (null == data) {
/*  516 */           return null;
/*      */         }
/*  518 */         List<byte[]> l = (List<byte[]>)data;
/*  519 */         Set<Tuple> result = new LinkedHashSet<>(l.size() / 2, 1.0F);
/*  520 */         Iterator<byte[]> iterator = (Iterator)l.iterator();
/*  521 */         while (iterator.hasNext()) {
/*  522 */           result.add(new Tuple(iterator.next(), BuilderFactory.DOUBLE.build(iterator.next())));
/*      */         }
/*  524 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  529 */         return "ZSet<Tuple>";
/*      */       }
/*      */     };
/*      */   
/*  533 */   private static final Builder<List<Tuple>> TUPLE_LIST_FROM_PAIRS = new Builder<List<Tuple>>()
/*      */     {
/*      */       public List<Tuple> build(Object data)
/*      */       {
/*  537 */         if (data == null) return null; 
/*  538 */         return (List<Tuple>)((List)data).stream()
/*  539 */           .map(o -> (List)o).map(p -> (Tuple)BuilderFactory.TUPLE.build(p))
/*  540 */           .collect(Collectors.toList());
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  545 */         return "List<Tuple>";
/*      */       }
/*      */     };
/*      */   
/*  549 */   public static final Builder<KeyValue<String, List<Tuple>>> KEYED_TUPLE_LIST = new Builder<KeyValue<String, List<Tuple>>>()
/*      */     {
/*      */       
/*      */       public KeyValue<String, List<Tuple>> build(Object data)
/*      */       {
/*  554 */         if (data == null) return null; 
/*  555 */         List<Object> l = (List<Object>)data;
/*  556 */         return new KeyValue(BuilderFactory.STRING.build(l.get(0)), BuilderFactory.TUPLE_LIST_FROM_PAIRS.build(l.get(1)));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  561 */         return "KeyValue<String, List<Tuple>>";
/*      */       }
/*      */     };
/*      */   
/*  565 */   public static final Builder<KeyValue<byte[], List<Tuple>>> BINARY_KEYED_TUPLE_LIST = new Builder<KeyValue<byte[], List<Tuple>>>()
/*      */     {
/*      */       
/*      */       public KeyValue<byte[], List<Tuple>> build(Object data)
/*      */       {
/*  570 */         if (data == null) return null; 
/*  571 */         List<Object> l = (List<Object>)data;
/*  572 */         return new KeyValue(BuilderFactory.BINARY.build(l.get(0)), BuilderFactory.TUPLE_LIST_FROM_PAIRS.build(l.get(1)));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  577 */         return "KeyValue<byte[], List<Tuple>>";
/*      */       }
/*      */     };
/*      */   
/*  581 */   public static final Builder<ScanResult<String>> SCAN_RESPONSE = new Builder<ScanResult<String>>()
/*      */     {
/*      */       public ScanResult<String> build(Object data) {
/*  584 */         List<Object> result = (List<Object>)data;
/*  585 */         String newcursor = new String((byte[])result.get(0));
/*  586 */         List<byte[]> rawResults = (List<byte[]>)result.get(1);
/*  587 */         List<String> results = new ArrayList<>(rawResults.size());
/*  588 */         for (byte[] bs : rawResults) {
/*  589 */           results.add(SafeEncoder.encode(bs));
/*      */         }
/*  591 */         return new ScanResult(newcursor, results);
/*      */       }
/*      */     };
/*      */   
/*  595 */   public static final Builder<ScanResult<Map.Entry<String, String>>> HSCAN_RESPONSE = new Builder<ScanResult<Map.Entry<String, String>>>()
/*      */     {
/*      */       public ScanResult<Map.Entry<String, String>> build(Object data)
/*      */       {
/*  599 */         List<Object> result = (List<Object>)data;
/*  600 */         String newcursor = new String((byte[])result.get(0));
/*  601 */         List<byte[]> rawResults = (List<byte[]>)result.get(1);
/*  602 */         List<Map.Entry<String, String>> results = new ArrayList<>(rawResults.size() / 2);
/*  603 */         Iterator<byte[]> iterator = (Iterator)rawResults.iterator();
/*  604 */         while (iterator.hasNext()) {
/*  605 */           results.add(new AbstractMap.SimpleEntry<>(SafeEncoder.encode(iterator.next()), 
/*  606 */                 SafeEncoder.encode(iterator.next())));
/*      */         }
/*  608 */         return new ScanResult(newcursor, results);
/*      */       }
/*      */     };
/*      */   
/*  612 */   public static final Builder<ScanResult<String>> SSCAN_RESPONSE = new Builder<ScanResult<String>>()
/*      */     {
/*      */       public ScanResult<String> build(Object data) {
/*  615 */         List<Object> result = (List<Object>)data;
/*  616 */         String newcursor = new String((byte[])result.get(0));
/*  617 */         List<byte[]> rawResults = (List<byte[]>)result.get(1);
/*  618 */         List<String> results = new ArrayList<>(rawResults.size());
/*  619 */         for (byte[] bs : rawResults) {
/*  620 */           results.add(SafeEncoder.encode(bs));
/*      */         }
/*  622 */         return new ScanResult(newcursor, results);
/*      */       }
/*      */     };
/*      */   
/*  626 */   public static final Builder<ScanResult<Tuple>> ZSCAN_RESPONSE = new Builder<ScanResult<Tuple>>()
/*      */     {
/*      */       public ScanResult<Tuple> build(Object data) {
/*  629 */         List<Object> result = (List<Object>)data;
/*  630 */         String newcursor = new String((byte[])result.get(0));
/*  631 */         List<byte[]> rawResults = (List<byte[]>)result.get(1);
/*  632 */         List<Tuple> results = new ArrayList<>(rawResults.size() / 2);
/*  633 */         Iterator<byte[]> iterator = (Iterator)rawResults.iterator();
/*  634 */         while (iterator.hasNext()) {
/*  635 */           results.add(new Tuple(iterator.next(), BuilderFactory.DOUBLE.build(iterator.next())));
/*      */         }
/*  637 */         return new ScanResult(newcursor, results);
/*      */       }
/*      */     };
/*      */   
/*  641 */   public static final Builder<ScanResult<byte[]>> SCAN_BINARY_RESPONSE = new Builder<ScanResult<byte[]>>()
/*      */     {
/*      */       public ScanResult<byte[]> build(Object data) {
/*  644 */         List<Object> result = (List<Object>)data;
/*  645 */         byte[] newcursor = (byte[])result.get(0);
/*  646 */         List<byte[]> rawResults = (List<byte[]>)result.get(1);
/*  647 */         return new ScanResult(newcursor, rawResults);
/*      */       }
/*      */     };
/*      */   
/*  651 */   public static final Builder<ScanResult<Map.Entry<byte[], byte[]>>> HSCAN_BINARY_RESPONSE = new Builder<ScanResult<Map.Entry<byte[], byte[]>>>()
/*      */     {
/*      */       public ScanResult<Map.Entry<byte[], byte[]>> build(Object data)
/*      */       {
/*  655 */         List<Object> result = (List<Object>)data;
/*  656 */         byte[] newcursor = (byte[])result.get(0);
/*  657 */         List<byte[]> rawResults = (List<byte[]>)result.get(1);
/*  658 */         List<Map.Entry<byte[], byte[]>> results = new ArrayList<>(rawResults.size() / 2);
/*  659 */         Iterator<byte[]> iterator = (Iterator)rawResults.iterator();
/*  660 */         while (iterator.hasNext()) {
/*  661 */           results.add((Map.Entry)new AbstractMap.SimpleEntry<>(iterator.next(), iterator.next()));
/*      */         }
/*  663 */         return new ScanResult(newcursor, results);
/*      */       }
/*      */     };
/*      */   
/*  667 */   public static final Builder<ScanResult<byte[]>> SSCAN_BINARY_RESPONSE = new Builder<ScanResult<byte[]>>()
/*      */     {
/*      */       public ScanResult<byte[]> build(Object data) {
/*  670 */         List<Object> result = (List<Object>)data;
/*  671 */         byte[] newcursor = (byte[])result.get(0);
/*  672 */         List<byte[]> rawResults = (List<byte[]>)result.get(1);
/*  673 */         return new ScanResult(newcursor, rawResults);
/*      */       }
/*      */     };
/*      */   
/*  677 */   public static final Builder<Map<String, Long>> PUBSUB_NUMSUB_MAP = new Builder<Map<String, Long>>()
/*      */     {
/*      */       public Map<String, Long> build(Object data)
/*      */       {
/*  681 */         List<Object> flatHash = (List<Object>)data;
/*  682 */         Map<String, Long> hash = new HashMap<>(flatHash.size() / 2, 1.0F);
/*  683 */         Iterator<Object> iterator = flatHash.iterator();
/*  684 */         while (iterator.hasNext()) {
/*  685 */           hash.put(SafeEncoder.encode((byte[])iterator.next()), (Long)iterator.next());
/*      */         }
/*  687 */         return hash;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  692 */         return "PUBSUB_NUMSUB_MAP<String, String>";
/*      */       }
/*      */     };
/*      */   
/*  696 */   public static final Builder<List<GeoCoordinate>> GEO_COORDINATE_LIST = new Builder<List<GeoCoordinate>>()
/*      */     {
/*      */       public List<GeoCoordinate> build(Object data) {
/*  699 */         if (null == data) {
/*  700 */           return null;
/*      */         }
/*  702 */         return interpretGeoposResult((List<Object>)data);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  707 */         return "List<GeoCoordinate>";
/*      */       }
/*      */       
/*      */       private List<GeoCoordinate> interpretGeoposResult(List<Object> responses) {
/*  711 */         List<GeoCoordinate> responseCoordinate = new ArrayList<>(responses.size());
/*  712 */         for (Object response : responses) {
/*  713 */           if (response == null) {
/*  714 */             responseCoordinate.add((GeoCoordinate)null); continue;
/*      */           } 
/*  716 */           List<Object> respList = (List<Object>)response;
/*      */           
/*  718 */           GeoCoordinate coord = new GeoCoordinate(((Double)BuilderFactory.DOUBLE.build(respList.get(0))).doubleValue(), ((Double)BuilderFactory.DOUBLE.build(respList.get(1))).doubleValue());
/*  719 */           responseCoordinate.add(coord);
/*      */         } 
/*      */         
/*  722 */         return responseCoordinate;
/*      */       }
/*      */     };
/*      */   
/*  726 */   public static final Builder<List<GeoRadiusResponse>> GEORADIUS_WITH_PARAMS_RESULT = new Builder<List<GeoRadiusResponse>>()
/*      */     {
/*      */       public List<GeoRadiusResponse> build(Object data) {
/*  729 */         if (data == null) {
/*  730 */           return null;
/*      */         }
/*      */         
/*  733 */         List<Object> objectList = (List<Object>)data;
/*      */         
/*  735 */         List<GeoRadiusResponse> responses = new ArrayList<>(objectList.size());
/*  736 */         if (objectList.isEmpty()) {
/*  737 */           return responses;
/*      */         }
/*      */         
/*  740 */         if (objectList.get(0) instanceof List) {
/*      */ 
/*      */           
/*  743 */           for (Object obj : objectList) {
/*  744 */             List<Object> informations = (List<Object>)obj;
/*      */             
/*  746 */             GeoRadiusResponse resp = new GeoRadiusResponse((byte[])informations.get(0));
/*      */             
/*  748 */             int size = informations.size();
/*  749 */             for (int idx = 1; idx < size; idx++) {
/*  750 */               Object info = informations.get(idx);
/*  751 */               if (info instanceof List) {
/*      */                 
/*  753 */                 List<Object> coord = (List<Object>)info;
/*      */                 
/*  755 */                 resp.setCoordinate(new GeoCoordinate(((Double)BuilderFactory.DOUBLE.build(coord.get(0))).doubleValue(), ((Double)BuilderFactory.DOUBLE
/*  756 */                       .build(coord.get(1))).doubleValue()));
/*  757 */               } else if (info instanceof Long) {
/*      */                 
/*  759 */                 resp.setRawScore(((Long)BuilderFactory.LONG.build(info)).longValue());
/*      */               } else {
/*      */                 
/*  762 */                 resp.setDistance(((Double)BuilderFactory.DOUBLE.build(info)).doubleValue());
/*      */               } 
/*      */             } 
/*      */             
/*  766 */             responses.add(resp);
/*      */           } 
/*      */         } else {
/*      */           
/*  770 */           for (Object obj : objectList) {
/*  771 */             responses.add(new GeoRadiusResponse((byte[])obj));
/*      */           }
/*      */         } 
/*      */         
/*  775 */         return responses;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  780 */         return "GeoRadiusWithParamsResult";
/*      */       }
/*      */     };
/*      */   
/*  784 */   public static final Builder<Map<String, CommandDocument>> COMMAND_DOCS_RESPONSE = new Builder<Map<String, CommandDocument>>()
/*      */     {
/*      */       public Map<String, CommandDocument> build(Object data) {
/*  787 */         if (data == null) {
/*  788 */           return null;
/*      */         }
/*      */         
/*  791 */         List<Object> list = (List<Object>)data;
/*  792 */         Map<String, CommandDocument> map = new HashMap<>(list.size());
/*      */         
/*  794 */         for (int i = 0; i < list.size(); ) {
/*  795 */           String name = BuilderFactory.STRING.build(list.get(i++));
/*  796 */           CommandDocument doc = CommandDocument.COMMAND_DOCUMENT_BUILDER.build(list.get(i++));
/*  797 */           map.put(name, doc);
/*      */         } 
/*      */         
/*  800 */         return map;
/*      */       }
/*      */     };
/*      */   
/*  804 */   public static final Builder<Map<String, CommandInfo>> COMMAND_INFO_RESPONSE = new Builder<Map<String, CommandInfo>>()
/*      */     {
/*      */       public Map<String, CommandInfo> build(Object data) {
/*  807 */         if (data == null) {
/*  808 */           return null;
/*      */         }
/*      */         
/*  811 */         List<Object> rawList = (List<Object>)data;
/*  812 */         Map<String, CommandInfo> map = new HashMap<>(rawList.size());
/*      */         
/*  814 */         for (Object rawCommandInfo : rawList) {
/*  815 */           if (rawCommandInfo == null) {
/*      */             continue;
/*      */           }
/*      */           
/*  819 */           List<Object> commandInfo = (List<Object>)rawCommandInfo;
/*  820 */           String name = BuilderFactory.STRING.build(commandInfo.get(0));
/*  821 */           CommandInfo info = CommandInfo.COMMAND_INFO_BUILDER.build(commandInfo);
/*  822 */           map.put(name, info);
/*      */         } 
/*      */         
/*  825 */         return map;
/*      */       }
/*      */     };
/*      */   
/*  829 */   public static final Builder<List<Module>> MODULE_LIST = new Builder<List<Module>>()
/*      */     {
/*      */       public List<Module> build(Object data) {
/*  832 */         if (data == null) {
/*  833 */           return null;
/*      */         }
/*      */         
/*  836 */         List<List<Object>> objectList = (List<List<Object>>)data;
/*      */         
/*  838 */         List<Module> responses = new ArrayList<>(objectList.size());
/*  839 */         if (objectList.isEmpty()) {
/*  840 */           return responses;
/*      */         }
/*      */         
/*  843 */         for (List<Object> moduleResp : objectList) {
/*      */           
/*  845 */           Module m = new Module(SafeEncoder.encode((byte[])moduleResp.get(1)), ((Long)moduleResp.get(3)).intValue());
/*  846 */           responses.add(m);
/*      */         } 
/*      */         
/*  849 */         return responses;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  854 */         return "List<Module>";
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  861 */   public static final Builder<AccessControlUser> ACCESS_CONTROL_USER = new Builder<AccessControlUser>()
/*      */     {
/*      */       public AccessControlUser build(Object data)
/*      */       {
/*  865 */         if (data == null) {
/*  866 */           return null;
/*      */         }
/*      */         
/*  869 */         List<Object> objectList = (List<Object>)data;
/*  870 */         if (objectList.isEmpty()) {
/*  871 */           return null;
/*      */         }
/*      */         
/*  874 */         AccessControlUser accessControlUser = new AccessControlUser();
/*      */ 
/*      */         
/*  877 */         List<Object> flags = (List<Object>)objectList.get(1);
/*  878 */         for (Object f : flags) {
/*  879 */           accessControlUser.addFlag(SafeEncoder.encode((byte[])f));
/*      */         }
/*      */ 
/*      */         
/*  883 */         List<Object> passwords = (List<Object>)objectList.get(3);
/*  884 */         for (Object p : passwords) {
/*  885 */           accessControlUser.addPassword(SafeEncoder.encode((byte[])p));
/*      */         }
/*      */ 
/*      */         
/*  889 */         accessControlUser.setCommands(SafeEncoder.encode((byte[])objectList.get(5)));
/*      */ 
/*      */         
/*  892 */         boolean withSelectors = (objectList.size() >= 12);
/*  893 */         if (!withSelectors) {
/*      */ 
/*      */           
/*  896 */           List<Object> keys = (List<Object>)objectList.get(7);
/*  897 */           for (Object k : keys) {
/*  898 */             accessControlUser.addKey(SafeEncoder.encode((byte[])k));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  903 */           if (objectList.size() >= 10) {
/*  904 */             List<Object> channels = (List<Object>)objectList.get(9);
/*  905 */             for (Object channel : channels) {
/*  906 */               accessControlUser.addChannel(SafeEncoder.encode((byte[])channel));
/*      */             
/*      */             }
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  914 */           accessControlUser.addKeys(SafeEncoder.encode((byte[])objectList.get(7)));
/*      */ 
/*      */           
/*  917 */           accessControlUser.addChannels(SafeEncoder.encode((byte[])objectList.get(9)));
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  922 */         return accessControlUser;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  927 */         return "AccessControlUser";
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  935 */   public static final Builder<List<AccessControlLogEntry>> ACCESS_CONTROL_LOG_ENTRY_LIST = new Builder<List<AccessControlLogEntry>>()
/*      */     {
/*  937 */       private final Map<String, Builder> mappingFunctions = createDecoderMap();
/*      */ 
/*      */       
/*      */       private Map<String, Builder> createDecoderMap() {
/*  941 */         Map<String, Builder> tempMappingFunctions = new HashMap<>();
/*  942 */         tempMappingFunctions.put("count", BuilderFactory.LONG);
/*  943 */         tempMappingFunctions.put("reason", BuilderFactory.STRING);
/*  944 */         tempMappingFunctions.put("context", BuilderFactory.STRING);
/*  945 */         tempMappingFunctions.put("object", BuilderFactory.STRING);
/*  946 */         tempMappingFunctions.put("username", BuilderFactory.STRING);
/*  947 */         tempMappingFunctions.put("age-seconds", BuilderFactory.STRING);
/*  948 */         tempMappingFunctions.put("client-info", BuilderFactory.STRING);
/*      */         
/*  950 */         return tempMappingFunctions;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public List<AccessControlLogEntry> build(Object data) {
/*  956 */         if (null == data) {
/*  957 */           return null;
/*      */         }
/*      */         
/*  960 */         List<AccessControlLogEntry> list = new ArrayList<>();
/*  961 */         List<List<Object>> logEntries = (List<List<Object>>)data;
/*  962 */         for (List<Object> logEntryData : logEntries) {
/*  963 */           Iterator<Object> logEntryDataIterator = logEntryData.iterator();
/*      */           
/*  965 */           AccessControlLogEntry accessControlLogEntry = new AccessControlLogEntry(BuilderFactory.createMapFromDecodingFunctions(logEntryDataIterator, this.mappingFunctions));
/*  966 */           list.add(accessControlLogEntry);
/*      */         } 
/*  968 */         return list;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  973 */         return "List<AccessControlLogEntry>";
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*  979 */   public static final Builder<StreamEntryID> STREAM_ENTRY_ID = new Builder<StreamEntryID>()
/*      */     {
/*      */       public StreamEntryID build(Object data) {
/*  982 */         if (null == data) {
/*  983 */           return null;
/*      */         }
/*  985 */         String id = SafeEncoder.encode((byte[])data);
/*  986 */         return new StreamEntryID(id);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  991 */         return "StreamEntryID";
/*      */       }
/*      */     };
/*      */   
/*  995 */   public static final Builder<List<StreamEntryID>> STREAM_ENTRY_ID_LIST = new Builder<List<StreamEntryID>>()
/*      */     {
/*      */       public List<StreamEntryID> build(Object data)
/*      */       {
/*  999 */         if (null == data) {
/* 1000 */           return null;
/*      */         }
/* 1002 */         List<Object> objectList = (List<Object>)data;
/* 1003 */         List<StreamEntryID> responses = new ArrayList<>(objectList.size());
/* 1004 */         if (!objectList.isEmpty()) {
/* 1005 */           for (Object object : objectList) {
/* 1006 */             responses.add(BuilderFactory.STREAM_ENTRY_ID.build(object));
/*      */           }
/*      */         }
/* 1009 */         return responses;
/*      */       }
/*      */     };
/*      */   
/* 1013 */   public static final Builder<StreamEntry> STREAM_ENTRY = new Builder<StreamEntry>()
/*      */     {
/*      */       public StreamEntry build(Object data)
/*      */       {
/* 1017 */         if (null == data) {
/* 1018 */           return null;
/*      */         }
/* 1020 */         List<Object> objectList = (List<Object>)data;
/*      */         
/* 1022 */         if (objectList.isEmpty()) {
/* 1023 */           return null;
/*      */         }
/*      */         
/* 1026 */         String entryIdString = SafeEncoder.encode((byte[])objectList.get(0));
/* 1027 */         StreamEntryID entryID = new StreamEntryID(entryIdString);
/* 1028 */         List<byte[]> hash = (List<byte[]>)objectList.get(1);
/*      */         
/* 1030 */         Iterator<byte[]> hashIterator = (Iterator)hash.iterator();
/* 1031 */         Map<String, String> map = new HashMap<>(hash.size() / 2);
/* 1032 */         while (hashIterator.hasNext()) {
/* 1033 */           map.put(SafeEncoder.encode(hashIterator.next()), SafeEncoder.encode(hashIterator.next()));
/*      */         }
/* 1035 */         return new StreamEntry(entryID, map);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1040 */         return "StreamEntry";
/*      */       }
/*      */     };
/*      */   
/* 1044 */   public static final Builder<List<StreamEntry>> STREAM_ENTRY_LIST = new Builder<List<StreamEntry>>()
/*      */     {
/*      */       public List<StreamEntry> build(Object data)
/*      */       {
/* 1048 */         if (null == data) {
/* 1049 */           return null;
/*      */         }
/* 1051 */         List<ArrayList<Object>> objectList = (List<ArrayList<Object>>)data;
/*      */         
/* 1053 */         List<StreamEntry> responses = new ArrayList<>(objectList.size() / 2);
/* 1054 */         if (objectList.isEmpty()) {
/* 1055 */           return responses;
/*      */         }
/*      */         
/* 1058 */         for (ArrayList<Object> res : objectList) {
/* 1059 */           if (res == null) {
/* 1060 */             responses.add((StreamEntry)null);
/*      */             continue;
/*      */           } 
/* 1063 */           String entryIdString = SafeEncoder.encode((byte[])res.get(0));
/* 1064 */           StreamEntryID entryID = new StreamEntryID(entryIdString);
/* 1065 */           List<byte[]> hash = (List<byte[]>)res.get(1);
/*      */           
/* 1067 */           Iterator<byte[]> hashIterator = (Iterator)hash.iterator();
/* 1068 */           Map<String, String> map = new HashMap<>(hash.size() / 2);
/* 1069 */           while (hashIterator.hasNext()) {
/* 1070 */             map.put(SafeEncoder.encode(hashIterator.next()), SafeEncoder.encode(hashIterator.next()));
/*      */           }
/* 1072 */           responses.add(new StreamEntry(entryID, map));
/*      */         } 
/*      */         
/* 1075 */         return responses;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1080 */         return "List<StreamEntry>";
/*      */       }
/*      */     };
/*      */   
/* 1084 */   public static final Builder<Map.Entry<StreamEntryID, List<StreamEntry>>> STREAM_AUTO_CLAIM_RESPONSE = new Builder<Map.Entry<StreamEntryID, List<StreamEntry>>>()
/*      */     {
/*      */       
/*      */       public Map.Entry<StreamEntryID, List<StreamEntry>> build(Object data)
/*      */       {
/* 1089 */         if (null == data) {
/* 1090 */           return null;
/*      */         }
/*      */         
/* 1093 */         List<Object> objectList = (List<Object>)data;
/* 1094 */         return new AbstractMap.SimpleEntry<>(BuilderFactory.STREAM_ENTRY_ID.build(objectList.get(0)), BuilderFactory.STREAM_ENTRY_LIST
/* 1095 */             .build(objectList.get(1)));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1100 */         return "Map.Entry<StreamEntryID, List<StreamEntry>>";
/*      */       }
/*      */     };
/*      */   
/* 1104 */   public static final Builder<Map.Entry<StreamEntryID, List<StreamEntryID>>> STREAM_AUTO_CLAIM_ID_RESPONSE = new Builder<Map.Entry<StreamEntryID, List<StreamEntryID>>>()
/*      */     {
/*      */       
/*      */       public Map.Entry<StreamEntryID, List<StreamEntryID>> build(Object data)
/*      */       {
/* 1109 */         if (null == data) {
/* 1110 */           return null;
/*      */         }
/*      */         
/* 1113 */         List<Object> objectList = (List<Object>)data;
/* 1114 */         return new AbstractMap.SimpleEntry<>(BuilderFactory.STREAM_ENTRY_ID.build(objectList.get(0)), BuilderFactory.STREAM_ENTRY_ID_LIST
/* 1115 */             .build(objectList.get(1)));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1120 */         return "Map.Entry<StreamEntryID, List<StreamEntryID>>";
/*      */       }
/*      */     };
/*      */   
/* 1124 */   public static final Builder<List<Map.Entry<String, List<StreamEntry>>>> STREAM_READ_RESPONSE = new Builder<List<Map.Entry<String, List<StreamEntry>>>>()
/*      */     {
/*      */       public List<Map.Entry<String, List<StreamEntry>>> build(Object data)
/*      */       {
/* 1128 */         if (data == null) {
/* 1129 */           return null;
/*      */         }
/* 1131 */         List<Object> streams = (List<Object>)data;
/*      */         
/* 1133 */         List<Map.Entry<String, List<StreamEntry>>> result = new ArrayList<>(streams.size());
/* 1134 */         for (Object streamObj : streams) {
/* 1135 */           List<Object> stream = (List<Object>)streamObj;
/* 1136 */           String streamId = SafeEncoder.encode((byte[])stream.get(0));
/* 1137 */           List<StreamEntry> streamEntries = BuilderFactory.STREAM_ENTRY_LIST.build(stream.get(1));
/* 1138 */           result.add(new AbstractMap.SimpleEntry<>(streamId, streamEntries));
/*      */         } 
/*      */         
/* 1141 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1146 */         return "List<Entry<String, List<StreamEntry>>>";
/*      */       }
/*      */     };
/*      */   
/* 1150 */   public static final Builder<List<StreamPendingEntry>> STREAM_PENDING_ENTRY_LIST = new Builder<List<StreamPendingEntry>>()
/*      */     {
/*      */       public List<StreamPendingEntry> build(Object data)
/*      */       {
/* 1154 */         if (null == data) {
/* 1155 */           return null;
/*      */         }
/*      */         
/* 1158 */         List<Object> streamsEntries = (List<Object>)data;
/* 1159 */         List<StreamPendingEntry> result = new ArrayList<>(streamsEntries.size());
/* 1160 */         for (Object streamObj : streamsEntries) {
/* 1161 */           List<Object> stream = (List<Object>)streamObj;
/* 1162 */           String id = SafeEncoder.encode((byte[])stream.get(0));
/* 1163 */           String consumerName = SafeEncoder.encode((byte[])stream.get(1));
/* 1164 */           long idleTime = ((Long)BuilderFactory.LONG.build(stream.get(2))).longValue();
/* 1165 */           long deliveredTimes = ((Long)BuilderFactory.LONG.build(stream.get(3))).longValue();
/* 1166 */           result.add(new StreamPendingEntry(new StreamEntryID(id), consumerName, idleTime, deliveredTimes));
/*      */         } 
/*      */         
/* 1169 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1174 */         return "List<StreamPendingEntry>";
/*      */       }
/*      */     };
/*      */   
/* 1178 */   public static final Builder<StreamInfo> STREAM_INFO = new Builder<StreamInfo>()
/*      */     {
/* 1180 */       Map<String, Builder> mappingFunctions = createDecoderMap();
/*      */ 
/*      */       
/*      */       private Map<String, Builder> createDecoderMap() {
/* 1184 */         Map<String, Builder> tempMappingFunctions = new HashMap<>();
/* 1185 */         tempMappingFunctions.put("last-generated-id", BuilderFactory.STREAM_ENTRY_ID);
/* 1186 */         tempMappingFunctions.put("first-entry", BuilderFactory.STREAM_ENTRY);
/* 1187 */         tempMappingFunctions.put("length", BuilderFactory.LONG);
/* 1188 */         tempMappingFunctions.put("radix-tree-keys", BuilderFactory.LONG);
/* 1189 */         tempMappingFunctions.put("radix-tree-nodes", BuilderFactory.LONG);
/* 1190 */         tempMappingFunctions.put("last-entry", BuilderFactory.STREAM_ENTRY);
/* 1191 */         tempMappingFunctions.put("groups", BuilderFactory.LONG);
/*      */         
/* 1193 */         return tempMappingFunctions;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public StreamInfo build(Object data) {
/* 1199 */         if (null == data) {
/* 1200 */           return null;
/*      */         }
/*      */         
/* 1203 */         List<Object> streamsEntries = (List<Object>)data;
/* 1204 */         Iterator<Object> iterator = streamsEntries.iterator();
/*      */         
/* 1206 */         return new StreamInfo(BuilderFactory.createMapFromDecodingFunctions(iterator, this.mappingFunctions));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1211 */         return "StreamInfo";
/*      */       }
/*      */     };
/*      */   
/* 1215 */   public static final Builder<List<StreamGroupInfo>> STREAM_GROUP_INFO_LIST = new Builder<List<StreamGroupInfo>>()
/*      */     {
/* 1217 */       Map<String, Builder> mappingFunctions = createDecoderMap();
/*      */ 
/*      */       
/*      */       private Map<String, Builder> createDecoderMap() {
/* 1221 */         Map<String, Builder> tempMappingFunctions = new HashMap<>();
/* 1222 */         tempMappingFunctions.put("name", BuilderFactory.STRING);
/* 1223 */         tempMappingFunctions.put("consumers", BuilderFactory.LONG);
/* 1224 */         tempMappingFunctions.put("pending", BuilderFactory.LONG);
/* 1225 */         tempMappingFunctions.put("last-delivered-id", BuilderFactory.STREAM_ENTRY_ID);
/*      */         
/* 1227 */         return tempMappingFunctions;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public List<StreamGroupInfo> build(Object data) {
/* 1233 */         if (null == data) {
/* 1234 */           return null;
/*      */         }
/*      */         
/* 1237 */         List<StreamGroupInfo> list = new ArrayList<>();
/* 1238 */         List<Object> streamsEntries = (List<Object>)data;
/* 1239 */         Iterator<Object> groupsArray = streamsEntries.iterator();
/*      */         
/* 1241 */         while (groupsArray.hasNext()) {
/*      */           
/* 1243 */           List<Object> groupInfo = (List<Object>)groupsArray.next();
/*      */           
/* 1245 */           Iterator<Object> groupInfoIterator = groupInfo.iterator();
/*      */           
/* 1247 */           StreamGroupInfo streamGroupInfo = new StreamGroupInfo(BuilderFactory.createMapFromDecodingFunctions(groupInfoIterator, this.mappingFunctions));
/*      */           
/* 1249 */           list.add(streamGroupInfo);
/*      */         } 
/*      */         
/* 1252 */         return list;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1258 */         return "List<StreamGroupInfo>";
/*      */       }
/*      */     };
/*      */   
/* 1262 */   public static final Builder<List<StreamConsumersInfo>> STREAM_CONSUMERS_INFO_LIST = new Builder<List<StreamConsumersInfo>>()
/*      */     {
/* 1264 */       Map<String, Builder> mappingFunctions = createDecoderMap();
/*      */       
/*      */       private Map<String, Builder> createDecoderMap() {
/* 1267 */         Map<String, Builder> tempMappingFunctions = new HashMap<>();
/* 1268 */         tempMappingFunctions.put("name", BuilderFactory.STRING);
/* 1269 */         tempMappingFunctions.put("idle", BuilderFactory.LONG);
/* 1270 */         tempMappingFunctions.put("pending", BuilderFactory.LONG);
/* 1271 */         tempMappingFunctions.put("last-delivered-id", BuilderFactory.STRING);
/* 1272 */         return tempMappingFunctions;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public List<StreamConsumersInfo> build(Object data) {
/* 1279 */         if (null == data) {
/* 1280 */           return null;
/*      */         }
/*      */         
/* 1283 */         List<StreamConsumersInfo> list = new ArrayList<>();
/* 1284 */         List<Object> streamsEntries = (List<Object>)data;
/* 1285 */         Iterator<Object> groupsArray = streamsEntries.iterator();
/*      */         
/* 1287 */         while (groupsArray.hasNext()) {
/*      */           
/* 1289 */           List<Object> groupInfo = (List<Object>)groupsArray.next();
/*      */           
/* 1291 */           Iterator<Object> consumerInfoIterator = groupInfo.iterator();
/*      */ 
/*      */           
/* 1294 */           StreamConsumersInfo streamGroupInfo = new StreamConsumersInfo(BuilderFactory.createMapFromDecodingFunctions(consumerInfoIterator, this.mappingFunctions));
/* 1295 */           list.add(streamGroupInfo);
/*      */         } 
/*      */         
/* 1298 */         return list;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1304 */         return "List<StreamConsumersInfo>";
/*      */       }
/*      */     };
/*      */   
/* 1308 */   private static final Builder<List<StreamConsumerFullInfo>> STREAM_CONSUMER_FULL_INFO_LIST = new Builder<List<StreamConsumerFullInfo>>()
/*      */     {
/* 1310 */       final Map<String, Builder> mappingFunctions = createDecoderMap();
/*      */ 
/*      */       
/*      */       private Map<String, Builder> createDecoderMap() {
/* 1314 */         Map<String, Builder> tempMappingFunctions = new HashMap<>();
/* 1315 */         tempMappingFunctions.put("name", BuilderFactory.STRING);
/* 1316 */         tempMappingFunctions.put("seen-time", BuilderFactory.LONG);
/* 1317 */         tempMappingFunctions.put("pel-count", BuilderFactory.LONG);
/* 1318 */         tempMappingFunctions.put("pending", BuilderFactory.LONG_LIST);
/*      */         
/* 1320 */         return tempMappingFunctions;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public List<StreamConsumerFullInfo> build(Object data) {
/* 1326 */         if (null == data) {
/* 1327 */           return null;
/*      */         }
/*      */         
/* 1330 */         List<StreamConsumerFullInfo> list = new ArrayList<>();
/* 1331 */         List<Object> streamsEntries = (List<Object>)data;
/*      */         
/* 1333 */         for (Object streamsEntry : streamsEntries) {
/* 1334 */           List<Object> consumerInfoList = (List<Object>)streamsEntry;
/* 1335 */           Iterator<Object> consumerInfoIterator = consumerInfoList.iterator();
/* 1336 */           StreamConsumerFullInfo consumerInfo = new StreamConsumerFullInfo(BuilderFactory.createMapFromDecodingFunctions(consumerInfoIterator, this.mappingFunctions));
/* 1337 */           list.add(consumerInfo);
/*      */         } 
/* 1339 */         return list;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1344 */         return "List<StreamConsumerFullInfo>";
/*      */       }
/*      */     };
/*      */   
/* 1348 */   private static final Builder<List<StreamGroupFullInfo>> STREAM_GROUP_FULL_INFO_LIST = new Builder<List<StreamGroupFullInfo>>()
/*      */     {
/* 1350 */       final Map<String, Builder> mappingFunctions = createDecoderMap();
/*      */ 
/*      */       
/*      */       private Map<String, Builder> createDecoderMap() {
/* 1354 */         Map<String, Builder> tempMappingFunctions = new HashMap<>();
/* 1355 */         tempMappingFunctions.put("name", BuilderFactory.STRING);
/* 1356 */         tempMappingFunctions.put("consumers", BuilderFactory.STREAM_CONSUMER_FULL_INFO_LIST);
/* 1357 */         tempMappingFunctions.put("pending", BuilderFactory.STRING_LIST);
/* 1358 */         tempMappingFunctions.put("last-delivered-id", BuilderFactory.STREAM_ENTRY_ID);
/* 1359 */         tempMappingFunctions.put("pel-count", BuilderFactory.LONG);
/*      */         
/* 1361 */         return tempMappingFunctions;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public List<StreamGroupFullInfo> build(Object data) {
/* 1367 */         if (null == data) {
/* 1368 */           return null;
/*      */         }
/*      */         
/* 1371 */         List<StreamGroupFullInfo> list = new ArrayList<>();
/* 1372 */         List<Object> streamsEntries = (List<Object>)data;
/*      */         
/* 1374 */         for (Object streamsEntry : streamsEntries) {
/*      */           
/* 1376 */           List<Object> groupInfo = (List<Object>)streamsEntry;
/*      */           
/* 1378 */           Iterator<Object> groupInfoIterator = groupInfo.iterator();
/*      */           
/* 1380 */           StreamGroupFullInfo groupFullInfo = new StreamGroupFullInfo(BuilderFactory.createMapFromDecodingFunctions(groupInfoIterator, this.mappingFunctions));
/*      */           
/* 1382 */           list.add(groupFullInfo);
/*      */         } 
/*      */         
/* 1385 */         return list;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1390 */         return "List<StreamGroupFullInfo>";
/*      */       }
/*      */     };
/*      */   
/* 1394 */   public static final Builder<StreamFullInfo> STREAM_INFO_FULL = new Builder<StreamFullInfo>()
/*      */     {
/* 1396 */       final Map<String, Builder> mappingFunctions = createDecoderMap();
/*      */ 
/*      */       
/*      */       private Map<String, Builder> createDecoderMap() {
/* 1400 */         Map<String, Builder> tempMappingFunctions = new HashMap<>();
/* 1401 */         tempMappingFunctions.put("last-generated-id", BuilderFactory.STREAM_ENTRY_ID);
/* 1402 */         tempMappingFunctions.put("length", BuilderFactory.LONG);
/* 1403 */         tempMappingFunctions.put("radix-tree-keys", BuilderFactory.LONG);
/* 1404 */         tempMappingFunctions.put("radix-tree-nodes", BuilderFactory.LONG);
/* 1405 */         tempMappingFunctions.put("groups", BuilderFactory.STREAM_GROUP_FULL_INFO_LIST);
/* 1406 */         tempMappingFunctions.put("entries", BuilderFactory.STREAM_ENTRY_LIST);
/*      */         
/* 1408 */         return tempMappingFunctions;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public StreamFullInfo build(Object data) {
/* 1414 */         if (null == data) {
/* 1415 */           return null;
/*      */         }
/*      */         
/* 1418 */         List<Object> streamsEntries = (List<Object>)data;
/* 1419 */         Iterator<Object> iterator = streamsEntries.iterator();
/*      */         
/* 1421 */         return new StreamFullInfo(BuilderFactory.createMapFromDecodingFunctions(iterator, this.mappingFunctions));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1426 */         return "StreamFullInfo";
/*      */       }
/*      */     };
/*      */   
/* 1430 */   public static final Builder<StreamPendingSummary> STREAM_PENDING_SUMMARY = new Builder<StreamPendingSummary>()
/*      */     {
/*      */       public StreamPendingSummary build(Object data)
/*      */       {
/* 1434 */         if (null == data) {
/* 1435 */           return null;
/*      */         }
/*      */         
/* 1438 */         List<Object> objectList = (List<Object>)data;
/* 1439 */         long total = ((Long)BuilderFactory.LONG.build(objectList.get(0))).longValue();
/* 1440 */         String minId = SafeEncoder.encode((byte[])objectList.get(1));
/* 1441 */         String maxId = SafeEncoder.encode((byte[])objectList.get(2));
/* 1442 */         List<List<Object>> consumerObjList = (List<List<Object>>)objectList.get(3);
/* 1443 */         Map<String, Long> map = new HashMap<>(consumerObjList.size());
/* 1444 */         for (List<Object> consumerObj : consumerObjList) {
/* 1445 */           map.put(SafeEncoder.encode((byte[])consumerObj.get(0)), Long.valueOf(Long.parseLong(SafeEncoder.encode((byte[])consumerObj.get(1)))));
/*      */         }
/* 1447 */         return new StreamPendingSummary(total, new StreamEntryID(minId), new StreamEntryID(maxId), map);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1452 */         return "StreamPendingSummary";
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, Object> createMapFromDecodingFunctions(Iterator<Object> iterator, Map<String, Builder> mappingFunctions) {
/* 1459 */     Map<String, Object> resultMap = new HashMap<>();
/* 1460 */     while (iterator.hasNext()) {
/*      */       
/* 1462 */       String mapKey = STRING.build(iterator.next());
/* 1463 */       if (mappingFunctions.containsKey(mapKey)) {
/* 1464 */         resultMap.put(mapKey, ((Builder)mappingFunctions.get(mapKey)).build(iterator.next())); continue;
/*      */       } 
/* 1466 */       Object unknownData = iterator.next();
/* 1467 */       for (Builder b : mappingFunctions.values()) {
/*      */         try {
/* 1469 */           resultMap.put(mapKey, b.build(unknownData));
/*      */           break;
/* 1471 */         } catch (ClassCastException classCastException) {}
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1478 */     return resultMap;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1483 */   public static final Builder<LCSMatchResult> STR_ALGO_LCS_RESULT_BUILDER = new Builder<LCSMatchResult>()
/*      */     {
/*      */       public LCSMatchResult build(Object data) {
/* 1486 */         if (data == null) {
/* 1487 */           return null;
/*      */         }
/*      */         
/* 1490 */         if (data instanceof byte[])
/* 1491 */           return new LCSMatchResult(BuilderFactory.STRING.build(data)); 
/* 1492 */         if (data instanceof Long) {
/* 1493 */           return new LCSMatchResult(((Long)BuilderFactory.LONG.build(data)).longValue());
/*      */         }
/* 1495 */         long len = 0L;
/* 1496 */         List<LCSMatchResult.MatchedPosition> matchedPositions = new ArrayList<>();
/*      */         
/* 1498 */         List<Object> objectList = (List<Object>)data;
/* 1499 */         if ("matches".equalsIgnoreCase(BuilderFactory.STRING.build(objectList.get(0)))) {
/* 1500 */           List<Object> matches = (List<Object>)objectList.get(1);
/* 1501 */           for (Object obj : matches) {
/* 1502 */             if (obj instanceof List) {
/* 1503 */               List<Object> positions = (List<Object>)obj;
/*      */ 
/*      */               
/* 1506 */               LCSMatchResult.Position a = new LCSMatchResult.Position(((Long)BuilderFactory.LONG.build(((List)positions.get(0)).get(0))).longValue(), ((Long)BuilderFactory.LONG.build(((List)positions.get(0)).get(1))).longValue());
/*      */ 
/*      */ 
/*      */               
/* 1510 */               LCSMatchResult.Position b = new LCSMatchResult.Position(((Long)BuilderFactory.LONG.build(((List)positions.get(1)).get(0))).longValue(), ((Long)BuilderFactory.LONG.build(((List)positions.get(1)).get(1))).longValue());
/*      */               
/* 1512 */               long matchLen = 0L;
/* 1513 */               if (positions.size() >= 3) {
/* 1514 */                 matchLen = ((Long)BuilderFactory.LONG.build(positions.get(2))).longValue();
/*      */               }
/* 1516 */               matchedPositions.add(new LCSMatchResult.MatchedPosition(a, b, matchLen));
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 1521 */         if ("len".equalsIgnoreCase(BuilderFactory.STRING.build(objectList.get(2)))) {
/* 1522 */           len = ((Long)BuilderFactory.LONG.build(objectList.get(3))).longValue();
/*      */         }
/* 1524 */         return new LCSMatchResult(matchedPositions, len);
/*      */       }
/*      */     };
/*      */ 
/*      */   
/* 1529 */   public static final Builder<Map<String, String>> STRING_MAP_FROM_PAIRS = new Builder<Map<String, String>>()
/*      */     {
/*      */       public Map<String, String> build(Object data)
/*      */       {
/* 1533 */         List<Object> list = (List<Object>)data;
/* 1534 */         Map<String, String> map = new HashMap<>(list.size());
/* 1535 */         for (Object object : list) {
/* 1536 */           List<byte[]> flat = (List<byte[]>)object;
/* 1537 */           map.put(SafeEncoder.encode(flat.get(0)), (flat.get(1) != null) ? SafeEncoder.encode(flat.get(1)) : null);
/*      */         } 
/*      */         
/* 1540 */         return map;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1545 */         return "Map<String, String>";
/*      */       }
/*      */     };
/*      */   
/* 1549 */   public static final Builder<List<LibraryInfo>> LIBRARY_LIST = new Builder<List<LibraryInfo>>()
/*      */     {
/*      */       public List<LibraryInfo> build(Object data) {
/* 1552 */         List<Object> list = (List<Object>)data;
/* 1553 */         return (List<LibraryInfo>)list.stream().map(o -> (LibraryInfo)LibraryInfo.LIBRARY_BUILDER.build(o)).collect(Collectors.toList());
/*      */       }
/*      */     };
/*      */   
/* 1557 */   public static final Builder<Class<?>> JSON_TYPE = new Builder<Class<?>>()
/*      */     {
/*      */       public Class<?> build(Object data) {
/* 1560 */         if (data == null) return null; 
/* 1561 */         String str = BuilderFactory.STRING.build(data);
/* 1562 */         switch (str) {
/*      */           case "null":
/* 1564 */             return null;
/*      */           case "boolean":
/* 1566 */             return boolean.class;
/*      */           case "integer":
/* 1568 */             return int.class;
/*      */           case "number":
/* 1570 */             return float.class;
/*      */           case "string":
/* 1572 */             return String.class;
/*      */           case "object":
/* 1574 */             return Object.class;
/*      */           case "array":
/* 1576 */             return List.class;
/*      */         } 
/* 1578 */         throw new JedisException("Unknown type: " + str);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1584 */         return "Class<?>";
/*      */       }
/*      */     };
/*      */   
/* 1588 */   public static final Builder<List<Class<?>>> JSON_TYPE_LIST = new Builder<List<Class<?>>>()
/*      */     {
/*      */       public List<Class<?>> build(Object data) {
/* 1591 */         List<Object> list = (List<Object>)data;
/* 1592 */         List<Class<?>> classes = new ArrayList<>(list.size());
/* 1593 */         for (Object elem : list) {
/*      */           try {
/* 1595 */             classes.add(BuilderFactory.JSON_TYPE.build(elem));
/* 1596 */           } catch (JedisException je) {
/* 1597 */             classes.add((Class<?>)null);
/*      */           } 
/*      */         } 
/* 1600 */         return classes;
/*      */       }
/*      */     };
/*      */   
/* 1604 */   public static final Builder<Object> JSON_OBJECT = new Builder()
/*      */     {
/*      */       public Object build(Object data) {
/* 1607 */         if (data == null) return null;
/*      */         
/* 1609 */         if (!(data instanceof byte[])) return data;
/*      */         
/* 1611 */         String str = BuilderFactory.STRING.build(data);
/* 1612 */         if (str.charAt(0) == '{') {
/*      */           try {
/* 1614 */             return new JSONObject(str);
/* 1615 */           } catch (Exception exception) {}
/* 1616 */         } else if (str.charAt(0) == '[') {
/*      */           try {
/* 1618 */             return new JSONArray(str);
/* 1619 */           } catch (Exception exception) {}
/*      */         } 
/* 1621 */         return str;
/*      */       }
/*      */     };
/*      */   
/* 1625 */   public static final Builder<JSONArray> JSON_ARRAY = new Builder<JSONArray>()
/*      */     {
/*      */       public JSONArray build(Object data) {
/* 1628 */         if (data == null) return null; 
/* 1629 */         return new JSONArray(BuilderFactory.STRING.build(data));
/*      */       }
/*      */     };
/*      */   
/* 1633 */   public static final Builder<List<JSONArray>> JSON_ARRAY_LIST = new Builder<List<JSONArray>>()
/*      */     {
/*      */       public List<JSONArray> build(Object data) {
/* 1636 */         if (data == null) return null; 
/* 1637 */         List<Object> list = (List<Object>)data;
/* 1638 */         return (List<JSONArray>)list.stream().map(o -> (JSONArray)BuilderFactory.JSON_ARRAY.build(o)).collect(Collectors.toList());
/*      */       }
/*      */     };
/*      */   
/* 1642 */   public static final Builder<AggregationResult> SEARCH_AGGREGATION_RESULT = new Builder<AggregationResult>()
/*      */     {
/*      */       public AggregationResult build(Object data) {
/* 1645 */         return new AggregationResult(data);
/*      */       }
/*      */     };
/*      */   
/* 1649 */   public static final Builder<AggregationResult> SEARCH_AGGREGATION_RESULT_WITH_CURSOR = new Builder<AggregationResult>()
/*      */     {
/*      */       public AggregationResult build(Object data) {
/* 1652 */         List<Object> list = (List<Object>)data;
/* 1653 */         return new AggregationResult(list.get(0), ((Long)list.get(1)).longValue());
/*      */       }
/*      */     };
/*      */   
/* 1657 */   public static final Builder<Map<String, List<String>>> SEARCH_SYNONYM_GROUPS = new Builder<Map<String, List<String>>>()
/*      */     {
/*      */       public Map<String, List<String>> build(Object data) {
/* 1660 */         List<Object> list = (List<Object>)data;
/* 1661 */         Map<String, List<String>> dump = new HashMap<>(list.size() / 2);
/* 1662 */         for (int i = 0; i < list.size(); i += 2) {
/* 1663 */           dump.put(BuilderFactory.STRING.build(list.get(i)), BuilderFactory.STRING_LIST.build(list.get(i + 1)));
/*      */         }
/* 1665 */         return dump;
/*      */       }
/*      */     };
/*      */   
/* 1669 */   public static final Builder<TSElement> TIMESERIES_ELEMENT = new Builder<TSElement>()
/*      */     {
/*      */       public TSElement build(Object data) {
/* 1672 */         List<Object> list = (List<Object>)data;
/* 1673 */         if (list == null || list.isEmpty()) return null; 
/* 1674 */         return new TSElement(((Long)BuilderFactory.LONG.build(list.get(0))).longValue(), ((Double)BuilderFactory.DOUBLE.build(list.get(1))).doubleValue());
/*      */       }
/*      */     };
/*      */   
/* 1678 */   public static final Builder<List<TSElement>> TIMESERIES_ELEMENT_LIST = new Builder<List<TSElement>>()
/*      */     {
/*      */       public List<TSElement> build(Object data) {
/* 1681 */         return (List<TSElement>)((List)data).stream().map(pairObject -> (List)pairObject)
/* 1682 */           .map(pairList -> new TSElement(((Long)BuilderFactory.LONG.build(pairList.get(0))).longValue(), ((Double)BuilderFactory.DOUBLE.build(pairList.get(1))).doubleValue()))
/*      */           
/* 1684 */           .collect(Collectors.toList());
/*      */       }
/*      */     };
/*      */   
/* 1688 */   public static final Builder<List<TSKeyedElements>> TIMESERIES_MRANGE_RESPONSE = new Builder<List<TSKeyedElements>>()
/*      */     {
/*      */       public List<TSKeyedElements> build(Object data) {
/* 1691 */         return (List<TSKeyedElements>)((List)data).stream().map(tsObject -> (List)tsObject)
/* 1692 */           .map(tsList -> new TSKeyedElements(BuilderFactory.STRING.build(tsList.get(0)), BuilderFactory.STRING_MAP_FROM_PAIRS.build(tsList.get(1)), BuilderFactory.TIMESERIES_ELEMENT_LIST.build(tsList.get(2))))
/*      */ 
/*      */           
/* 1695 */           .collect(Collectors.toList());
/*      */       }
/*      */     };
/*      */   
/* 1699 */   public static final Builder<List<TSKeyValue<TSElement>>> TIMESERIES_MGET_RESPONSE = new Builder<List<TSKeyValue<TSElement>>>()
/*      */     {
/*      */       public List<TSKeyValue<TSElement>> build(Object data)
/*      */       {
/* 1703 */         return (List<TSKeyValue<TSElement>>)((List)data).stream().map(tsObject -> (List)tsObject)
/* 1704 */           .map(tsList -> new TSKeyValue(BuilderFactory.STRING.build(tsList.get(0)), BuilderFactory.STRING_MAP_FROM_PAIRS.build(tsList.get(1)), BuilderFactory.TIMESERIES_ELEMENT.build(tsList.get(2))))
/*      */ 
/*      */           
/* 1707 */           .collect(Collectors.toList());
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class SetFromList<E>
/*      */     extends AbstractSet<E>
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = -2850347066962734052L;
/*      */     
/*      */     private final List<E> list;
/*      */ 
/*      */     
/*      */     private SetFromList(List<E> list) {
/* 1723 */       this.list = list;
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1728 */       this.list.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1733 */       return this.list.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1738 */       return this.list.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object o) {
/* 1743 */       return this.list.contains(o);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object o) {
/* 1748 */       return this.list.remove(o);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean add(E e) {
/* 1753 */       return (!contains(e) && this.list.add(e));
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<E> iterator() {
/* 1758 */       return this.list.iterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/* 1763 */       return this.list.toArray();
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T[] toArray(T[] a) {
/* 1768 */       return this.list.toArray(a);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1773 */       return this.list.toString();
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1778 */       return this.list.hashCode();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/* 1783 */       if (o == null) return false; 
/* 1784 */       if (o == this) return true; 
/* 1785 */       if (!(o instanceof Set)) return false;
/*      */       
/* 1787 */       Collection<?> c = (Collection)o;
/* 1788 */       if (c.size() != size()) {
/* 1789 */         return false;
/*      */       }
/*      */       
/* 1792 */       return containsAll(c);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsAll(Collection<?> c) {
/* 1797 */       return this.list.containsAll(c);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(Collection<?> c) {
/* 1802 */       return this.list.removeAll(c);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(Collection<?> c) {
/* 1807 */       return this.list.retainAll(c);
/*      */     }
/*      */     
/*      */     protected static <E> SetFromList<E> of(List<E> list) {
/* 1811 */       if (list == null) {
/* 1812 */         return null;
/*      */       }
/* 1814 */       return new SetFromList<>(list);
/*      */     }
/*      */   }
/*      */   
/*      */   private BuilderFactory() {
/* 1819 */     throw new InstantiationError("Must not instantiate this class");
/*      */   }
/*      */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\BuilderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */