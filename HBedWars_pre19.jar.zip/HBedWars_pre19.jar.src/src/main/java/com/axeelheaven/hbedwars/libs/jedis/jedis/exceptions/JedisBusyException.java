/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ public class JedisBusyException
/*    */   extends JedisDataException {
/*    */   private static final long serialVersionUID = 3992655220229243478L;
/*    */   
/*    */   public JedisBusyException(String message) {
/*  8 */     super(message);
/*    */   }
/*    */   
/*    */   public JedisBusyException(Throwable cause) {
/* 12 */     super(cause);
/*    */   }
/*    */   
/*    */   public JedisBusyException(String message, Throwable cause) {
/* 16 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\JedisBusyException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */