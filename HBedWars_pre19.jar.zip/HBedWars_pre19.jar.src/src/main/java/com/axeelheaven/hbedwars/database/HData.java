package com.axeelheaven.hbedwars.database;

import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;

public class HData {
    private final Player player;
    private String selectedDeathCry;
    private List<String> purchasedCries;
    
    public HData(Player player) {
        this.player = player;
        this.selectedDeathCry = "default";
        this.purchasedCries = new ArrayList<>();
        this.purchasedCries.add("default");
    }
    
    public Player getPlayer() {
        return player;
    }
    
    public String getSelectedDeathCry() {
        return selectedDeathCry;
    }
    
    public void setSelectedDeathCry(String cry) {
        this.selectedDeathCry = cry;
    }
    
    public List<String> getPurchasedCries() {
        return new ArrayList<>(purchasedCries);
    }
    
    public void addPurchasedCry(String cry) {
        if (!purchasedCries.contains(cry)) {
            purchasedCries.add(cry);
        }
    }
} 