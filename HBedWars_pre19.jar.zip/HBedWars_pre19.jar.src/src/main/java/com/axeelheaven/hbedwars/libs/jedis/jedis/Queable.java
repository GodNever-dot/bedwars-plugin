/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.Queue;
/*    */ 
/*    */ public class Queable
/*    */ {
/*  8 */   private final Queue<Response<?>> pipelinedResponses = new LinkedList<>();
/*    */   
/*    */   protected final void clean() {
/* 11 */     this.pipelinedResponses.clear();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected final Response<?> generateResponse(Object data) {
/* 17 */     Response<?> response = this.pipelinedResponses.poll();
/* 18 */     response.set(data);
/* 19 */     return response;
/*    */   }
/*    */   
/*    */   protected final <T> Response<T> enqueResponse(Builder<T> builder) {
/* 23 */     Response<T> lr = new Response<>(builder);
/* 24 */     this.pipelinedResponses.add(lr);
/* 25 */     return lr;
/*    */   }
/*    */   
/*    */   protected final int getPipelinedResponseLength() {
/* 29 */     return this.pipelinedResponses.size();
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\Queable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */