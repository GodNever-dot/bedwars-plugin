/*    */ package com.axeelheaven.hbedwars.api.events.game.player;
/*    */ import com.axeelheaven.hbedwars.api.arena.Arena;
/*    */ import com.axeelheaven.hbedwars.arena.ArenaTeam;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsPlayerSelectTeamEvent extends Event {
/*    */   private final Arena arena;
/*    */   private final Player player;
/*    */   private final ArenaTeam arenaTeam;
/* 12 */   private static final HandlerList handlerList = new HandlerList(); public Arena getArena() {
/* 13 */     return this.arena; }
/* 14 */   public Player getPlayer() { return this.player; } public ArenaTeam getArenaTeam() {
/* 15 */     return this.arenaTeam;
/*    */   }
/*    */   public BedWarsPlayerSelectTeamEvent(Arena arena, Player player, ArenaTeam arenaTeam) {
/* 18 */     this.arena = arena;
/* 19 */     this.player = player;
/* 20 */     this.arenaTeam = arenaTeam;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 25 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 29 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\game\player\BedWarsPlayerSelectTeamEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */