package com.axeelheaven.hbedwars.libs.jedis.jedis.bloom;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import java.util.List;
import java.util.Map;

public interface CuckooFilterPipelineCommands {
  Response<String> cfReserve(String paramString, long paramLong);
  
  Response<String> cfReserve(String paramString, long paramLong, CFReserveParams paramCFReserveParams);
  
  Response<Boolean> cfAdd(String paramString1, String paramString2);
  
  Response<Boolean> cfAddNx(String paramString1, String paramString2);
  
  Response<List<Boolean>> cfInsert(String paramString, String... paramVarArgs);
  
  Response<List<Boolean>> cfInsert(String paramString, CFInsertParams paramCFInsertParams, String... paramVarArgs);
  
  Response<List<Boolean>> cfInsertNx(String paramString, String... paramVarArgs);
  
  Response<List<Boolean>> cfInsertNx(String paramString, CFInsertParams paramCFInsertParams, String... paramVarArgs);
  
  Response<Boolean> cfExists(String paramString1, String paramString2);
  
  Response<Boolean> cfDel(String paramString1, String paramString2);
  
  Response<Long> cfCount(String paramString1, String paramString2);
  
  Response<Map<String, Object>> cfInfo(String paramString);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\bloom\CuckooFilterPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */