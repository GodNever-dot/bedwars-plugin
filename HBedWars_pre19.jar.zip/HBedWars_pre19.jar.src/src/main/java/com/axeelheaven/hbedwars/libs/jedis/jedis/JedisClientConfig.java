/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*    */ 
/*    */ import javax.net.ssl.HostnameVerifier;
/*    */ import javax.net.ssl.SSLParameters;
/*    */ import javax.net.ssl.SSLSocketFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface JedisClientConfig
/*    */ {
/*    */   default int getConnectionTimeoutMillis() {
/* 13 */     return 2000;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default int getSocketTimeoutMillis() {
/* 20 */     return 2000;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default int getBlockingSocketTimeoutMillis() {
/* 28 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default String getUser() {
/* 35 */     return null;
/*    */   }
/*    */   
/*    */   default String getPassword() {
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   default void updatePassword(String password) {}
/*    */   
/*    */   default int getDatabase() {
/* 46 */     return 0;
/*    */   }
/*    */   
/*    */   default String getClientName() {
/* 50 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean isSsl() {
/* 57 */     return false;
/*    */   }
/*    */   
/*    */   default SSLSocketFactory getSslSocketFactory() {
/* 61 */     return null;
/*    */   }
/*    */   
/*    */   default SSLParameters getSslParameters() {
/* 65 */     return null;
/*    */   }
/*    */   
/*    */   default HostnameVerifier getHostnameVerifier() {
/* 69 */     return null;
/*    */   }
/*    */   
/*    */   default HostAndPortMapper getHostAndPortMapper() {
/* 73 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\JedisClientConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */