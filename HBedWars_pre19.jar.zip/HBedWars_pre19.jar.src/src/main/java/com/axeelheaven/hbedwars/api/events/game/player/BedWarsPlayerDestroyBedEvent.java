/*    */ package com.axeelheaven.hbedwars.api.events.game.player;
/*    */ import com.axeelheaven.hbedwars.api.arena.Arena;
/*    */ import com.axeelheaven.hbedwars.arena.ArenaTeam;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsPlayerDestroyBedEvent extends Event {
/*    */   private final Arena arena;
/*    */   private final Player player;
/*    */   private final ArenaTeam victim;
/* 13 */   private static final HandlerList handlerList = new HandlerList(); private final Block block; public Arena getArena() {
/* 14 */     return this.arena; }
/* 15 */   public Player getPlayer() { return this.player; }
/* 16 */   public ArenaTeam getVictim() { return this.victim; } public Block getBlock() {
/* 17 */     return this.block;
/*    */   }
/*    */   public BedWarsPlayerDestroyBedEvent(Arena arena, Player player, ArenaTeam victim, Block block) {
/* 20 */     this.arena = arena;
/* 21 */     this.player = player;
/* 22 */     this.victim = victim;
/* 23 */     this.block = block;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 28 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 32 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\game\player\BedWarsPlayerDestroyBedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */