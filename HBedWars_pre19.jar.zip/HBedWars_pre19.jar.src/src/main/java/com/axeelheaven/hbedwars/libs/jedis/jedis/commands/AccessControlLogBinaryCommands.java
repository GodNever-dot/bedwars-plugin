package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.AccessControlUser;
import java.util.List;

public interface AccessControlLogBinaryCommands {
  byte[] aclWhoAmIBinary();
  
  byte[] aclGenPassBinary();
  
  byte[] aclGenPassBinary(int paramInt);
  
  List<byte[]> aclListBinary();
  
  List<byte[]> aclUsersBinary();
  
  AccessControlUser aclGetUser(byte[] paramArrayOfbyte);
  
  String aclSetUser(byte[] paramArrayOfbyte);
  
  String aclSetUser(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  long aclDelUser(byte[] paramArrayOfbyte);
  
  long aclDelUser(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  List<byte[]> aclCatBinary();
  
  List<byte[]> aclCat(byte[] paramArrayOfbyte);
  
  List<byte[]> aclLogBinary();
  
  List<byte[]> aclLogBinary(int paramInt);
  
  String aclLogReset();
  
  String aclLoad();
  
  String aclSave();
  
  byte[] aclDryRunBinary(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[]... paramVarArgs);
  
  byte[] aclDryRunBinary(byte[] paramArrayOfbyte, CommandArguments paramCommandArguments);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\AccessControlLogBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */