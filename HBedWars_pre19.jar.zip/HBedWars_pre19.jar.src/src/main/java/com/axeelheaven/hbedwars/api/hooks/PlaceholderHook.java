package com.axeelheaven.hbedwars.api.hooks;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.arena.groups.Group;
import com.axeelheaven.hbedwars.bungeemode.lobby.LServer;
import com.axeelheaven.hbedwars.libs.annotations.NotNull;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;

public class PlaceholderHook extends PlaceholderExpansion {
  private String getLevelFormat(char llllllllllllllllIlIllIllllllIlll, boolean llllllllllllllllIlIllIllllllIllI, short llllllllllllllllIlIllIllllllIlIl) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aload_0
    //   4: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7: invokevirtual getSettings : ()Lcom/axeelheaven/hbedwars/custom/config/HConfiguration;
    //   10: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   13: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   16: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   19: sipush #190
    //   22: iaload
    //   23: iaload
    //   24: aaload
    //   25: invokevirtual getConfigurationSection : (Ljava/lang/String;)Lorg/bukkit/configuration/ConfigurationSection;
    //   28: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   31: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   34: iconst_3
    //   35: iaload
    //   36: iaload
    //   37: invokeinterface getKeys : (Z)Ljava/util/Set;
    //   42: invokeinterface iterator : ()Ljava/util/Iterator;
    //   47: astore #5
    //   49: aload #5
    //   51: invokeinterface hasNext : ()Z
    //   56: invokestatic llllIIIlI : (I)Z
    //   59: invokestatic lllIllllIlII : (I)Z
    //   62: ifeq -> 536
    //   65: aload #5
    //   67: invokeinterface next : ()Ljava/lang/Object;
    //   72: checkcast java/lang/String
    //   75: astore #6
    //   77: aload #6
    //   79: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   82: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   85: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   88: sipush #191
    //   91: iaload
    //   92: iaload
    //   93: aaload
    //   94: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   97: astore #7
    //   99: aload #7
    //   101: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   104: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   107: iconst_3
    //   108: iaload
    //   109: iaload
    //   110: aaload
    //   111: invokestatic parseInt : (Ljava/lang/String;)I
    //   114: istore #8
    //   116: aload #7
    //   118: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   121: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   124: iconst_0
    //   125: iaload
    //   126: iaload
    //   127: aaload
    //   128: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   131: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   134: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   137: sipush #181
    //   140: iaload
    //   141: iaload
    //   142: aaload
    //   143: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   146: invokestatic llllIIIlI : (I)Z
    //   149: invokestatic lllIllllIlII : (I)Z
    //   152: ifeq -> 208
    //   155: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   158: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   161: sipush #192
    //   164: iaload
    //   165: iaload
    //   166: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   169: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   172: sipush #440
    //   175: iaload
    //   176: aaload
    //   177: invokevirtual length : ()I
    //   180: ldc ''
    //   182: invokevirtual length : ()I
    //   185: pop2
    //   186: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   189: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   192: sipush #441
    //   195: iaload
    //   196: aaload
    //   197: invokevirtual length : ()I
    //   200: invokestatic llllIIIIlIll : (I)Z
    //   203: ifeq -> 223
    //   206: aconst_null
    //   207: areturn
    //   208: aload #7
    //   210: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   213: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   216: iconst_0
    //   217: iaload
    //   218: iaload
    //   219: aaload
    //   220: invokestatic parseInt : (Ljava/lang/String;)I
    //   223: istore #9
    //   225: iload_1
    //   226: iload #8
    //   228: invokestatic llllIIlII : (II)Z
    //   231: invokestatic lllIllllIlII : (I)Z
    //   234: ifeq -> 474
    //   237: iload_1
    //   238: iload #9
    //   240: invokestatic llllIIlIl : (II)Z
    //   243: invokestatic lllIllllIlII : (I)Z
    //   246: ifeq -> 474
    //   249: aload_0
    //   250: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   253: invokevirtual getSettings : ()Lcom/axeelheaven/hbedwars/custom/config/HConfiguration;
    //   256: new java/lang/StringBuilder
    //   259: dup
    //   260: invokespecial <init> : ()V
    //   263: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   266: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   269: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   272: sipush #193
    //   275: iaload
    //   276: iaload
    //   277: aaload
    //   278: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   281: aload #6
    //   283: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   286: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   289: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   292: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   295: sipush #194
    //   298: iaload
    //   299: iaload
    //   300: aaload
    //   301: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   304: aload_2
    //   305: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   308: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   311: aload_3
    //   312: invokevirtual getString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   315: astore #4
    //   317: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   320: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   323: sipush #442
    //   326: iaload
    //   327: aaload
    //   328: invokevirtual length : ()I
    //   331: ldc ''
    //   333: invokevirtual length : ()I
    //   336: pop2
    //   337: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   340: bipush #62
    //   342: iaload
    //   343: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   346: bipush #43
    //   348: iaload
    //   349: iadd
    //   350: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   353: bipush #13
    //   355: iaload
    //   356: isub
    //   357: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   360: bipush #73
    //   362: iaload
    //   363: iadd
    //   364: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   367: bipush #121
    //   369: iaload
    //   370: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   373: bipush #87
    //   375: iaload
    //   376: iadd
    //   377: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   380: bipush #108
    //   382: iaload
    //   383: isub
    //   384: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   387: bipush #33
    //   389: iaload
    //   390: iadd
    //   391: ixor
    //   392: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   395: bipush #74
    //   397: iaload
    //   398: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   401: bipush #52
    //   403: iaload
    //   404: iadd
    //   405: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   408: bipush #10
    //   410: iaload
    //   411: isub
    //   412: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   415: bipush #41
    //   417: iaload
    //   418: iadd
    //   419: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   422: bipush #16
    //   424: iaload
    //   425: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   428: sipush #146
    //   431: iaload
    //   432: iadd
    //   433: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   436: bipush #110
    //   438: iaload
    //   439: isub
    //   440: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   443: sipush #151
    //   446: iaload
    //   447: iadd
    //   448: ixor
    //   449: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   452: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   455: sipush #443
    //   458: iaload
    //   459: aaload
    //   460: invokevirtual length : ()I
    //   463: ineg
    //   464: ixor
    //   465: iand
    //   466: invokestatic lllIllllIlII : (I)Z
    //   469: ifeq -> 536
    //   472: aconst_null
    //   473: areturn
    //   474: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   477: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   480: sipush #444
    //   483: iaload
    //   484: aaload
    //   485: invokevirtual length : ()I
    //   488: ldc ''
    //   490: invokevirtual length : ()I
    //   493: pop2
    //   494: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   497: bipush #87
    //   499: iaload
    //   500: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   503: bipush #12
    //   505: iaload
    //   506: ixor
    //   507: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   510: iconst_4
    //   511: iaload
    //   512: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   515: bipush #95
    //   517: iaload
    //   518: ixor
    //   519: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   522: sipush #135
    //   525: iaload
    //   526: ixor
    //   527: iand
    //   528: invokestatic lllIllllIlII : (I)Z
    //   531: ifeq -> 49
    //   534: aconst_null
    //   535: areturn
    //   536: aload #4
    //   538: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	539	7	llllllllllllllllIlIlllIIIIIIIIll	S
    //   0	539	1	llllllllllllllllIlIllIlllllllIlI	Z
    //   0	539	5	llllllllllllllllIlIllIllllllIIll	Ljava/lang/Exception;
    //   0	539	2	llllllllllllllllIlIlllIIIIIIIIIl	S
    //   0	539	6	llllllllllllllllIlIllIllllllIIlI	Ljava/lang/Exception;
    //   0	539	8	llllllllllllllllIlIllIllllllIIII	Ljava/lang/String;
    //   77	397	6	llllllllllllllllIlIllIlllllllllI	Ljava/lang/String;
    //   99	375	7	llllllllllllllllIlIlllIIIIIIIlII	[Ljava/lang/String;
    //   0	539	1	llllllllllllllllIlIllIllllllIlll	C
    //   0	539	0	llllllllllllllllIlIlllIIIIIIlIlI	Z
    //   0	539	3	llllllllllllllllIlIlllIIIIIIlIII	Ljava/lang/String;
    //   0	539	1	llllllllllllllllIlIlllIIIIIIIIlI	I
    //   0	539	3	llllllllllllllllIlIllIllllllIlIl	S
    //   0	539	0	llllllllllllllllIlIllIlllllllIII	S
    //   0	539	4	llllllllllllllllIlIllIllllllIlII	S
    //   0	539	2	llllllllllllllllIlIllIllllllIllI	Z
    //   0	539	8	llllllllllllllllIlIlllIIIIIIIlll	Ljava/lang/Exception;
    //   3	536	4	llllllllllllllllIlIllIlllllllIIl	Ljava/lang/String;
    //   0	539	4	llllllllllllllllIlIllIllllllllIl	B
    //   0	539	3	llllllllllllllllIlIlllIIIIIIlIIl	D
    //   116	358	8	llllllllllllllllIlIllIlllllllIll	I
    //   0	539	0	llllllllllllllllIlIlllIIIIIIIlIl	Lcom/axeelheaven/hbedwars/api/hooks/PlaceholderHook;
    //   225	249	9	llllllllllllllllIlIlllIIIIIIlIll	I
    //   0	539	7	llllllllllllllllIlIllIllllllIIIl	D
    //   0	539	9	llllllllllllllllIlIlllIIIIIIIllI	Ljava/lang/String;
    //   0	539	2	llllllllllllllllIlIlllIIIIIIIIII	Ljava/lang/String;
    //   0	539	9	llllllllllllllllIlIllIlllllIllll	Ljava/lang/Exception;
    //   0	539	6	llllllllllllllllIlIllIllllllllll	C
    //   0	539	5	llllllllllllllllIlIllIllllllllII	Z
  }
  
  private static void llllIIIII() {
    lIlIIlll = new String[lIlIlIII[llIIllIlII[189]]];
    lIlIIlll[lIlIlIII[llIIllIlII[3]]] = lllIlllIl(llIIlIllll[llIIllIlII[23]], llIIlIllll[llIIllIlII[24]]);
    lIlIIlll[lIlIlIII[llIIllIlII[0]]] = lllIllllI(llIIlIllll[llIIllIlII[25]], llIIlIllll[llIIllIlII[26]]);
    lIlIIlll[lIlIlIII[llIIllIlII[1]]] = lllIllllI(llIIlIllll[llIIllIlII[27]], llIIlIllll[llIIllIlII[28]]);
    lIlIIlll[lIlIlIII[llIIllIlII[2]]] = lllIlllll(llIIlIllll[llIIllIlII[29]], llIIlIllll[llIIllIlII[30]]);
    lIlIIlll[lIlIlIII[llIIllIlII[4]]] = lllIlllll(llIIlIllll[llIIllIlII[31]], llIIlIllll[llIIllIlII[32]]);
    lIlIIlll[lIlIlIII[llIIllIlII[5]]] = lllIlllIl(llIIlIllll[llIIllIlII[33]], llIIlIllll[llIIllIlII[34]]);
    lIlIIlll[lIlIlIII[llIIllIlII[6]]] = lllIllllI(llIIlIllll[llIIllIlII[35]], llIIlIllll[llIIllIlII[36]]);
    lIlIIlll[lIlIlIII[llIIllIlII[7]]] = lllIllllI(llIIlIllll[llIIllIlII[37]], llIIlIllll[llIIllIlII[38]]);
    lIlIIlll[lIlIlIII[llIIllIlII[8]]] = lllIlllIl(llIIlIllll[llIIllIlII[39]], llIIlIllll[llIIllIlII[40]]);
    lIlIIlll[lIlIlIII[llIIllIlII[9]]] = lllIllllI(llIIlIllll[llIIllIlII[41]], llIIlIllll[llIIllIlII[42]]);
    lIlIIlll[lIlIlIII[llIIllIlII[10]]] = lllIllllI(llIIlIllll[llIIllIlII[43]], llIIlIllll[llIIllIlII[44]]);
    lIlIIlll[lIlIlIII[llIIllIlII[11]]] = lllIllllI(llIIlIllll[llIIllIlII[45]], llIIlIllll[llIIllIlII[46]]);
    lIlIIlll[lIlIlIII[llIIllIlII[12]]] = lllIlllll(llIIlIllll[llIIllIlII[47]], llIIlIllll[llIIllIlII[48]]);
    lIlIIlll[lIlIlIII[llIIllIlII[13]]] = lllIlllIl(llIIlIllll[llIIllIlII[49]], llIIlIllll[llIIllIlII[50]]);
    lIlIIlll[lIlIlIII[llIIllIlII[14]]] = lllIlllIl(llIIlIllll[llIIllIlII[51]], llIIlIllll[llIIllIlII[52]]);
    lIlIIlll[lIlIlIII[llIIllIlII[15]]] = lllIlllll(llIIlIllll[llIIllIlII[53]], llIIlIllll[llIIllIlII[54]]);
    lIlIIlll[lIlIlIII[llIIllIlII[16]]] = lllIlllIl(llIIlIllll[llIIllIlII[55]], llIIlIllll[llIIllIlII[56]]);
    lIlIIlll[lIlIlIII[llIIllIlII[17]]] = lllIlllIl(llIIlIllll[llIIllIlII[57]], llIIlIllll[llIIllIlII[58]]);
    lIlIIlll[lIlIlIII[llIIllIlII[18]]] = lllIlllll(llIIlIllll[llIIllIlII[59]], llIIlIllll[llIIllIlII[60]]);
    lIlIIlll[lIlIlIII[llIIllIlII[19]]] = lllIlllll(llIIlIllll[llIIllIlII[61]], llIIlIllll[llIIllIlII[62]]);
    lIlIIlll[lIlIlIII[llIIllIlII[20]]] = lllIlllIl(llIIlIllll[llIIllIlII[63]], llIIlIllll[llIIllIlII[64]]);
    lIlIIlll[lIlIlIII[llIIllIlII[21]]] = lllIlllll(llIIlIllll[llIIllIlII[65]], llIIlIllll[llIIllIlII[66]]);
    lIlIIlll[lIlIlIII[llIIllIlII[22]]] = lllIlllll(llIIlIllll[llIIllIlII[67]], llIIlIllll[llIIllIlII[68]]);
    lIlIIlll[lIlIlIII[llIIllIlII[23]]] = lllIllllI(llIIlIllll[llIIllIlII[69]], llIIlIllll[llIIllIlII[70]]);
    lIlIIlll[lIlIlIII[llIIllIlII[24]]] = lllIlllll(llIIlIllll[llIIllIlII[71]], llIIlIllll[llIIllIlII[72]]);
    lIlIIlll[lIlIlIII[llIIllIlII[25]]] = lllIllllI(llIIlIllll[llIIllIlII[73]], llIIlIllll[llIIllIlII[74]]);
    lIlIIlll[lIlIlIII[llIIllIlII[26]]] = lllIlllIl(llIIlIllll[llIIllIlII[75]], llIIlIllll[llIIllIlII[76]]);
    lIlIIlll[lIlIlIII[llIIllIlII[27]]] = lllIlllIl(llIIlIllll[llIIllIlII[77]], llIIlIllll[llIIllIlII[78]]);
    lIlIIlll[lIlIlIII[llIIllIlII[28]]] = lllIlllll(llIIlIllll[llIIllIlII[79]], llIIlIllll[llIIllIlII[80]]);
    lIlIIlll[lIlIlIII[llIIllIlII[29]]] = lllIlllll(llIIlIllll[llIIllIlII[81]], llIIlIllll[llIIllIlII[82]]);
    lIlIIlll[lIlIlIII[llIIllIlII[30]]] = lllIlllIl(llIIlIllll[llIIllIlII[83]], llIIlIllll[llIIllIlII[84]]);
    lIlIIlll[lIlIlIII[llIIllIlII[31]]] = lllIlllll(llIIlIllll[llIIllIlII[85]], llIIlIllll[llIIllIlII[86]]);
    lIlIIlll[lIlIlIII[llIIllIlII[32]]] = lllIllllI(llIIlIllll[llIIllIlII[87]], llIIlIllll[llIIllIlII[88]]);
    lIlIIlll[lIlIlIII[llIIllIlII[33]]] = lllIlllll(llIIlIllll[llIIllIlII[89]], llIIlIllll[llIIllIlII[90]]);
    lIlIIlll[lIlIlIII[llIIllIlII[34]]] = lllIlllll(llIIlIllll[llIIllIlII[91]], llIIlIllll[llIIllIlII[92]]);
    lIlIIlll[lIlIlIII[llIIllIlII[35]]] = lllIlllll(llIIlIllll[llIIllIlII[93]], llIIlIllll[llIIllIlII[94]]);
    lIlIIlll[lIlIlIII[llIIllIlII[36]]] = lllIlllll(llIIlIllll[llIIllIlII[95]], llIIlIllll[llIIllIlII[96]]);
    lIlIIlll[lIlIlIII[llIIllIlII[37]]] = lllIlllll(llIIlIllll[llIIllIlII[97]], llIIlIllll[llIIllIlII[98]]);
    lIlIIlll[lIlIlIII[llIIllIlII[38]]] = lllIlllll(llIIlIllll[llIIllIlII[99]], llIIlIllll[llIIllIlII[100]]);
    lIlIIlll[lIlIlIII[llIIllIlII[39]]] = lllIlllIl(llIIlIllll[llIIllIlII[101]], llIIlIllll[llIIllIlII[102]]);
    lIlIIlll[lIlIlIII[llIIllIlII[40]]] = lllIlllll(llIIlIllll[llIIllIlII[103]], llIIlIllll[llIIllIlII[104]]);
    lIlIIlll[lIlIlIII[llIIllIlII[41]]] = lllIlllll(llIIlIllll[llIIllIlII[105]], llIIlIllll[llIIllIlII[106]]);
    lIlIIlll[lIlIlIII[llIIllIlII[42]]] = lllIlllll(llIIlIllll[llIIllIlII[107]], llIIlIllll[llIIllIlII[108]]);
    lIlIIlll[lIlIlIII[llIIllIlII[43]]] = lllIlllll(llIIlIllll[llIIllIlII[109]], llIIlIllll[llIIllIlII[110]]);
    lIlIIlll[lIlIlIII[llIIllIlII[44]]] = lllIllllI(llIIlIllll[llIIllIlII[111]], llIIlIllll[llIIllIlII[112]]);
    lIlIIlll[lIlIlIII[llIIllIlII[45]]] = lllIlllIl(llIIlIllll[llIIllIlII[113]], llIIlIllll[llIIllIlII[114]]);
    lIlIIlll[lIlIlIII[llIIllIlII[46]]] = lllIlllll(llIIlIllll[llIIllIlII[115]], llIIlIllll[llIIllIlII[116]]);
    lIlIIlll[lIlIlIII[llIIllIlII[47]]] = lllIllllI(llIIlIllll[llIIllIlII[117]], llIIlIllll[llIIllIlII[118]]);
    lIlIIlll[lIlIlIII[llIIllIlII[48]]] = lllIlllIl(llIIlIllll[llIIllIlII[119]], llIIlIllll[llIIllIlII[120]]);
    lIlIIlll[lIlIlIII[llIIllIlII[49]]] = lllIllllI(llIIlIllll[llIIllIlII[121]], llIIlIllll[llIIllIlII[122]]);
    lIlIIlll[lIlIlIII[llIIllIlII[50]]] = lllIlllIl(llIIlIllll[llIIllIlII[129]], llIIlIllll[llIIllIlII[130]]);
    lIlIIlll[lIlIlIII[llIIllIlII[51]]] = lllIlllll(llIIlIllll[llIIllIlII[131]], llIIlIllll[llIIllIlII[132]]);
    lIlIIlll[lIlIlIII[llIIllIlII[52]]] = lllIllllI(llIIlIllll[llIIllIlII[133]], llIIlIllll[llIIllIlII[134]]);
    lIlIIlll[lIlIlIII[llIIllIlII[53]]] = lllIlllIl(llIIlIllll[llIIllIlII[136]], llIIlIllll[llIIllIlII[123]]);
    lIlIIlll[lIlIlIII[llIIllIlII[54]]] = lllIllllI(llIIlIllll[llIIllIlII[137]], llIIlIllll[llIIllIlII[138]]);
    lIlIIlll[lIlIlIII[llIIllIlII[55]]] = lllIlllIl(llIIlIllll[llIIllIlII[139]], llIIlIllll[llIIllIlII[140]]);
    lIlIIlll[lIlIlIII[llIIllIlII[56]]] = lllIlllll(llIIlIllll[llIIllIlII[143]], llIIlIllll[llIIllIlII[144]]);
    lIlIIlll[lIlIlIII[llIIllIlII[57]]] = lllIlllll(llIIlIllll[llIIllIlII[145]], llIIlIllll[llIIllIlII[146]]);
    lIlIIlll[lIlIlIII[llIIllIlII[58]]] = lllIllllI(llIIlIllll[llIIllIlII[142]], llIIlIllll[llIIllIlII[147]]);
    lIlIIlll[lIlIlIII[llIIllIlII[59]]] = lllIlllIl(llIIlIllll[llIIllIlII[148]], llIIlIllll[llIIllIlII[149]]);
    lIlIIlll[lIlIlIII[llIIllIlII[60]]] = lllIllllI(llIIlIllll[llIIllIlII[126]], llIIlIllll[llIIllIlII[150]]);
    lIlIIlll[lIlIlIII[llIIllIlII[61]]] = lllIlllll(llIIlIllll[llIIllIlII[151]], llIIlIllll[llIIllIlII[152]]);
    lIlIIlll[lIlIlIII[llIIllIlII[62]]] = lllIllllI(llIIlIllll[llIIllIlII[153]], llIIlIllll[llIIllIlII[154]]);
    lIlIIlll[lIlIlIII[llIIllIlII[63]]] = lllIllllI(llIIlIllll[llIIllIlII[155]], llIIlIllll[llIIllIlII[156]]);
    lIlIIlll[lIlIlIII[llIIllIlII[64]]] = lllIlllIl(llIIlIllll[llIIllIlII[157]], llIIlIllll[llIIllIlII[158]]);
    lIlIIlll[lIlIlIII[llIIllIlII[65]]] = lllIllllI(llIIlIllll[llIIllIlII[159]], llIIlIllll[llIIllIlII[141]]);
    lIlIIlll[lIlIlIII[llIIllIlII[66]]] = lllIlllIl(llIIlIllll[llIIllIlII[160]], llIIlIllll[llIIllIlII[128]]);
    lIlIIlll[lIlIlIII[llIIllIlII[67]]] = lllIlllIl(llIIlIllll[llIIllIlII[161]], llIIlIllll[llIIllIlII[162]]);
    lIlIIlll[lIlIlIII[llIIllIlII[68]]] = lllIlllIl(llIIlIllll[llIIllIlII[163]], llIIlIllll[llIIllIlII[164]]);
    lIlIIlll[lIlIlIII[llIIllIlII[69]]] = lllIlllIl(llIIlIllll[llIIllIlII[165]], llIIlIllll[llIIllIlII[166]]);
    lIlIIlll[lIlIlIII[llIIllIlII[70]]] = lllIllllI(llIIlIllll[llIIllIlII[167]], llIIlIllll[llIIllIlII[168]]);
    lIlIIlll[lIlIlIII[llIIllIlII[71]]] = lllIllllI(llIIlIllll[llIIllIlII[169]], llIIlIllll[llIIllIlII[170]]);
    lIlIIlll[lIlIlIII[llIIllIlII[72]]] = lllIlllll(llIIlIllll[llIIllIlII[171]], llIIlIllll[llIIllIlII[125]]);
    lIlIIlll[lIlIlIII[llIIllIlII[73]]] = lllIlllIl(llIIlIllll[llIIllIlII[172]], llIIlIllll[llIIllIlII[173]]);
    lIlIIlll[lIlIlIII[llIIllIlII[74]]] = lllIlllIl(llIIlIllll[llIIllIlII[174]], llIIlIllll[llIIllIlII[175]]);
    lIlIIlll[lIlIlIII[llIIllIlII[75]]] = lllIlllIl(llIIlIllll[llIIllIlII[176]], llIIlIllll[llIIllIlII[177]]);
    lIlIIlll[lIlIlIII[llIIllIlII[76]]] = lllIlllIl(llIIlIllll[llIIllIlII[127]], llIIlIllll[llIIllIlII[183]]);
    lIlIIlll[lIlIlIII[llIIllIlII[77]]] = lllIllllI(llIIlIllll[llIIllIlII[184]], llIIlIllll[llIIllIlII[178]]);
    lIlIIlll[lIlIlIII[llIIllIlII[78]]] = lllIlllll(llIIlIllll[llIIllIlII[185]], llIIlIllll[llIIllIlII[186]]);
    lIlIIlll[lIlIlIII[llIIllIlII[79]]] = lllIllllI(llIIlIllll[llIIllIlII[187]], llIIlIllll[llIIllIlII[188]]);
    lIlIIlll[lIlIlIII[llIIllIlII[80]]] = lllIlllIl(llIIlIllll[llIIllIlII[190]], llIIlIllll[llIIllIlII[191]]);
    lIlIIlll[lIlIlIII[llIIllIlII[81]]] = lllIlllll(llIIlIllll[llIIllIlII[181]], llIIlIllll[llIIllIlII[192]]);
    lIlIIlll[lIlIlIII[llIIllIlII[82]]] = lllIlllll(llIIlIllll[llIIllIlII[193]], llIIlIllll[llIIllIlII[194]]);
    lIlIIlll[lIlIlIII[llIIllIlII[83]]] = lllIllllI(llIIlIllll[llIIllIlII[189]], llIIlIllll[llIIllIlII[195]]);
    lIlIIlll[lIlIlIII[llIIllIlII[84]]] = lllIllllI(llIIlIllll[llIIllIlII[196]], llIIlIllll[llIIllIlII[197]]);
    lIlIIlll[lIlIlIII[llIIllIlII[85]]] = lllIlllll(llIIlIllll[llIIllIlII[124]], llIIlIllll[llIIllIlII[198]]);
    lIlIIlll[lIlIlIII[llIIllIlII[86]]] = lllIllllI(llIIlIllll[llIIllIlII[199]], llIIlIllll[llIIllIlII[200]]);
    lIlIIlll[lIlIlIII[llIIllIlII[87]]] = lllIlllIl(llIIlIllll[llIIllIlII[201]], llIIlIllll[llIIllIlII[202]]);
    lIlIIlll[lIlIlIII[llIIllIlII[88]]] = lllIlllIl(llIIlIllll[llIIllIlII[203]], llIIlIllll[llIIllIlII[204]]);
    lIlIIlll[lIlIlIII[llIIllIlII[89]]] = lllIlllll(llIIlIllll[llIIllIlII[205]], llIIlIllll[llIIllIlII[206]]);
    lIlIIlll[lIlIlIII[llIIllIlII[90]]] = lllIlllIl(llIIlIllll[llIIllIlII[207]], llIIlIllll[llIIllIlII[208]]);
    lIlIIlll[lIlIlIII[llIIllIlII[91]]] = lllIlllIl(llIIlIllll[llIIllIlII[209]], llIIlIllll[llIIllIlII[210]]);
    lIlIIlll[lIlIlIII[llIIllIlII[92]]] = lllIllllI(llIIlIllll[llIIllIlII[211]], llIIlIllll[llIIllIlII[212]]);
    lIlIIlll[lIlIlIII[llIIllIlII[93]]] = lllIllllI(llIIlIllll[llIIllIlII[213]], llIIlIllll[llIIllIlII[214]]);
    lIlIIlll[lIlIlIII[llIIllIlII[94]]] = lllIlllIl(llIIlIllll[llIIllIlII[215]], llIIlIllll[llIIllIlII[216]]);
    lIlIIlll[lIlIlIII[llIIllIlII[95]]] = lllIllllI(llIIlIllll[llIIllIlII[217]], llIIlIllll[llIIllIlII[218]]);
    lIlIIlll[lIlIlIII[llIIllIlII[96]]] = lllIlllIl(llIIlIllll[llIIllIlII[219]], llIIlIllll[llIIllIlII[220]]);
    lIlIIlll[lIlIlIII[llIIllIlII[97]]] = lllIllllI(llIIlIllll[llIIllIlII[221]], llIIlIllll[llIIllIlII[222]]);
    lIlIIlll[lIlIlIII[llIIllIlII[98]]] = lllIlllIl(llIIlIllll[llIIllIlII[223]], llIIlIllll[llIIllIlII[224]]);
    lIlIIlll[lIlIlIII[llIIllIlII[99]]] = lllIlllll(llIIlIllll[llIIllIlII[225]], llIIlIllll[llIIllIlII[226]]);
    lIlIIlll[lIlIlIII[llIIllIlII[100]]] = lllIlllll(llIIlIllll[llIIllIlII[227]], llIIlIllll[llIIllIlII[180]]);
    lIlIIlll[lIlIlIII[llIIllIlII[101]]] = lllIlllIl(llIIlIllll[llIIllIlII[228]], llIIlIllll[llIIllIlII[229]]);
    lIlIIlll[lIlIlIII[llIIllIlII[102]]] = lllIllllI(llIIlIllll[llIIllIlII[230]], llIIlIllll[llIIllIlII[231]]);
    lIlIIlll[lIlIlIII[llIIllIlII[103]]] = lllIlllIl(llIIlIllll[llIIllIlII[232]], llIIlIllll[llIIllIlII[233]]);
    lIlIIlll[lIlIlIII[llIIllIlII[104]]] = lllIlllIl(llIIlIllll[llIIllIlII[234]], llIIlIllll[llIIllIlII[235]]);
    lIlIIlll[lIlIlIII[llIIllIlII[105]]] = lllIlllIl(llIIlIllll[llIIllIlII[236]], llIIlIllll[llIIllIlII[237]]);
    lIlIIlll[lIlIlIII[llIIllIlII[106]]] = lllIllllI(llIIlIllll[llIIllIlII[238]], llIIlIllll[llIIllIlII[239]]);
    lIlIIlll[lIlIlIII[llIIllIlII[107]]] = lllIllllI(llIIlIllll[llIIllIlII[240]], llIIlIllll[llIIllIlII[241]]);
    lIlIIlll[lIlIlIII[llIIllIlII[108]]] = lllIlllll(llIIlIllll[llIIllIlII[242]], llIIlIllll[llIIllIlII[243]]);
    lIlIIlll[lIlIlIII[llIIllIlII[109]]] = lllIlllIl(llIIlIllll[llIIllIlII[244]], llIIlIllll[llIIllIlII[245]]);
    lIlIIlll[lIlIlIII[llIIllIlII[110]]] = lllIllllI(llIIlIllll[llIIllIlII[246]], llIIlIllll[llIIllIlII[182]]);
    lIlIIlll[lIlIlIII[llIIllIlII[111]]] = lllIllllI(llIIlIllll[llIIllIlII[247]], llIIlIllll[llIIllIlII[248]]);
    lIlIIlll[lIlIlIII[llIIllIlII[112]]] = lllIllllI(llIIlIllll[llIIllIlII[249]], llIIlIllll[llIIllIlII[250]]);
    lIlIIlll[lIlIlIII[llIIllIlII[113]]] = lllIlllIl(llIIlIllll[llIIllIlII[251]], llIIlIllll[llIIllIlII[252]]);
    lIlIIlll[lIlIlIII[llIIllIlII[114]]] = lllIlllIl(llIIlIllll[llIIllIlII[253]], llIIlIllll[llIIllIlII[254]]);
    lIlIIlll[lIlIlIII[llIIllIlII[115]]] = lllIllllI(llIIlIllll[llIIllIlII[255]], llIIlIllll[llIIllIlII[256]]);
    lIlIIlll[lIlIlIII[llIIllIlII[116]]] = lllIllllI(llIIlIllll[llIIllIlII[257]], llIIlIllll[llIIllIlII[258]]);
    lIlIIlll[lIlIlIII[llIIllIlII[117]]] = lllIlllll(llIIlIllll[llIIllIlII[259]], llIIlIllll[llIIllIlII[260]]);
    lIlIIlll[lIlIlIII[llIIllIlII[118]]] = lllIlllIl(llIIlIllll[llIIllIlII[261]], llIIlIllll[llIIllIlII[262]]);
    lIlIIlll[lIlIlIII[llIIllIlII[119]]] = lllIlllll(llIIlIllll[llIIllIlII[263]], llIIlIllll[llIIllIlII[264]]);
    lIlIIlll[lIlIlIII[llIIllIlII[120]]] = lllIllllI(llIIlIllll[llIIllIlII[265]], llIIlIllll[llIIllIlII[266]]);
    lIlIIlll[lIlIlIII[llIIllIlII[121]]] = lllIlllIl(llIIlIllll[llIIllIlII[267]], llIIlIllll[llIIllIlII[268]]);
    lIlIIlll[lIlIlIII[llIIllIlII[122]]] = lllIlllll(llIIlIllll[llIIllIlII[269]], llIIlIllll[llIIllIlII[270]]);
    lIlIIlll[lIlIlIII[llIIllIlII[129]]] = lllIllllI(llIIlIllll[llIIllIlII[271]], llIIlIllll[llIIllIlII[272]]);
    lIlIIlll[lIlIlIII[llIIllIlII[130]]] = lllIllllI(llIIlIllll[llIIllIlII[273]], llIIlIllll[llIIllIlII[274]]);
    lIlIIlll[lIlIlIII[llIIllIlII[131]]] = lllIllllI(llIIlIllll[llIIllIlII[275]], llIIlIllll[llIIllIlII[276]]);
    lIlIIlll[lIlIlIII[llIIllIlII[132]]] = lllIlllIl(llIIlIllll[llIIllIlII[277]], llIIlIllll[llIIllIlII[278]]);
    lIlIIlll[lIlIlIII[llIIllIlII[133]]] = lllIllllI(llIIlIllll[llIIllIlII[279]], llIIlIllll[llIIllIlII[280]]);
    lIlIIlll[lIlIlIII[llIIllIlII[134]]] = lllIlllll(llIIlIllll[llIIllIlII[281]], llIIlIllll[llIIllIlII[282]]);
    lIlIIlll[lIlIlIII[llIIllIlII[136]]] = lllIllllI(llIIlIllll[llIIllIlII[283]], llIIlIllll[llIIllIlII[284]]);
    lIlIIlll[lIlIlIII[llIIllIlII[123]]] = lllIlllll(llIIlIllll[llIIllIlII[285]], llIIlIllll[llIIllIlII[286]]);
    lIlIIlll[lIlIlIII[llIIllIlII[137]]] = lllIllllI(llIIlIllll[llIIllIlII[287]], llIIlIllll[llIIllIlII[288]]);
    lIlIIlll[lIlIlIII[llIIllIlII[138]]] = lllIlllIl(llIIlIllll[llIIllIlII[289]], llIIlIllll[llIIllIlII[290]]);
    lIlIIlll[lIlIlIII[llIIllIlII[139]]] = lllIlllll(llIIlIllll[llIIllIlII[291]], llIIlIllll[llIIllIlII[292]]);
    lIlIIlll[lIlIlIII[llIIllIlII[140]]] = lllIlllll(llIIlIllll[llIIllIlII[293]], llIIlIllll[llIIllIlII[294]]);
    lIlIIlll[lIlIlIII[llIIllIlII[143]]] = lllIllllI(llIIlIllll[llIIllIlII[295]], llIIlIllll[llIIllIlII[296]]);
    lIlIIlll[lIlIlIII[llIIllIlII[144]]] = lllIlllIl(llIIlIllll[llIIllIlII[297]], llIIlIllll[llIIllIlII[298]]);
    lIlIIlll[lIlIlIII[llIIllIlII[145]]] = lllIllllI(llIIlIllll[llIIllIlII[299]], llIIlIllll[llIIllIlII[300]]);
    lIlIIlll[lIlIlIII[llIIllIlII[146]]] = lllIllllI(llIIlIllll[llIIllIlII[301]], llIIlIllll[llIIllIlII[302]]);
    lIlIIlll[lIlIlIII[llIIllIlII[142]]] = lllIlllIl(llIIlIllll[llIIllIlII[303]], llIIlIllll[llIIllIlII[304]]);
    lIlIIlll[lIlIlIII[llIIllIlII[147]]] = lllIlllIl(llIIlIllll[llIIllIlII[305]], llIIlIllll[llIIllIlII[306]]);
    lIlIIlll[lIlIlIII[llIIllIlII[148]]] = lllIllllI(llIIlIllll[llIIllIlII[307]], llIIlIllll[llIIllIlII[308]]);
    lIlIIlll[lIlIlIII[llIIllIlII[149]]] = lllIlllIl(llIIlIllll[llIIllIlII[309]], llIIlIllll[llIIllIlII[310]]);
    lIlIIlll[lIlIlIII[llIIllIlII[126]]] = lllIlllll(llIIlIllll[llIIllIlII[311]], llIIlIllll[llIIllIlII[312]]);
    lIlIIlll[lIlIlIII[llIIllIlII[150]]] = lllIlllll(llIIlIllll[llIIllIlII[313]], llIIlIllll[llIIllIlII[314]]);
    lIlIIlll[lIlIlIII[llIIllIlII[151]]] = lllIllllI(llIIlIllll[llIIllIlII[315]], llIIlIllll[llIIllIlII[316]]);
    lIlIIlll[lIlIlIII[llIIllIlII[152]]] = lllIlllll(llIIlIllll[llIIllIlII[317]], llIIlIllll[llIIllIlII[318]]);
    lIlIIlll[lIlIlIII[llIIllIlII[153]]] = lllIlllll(llIIlIllll[llIIllIlII[319]], llIIlIllll[llIIllIlII[320]]);
    lIlIIlll[lIlIlIII[llIIllIlII[154]]] = lllIlllll(llIIlIllll[llIIllIlII[321]], llIIlIllll[llIIllIlII[322]]);
    lIlIIlll[lIlIlIII[llIIllIlII[155]]] = lllIlllIl(llIIlIllll[llIIllIlII[323]], llIIlIllll[llIIllIlII[324]]);
    lIlIIlll[lIlIlIII[llIIllIlII[156]]] = lllIlllIl(llIIlIllll[llIIllIlII[325]], llIIlIllll[llIIllIlII[326]]);
    lIlIIlll[lIlIlIII[llIIllIlII[157]]] = lllIlllll(llIIlIllll[llIIllIlII[327]], llIIlIllll[llIIllIlII[328]]);
    lIlIIlll[lIlIlIII[llIIllIlII[158]]] = lllIlllll(llIIlIllll[llIIllIlII[329]], llIIlIllll[llIIllIlII[330]]);
    lIlIIlll[lIlIlIII[llIIllIlII[159]]] = lllIlllll(llIIlIllll[llIIllIlII[331]], llIIlIllll[llIIllIlII[332]]);
    lIlIIlll[lIlIlIII[llIIllIlII[141]]] = lllIlllll(llIIlIllll[llIIllIlII[333]], llIIlIllll[llIIllIlII[334]]);
    lIlIIlll[lIlIlIII[llIIllIlII[160]]] = lllIllllI(llIIlIllll[llIIllIlII[335]], llIIlIllll[llIIllIlII[336]]);
    lIlIIlll[lIlIlIII[llIIllIlII[128]]] = lllIllllI(llIIlIllll[llIIllIlII[337]], llIIlIllll[llIIllIlII[338]]);
    lIlIIlll[lIlIlIII[llIIllIlII[161]]] = lllIlllll(llIIlIllll[llIIllIlII[339]], llIIlIllll[llIIllIlII[340]]);
    lIlIIlll[lIlIlIII[llIIllIlII[162]]] = lllIllllI(llIIlIllll[llIIllIlII[341]], llIIlIllll[llIIllIlII[342]]);
    lIlIIlll[lIlIlIII[llIIllIlII[163]]] = lllIlllll(llIIlIllll[llIIllIlII[343]], llIIlIllll[llIIllIlII[344]]);
    lIlIIlll[lIlIlIII[llIIllIlII[164]]] = lllIlllll(llIIlIllll[llIIllIlII[345]], llIIlIllll[llIIllIlII[346]]);
    lIlIIlll[lIlIlIII[llIIllIlII[165]]] = lllIllllI(llIIlIllll[llIIllIlII[347]], llIIlIllll[llIIllIlII[348]]);
    lIlIIlll[lIlIlIII[llIIllIlII[166]]] = lllIlllll(llIIlIllll[llIIllIlII[349]], llIIlIllll[llIIllIlII[350]]);
    lIlIIlll[lIlIlIII[llIIllIlII[167]]] = lllIlllIl(llIIlIllll[llIIllIlII[351]], llIIlIllll[llIIllIlII[352]]);
    lIlIIlll[lIlIlIII[llIIllIlII[168]]] = lllIlllIl(llIIlIllll[llIIllIlII[353]], llIIlIllll[llIIllIlII[354]]);
    lIlIIlll[lIlIlIII[llIIllIlII[169]]] = lllIlllIl(llIIlIllll[llIIllIlII[355]], llIIlIllll[llIIllIlII[356]]);
    lIlIIlll[lIlIlIII[llIIllIlII[170]]] = lllIlllIl(llIIlIllll[llIIllIlII[357]], llIIlIllll[llIIllIlII[358]]);
    lIlIIlll[lIlIlIII[llIIllIlII[171]]] = lllIlllll(llIIlIllll[llIIllIlII[359]], llIIlIllll[llIIllIlII[360]]);
    lIlIIlll[lIlIlIII[llIIllIlII[125]]] = lllIllllI(llIIlIllll[llIIllIlII[361]], llIIlIllll[llIIllIlII[362]]);
    lIlIIlll[lIlIlIII[llIIllIlII[172]]] = lllIlllIl(llIIlIllll[llIIllIlII[363]], llIIlIllll[llIIllIlII[364]]);
    lIlIIlll[lIlIlIII[llIIllIlII[173]]] = lllIlllll(llIIlIllll[llIIllIlII[365]], llIIlIllll[llIIllIlII[366]]);
    lIlIIlll[lIlIlIII[llIIllIlII[174]]] = lllIlllIl(llIIlIllll[llIIllIlII[367]], llIIlIllll[llIIllIlII[368]]);
    lIlIIlll[lIlIlIII[llIIllIlII[175]]] = lllIllllI(llIIlIllll[llIIllIlII[369]], llIIlIllll[llIIllIlII[370]]);
    lIlIIlll[lIlIlIII[llIIllIlII[176]]] = lllIlllIl(llIIlIllll[llIIllIlII[371]], llIIlIllll[llIIllIlII[372]]);
    lIlIIlll[lIlIlIII[llIIllIlII[177]]] = lllIlllIl(llIIlIllll[llIIllIlII[373]], llIIlIllll[llIIllIlII[374]]);
    lIlIIlll[lIlIlIII[llIIllIlII[127]]] = lllIlllll(llIIlIllll[llIIllIlII[375]], llIIlIllll[llIIllIlII[376]]);
    lIlIIlll[lIlIlIII[llIIllIlII[183]]] = lllIlllll(llIIlIllll[llIIllIlII[377]], llIIlIllll[llIIllIlII[378]]);
    lIlIIlll[lIlIlIII[llIIllIlII[184]]] = lllIlllll(llIIlIllll[llIIllIlII[379]], llIIlIllll[llIIllIlII[380]]);
    lIlIIlll[lIlIlIII[llIIllIlII[178]]] = lllIlllIl(llIIlIllll[llIIllIlII[381]], llIIlIllll[llIIllIlII[382]]);
    lIlIIlll[lIlIlIII[llIIllIlII[185]]] = lllIlllll(llIIlIllll[llIIllIlII[383]], llIIlIllll[llIIllIlII[384]]);
    lIlIIlll[lIlIlIII[llIIllIlII[186]]] = lllIlllll(llIIlIllll[llIIllIlII[385]], llIIlIllll[llIIllIlII[386]]);
    lIlIIlll[lIlIlIII[llIIllIlII[187]]] = lllIllllI(llIIlIllll[llIIllIlII[387]], llIIlIllll[llIIllIlII[388]]);
    lIlIIlll[lIlIlIII[llIIllIlII[188]]] = lllIlllIl(llIIlIllll[llIIllIlII[389]], llIIlIllll[llIIllIlII[390]]);
    lIlIIlll[lIlIlIII[llIIllIlII[190]]] = lllIllllI(llIIlIllll[llIIllIlII[391]], llIIlIllll[llIIllIlII[392]]);
    lIlIIlll[lIlIlIII[llIIllIlII[191]]] = lllIllllI(llIIlIllll[llIIllIlII[393]], llIIlIllll[llIIllIlII[394]]);
    lIlIIlll[lIlIlIII[llIIllIlII[181]]] = lllIllllI(llIIlIllll[llIIllIlII[395]], llIIlIllll[llIIllIlII[396]]);
    lIlIIlll[lIlIlIII[llIIllIlII[193]]] = lllIllllI(llIIlIllll[llIIllIlII[397]], llIIlIllll[llIIllIlII[398]]);
    lIlIIlll[lIlIlIII[llIIllIlII[194]]] = lllIllllI(llIIlIllll[llIIllIlII[399]], llIIlIllll[llIIllIlII[400]]);
  }
  
  private static boolean llllIIIll(String llllllllllllllllIlIlllIIIlIIIIIl) {
    if (lllIllllllll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (" ".length() >= (0x10 ^ 0x14))
        return (0x5C ^ 0x13) & (0xF9 ^ 0xB6 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIIllIlII[3];
  }
  
  private static boolean lllIllllllll(String llllllllllllllllIlIllIlllIIlIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean llllIIlII(Exception llllllllllllllllIlIlllIIlIlIlIll, boolean llllllllllllllllIlIlllIIlIlIlIlI) {
    if (llllIIIIlIlI(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (-(0x14 ^ 0x11) >= 0)
        return " ".length() & (" ".length() ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIIllIlII[3];
  }
  
  private static boolean lllIlllllIll(long llllllllllllllllIlIllIlllIIIlllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < null);
  }
  
  private static String lIlIllllIllI(Exception llllllllllllllllIlIllIlllIlllllI, String llllllllllllllllIlIllIlllIllllll) {
    try {
      SecretKeySpec llllllllllllllllIlIllIllllIIIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIllIlllIllllll.getBytes(StandardCharsets.UTF_8)), llIIllIlII[8]), "DES");
      Cipher llllllllllllllllIlIllIllllIIIIlI = Cipher.getInstance("DES");
      llllllllllllllllIlIllIllllIIIIlI.init(llIIllIlII[1], llllllllllllllllIlIllIllllIIIIll);
      return new String(llllllllllllllllIlIllIllllIIIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllIlIllIlllIlllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception llllllllllllllllIlIllIllllIIIIIl) {
      llllllllllllllllIlIllIllllIIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static boolean lllIllllIlIl(String llllllllllllllllIlIllIlllIlIlIll, int llllllllllllllllIlIllIlllIlIlIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  static {
    lllIllllIIIl();
    lIllIIIIllIl();
    llllIIIIl();
    llllIIIII();
  }
  
  @NotNull
  public String getIdentifier() {
    return lIlIIlll[lIlIlIII[llIIllIlII[3]]];
  }
  
  private static String lIlIllllIlll(long llllllllllllllllIlIllIlllIllIIIl, char llllllllllllllllIlIllIlllIlIllll) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc_w 'Blowfish'
    //   22: invokespecial <init> : ([BLjava/lang/String;)V
    //   25: astore_2
    //   26: ldc_w 'Blowfish'
    //   29: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   32: astore_3
    //   33: aload_3
    //   34: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   37: iconst_1
    //   38: iaload
    //   39: aload_2
    //   40: invokevirtual init : (ILjava/security/Key;)V
    //   43: new java/lang/String
    //   46: dup
    //   47: aload_3
    //   48: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   51: aload_0
    //   52: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   55: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   58: invokevirtual decode : ([B)[B
    //   61: invokevirtual doFinal : ([B)[B
    //   64: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   67: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   70: areturn
    //   71: astore_2
    //   72: aload_2
    //   73: invokevirtual printStackTrace : ()V
    //   76: aconst_null
    //   77: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	78	1	llllllllllllllllIlIllIlllIllIIII	B
    //   72	4	2	llllllllllllllllIlIllIlllIllIlII	Ljava/lang/Exception;
    //   0	78	3	llllllllllllllllIlIllIlllIlIlllI	B
    //   26	45	2	llllllllllllllllIlIllIlllIllIllI	Ljavax/crypto/spec/SecretKeySpec;
    //   0	78	0	llllllllllllllllIlIllIlllIllIIll	Ljava/lang/String;
    //   0	78	1	llllllllllllllllIlIllIlllIllIIlI	Ljava/lang/String;
    //   0	78	0	llllllllllllllllIlIllIlllIllIIIl	J
    //   33	38	3	llllllllllllllllIlIllIlllIllIlIl	Ljavax/crypto/Cipher;
    //   0	78	2	llllllllllllllllIlIllIlllIlIllll	C
    // Exception table:
    //   from	to	target	type
    //   0	70	71	java/lang/Exception
  }
  
  private static String lllIlllIl(String llllllllllllllllIlIlllIIlIlIIIII, Exception llllllllllllllllIlIlllIIlIIlIIII) {
    String str = new String(Base64.getDecoder().decode(llllllllllllllllIlIlllIIlIlIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlIlllIIlIIlIlIl = new StringBuilder();
    char[] llllllllllllllllIlIlllIIlIIllIll = llllllllllllllllIlIlllIIlIIlIIII.toCharArray();
    int llllllllllllllllIlIlllIIlIIllIII = lIlIlIII[llIIllIlII[3]];
    char[] arrayOfChar1 = str.toCharArray();
    llllllllllllllllIlIlllIIlIIIlIll = arrayOfChar1.length;
    int i = lIlIlIII[llIIllIlII[3]];
    while (lllIllllIlII(llllIIlIl(i, llllllllllllllllIlIlllIIlIIIlIll))) {
      char llllllllllllllllIlIlllIIlIIllllI = arrayOfChar1[i];
      llIIlIllll[llIIllIlII[401]].length();
      llllllllllllllllIlIlllIIlIIllIII++;
      i++;
      "".length();
      if (llllIIIIlIlI(llIIlIllll[llIIllIlII[403]].length(), llIIlIllll[llIIllIlII[404]].length()))
        return null; 
    } 
    return String.valueOf(llllllllllllllllIlIlllIIlIIlIlIl);
  }
  
  private static String lIlIllllIlIl(String llllllllllllllllIlIllIllllIlIlIl, String llllllllllllllllIlIllIllllIlIlII) {
    llllllllllllllllIlIllIllllIlIIII = new String(Base64.getDecoder().decode(llllllllllllllllIlIllIllllIlIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlIllIllllIlIIll = new StringBuilder();
    char[] llllllllllllllllIlIllIllllIlIIlI = llllllllllllllllIlIllIllllIlIlII.toCharArray();
    int llllllllllllllllIlIllIllllIlIIIl = llIIllIlII[3];
    char[] arrayOfChar1 = llllllllllllllllIlIllIllllIlIIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIllIlII[3];
    while (lllIllllIllI(j, i)) {
      char llllllllllllllllIlIllIllllIlIllI = arrayOfChar1[j];
      "".length();
      llllllllllllllllIlIllIllllIlIIIl++;
      j++;
      "".length();
      if (-" ".length() >= " ".length())
        return null; 
    } 
    return String.valueOf(llllllllllllllllIlIllIllllIlIIll);
  }
  
  private static boolean llllIIlIl(int llllllllllllllllIlIlllIIIlllIIll, Exception llllllllllllllllIlIlllIIIlllIlIl) {
    if (lllIllllIllI(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (((0x15 ^ 0x7) & (0x9 ^ 0x1B ^ 0xFFFFFFFF)) <= -" ".length())
        return (0x29 ^ 0x48) & (0x27 ^ 0x46 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIIllIlII[3];
  }
  
  @NotNull
  public String getVersion() {
    // Byte code:
    //   0: aload_0
    //   1: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4: invokevirtual getDescription : ()Lorg/bukkit/plugin/PluginDescriptionFile;
    //   7: invokevirtual getVersion : ()Ljava/lang/String;
    //   10: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	11	0	llllllllllllllllIlIllIlllllIIlIl	Lcom/axeelheaven/hbedwars/api/hooks/PlaceholderHook;
    //   0	11	0	llllllllllllllllIlIllIlllllIIlII	B
    //   0	11	0	llllllllllllllllIlIllIlllllIIIll	Ljava/lang/String;
  }
  
  public String onPlaceholderRequest(Exception llllllllllllllllIlIlllIIllIlllll, @NotNull float llllllllllllllllIlIlllIIllIlllIl) {
    // Byte code:
    //   0: aload_0
    //   1: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4: invokevirtual getGameManager : ()Lcom/axeelheaven/hbedwars/GameManager;
    //   7: aload_1
    //   8: invokeinterface getUniqueId : ()Ljava/util/UUID;
    //   13: invokevirtual getData : (Ljava/util/UUID;)Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   16: astore_3
    //   17: aload_2
    //   18: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   21: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   24: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   27: iconst_0
    //   28: iaload
    //   29: iaload
    //   30: aaload
    //   31: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   34: invokestatic llllIIIlI : (I)Z
    //   37: invokestatic lllIllllIlII : (I)Z
    //   40: ifeq -> 380
    //   43: aload_0
    //   44: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   47: invokevirtual getGroupManager : ()Lcom/axeelheaven/hbedwars/arena/groups/GroupManager;
    //   50: aload_2
    //   51: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   54: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   57: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   60: iconst_1
    //   61: iaload
    //   62: iaload
    //   63: aaload
    //   64: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   67: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   70: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   73: iconst_2
    //   74: iaload
    //   75: iaload
    //   76: aaload
    //   77: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   80: invokevirtual getGroup : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/arena/groups/Group;
    //   83: astore #4
    //   85: aload #4
    //   87: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   90: invokestatic lllIllllIlII : (I)Z
    //   93: ifeq -> 380
    //   96: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   99: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   102: iconst_3
    //   103: iaload
    //   104: iaload
    //   105: istore #5
    //   107: new java/util/ArrayList
    //   110: dup
    //   111: invokespecial <init> : ()V
    //   114: astore #6
    //   116: aload_0
    //   117: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   120: invokevirtual getBungeeMode : ()Lcom/axeelheaven/hbedwars/bungeemode/BungeeMode;
    //   123: getstatic com/axeelheaven/hbedwars/bungeemode/BungeeMode.BUNGEELOBBY : Lcom/axeelheaven/hbedwars/bungeemode/BungeeMode;
    //   126: invokevirtual equals : (Ljava/lang/Object;)Z
    //   129: invokestatic llllIIIlI : (I)Z
    //   132: invokestatic lllIllllIlII : (I)Z
    //   135: ifeq -> 213
    //   138: aload_0
    //   139: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   142: invokevirtual getLobbyManager : ()Lcom/axeelheaven/hbedwars/bungeemode/lobby/LobbyManager;
    //   145: invokevirtual getServers : ()Ljava/util/HashMap;
    //   148: invokevirtual values : ()Ljava/util/Collection;
    //   151: aload #6
    //   153: <illegal opcode> accept : (Ljava/util/Collection;)Ljava/util/function/Consumer;
    //   158: invokeinterface forEach : (Ljava/util/function/Consumer;)V
    //   163: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   166: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   169: iconst_3
    //   170: iaload
    //   171: aaload
    //   172: invokevirtual length : ()I
    //   175: ldc ''
    //   177: invokevirtual length : ()I
    //   180: pop2
    //   181: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   184: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   187: iconst_0
    //   188: iaload
    //   189: aaload
    //   190: invokevirtual length : ()I
    //   193: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   196: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   199: iconst_1
    //   200: iaload
    //   201: aaload
    //   202: invokevirtual length : ()I
    //   205: invokestatic lllIllllIlIl : (II)Z
    //   208: ifeq -> 238
    //   211: aconst_null
    //   212: areturn
    //   213: aload_0
    //   214: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   217: invokevirtual getArenaManager : ()Lcom/axeelheaven/hbedwars/arena/ArenaManager;
    //   220: invokevirtual getGames : ()Ljava/util/HashMap;
    //   223: invokevirtual values : ()Ljava/util/Collection;
    //   226: aload #6
    //   228: <illegal opcode> accept : (Ljava/util/Collection;)Ljava/util/function/Consumer;
    //   233: invokeinterface forEach : (Ljava/util/function/Consumer;)V
    //   238: aload #6
    //   240: aload #4
    //   242: <illegal opcode> test : (Lcom/axeelheaven/hbedwars/arena/groups/Group;)Ljava/util/function/Predicate;
    //   247: invokeinterface removeIf : (Ljava/util/function/Predicate;)Z
    //   252: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   255: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   258: iconst_2
    //   259: iaload
    //   260: aaload
    //   261: invokevirtual length : ()I
    //   264: pop2
    //   265: aload #6
    //   267: invokeinterface iterator : ()Ljava/util/Iterator;
    //   272: astore #7
    //   274: aload #7
    //   276: invokeinterface hasNext : ()Z
    //   281: invokestatic llllIIIlI : (I)Z
    //   284: invokestatic lllIllllIlII : (I)Z
    //   287: ifeq -> 363
    //   290: aload #7
    //   292: invokeinterface next : ()Ljava/lang/Object;
    //   297: checkcast com/axeelheaven/hbedwars/api/arena/ArenaData
    //   300: astore #8
    //   302: iload #5
    //   304: aload #8
    //   306: invokevirtual getPlayers : ()I
    //   309: iadd
    //   310: istore #5
    //   312: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   315: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   318: iconst_4
    //   319: iaload
    //   320: aaload
    //   321: invokevirtual length : ()I
    //   324: ldc ''
    //   326: invokevirtual length : ()I
    //   329: pop2
    //   330: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   333: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   336: iconst_5
    //   337: iaload
    //   338: aaload
    //   339: invokevirtual length : ()I
    //   342: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   345: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   348: bipush #6
    //   350: iaload
    //   351: aaload
    //   352: invokevirtual length : ()I
    //   355: invokestatic lllIllllIllI : (II)Z
    //   358: ifeq -> 274
    //   361: aconst_null
    //   362: areturn
    //   363: aload_0
    //   364: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   367: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   370: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   373: iload #5
    //   375: i2l
    //   376: invokevirtual format : (J)Ljava/lang/String;
    //   379: areturn
    //   380: aload_3
    //   381: invokevirtual getArena : ()Lcom/axeelheaven/hbedwars/api/arena/Arena;
    //   384: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   387: invokestatic lllIllllIlII : (I)Z
    //   390: ifeq -> 531
    //   393: aload_2
    //   394: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   397: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   400: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   403: iconst_4
    //   404: iaload
    //   405: iaload
    //   406: aaload
    //   407: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   410: invokestatic llllIIIlI : (I)Z
    //   413: invokestatic lllIllllIlII : (I)Z
    //   416: ifeq -> 427
    //   419: aload_3
    //   420: invokevirtual getGameFinalKills : ()I
    //   423: invokestatic valueOf : (I)Ljava/lang/String;
    //   426: areturn
    //   427: aload_2
    //   428: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   431: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   434: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   437: iconst_5
    //   438: iaload
    //   439: iaload
    //   440: aaload
    //   441: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   444: invokestatic llllIIIlI : (I)Z
    //   447: invokestatic lllIllllIlII : (I)Z
    //   450: ifeq -> 461
    //   453: aload_3
    //   454: invokevirtual getGameKills : ()I
    //   457: invokestatic valueOf : (I)Ljava/lang/String;
    //   460: areturn
    //   461: aload_2
    //   462: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   465: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   468: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   471: bipush #6
    //   473: iaload
    //   474: iaload
    //   475: aaload
    //   476: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   479: invokestatic llllIIIlI : (I)Z
    //   482: invokestatic lllIllllIlII : (I)Z
    //   485: ifeq -> 496
    //   488: aload_3
    //   489: invokevirtual getGameDeaths : ()I
    //   492: invokestatic valueOf : (I)Ljava/lang/String;
    //   495: areturn
    //   496: aload_2
    //   497: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   500: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   503: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   506: bipush #7
    //   508: iaload
    //   509: iaload
    //   510: aaload
    //   511: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   514: invokestatic llllIIIlI : (I)Z
    //   517: invokestatic lllIllllIlII : (I)Z
    //   520: ifeq -> 531
    //   523: aload_3
    //   524: invokevirtual getGameBeds : ()I
    //   527: invokestatic valueOf : (I)Ljava/lang/String;
    //   530: areturn
    //   531: aload_2
    //   532: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   535: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   538: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   541: bipush #8
    //   543: iaload
    //   544: iaload
    //   545: aaload
    //   546: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   549: invokestatic llllIIIlI : (I)Z
    //   552: invokestatic lllIllllIlII : (I)Z
    //   555: ifeq -> 577
    //   558: aload_0
    //   559: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   562: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   565: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   568: aload_3
    //   569: invokevirtual getLevel : ()I
    //   572: i2l
    //   573: invokevirtual format : (J)Ljava/lang/String;
    //   576: areturn
    //   577: aload_2
    //   578: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   581: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   584: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   587: bipush #9
    //   589: iaload
    //   590: iaload
    //   591: aaload
    //   592: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   595: invokestatic llllIIIlI : (I)Z
    //   598: invokestatic lllIllllIlII : (I)Z
    //   601: ifeq -> 641
    //   604: aload_0
    //   605: aload_3
    //   606: invokevirtual getLevel : ()I
    //   609: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   612: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   615: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   618: bipush #10
    //   620: iaload
    //   621: iaload
    //   622: aaload
    //   623: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   626: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   629: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   632: bipush #11
    //   634: iaload
    //   635: iaload
    //   636: aaload
    //   637: invokespecial getLevelFormat : (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   640: areturn
    //   641: aload_2
    //   642: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   645: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   648: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   651: bipush #12
    //   653: iaload
    //   654: iaload
    //   655: aaload
    //   656: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   659: invokestatic llllIIIlI : (I)Z
    //   662: invokestatic lllIllllIlII : (I)Z
    //   665: ifeq -> 705
    //   668: aload_0
    //   669: aload_3
    //   670: invokevirtual getLevel : ()I
    //   673: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   676: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   679: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   682: bipush #13
    //   684: iaload
    //   685: iaload
    //   686: aaload
    //   687: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   690: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   693: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   696: bipush #14
    //   698: iaload
    //   699: iaload
    //   700: aaload
    //   701: invokespecial getLevelFormat : (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   704: areturn
    //   705: aload_2
    //   706: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   709: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   712: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   715: bipush #15
    //   717: iaload
    //   718: iaload
    //   719: aaload
    //   720: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   723: invokestatic llllIIIlI : (I)Z
    //   726: invokestatic lllIllllIlII : (I)Z
    //   729: ifeq -> 748
    //   732: aload_0
    //   733: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   736: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   739: aload_3
    //   740: invokevirtual getExperience : ()D
    //   743: d2i
    //   744: invokevirtual roundingK : (I)Ljava/lang/String;
    //   747: areturn
    //   748: aload_2
    //   749: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   752: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   755: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   758: bipush #16
    //   760: iaload
    //   761: iaload
    //   762: aaload
    //   763: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   766: invokestatic llllIIIlI : (I)Z
    //   769: invokestatic lllIllllIlII : (I)Z
    //   772: ifeq -> 791
    //   775: aload_0
    //   776: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   779: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   782: aload_3
    //   783: invokevirtual getExperienceToNextLevel : ()D
    //   786: d2i
    //   787: invokevirtual roundingK : (I)Ljava/lang/String;
    //   790: areturn
    //   791: aload_2
    //   792: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   795: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   798: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   801: bipush #17
    //   803: iaload
    //   804: iaload
    //   805: aaload
    //   806: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   809: invokestatic llllIIIlI : (I)Z
    //   812: invokestatic lllIllllIlII : (I)Z
    //   815: ifeq -> 860
    //   818: aload_0
    //   819: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   822: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   825: aload_3
    //   826: invokevirtual getLanguage : ()Ljava/lang/String;
    //   829: aload_3
    //   830: invokevirtual getExperience : ()D
    //   833: aload_3
    //   834: invokevirtual getExperienceToNextLevel : ()D
    //   837: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   840: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   843: iconst_3
    //   844: iaload
    //   845: iaload
    //   846: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   849: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   852: bipush #10
    //   854: iaload
    //   855: iaload
    //   856: invokevirtual getProgressBar : (Ljava/lang/String;DDZI)Ljava/lang/String;
    //   859: areturn
    //   860: aload_2
    //   861: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   864: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   867: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   870: bipush #18
    //   872: iaload
    //   873: iaload
    //   874: aaload
    //   875: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   878: invokestatic llllIIIlI : (I)Z
    //   881: invokestatic lllIllllIlII : (I)Z
    //   884: ifeq -> 892
    //   887: aload_3
    //   888: invokevirtual getLanguage : ()Ljava/lang/String;
    //   891: areturn
    //   892: aload_2
    //   893: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   896: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   899: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   902: bipush #19
    //   904: iaload
    //   905: iaload
    //   906: aaload
    //   907: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   910: invokestatic llllIIIlI : (I)Z
    //   913: invokestatic lllIllllIlII : (I)Z
    //   916: ifeq -> 935
    //   919: aload_0
    //   920: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   923: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   926: aload_3
    //   927: invokevirtual getPoints : ()D
    //   930: d2i
    //   931: invokevirtual roundingK : (I)Ljava/lang/String;
    //   934: areturn
    //   935: aload_2
    //   936: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   939: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   942: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   945: bipush #20
    //   947: iaload
    //   948: iaload
    //   949: aaload
    //   950: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   953: invokestatic llllIIIlI : (I)Z
    //   956: invokestatic lllIllllIlII : (I)Z
    //   959: ifeq -> 971
    //   962: aload_3
    //   963: invokevirtual getPoints : ()D
    //   966: d2i
    //   967: invokestatic valueOf : (I)Ljava/lang/String;
    //   970: areturn
    //   971: aload_2
    //   972: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   975: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   978: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   981: bipush #21
    //   983: iaload
    //   984: iaload
    //   985: aaload
    //   986: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   989: invokestatic llllIIIlI : (I)Z
    //   992: invokestatic lllIllllIlII : (I)Z
    //   995: ifeq -> 1030
    //   998: aload_0
    //   999: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1002: invokevirtual getDescription : ()Lorg/bukkit/plugin/PluginDescriptionFile;
    //   1005: invokevirtual getVersion : ()Ljava/lang/String;
    //   1008: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1011: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1014: iconst_3
    //   1015: iaload
    //   1016: iaload
    //   1017: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1020: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1023: iconst_2
    //   1024: iaload
    //   1025: iaload
    //   1026: invokevirtual substring : (II)Ljava/lang/String;
    //   1029: areturn
    //   1030: aload_2
    //   1031: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1034: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1037: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1040: bipush #22
    //   1042: iaload
    //   1043: iaload
    //   1044: aaload
    //   1045: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   1048: invokestatic llllIIIlI : (I)Z
    //   1051: invokestatic lllIllllIlII : (I)Z
    //   1054: ifeq -> 1177
    //   1057: aload_2
    //   1058: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1061: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1064: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1067: bipush #23
    //   1069: iaload
    //   1070: iaload
    //   1071: aaload
    //   1072: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1075: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1078: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1081: bipush #24
    //   1083: iaload
    //   1084: iaload
    //   1085: aaload
    //   1086: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   1089: astore #4
    //   1091: aload #4
    //   1093: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1096: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1099: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1102: bipush #25
    //   1104: iaload
    //   1105: iaload
    //   1106: aaload
    //   1107: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1110: invokestatic llllIIIlI : (I)Z
    //   1113: invokestatic lllIllllIlII : (I)Z
    //   1116: ifeq -> 1138
    //   1119: aload_0
    //   1120: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1123: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1126: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1129: aload_3
    //   1130: invokevirtual getTotalGamesPlayed : ()I
    //   1133: i2l
    //   1134: invokevirtual format : (J)Ljava/lang/String;
    //   1137: areturn
    //   1138: aload_3
    //   1139: aload #4
    //   1141: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   1144: astore #5
    //   1146: aload #5
    //   1148: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   1151: invokestatic lllIllllIlII : (I)Z
    //   1154: ifeq -> 1177
    //   1157: aload_0
    //   1158: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1161: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1164: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1167: aload #5
    //   1169: invokevirtual getGamesPlayed : ()I
    //   1172: i2l
    //   1173: invokevirtual format : (J)Ljava/lang/String;
    //   1176: areturn
    //   1177: aload_2
    //   1178: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1181: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1184: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1187: bipush #26
    //   1189: iaload
    //   1190: iaload
    //   1191: aaload
    //   1192: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   1195: invokestatic llllIIIlI : (I)Z
    //   1198: invokestatic lllIllllIlII : (I)Z
    //   1201: ifeq -> 1324
    //   1204: aload_2
    //   1205: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1208: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1211: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1214: bipush #27
    //   1216: iaload
    //   1217: iaload
    //   1218: aaload
    //   1219: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1222: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1225: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1228: bipush #28
    //   1230: iaload
    //   1231: iaload
    //   1232: aaload
    //   1233: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   1236: astore #4
    //   1238: aload #4
    //   1240: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1243: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1246: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1249: bipush #29
    //   1251: iaload
    //   1252: iaload
    //   1253: aaload
    //   1254: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1257: invokestatic llllIIIlI : (I)Z
    //   1260: invokestatic lllIllllIlII : (I)Z
    //   1263: ifeq -> 1285
    //   1266: aload_0
    //   1267: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1270: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1273: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1276: aload_3
    //   1277: invokevirtual getTotalFinalKills : ()I
    //   1280: i2l
    //   1281: invokevirtual format : (J)Ljava/lang/String;
    //   1284: areturn
    //   1285: aload_3
    //   1286: aload #4
    //   1288: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   1291: astore #5
    //   1293: aload #5
    //   1295: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   1298: invokestatic lllIllllIlII : (I)Z
    //   1301: ifeq -> 1324
    //   1304: aload_0
    //   1305: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1308: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1311: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1314: aload #5
    //   1316: invokevirtual getFinalKills : ()I
    //   1319: i2l
    //   1320: invokevirtual format : (J)Ljava/lang/String;
    //   1323: areturn
    //   1324: aload_2
    //   1325: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1328: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1331: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1334: bipush #30
    //   1336: iaload
    //   1337: iaload
    //   1338: aaload
    //   1339: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   1342: invokestatic llllIIIlI : (I)Z
    //   1345: invokestatic lllIllllIlII : (I)Z
    //   1348: ifeq -> 1471
    //   1351: aload_2
    //   1352: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1355: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1358: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1361: bipush #31
    //   1363: iaload
    //   1364: iaload
    //   1365: aaload
    //   1366: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1369: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1372: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1375: bipush #32
    //   1377: iaload
    //   1378: iaload
    //   1379: aaload
    //   1380: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   1383: astore #4
    //   1385: aload #4
    //   1387: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1390: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1393: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1396: bipush #33
    //   1398: iaload
    //   1399: iaload
    //   1400: aaload
    //   1401: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1404: invokestatic llllIIIlI : (I)Z
    //   1407: invokestatic lllIllllIlII : (I)Z
    //   1410: ifeq -> 1432
    //   1413: aload_0
    //   1414: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1417: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1420: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1423: aload_3
    //   1424: invokevirtual getTotalKills : ()I
    //   1427: i2l
    //   1428: invokevirtual format : (J)Ljava/lang/String;
    //   1431: areturn
    //   1432: aload_3
    //   1433: aload #4
    //   1435: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   1438: astore #5
    //   1440: aload #5
    //   1442: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   1445: invokestatic lllIllllIlII : (I)Z
    //   1448: ifeq -> 1471
    //   1451: aload_0
    //   1452: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1455: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1458: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1461: aload #5
    //   1463: invokevirtual getKills : ()I
    //   1466: i2l
    //   1467: invokevirtual format : (J)Ljava/lang/String;
    //   1470: areturn
    //   1471: aload_2
    //   1472: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1475: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1478: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1481: bipush #34
    //   1483: iaload
    //   1484: iaload
    //   1485: aaload
    //   1486: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   1489: invokestatic llllIIIlI : (I)Z
    //   1492: invokestatic lllIllllIlII : (I)Z
    //   1495: ifeq -> 1618
    //   1498: aload_2
    //   1499: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1502: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1505: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1508: bipush #35
    //   1510: iaload
    //   1511: iaload
    //   1512: aaload
    //   1513: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1516: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1519: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1522: bipush #36
    //   1524: iaload
    //   1525: iaload
    //   1526: aaload
    //   1527: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   1530: astore #4
    //   1532: aload #4
    //   1534: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1537: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1540: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1543: bipush #37
    //   1545: iaload
    //   1546: iaload
    //   1547: aaload
    //   1548: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1551: invokestatic llllIIIlI : (I)Z
    //   1554: invokestatic lllIllllIlII : (I)Z
    //   1557: ifeq -> 1579
    //   1560: aload_0
    //   1561: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1564: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1567: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1570: aload_3
    //   1571: invokevirtual getTotalFinalDeaths : ()I
    //   1574: i2l
    //   1575: invokevirtual format : (J)Ljava/lang/String;
    //   1578: areturn
    //   1579: aload_3
    //   1580: aload #4
    //   1582: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   1585: astore #5
    //   1587: aload #5
    //   1589: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   1592: invokestatic lllIllllIlII : (I)Z
    //   1595: ifeq -> 1618
    //   1598: aload_0
    //   1599: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1602: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1605: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1608: aload #5
    //   1610: invokevirtual getFinalDeaths : ()I
    //   1613: i2l
    //   1614: invokevirtual format : (J)Ljava/lang/String;
    //   1617: areturn
    //   1618: aload_2
    //   1619: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1622: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1625: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1628: bipush #38
    //   1630: iaload
    //   1631: iaload
    //   1632: aaload
    //   1633: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   1636: invokestatic llllIIIlI : (I)Z
    //   1639: invokestatic lllIllllIlII : (I)Z
    //   1642: ifeq -> 1765
    //   1645: aload_2
    //   1646: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1649: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1652: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1655: bipush #39
    //   1657: iaload
    //   1658: iaload
    //   1659: aaload
    //   1660: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1663: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1666: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1669: bipush #40
    //   1671: iaload
    //   1672: iaload
    //   1673: aaload
    //   1674: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   1677: astore #4
    //   1679: aload #4
    //   1681: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1684: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1687: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1690: bipush #41
    //   1692: iaload
    //   1693: iaload
    //   1694: aaload
    //   1695: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1698: invokestatic llllIIIlI : (I)Z
    //   1701: invokestatic lllIllllIlII : (I)Z
    //   1704: ifeq -> 1726
    //   1707: aload_0
    //   1708: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1711: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1714: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1717: aload_3
    //   1718: invokevirtual getTotalDeaths : ()I
    //   1721: i2l
    //   1722: invokevirtual format : (J)Ljava/lang/String;
    //   1725: areturn
    //   1726: aload_3
    //   1727: aload #4
    //   1729: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   1732: astore #5
    //   1734: aload #5
    //   1736: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   1739: invokestatic lllIllllIlII : (I)Z
    //   1742: ifeq -> 1765
    //   1745: aload_0
    //   1746: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1749: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1752: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1755: aload #5
    //   1757: invokevirtual getDeaths : ()I
    //   1760: i2l
    //   1761: invokevirtual format : (J)Ljava/lang/String;
    //   1764: areturn
    //   1765: aload_2
    //   1766: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1769: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1772: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1775: bipush #42
    //   1777: iaload
    //   1778: iaload
    //   1779: aaload
    //   1780: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   1783: invokestatic llllIIIlI : (I)Z
    //   1786: invokestatic lllIllllIlII : (I)Z
    //   1789: ifeq -> 1912
    //   1792: aload_2
    //   1793: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1796: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1799: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1802: bipush #43
    //   1804: iaload
    //   1805: iaload
    //   1806: aaload
    //   1807: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1810: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1813: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1816: bipush #44
    //   1818: iaload
    //   1819: iaload
    //   1820: aaload
    //   1821: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   1824: astore #4
    //   1826: aload #4
    //   1828: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1831: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1834: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1837: bipush #45
    //   1839: iaload
    //   1840: iaload
    //   1841: aaload
    //   1842: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1845: invokestatic llllIIIlI : (I)Z
    //   1848: invokestatic lllIllllIlII : (I)Z
    //   1851: ifeq -> 1873
    //   1854: aload_0
    //   1855: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1858: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1861: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1864: aload_3
    //   1865: invokevirtual getTotalBedsBroken : ()I
    //   1868: i2l
    //   1869: invokevirtual format : (J)Ljava/lang/String;
    //   1872: areturn
    //   1873: aload_3
    //   1874: aload #4
    //   1876: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   1879: astore #5
    //   1881: aload #5
    //   1883: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   1886: invokestatic lllIllllIlII : (I)Z
    //   1889: ifeq -> 1912
    //   1892: aload_0
    //   1893: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   1896: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   1899: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   1902: aload #5
    //   1904: invokevirtual getBedsBroken : ()I
    //   1907: i2l
    //   1908: invokevirtual format : (J)Ljava/lang/String;
    //   1911: areturn
    //   1912: aload_2
    //   1913: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1916: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1919: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1922: bipush #46
    //   1924: iaload
    //   1925: iaload
    //   1926: aaload
    //   1927: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   1930: invokestatic llllIIIlI : (I)Z
    //   1933: invokestatic lllIllllIlII : (I)Z
    //   1936: ifeq -> 2059
    //   1939: aload_2
    //   1940: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1943: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1946: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1949: bipush #47
    //   1951: iaload
    //   1952: iaload
    //   1953: aaload
    //   1954: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1957: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1960: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1963: bipush #48
    //   1965: iaload
    //   1966: iaload
    //   1967: aaload
    //   1968: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   1971: astore #4
    //   1973: aload #4
    //   1975: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   1978: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   1981: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   1984: bipush #49
    //   1986: iaload
    //   1987: iaload
    //   1988: aaload
    //   1989: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1992: invokestatic llllIIIlI : (I)Z
    //   1995: invokestatic lllIllllIlII : (I)Z
    //   1998: ifeq -> 2020
    //   2001: aload_0
    //   2002: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2005: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2008: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2011: aload_3
    //   2012: invokevirtual getTotalBedsLost : ()I
    //   2015: i2l
    //   2016: invokevirtual format : (J)Ljava/lang/String;
    //   2019: areturn
    //   2020: aload_3
    //   2021: aload #4
    //   2023: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2026: astore #5
    //   2028: aload #5
    //   2030: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   2033: invokestatic lllIllllIlII : (I)Z
    //   2036: ifeq -> 2059
    //   2039: aload_0
    //   2040: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2043: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2046: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2049: aload #5
    //   2051: invokevirtual getBedsLost : ()I
    //   2054: i2l
    //   2055: invokevirtual format : (J)Ljava/lang/String;
    //   2058: areturn
    //   2059: aload_2
    //   2060: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2063: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2066: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2069: bipush #50
    //   2071: iaload
    //   2072: iaload
    //   2073: aaload
    //   2074: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   2077: invokestatic llllIIIlI : (I)Z
    //   2080: invokestatic lllIllllIlII : (I)Z
    //   2083: ifeq -> 2206
    //   2086: aload_2
    //   2087: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2090: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2093: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2096: bipush #51
    //   2098: iaload
    //   2099: iaload
    //   2100: aaload
    //   2101: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2104: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2107: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2110: bipush #52
    //   2112: iaload
    //   2113: iaload
    //   2114: aaload
    //   2115: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   2118: astore #4
    //   2120: aload #4
    //   2122: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2125: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2128: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2131: bipush #53
    //   2133: iaload
    //   2134: iaload
    //   2135: aaload
    //   2136: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   2139: invokestatic llllIIIlI : (I)Z
    //   2142: invokestatic lllIllllIlII : (I)Z
    //   2145: ifeq -> 2167
    //   2148: aload_0
    //   2149: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2152: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2155: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2158: aload_3
    //   2159: invokevirtual getTotalWins : ()I
    //   2162: i2l
    //   2163: invokevirtual format : (J)Ljava/lang/String;
    //   2166: areturn
    //   2167: aload_3
    //   2168: aload #4
    //   2170: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2173: astore #5
    //   2175: aload #5
    //   2177: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   2180: invokestatic lllIllllIlII : (I)Z
    //   2183: ifeq -> 2206
    //   2186: aload_0
    //   2187: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2190: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2193: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2196: aload #5
    //   2198: invokevirtual getWins : ()I
    //   2201: i2l
    //   2202: invokevirtual format : (J)Ljava/lang/String;
    //   2205: areturn
    //   2206: aload_2
    //   2207: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2210: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2213: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2216: bipush #54
    //   2218: iaload
    //   2219: iaload
    //   2220: aaload
    //   2221: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   2224: invokestatic llllIIIlI : (I)Z
    //   2227: invokestatic lllIllllIlII : (I)Z
    //   2230: ifeq -> 2353
    //   2233: aload_2
    //   2234: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2237: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2240: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2243: bipush #55
    //   2245: iaload
    //   2246: iaload
    //   2247: aaload
    //   2248: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2251: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2254: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2257: bipush #56
    //   2259: iaload
    //   2260: iaload
    //   2261: aaload
    //   2262: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   2265: astore #4
    //   2267: aload #4
    //   2269: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2272: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2275: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2278: bipush #57
    //   2280: iaload
    //   2281: iaload
    //   2282: aaload
    //   2283: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   2286: invokestatic llllIIIlI : (I)Z
    //   2289: invokestatic lllIllllIlII : (I)Z
    //   2292: ifeq -> 2314
    //   2295: aload_0
    //   2296: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2299: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2302: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2305: aload_3
    //   2306: invokevirtual getTotalWinSteak : ()I
    //   2309: i2l
    //   2310: invokevirtual format : (J)Ljava/lang/String;
    //   2313: areturn
    //   2314: aload_3
    //   2315: aload #4
    //   2317: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2320: astore #5
    //   2322: aload #5
    //   2324: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   2327: invokestatic lllIllllIlII : (I)Z
    //   2330: ifeq -> 2353
    //   2333: aload_0
    //   2334: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2337: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2340: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2343: aload #5
    //   2345: invokevirtual getWinSteak : ()I
    //   2348: i2l
    //   2349: invokevirtual format : (J)Ljava/lang/String;
    //   2352: areturn
    //   2353: aload_2
    //   2354: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2357: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2360: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2363: bipush #58
    //   2365: iaload
    //   2366: iaload
    //   2367: aaload
    //   2368: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   2371: invokestatic llllIIIlI : (I)Z
    //   2374: invokestatic lllIllllIlII : (I)Z
    //   2377: ifeq -> 2500
    //   2380: aload_2
    //   2381: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2384: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2387: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2390: bipush #59
    //   2392: iaload
    //   2393: iaload
    //   2394: aaload
    //   2395: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2398: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2401: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2404: bipush #60
    //   2406: iaload
    //   2407: iaload
    //   2408: aaload
    //   2409: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   2412: astore #4
    //   2414: aload #4
    //   2416: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2419: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2422: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2425: bipush #61
    //   2427: iaload
    //   2428: iaload
    //   2429: aaload
    //   2430: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   2433: invokestatic llllIIIlI : (I)Z
    //   2436: invokestatic lllIllllIlII : (I)Z
    //   2439: ifeq -> 2461
    //   2442: aload_0
    //   2443: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2446: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2449: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2452: aload_3
    //   2453: invokevirtual getTotalLosses : ()I
    //   2456: i2l
    //   2457: invokevirtual format : (J)Ljava/lang/String;
    //   2460: areturn
    //   2461: aload_3
    //   2462: aload #4
    //   2464: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2467: astore #5
    //   2469: aload #5
    //   2471: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   2474: invokestatic lllIllllIlII : (I)Z
    //   2477: ifeq -> 2500
    //   2480: aload_0
    //   2481: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2484: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2487: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2490: aload #5
    //   2492: invokevirtual getLosses : ()I
    //   2495: i2l
    //   2496: invokevirtual format : (J)Ljava/lang/String;
    //   2499: areturn
    //   2500: aload_2
    //   2501: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2504: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2507: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2510: bipush #62
    //   2512: iaload
    //   2513: iaload
    //   2514: aaload
    //   2515: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   2518: invokestatic llllIIIlI : (I)Z
    //   2521: invokestatic lllIllllIlII : (I)Z
    //   2524: ifeq -> 2647
    //   2527: aload_2
    //   2528: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2531: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2534: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2537: bipush #63
    //   2539: iaload
    //   2540: iaload
    //   2541: aaload
    //   2542: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2545: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2548: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2551: bipush #64
    //   2553: iaload
    //   2554: iaload
    //   2555: aaload
    //   2556: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   2559: astore #4
    //   2561: aload #4
    //   2563: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2566: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2569: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2572: bipush #65
    //   2574: iaload
    //   2575: iaload
    //   2576: aaload
    //   2577: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   2580: invokestatic llllIIIlI : (I)Z
    //   2583: invokestatic lllIllllIlII : (I)Z
    //   2586: ifeq -> 2608
    //   2589: aload_0
    //   2590: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2593: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2596: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2599: aload_3
    //   2600: invokevirtual getTotalBlocksBreak : ()I
    //   2603: i2l
    //   2604: invokevirtual format : (J)Ljava/lang/String;
    //   2607: areturn
    //   2608: aload_3
    //   2609: aload #4
    //   2611: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2614: astore #5
    //   2616: aload #5
    //   2618: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   2621: invokestatic lllIllllIlII : (I)Z
    //   2624: ifeq -> 2647
    //   2627: aload_0
    //   2628: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2631: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2634: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2637: aload #5
    //   2639: invokevirtual getBlockBreak : ()I
    //   2642: i2l
    //   2643: invokevirtual format : (J)Ljava/lang/String;
    //   2646: areturn
    //   2647: aload_2
    //   2648: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2651: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2654: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2657: bipush #66
    //   2659: iaload
    //   2660: iaload
    //   2661: aaload
    //   2662: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   2665: invokestatic llllIIIlI : (I)Z
    //   2668: invokestatic lllIllllIlII : (I)Z
    //   2671: ifeq -> 2794
    //   2674: aload_2
    //   2675: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2678: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2681: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2684: bipush #67
    //   2686: iaload
    //   2687: iaload
    //   2688: aaload
    //   2689: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2692: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2695: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2698: bipush #68
    //   2700: iaload
    //   2701: iaload
    //   2702: aaload
    //   2703: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   2706: astore #4
    //   2708: aload #4
    //   2710: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2713: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2716: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2719: bipush #69
    //   2721: iaload
    //   2722: iaload
    //   2723: aaload
    //   2724: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   2727: invokestatic llllIIIlI : (I)Z
    //   2730: invokestatic lllIllllIlII : (I)Z
    //   2733: ifeq -> 2755
    //   2736: aload_0
    //   2737: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2740: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2743: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2746: aload_3
    //   2747: invokevirtual getTotalBlockPlaced : ()I
    //   2750: i2l
    //   2751: invokevirtual format : (J)Ljava/lang/String;
    //   2754: areturn
    //   2755: aload_3
    //   2756: aload #4
    //   2758: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2761: astore #5
    //   2763: aload #5
    //   2765: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   2768: invokestatic lllIllllIlII : (I)Z
    //   2771: ifeq -> 2794
    //   2774: aload_0
    //   2775: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2778: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2781: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2784: aload #5
    //   2786: invokevirtual getBlockPlaced : ()I
    //   2789: i2l
    //   2790: invokevirtual format : (J)Ljava/lang/String;
    //   2793: areturn
    //   2794: aload_2
    //   2795: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2798: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2801: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2804: bipush #70
    //   2806: iaload
    //   2807: iaload
    //   2808: aaload
    //   2809: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   2812: invokestatic llllIIIlI : (I)Z
    //   2815: invokestatic lllIllllIlII : (I)Z
    //   2818: ifeq -> 2941
    //   2821: aload_2
    //   2822: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2825: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2828: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2831: bipush #71
    //   2833: iaload
    //   2834: iaload
    //   2835: aaload
    //   2836: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2839: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2842: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2845: bipush #72
    //   2847: iaload
    //   2848: iaload
    //   2849: aaload
    //   2850: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   2853: astore #4
    //   2855: aload #4
    //   2857: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2860: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2863: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2866: bipush #73
    //   2868: iaload
    //   2869: iaload
    //   2870: aaload
    //   2871: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   2874: invokestatic llllIIIlI : (I)Z
    //   2877: invokestatic lllIllllIlII : (I)Z
    //   2880: ifeq -> 2902
    //   2883: aload_0
    //   2884: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2887: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2890: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2893: aload_3
    //   2894: invokevirtual getTotalTntPlaced : ()I
    //   2897: i2l
    //   2898: invokevirtual format : (J)Ljava/lang/String;
    //   2901: areturn
    //   2902: aload_3
    //   2903: aload #4
    //   2905: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2908: astore #5
    //   2910: aload #5
    //   2912: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   2915: invokestatic lllIllllIlII : (I)Z
    //   2918: ifeq -> 2941
    //   2921: aload_0
    //   2922: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   2925: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   2928: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   2931: aload #5
    //   2933: invokevirtual getTntPlaced : ()I
    //   2936: i2l
    //   2937: invokevirtual format : (J)Ljava/lang/String;
    //   2940: areturn
    //   2941: aload_2
    //   2942: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2945: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2948: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2951: bipush #74
    //   2953: iaload
    //   2954: iaload
    //   2955: aaload
    //   2956: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   2959: invokestatic llllIIIlI : (I)Z
    //   2962: invokestatic lllIllllIlII : (I)Z
    //   2965: ifeq -> 3088
    //   2968: aload_2
    //   2969: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2972: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2975: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2978: bipush #75
    //   2980: iaload
    //   2981: iaload
    //   2982: aaload
    //   2983: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   2986: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   2989: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   2992: bipush #76
    //   2994: iaload
    //   2995: iaload
    //   2996: aaload
    //   2997: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   3000: astore #4
    //   3002: aload #4
    //   3004: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3007: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3010: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3013: bipush #77
    //   3015: iaload
    //   3016: iaload
    //   3017: aaload
    //   3018: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   3021: invokestatic llllIIIlI : (I)Z
    //   3024: invokestatic lllIllllIlII : (I)Z
    //   3027: ifeq -> 3049
    //   3030: aload_0
    //   3031: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3034: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3037: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3040: aload_3
    //   3041: invokevirtual getTotalProjectileShoot : ()I
    //   3044: i2l
    //   3045: invokevirtual format : (J)Ljava/lang/String;
    //   3048: areturn
    //   3049: aload_3
    //   3050: aload #4
    //   3052: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3055: astore #5
    //   3057: aload #5
    //   3059: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   3062: invokestatic lllIllllIlII : (I)Z
    //   3065: ifeq -> 3088
    //   3068: aload_0
    //   3069: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3072: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3075: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3078: aload #5
    //   3080: invokevirtual getProjectileShoot : ()I
    //   3083: i2l
    //   3084: invokevirtual format : (J)Ljava/lang/String;
    //   3087: areturn
    //   3088: aload_2
    //   3089: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3092: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3095: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3098: bipush #78
    //   3100: iaload
    //   3101: iaload
    //   3102: aaload
    //   3103: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   3106: invokestatic llllIIIlI : (I)Z
    //   3109: invokestatic lllIllllIlII : (I)Z
    //   3112: ifeq -> 3235
    //   3115: aload_2
    //   3116: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3119: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3122: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3125: bipush #79
    //   3127: iaload
    //   3128: iaload
    //   3129: aaload
    //   3130: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3133: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3136: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3139: bipush #80
    //   3141: iaload
    //   3142: iaload
    //   3143: aaload
    //   3144: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   3147: astore #4
    //   3149: aload #4
    //   3151: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3154: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3157: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3160: bipush #81
    //   3162: iaload
    //   3163: iaload
    //   3164: aaload
    //   3165: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   3168: invokestatic llllIIIlI : (I)Z
    //   3171: invokestatic lllIllllIlII : (I)Z
    //   3174: ifeq -> 3196
    //   3177: aload_0
    //   3178: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3181: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3184: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3187: aload_3
    //   3188: invokevirtual getTotalProjectileHit : ()I
    //   3191: i2l
    //   3192: invokevirtual format : (J)Ljava/lang/String;
    //   3195: areturn
    //   3196: aload_3
    //   3197: aload #4
    //   3199: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3202: astore #5
    //   3204: aload #5
    //   3206: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   3209: invokestatic lllIllllIlII : (I)Z
    //   3212: ifeq -> 3235
    //   3215: aload_0
    //   3216: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3219: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3222: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3225: aload #5
    //   3227: invokevirtual getProjectileHit : ()I
    //   3230: i2l
    //   3231: invokevirtual format : (J)Ljava/lang/String;
    //   3234: areturn
    //   3235: aload_2
    //   3236: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3239: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3242: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3245: bipush #82
    //   3247: iaload
    //   3248: iaload
    //   3249: aaload
    //   3250: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   3253: invokestatic llllIIIlI : (I)Z
    //   3256: invokestatic lllIllllIlII : (I)Z
    //   3259: ifeq -> 3382
    //   3262: aload_2
    //   3263: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3266: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3269: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3272: bipush #83
    //   3274: iaload
    //   3275: iaload
    //   3276: aaload
    //   3277: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3280: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3283: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3286: bipush #84
    //   3288: iaload
    //   3289: iaload
    //   3290: aaload
    //   3291: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   3294: astore #4
    //   3296: aload #4
    //   3298: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3301: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3304: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3307: bipush #85
    //   3309: iaload
    //   3310: iaload
    //   3311: aaload
    //   3312: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   3315: invokestatic llllIIIlI : (I)Z
    //   3318: invokestatic lllIllllIlII : (I)Z
    //   3321: ifeq -> 3343
    //   3324: aload_0
    //   3325: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3328: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3331: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3334: aload_3
    //   3335: invokevirtual getTotalFireballSoot : ()I
    //   3338: i2l
    //   3339: invokevirtual format : (J)Ljava/lang/String;
    //   3342: areturn
    //   3343: aload_3
    //   3344: aload #4
    //   3346: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3349: astore #5
    //   3351: aload #5
    //   3353: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   3356: invokestatic lllIllllIlII : (I)Z
    //   3359: ifeq -> 3382
    //   3362: aload_0
    //   3363: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3366: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3369: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3372: aload #5
    //   3374: invokevirtual getFireballShoot : ()I
    //   3377: i2l
    //   3378: invokevirtual format : (J)Ljava/lang/String;
    //   3381: areturn
    //   3382: aload_2
    //   3383: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3386: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3389: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3392: bipush #86
    //   3394: iaload
    //   3395: iaload
    //   3396: aaload
    //   3397: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   3400: invokestatic llllIIIlI : (I)Z
    //   3403: invokestatic lllIllllIlII : (I)Z
    //   3406: ifeq -> 3529
    //   3409: aload_2
    //   3410: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3413: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3416: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3419: bipush #87
    //   3421: iaload
    //   3422: iaload
    //   3423: aaload
    //   3424: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3427: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3430: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3433: bipush #88
    //   3435: iaload
    //   3436: iaload
    //   3437: aaload
    //   3438: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   3441: astore #4
    //   3443: aload #4
    //   3445: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3448: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3451: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3454: bipush #89
    //   3456: iaload
    //   3457: iaload
    //   3458: aaload
    //   3459: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   3462: invokestatic llllIIIlI : (I)Z
    //   3465: invokestatic lllIllllIlII : (I)Z
    //   3468: ifeq -> 3490
    //   3471: aload_0
    //   3472: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3475: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3478: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3481: aload_3
    //   3482: invokevirtual getTotalEmeraldCollected : ()I
    //   3485: i2l
    //   3486: invokevirtual format : (J)Ljava/lang/String;
    //   3489: areturn
    //   3490: aload_3
    //   3491: aload #4
    //   3493: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3496: astore #5
    //   3498: aload #5
    //   3500: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   3503: invokestatic lllIllllIlII : (I)Z
    //   3506: ifeq -> 3529
    //   3509: aload_0
    //   3510: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3513: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3516: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3519: aload #5
    //   3521: invokevirtual getEmeraldCollected : ()I
    //   3524: i2l
    //   3525: invokevirtual format : (J)Ljava/lang/String;
    //   3528: areturn
    //   3529: aload_2
    //   3530: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3533: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3536: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3539: bipush #90
    //   3541: iaload
    //   3542: iaload
    //   3543: aaload
    //   3544: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   3547: invokestatic llllIIIlI : (I)Z
    //   3550: invokestatic lllIllllIlII : (I)Z
    //   3553: ifeq -> 3676
    //   3556: aload_2
    //   3557: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3560: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3563: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3566: bipush #91
    //   3568: iaload
    //   3569: iaload
    //   3570: aaload
    //   3571: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3574: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3577: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3580: bipush #92
    //   3582: iaload
    //   3583: iaload
    //   3584: aaload
    //   3585: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   3588: astore #4
    //   3590: aload #4
    //   3592: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3595: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3598: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3601: bipush #93
    //   3603: iaload
    //   3604: iaload
    //   3605: aaload
    //   3606: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   3609: invokestatic llllIIIlI : (I)Z
    //   3612: invokestatic lllIllllIlII : (I)Z
    //   3615: ifeq -> 3637
    //   3618: aload_0
    //   3619: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3622: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3625: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3628: aload_3
    //   3629: invokevirtual getTotalDiamondCollected : ()I
    //   3632: i2l
    //   3633: invokevirtual format : (J)Ljava/lang/String;
    //   3636: areturn
    //   3637: aload_3
    //   3638: aload #4
    //   3640: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3643: astore #5
    //   3645: aload #5
    //   3647: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   3650: invokestatic lllIllllIlII : (I)Z
    //   3653: ifeq -> 3676
    //   3656: aload_0
    //   3657: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3660: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3663: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3666: aload #5
    //   3668: invokevirtual getDiamondCollected : ()I
    //   3671: i2l
    //   3672: invokevirtual format : (J)Ljava/lang/String;
    //   3675: areturn
    //   3676: aload_2
    //   3677: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3680: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3683: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3686: bipush #94
    //   3688: iaload
    //   3689: iaload
    //   3690: aaload
    //   3691: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   3694: invokestatic llllIIIlI : (I)Z
    //   3697: invokestatic lllIllllIlII : (I)Z
    //   3700: ifeq -> 3823
    //   3703: aload_2
    //   3704: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3707: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3710: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3713: bipush #95
    //   3715: iaload
    //   3716: iaload
    //   3717: aaload
    //   3718: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3721: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3724: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3727: bipush #96
    //   3729: iaload
    //   3730: iaload
    //   3731: aaload
    //   3732: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   3735: astore #4
    //   3737: aload #4
    //   3739: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3742: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3745: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3748: bipush #97
    //   3750: iaload
    //   3751: iaload
    //   3752: aaload
    //   3753: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   3756: invokestatic llllIIIlI : (I)Z
    //   3759: invokestatic lllIllllIlII : (I)Z
    //   3762: ifeq -> 3784
    //   3765: aload_0
    //   3766: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3769: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3772: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3775: aload_3
    //   3776: invokevirtual getTotalGoldCollected : ()I
    //   3779: i2l
    //   3780: invokevirtual format : (J)Ljava/lang/String;
    //   3783: areturn
    //   3784: aload_3
    //   3785: aload #4
    //   3787: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3790: astore #5
    //   3792: aload #5
    //   3794: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   3797: invokestatic lllIllllIlII : (I)Z
    //   3800: ifeq -> 3823
    //   3803: aload_0
    //   3804: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3807: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3810: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3813: aload #5
    //   3815: invokevirtual getGoldCollected : ()I
    //   3818: i2l
    //   3819: invokevirtual format : (J)Ljava/lang/String;
    //   3822: areturn
    //   3823: aload_2
    //   3824: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3827: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3830: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3833: bipush #98
    //   3835: iaload
    //   3836: iaload
    //   3837: aaload
    //   3838: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   3841: invokestatic llllIIIlI : (I)Z
    //   3844: invokestatic lllIllllIlII : (I)Z
    //   3847: ifeq -> 3970
    //   3850: aload_2
    //   3851: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3854: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3857: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3860: bipush #99
    //   3862: iaload
    //   3863: iaload
    //   3864: aaload
    //   3865: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3868: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3871: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3874: bipush #100
    //   3876: iaload
    //   3877: iaload
    //   3878: aaload
    //   3879: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   3882: astore #4
    //   3884: aload #4
    //   3886: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3889: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3892: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3895: bipush #101
    //   3897: iaload
    //   3898: iaload
    //   3899: aaload
    //   3900: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   3903: invokestatic llllIIIlI : (I)Z
    //   3906: invokestatic lllIllllIlII : (I)Z
    //   3909: ifeq -> 3931
    //   3912: aload_0
    //   3913: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3916: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3919: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3922: aload_3
    //   3923: invokevirtual getTotalIronCollected : ()I
    //   3926: i2l
    //   3927: invokevirtual format : (J)Ljava/lang/String;
    //   3930: areturn
    //   3931: aload_3
    //   3932: aload #4
    //   3934: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3937: astore #5
    //   3939: aload #5
    //   3941: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   3944: invokestatic lllIllllIlII : (I)Z
    //   3947: ifeq -> 3970
    //   3950: aload_0
    //   3951: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   3954: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   3957: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   3960: aload #5
    //   3962: invokevirtual getIronCollected : ()I
    //   3965: i2l
    //   3966: invokevirtual format : (J)Ljava/lang/String;
    //   3969: areturn
    //   3970: aload_2
    //   3971: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   3974: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   3977: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   3980: bipush #102
    //   3982: iaload
    //   3983: iaload
    //   3984: aaload
    //   3985: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   3988: invokestatic llllIIIlI : (I)Z
    //   3991: invokestatic lllIllllIlII : (I)Z
    //   3994: ifeq -> 4117
    //   3997: aload_2
    //   3998: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4001: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4004: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4007: bipush #103
    //   4009: iaload
    //   4010: iaload
    //   4011: aaload
    //   4012: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4015: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4018: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4021: bipush #104
    //   4023: iaload
    //   4024: iaload
    //   4025: aaload
    //   4026: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   4029: astore #4
    //   4031: aload #4
    //   4033: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4036: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4039: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4042: bipush #105
    //   4044: iaload
    //   4045: iaload
    //   4046: aaload
    //   4047: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   4050: invokestatic llllIIIlI : (I)Z
    //   4053: invokestatic lllIllllIlII : (I)Z
    //   4056: ifeq -> 4078
    //   4059: aload_0
    //   4060: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4063: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   4066: aload_3
    //   4067: invokevirtual getTotalTimePlayed : ()I
    //   4070: aload_3
    //   4071: invokevirtual getLanguage : ()Ljava/lang/String;
    //   4074: invokevirtual formatTime : (ILjava/lang/String;)Ljava/lang/String;
    //   4077: areturn
    //   4078: aload_3
    //   4079: aload #4
    //   4081: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   4084: astore #5
    //   4086: aload #5
    //   4088: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   4091: invokestatic lllIllllIlII : (I)Z
    //   4094: ifeq -> 4117
    //   4097: aload_0
    //   4098: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4101: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   4104: aload #5
    //   4106: invokevirtual getTimePlayed : ()I
    //   4109: aload_3
    //   4110: invokevirtual getLanguage : ()Ljava/lang/String;
    //   4113: invokevirtual formatTime : (ILjava/lang/String;)Ljava/lang/String;
    //   4116: areturn
    //   4117: aload_2
    //   4118: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4121: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4124: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4127: bipush #106
    //   4129: iaload
    //   4130: iaload
    //   4131: aaload
    //   4132: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   4135: invokestatic llllIIIlI : (I)Z
    //   4138: invokestatic lllIllllIlII : (I)Z
    //   4141: ifeq -> 4262
    //   4144: aload_2
    //   4145: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4148: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4151: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4154: bipush #107
    //   4156: iaload
    //   4157: iaload
    //   4158: aaload
    //   4159: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4162: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4165: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4168: bipush #108
    //   4170: iaload
    //   4171: iaload
    //   4172: aaload
    //   4173: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   4176: astore #4
    //   4178: aload #4
    //   4180: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4183: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4186: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4189: bipush #109
    //   4191: iaload
    //   4192: iaload
    //   4193: aaload
    //   4194: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   4197: invokestatic llllIIIlI : (I)Z
    //   4200: invokestatic lllIllllIlII : (I)Z
    //   4203: ifeq -> 4224
    //   4206: aload_0
    //   4207: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4210: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   4213: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   4216: aload_3
    //   4217: invokevirtual getKD : ()D
    //   4220: invokevirtual format : (D)Ljava/lang/String;
    //   4223: areturn
    //   4224: aload_3
    //   4225: aload #4
    //   4227: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   4230: astore #5
    //   4232: aload #5
    //   4234: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   4237: invokestatic lllIllllIlII : (I)Z
    //   4240: ifeq -> 4262
    //   4243: aload_0
    //   4244: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4247: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   4250: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   4253: aload #5
    //   4255: invokevirtual getKD : ()D
    //   4258: invokevirtual format : (D)Ljava/lang/String;
    //   4261: areturn
    //   4262: aload_2
    //   4263: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4266: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4269: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4272: bipush #110
    //   4274: iaload
    //   4275: iaload
    //   4276: aaload
    //   4277: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   4280: invokestatic llllIIIlI : (I)Z
    //   4283: invokestatic lllIllllIlII : (I)Z
    //   4286: ifeq -> 4407
    //   4289: aload_2
    //   4290: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4293: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4296: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4299: bipush #111
    //   4301: iaload
    //   4302: iaload
    //   4303: aaload
    //   4304: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4307: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4310: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4313: bipush #112
    //   4315: iaload
    //   4316: iaload
    //   4317: aaload
    //   4318: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   4321: astore #4
    //   4323: aload #4
    //   4325: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4328: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4331: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4334: bipush #113
    //   4336: iaload
    //   4337: iaload
    //   4338: aaload
    //   4339: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   4342: invokestatic llllIIIlI : (I)Z
    //   4345: invokestatic lllIllllIlII : (I)Z
    //   4348: ifeq -> 4369
    //   4351: aload_0
    //   4352: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4355: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   4358: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   4361: aload_3
    //   4362: invokevirtual getFinalKD : ()D
    //   4365: invokevirtual format : (D)Ljava/lang/String;
    //   4368: areturn
    //   4369: aload_3
    //   4370: aload #4
    //   4372: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   4375: astore #5
    //   4377: aload #5
    //   4379: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   4382: invokestatic lllIllllIlII : (I)Z
    //   4385: ifeq -> 4407
    //   4388: aload_0
    //   4389: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4392: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   4395: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   4398: aload #5
    //   4400: invokevirtual getFinalKD : ()D
    //   4403: invokevirtual format : (D)Ljava/lang/String;
    //   4406: areturn
    //   4407: aload_2
    //   4408: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4411: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4414: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4417: bipush #114
    //   4419: iaload
    //   4420: iaload
    //   4421: aaload
    //   4422: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   4425: invokestatic llllIIIlI : (I)Z
    //   4428: invokestatic lllIllllIlII : (I)Z
    //   4431: ifeq -> 4552
    //   4434: aload_2
    //   4435: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4438: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4441: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4444: bipush #115
    //   4446: iaload
    //   4447: iaload
    //   4448: aaload
    //   4449: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4452: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4455: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4458: bipush #116
    //   4460: iaload
    //   4461: iaload
    //   4462: aaload
    //   4463: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   4466: astore #4
    //   4468: aload #4
    //   4470: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4473: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4476: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4479: bipush #117
    //   4481: iaload
    //   4482: iaload
    //   4483: aaload
    //   4484: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   4487: invokestatic llllIIIlI : (I)Z
    //   4490: invokestatic lllIllllIlII : (I)Z
    //   4493: ifeq -> 4514
    //   4496: aload_0
    //   4497: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4500: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   4503: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   4506: aload_3
    //   4507: invokevirtual getWinLosses : ()D
    //   4510: invokevirtual format : (D)Ljava/lang/String;
    //   4513: areturn
    //   4514: aload_3
    //   4515: aload #4
    //   4517: invokevirtual getGroupData : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   4520: astore #5
    //   4522: aload #5
    //   4524: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   4527: invokestatic lllIllllIlII : (I)Z
    //   4530: ifeq -> 4552
    //   4533: aload_0
    //   4534: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4537: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   4540: invokevirtual getNumberFormat : ()Ljava/text/DecimalFormat;
    //   4543: aload #5
    //   4545: invokevirtual getWinLosses : ()D
    //   4548: invokevirtual format : (D)Ljava/lang/String;
    //   4551: areturn
    //   4552: aload_2
    //   4553: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4556: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4559: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4562: bipush #118
    //   4564: iaload
    //   4565: iaload
    //   4566: aaload
    //   4567: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   4570: invokestatic llllIIIlI : (I)Z
    //   4573: invokestatic lllIllllIlII : (I)Z
    //   4576: ifeq -> 4599
    //   4579: aload_0
    //   4580: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4583: invokevirtual getTrailManager : ()Lcom/axeelheaven/hbedwars/cosmetics/trails/TrailManager;
    //   4586: aload_3
    //   4587: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   4590: invokeinterface size : ()I
    //   4595: invokestatic valueOf : (I)Ljava/lang/String;
    //   4598: areturn
    //   4599: aload_2
    //   4600: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4603: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4606: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4609: bipush #119
    //   4611: iaload
    //   4612: iaload
    //   4613: aaload
    //   4614: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   4617: invokestatic llllIIIlI : (I)Z
    //   4620: invokestatic lllIllllIlII : (I)Z
    //   4623: ifeq -> 4643
    //   4626: aload_0
    //   4627: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4630: invokevirtual getTrailManager : ()Lcom/axeelheaven/hbedwars/cosmetics/trails/TrailManager;
    //   4633: invokevirtual getTrails : ()Ljava/util/HashMap;
    //   4636: invokevirtual size : ()I
    //   4639: invokestatic valueOf : (I)Ljava/lang/String;
    //   4642: areturn
    //   4643: aload_2
    //   4644: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4647: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4650: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4653: bipush #120
    //   4655: iaload
    //   4656: iaload
    //   4657: aaload
    //   4658: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   4661: invokestatic llllIIIlI : (I)Z
    //   4664: invokestatic lllIllllIlII : (I)Z
    //   4667: ifeq -> 4715
    //   4670: aload_0
    //   4671: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4674: invokevirtual getTrailManager : ()Lcom/axeelheaven/hbedwars/cosmetics/trails/TrailManager;
    //   4677: aload_3
    //   4678: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   4681: invokeinterface size : ()I
    //   4686: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4689: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4692: bipush #100
    //   4694: iaload
    //   4695: iaload
    //   4696: imul
    //   4697: aload_0
    //   4698: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4701: invokevirtual getTrailManager : ()Lcom/axeelheaven/hbedwars/cosmetics/trails/TrailManager;
    //   4704: invokevirtual getTrails : ()Ljava/util/HashMap;
    //   4707: invokevirtual size : ()I
    //   4710: idiv
    //   4711: invokestatic valueOf : (I)Ljava/lang/String;
    //   4714: areturn
    //   4715: aload_2
    //   4716: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4719: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4722: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4725: bipush #121
    //   4727: iaload
    //   4728: iaload
    //   4729: aaload
    //   4730: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   4733: invokestatic llllIIIlI : (I)Z
    //   4736: invokestatic lllIllllIlII : (I)Z
    //   4739: ifeq -> 4986
    //   4742: aload_3
    //   4743: invokevirtual getTrail : ()Ljava/lang/String;
    //   4746: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   4749: invokestatic lllIllllIlII : (I)Z
    //   4752: ifeq -> 4953
    //   4755: aload_0
    //   4756: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4759: invokevirtual getTrailManager : ()Lcom/axeelheaven/hbedwars/cosmetics/trails/TrailManager;
    //   4762: aload_3
    //   4763: invokevirtual getTrail : ()Ljava/lang/String;
    //   4766: invokevirtual getTrail : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/cosmetics/trails/Trail;
    //   4769: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   4772: invokestatic lllIllllIlII : (I)Z
    //   4775: ifeq -> 4953
    //   4778: aload_0
    //   4779: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4782: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   4785: aload_3
    //   4786: invokevirtual getLanguage : ()Ljava/lang/String;
    //   4789: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   4792: new java/lang/StringBuilder
    //   4795: dup
    //   4796: invokespecial <init> : ()V
    //   4799: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4802: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4805: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4808: bipush #122
    //   4810: iaload
    //   4811: iaload
    //   4812: aaload
    //   4813: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   4816: aload_3
    //   4817: invokevirtual getTrail : ()Ljava/lang/String;
    //   4820: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   4823: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   4826: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   4829: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   4832: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4835: bipush #7
    //   4837: iaload
    //   4838: aaload
    //   4839: invokevirtual length : ()I
    //   4842: ldc ''
    //   4844: invokevirtual length : ()I
    //   4847: pop2
    //   4848: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4851: bipush #123
    //   4853: iaload
    //   4854: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4857: bipush #124
    //   4859: iaload
    //   4860: iadd
    //   4861: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4864: bipush #125
    //   4866: iaload
    //   4867: isub
    //   4868: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4871: bipush #90
    //   4873: iaload
    //   4874: iadd
    //   4875: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4878: bipush #28
    //   4880: iaload
    //   4881: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4884: bipush #126
    //   4886: iaload
    //   4887: iadd
    //   4888: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4891: bipush #67
    //   4893: iaload
    //   4894: isub
    //   4895: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4898: bipush #91
    //   4900: iaload
    //   4901: iadd
    //   4902: ixor
    //   4903: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4906: bipush #127
    //   4908: iaload
    //   4909: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4912: sipush #128
    //   4915: iaload
    //   4916: ixor
    //   4917: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4920: iconst_0
    //   4921: iaload
    //   4922: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4925: iconst_4
    //   4926: iaload
    //   4927: ixor
    //   4928: ixor
    //   4929: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   4932: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4935: bipush #8
    //   4937: iaload
    //   4938: aaload
    //   4939: invokevirtual length : ()I
    //   4942: ineg
    //   4943: ixor
    //   4944: iand
    //   4945: invokestatic lllIllllIlII : (I)Z
    //   4948: ifeq -> 4985
    //   4951: aconst_null
    //   4952: areturn
    //   4953: aload_0
    //   4954: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4957: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   4960: aload_3
    //   4961: invokevirtual getLanguage : ()Ljava/lang/String;
    //   4964: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   4967: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4970: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4973: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4976: sipush #129
    //   4979: iaload
    //   4980: iaload
    //   4981: aaload
    //   4982: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   4985: areturn
    //   4986: aload_2
    //   4987: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   4990: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   4993: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   4996: sipush #130
    //   4999: iaload
    //   5000: iaload
    //   5001: aaload
    //   5002: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5005: invokestatic llllIIIlI : (I)Z
    //   5008: invokestatic lllIllllIlII : (I)Z
    //   5011: ifeq -> 5034
    //   5014: aload_0
    //   5015: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5018: invokevirtual getWinDanceManager : ()Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceManager;
    //   5021: aload_3
    //   5022: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   5025: invokeinterface size : ()I
    //   5030: invokestatic valueOf : (I)Ljava/lang/String;
    //   5033: areturn
    //   5034: aload_2
    //   5035: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5038: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5041: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5044: sipush #131
    //   5047: iaload
    //   5048: iaload
    //   5049: aaload
    //   5050: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5053: invokestatic llllIIIlI : (I)Z
    //   5056: invokestatic lllIllllIlII : (I)Z
    //   5059: ifeq -> 5079
    //   5062: aload_0
    //   5063: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5066: invokevirtual getWinDanceManager : ()Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceManager;
    //   5069: invokevirtual getWinDances : ()Ljava/util/HashMap;
    //   5072: invokevirtual size : ()I
    //   5075: invokestatic valueOf : (I)Ljava/lang/String;
    //   5078: areturn
    //   5079: aload_2
    //   5080: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5083: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5086: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5089: sipush #132
    //   5092: iaload
    //   5093: iaload
    //   5094: aaload
    //   5095: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5098: invokestatic llllIIIlI : (I)Z
    //   5101: invokestatic lllIllllIlII : (I)Z
    //   5104: ifeq -> 5152
    //   5107: aload_0
    //   5108: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5111: invokevirtual getWinDanceManager : ()Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceManager;
    //   5114: aload_3
    //   5115: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   5118: invokeinterface size : ()I
    //   5123: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5126: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5129: bipush #100
    //   5131: iaload
    //   5132: iaload
    //   5133: imul
    //   5134: aload_0
    //   5135: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5138: invokevirtual getWinDanceManager : ()Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceManager;
    //   5141: invokevirtual getWinDances : ()Ljava/util/HashMap;
    //   5144: invokevirtual size : ()I
    //   5147: idiv
    //   5148: invokestatic valueOf : (I)Ljava/lang/String;
    //   5151: areturn
    //   5152: aload_2
    //   5153: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5156: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5159: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5162: sipush #133
    //   5165: iaload
    //   5166: iaload
    //   5167: aaload
    //   5168: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5171: invokestatic llllIIIlI : (I)Z
    //   5174: invokestatic lllIllllIlII : (I)Z
    //   5177: ifeq -> 5363
    //   5180: aload_3
    //   5181: invokevirtual getWinDance : ()Ljava/lang/String;
    //   5184: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   5187: invokestatic lllIllllIlII : (I)Z
    //   5190: ifeq -> 5330
    //   5193: aload_0
    //   5194: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5197: invokevirtual getWinDanceManager : ()Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDanceManager;
    //   5200: aload_3
    //   5201: invokevirtual getWinDance : ()Ljava/lang/String;
    //   5204: invokevirtual getWinDance : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/cosmetics/windances/WinDance;
    //   5207: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   5210: invokestatic lllIllllIlII : (I)Z
    //   5213: ifeq -> 5330
    //   5216: aload_0
    //   5217: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5220: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   5223: aload_3
    //   5224: invokevirtual getLanguage : ()Ljava/lang/String;
    //   5227: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   5230: new java/lang/StringBuilder
    //   5233: dup
    //   5234: invokespecial <init> : ()V
    //   5237: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5240: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5243: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5246: sipush #134
    //   5249: iaload
    //   5250: iaload
    //   5251: aaload
    //   5252: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   5255: aload_3
    //   5256: invokevirtual getWinDance : ()Ljava/lang/String;
    //   5259: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   5262: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   5265: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   5268: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   5271: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5274: bipush #9
    //   5276: iaload
    //   5277: aaload
    //   5278: invokevirtual length : ()I
    //   5281: ldc ''
    //   5283: invokevirtual length : ()I
    //   5286: pop2
    //   5287: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5290: bipush #28
    //   5292: iaload
    //   5293: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5296: bipush #55
    //   5298: iaload
    //   5299: ixor
    //   5300: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5303: bipush #49
    //   5305: iaload
    //   5306: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5309: bipush #26
    //   5311: iaload
    //   5312: ixor
    //   5313: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5316: sipush #135
    //   5319: iaload
    //   5320: ixor
    //   5321: iand
    //   5322: invokestatic lllIlllllIll : (I)Z
    //   5325: ifeq -> 5362
    //   5328: aconst_null
    //   5329: areturn
    //   5330: aload_0
    //   5331: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5334: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   5337: aload_3
    //   5338: invokevirtual getLanguage : ()Ljava/lang/String;
    //   5341: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   5344: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5347: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5350: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5353: sipush #136
    //   5356: iaload
    //   5357: iaload
    //   5358: aaload
    //   5359: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   5362: areturn
    //   5363: aload_2
    //   5364: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5367: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5370: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5373: bipush #123
    //   5375: iaload
    //   5376: iaload
    //   5377: aaload
    //   5378: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5381: invokestatic llllIIIlI : (I)Z
    //   5384: invokestatic lllIllllIlII : (I)Z
    //   5387: ifeq -> 5410
    //   5390: aload_0
    //   5391: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5394: invokevirtual getKillEffectManager : ()Lcom/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectManager;
    //   5397: aload_3
    //   5398: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   5401: invokeinterface size : ()I
    //   5406: invokestatic valueOf : (I)Ljava/lang/String;
    //   5409: areturn
    //   5410: aload_2
    //   5411: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5414: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5417: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5420: sipush #137
    //   5423: iaload
    //   5424: iaload
    //   5425: aaload
    //   5426: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5429: invokestatic llllIIIlI : (I)Z
    //   5432: invokestatic lllIllllIlII : (I)Z
    //   5435: ifeq -> 5455
    //   5438: aload_0
    //   5439: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5442: invokevirtual getKillEffectManager : ()Lcom/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectManager;
    //   5445: invokevirtual getKillEffects : ()Ljava/util/HashMap;
    //   5448: invokevirtual size : ()I
    //   5451: invokestatic valueOf : (I)Ljava/lang/String;
    //   5454: areturn
    //   5455: aload_2
    //   5456: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5459: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5462: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5465: sipush #138
    //   5468: iaload
    //   5469: iaload
    //   5470: aaload
    //   5471: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5474: invokestatic llllIIIlI : (I)Z
    //   5477: invokestatic lllIllllIlII : (I)Z
    //   5480: ifeq -> 5528
    //   5483: aload_0
    //   5484: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5487: invokevirtual getKillEffectManager : ()Lcom/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectManager;
    //   5490: aload_3
    //   5491: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   5494: invokeinterface size : ()I
    //   5499: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5502: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5505: bipush #100
    //   5507: iaload
    //   5508: iaload
    //   5509: imul
    //   5510: aload_0
    //   5511: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5514: invokevirtual getKillEffectManager : ()Lcom/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectManager;
    //   5517: invokevirtual getKillEffects : ()Ljava/util/HashMap;
    //   5520: invokevirtual size : ()I
    //   5523: idiv
    //   5524: invokestatic valueOf : (I)Ljava/lang/String;
    //   5527: areturn
    //   5528: aload_2
    //   5529: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5532: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5535: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5538: sipush #139
    //   5541: iaload
    //   5542: iaload
    //   5543: aaload
    //   5544: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5547: invokestatic llllIIIlI : (I)Z
    //   5550: invokestatic lllIllllIlII : (I)Z
    //   5553: ifeq -> 5778
    //   5556: aload_3
    //   5557: invokevirtual getKillEffect : ()Ljava/lang/String;
    //   5560: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   5563: invokestatic lllIllllIlII : (I)Z
    //   5566: ifeq -> 5745
    //   5569: aload_0
    //   5570: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5573: invokevirtual getKillEffectManager : ()Lcom/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectManager;
    //   5576: aload_3
    //   5577: invokevirtual getKillEffect : ()Ljava/lang/String;
    //   5580: invokevirtual getKillEffect : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/cosmetics/killeffects/KillEffect;
    //   5583: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   5586: invokestatic lllIllllIlII : (I)Z
    //   5589: ifeq -> 5745
    //   5592: aload_0
    //   5593: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5596: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   5599: aload_3
    //   5600: invokevirtual getLanguage : ()Ljava/lang/String;
    //   5603: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   5606: new java/lang/StringBuilder
    //   5609: dup
    //   5610: invokespecial <init> : ()V
    //   5613: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5616: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5619: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5622: sipush #140
    //   5625: iaload
    //   5626: iaload
    //   5627: aaload
    //   5628: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   5631: aload_3
    //   5632: invokevirtual getKillEffect : ()Ljava/lang/String;
    //   5635: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   5638: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   5641: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   5644: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   5647: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5650: bipush #10
    //   5652: iaload
    //   5653: aaload
    //   5654: invokevirtual length : ()I
    //   5657: ldc ''
    //   5659: invokevirtual length : ()I
    //   5662: pop2
    //   5663: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5666: sipush #139
    //   5669: iaload
    //   5670: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5673: sipush #141
    //   5676: iaload
    //   5677: ixor
    //   5678: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   5681: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5684: bipush #11
    //   5686: iaload
    //   5687: aaload
    //   5688: invokevirtual length : ()I
    //   5691: ixor
    //   5692: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5695: bipush #32
    //   5697: iaload
    //   5698: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5701: bipush #51
    //   5703: iaload
    //   5704: ixor
    //   5705: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5708: sipush #140
    //   5711: iaload
    //   5712: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5715: sipush #142
    //   5718: iaload
    //   5719: ixor
    //   5720: ixor
    //   5721: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   5724: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5727: bipush #12
    //   5729: iaload
    //   5730: aaload
    //   5731: invokevirtual length : ()I
    //   5734: ineg
    //   5735: ixor
    //   5736: iand
    //   5737: invokestatic lllIllllIlII : (I)Z
    //   5740: ifeq -> 5777
    //   5743: aconst_null
    //   5744: areturn
    //   5745: aload_0
    //   5746: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5749: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   5752: aload_3
    //   5753: invokevirtual getLanguage : ()Ljava/lang/String;
    //   5756: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   5759: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5762: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5765: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5768: sipush #143
    //   5771: iaload
    //   5772: iaload
    //   5773: aaload
    //   5774: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   5777: areturn
    //   5778: aload_2
    //   5779: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5782: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5785: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5788: sipush #144
    //   5791: iaload
    //   5792: iaload
    //   5793: aaload
    //   5794: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5797: invokestatic llllIIIlI : (I)Z
    //   5800: invokestatic lllIllllIlII : (I)Z
    //   5803: ifeq -> 5826
    //   5806: aload_0
    //   5807: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5810: invokevirtual getSprayManager : ()Lcom/axeelheaven/hbedwars/cosmetics/sprays/SprayManager;
    //   5813: aload_3
    //   5814: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   5817: invokeinterface size : ()I
    //   5822: invokestatic valueOf : (I)Ljava/lang/String;
    //   5825: areturn
    //   5826: aload_2
    //   5827: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5830: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5833: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5836: sipush #145
    //   5839: iaload
    //   5840: iaload
    //   5841: aaload
    //   5842: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5845: invokestatic llllIIIlI : (I)Z
    //   5848: invokestatic lllIllllIlII : (I)Z
    //   5851: ifeq -> 5871
    //   5854: aload_0
    //   5855: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5858: invokevirtual getSprayManager : ()Lcom/axeelheaven/hbedwars/cosmetics/sprays/SprayManager;
    //   5861: invokevirtual getSprays : ()Ljava/util/HashMap;
    //   5864: invokevirtual size : ()I
    //   5867: invokestatic valueOf : (I)Ljava/lang/String;
    //   5870: areturn
    //   5871: aload_2
    //   5872: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5875: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5878: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5881: sipush #146
    //   5884: iaload
    //   5885: iaload
    //   5886: aaload
    //   5887: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5890: invokestatic llllIIIlI : (I)Z
    //   5893: invokestatic lllIllllIlII : (I)Z
    //   5896: ifeq -> 5944
    //   5899: aload_0
    //   5900: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5903: invokevirtual getSprayManager : ()Lcom/axeelheaven/hbedwars/cosmetics/sprays/SprayManager;
    //   5906: aload_3
    //   5907: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   5910: invokeinterface size : ()I
    //   5915: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5918: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5921: bipush #100
    //   5923: iaload
    //   5924: iaload
    //   5925: imul
    //   5926: aload_0
    //   5927: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5930: invokevirtual getSprayManager : ()Lcom/axeelheaven/hbedwars/cosmetics/sprays/SprayManager;
    //   5933: invokevirtual getSprays : ()Ljava/util/HashMap;
    //   5936: invokevirtual size : ()I
    //   5939: idiv
    //   5940: invokestatic valueOf : (I)Ljava/lang/String;
    //   5943: areturn
    //   5944: aload_2
    //   5945: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   5948: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   5951: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   5954: sipush #142
    //   5957: iaload
    //   5958: iaload
    //   5959: aaload
    //   5960: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   5963: invokestatic llllIIIlI : (I)Z
    //   5966: invokestatic lllIllllIlII : (I)Z
    //   5969: ifeq -> 6134
    //   5972: aload_3
    //   5973: invokevirtual getSpray : ()Ljava/lang/String;
    //   5976: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   5979: invokestatic lllIllllIlII : (I)Z
    //   5982: ifeq -> 6101
    //   5985: aload_0
    //   5986: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   5989: invokevirtual getSprayManager : ()Lcom/axeelheaven/hbedwars/cosmetics/sprays/SprayManager;
    //   5992: aload_3
    //   5993: invokevirtual getSpray : ()Ljava/lang/String;
    //   5996: invokevirtual getSpray : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/cosmetics/sprays/Spray;
    //   5999: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   6002: invokestatic lllIllllIlII : (I)Z
    //   6005: ifeq -> 6101
    //   6008: aload_0
    //   6009: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6012: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   6015: aload_3
    //   6016: invokevirtual getLanguage : ()Ljava/lang/String;
    //   6019: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   6022: new java/lang/StringBuilder
    //   6025: dup
    //   6026: invokespecial <init> : ()V
    //   6029: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6032: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6035: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6038: sipush #147
    //   6041: iaload
    //   6042: iaload
    //   6043: aaload
    //   6044: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   6047: aload_3
    //   6048: invokevirtual getSpray : ()Ljava/lang/String;
    //   6051: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   6054: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   6057: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   6060: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   6063: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6066: bipush #13
    //   6068: iaload
    //   6069: aaload
    //   6070: invokevirtual length : ()I
    //   6073: ldc ''
    //   6075: invokevirtual length : ()I
    //   6078: pop2
    //   6079: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6082: bipush #35
    //   6084: iaload
    //   6085: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6088: bipush #39
    //   6090: iaload
    //   6091: ixor
    //   6092: ineg
    //   6093: invokestatic lllIllllllII : (I)Z
    //   6096: ifeq -> 6133
    //   6099: aconst_null
    //   6100: areturn
    //   6101: aload_0
    //   6102: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6105: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   6108: aload_3
    //   6109: invokevirtual getLanguage : ()Ljava/lang/String;
    //   6112: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   6115: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6118: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6121: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6124: sipush #148
    //   6127: iaload
    //   6128: iaload
    //   6129: aaload
    //   6130: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   6133: areturn
    //   6134: aload_2
    //   6135: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6138: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6141: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6144: sipush #149
    //   6147: iaload
    //   6148: iaload
    //   6149: aaload
    //   6150: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6153: invokestatic llllIIIlI : (I)Z
    //   6156: invokestatic lllIllllIlII : (I)Z
    //   6159: ifeq -> 6182
    //   6162: aload_0
    //   6163: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6166: invokevirtual getCryManager : ()Lcom/axeelheaven/hbedwars/cosmetics/deathcries/CryManager;
    //   6169: aload_3
    //   6170: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   6173: invokeinterface size : ()I
    //   6178: invokestatic valueOf : (I)Ljava/lang/String;
    //   6181: areturn
    //   6182: aload_2
    //   6183: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6186: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6189: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6192: bipush #126
    //   6194: iaload
    //   6195: iaload
    //   6196: aaload
    //   6197: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6200: invokestatic llllIIIlI : (I)Z
    //   6203: invokestatic lllIllllIlII : (I)Z
    //   6206: ifeq -> 6226
    //   6209: aload_0
    //   6210: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6213: invokevirtual getCryManager : ()Lcom/axeelheaven/hbedwars/cosmetics/deathcries/CryManager;
    //   6216: invokevirtual getCries : ()Ljava/util/HashMap;
    //   6219: invokevirtual size : ()I
    //   6222: invokestatic valueOf : (I)Ljava/lang/String;
    //   6225: areturn
    //   6226: aload_2
    //   6227: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6230: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6233: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6236: sipush #150
    //   6239: iaload
    //   6240: iaload
    //   6241: aaload
    //   6242: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6245: invokestatic llllIIIlI : (I)Z
    //   6248: invokestatic lllIllllIlII : (I)Z
    //   6251: ifeq -> 6299
    //   6254: aload_0
    //   6255: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6258: invokevirtual getCryManager : ()Lcom/axeelheaven/hbedwars/cosmetics/deathcries/CryManager;
    //   6261: aload_3
    //   6262: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   6265: invokeinterface size : ()I
    //   6270: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6273: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6276: bipush #100
    //   6278: iaload
    //   6279: iaload
    //   6280: imul
    //   6281: aload_0
    //   6282: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6285: invokevirtual getCryManager : ()Lcom/axeelheaven/hbedwars/cosmetics/deathcries/CryManager;
    //   6288: invokevirtual getCries : ()Ljava/util/HashMap;
    //   6291: invokevirtual size : ()I
    //   6294: idiv
    //   6295: invokestatic valueOf : (I)Ljava/lang/String;
    //   6298: areturn
    //   6299: aload_2
    //   6300: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6303: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6306: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6309: sipush #151
    //   6312: iaload
    //   6313: iaload
    //   6314: aaload
    //   6315: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6318: invokestatic llllIIIlI : (I)Z
    //   6321: invokestatic lllIllllIlII : (I)Z
    //   6324: ifeq -> 6501
    //   6327: aload_3
    //   6328: invokevirtual getCry : ()Ljava/lang/String;
    //   6331: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   6334: invokestatic lllIllllIlII : (I)Z
    //   6337: ifeq -> 6468
    //   6340: aload_0
    //   6341: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6344: invokevirtual getCryManager : ()Lcom/axeelheaven/hbedwars/cosmetics/deathcries/CryManager;
    //   6347: aload_3
    //   6348: invokevirtual getCry : ()Ljava/lang/String;
    //   6351: invokevirtual getCry : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/cosmetics/deathcries/Cry;
    //   6354: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   6357: invokestatic lllIllllIlII : (I)Z
    //   6360: ifeq -> 6468
    //   6363: aload_0
    //   6364: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6367: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   6370: aload_3
    //   6371: invokevirtual getLanguage : ()Ljava/lang/String;
    //   6374: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   6377: new java/lang/StringBuilder
    //   6380: dup
    //   6381: invokespecial <init> : ()V
    //   6384: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6387: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6390: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6393: sipush #152
    //   6396: iaload
    //   6397: iaload
    //   6398: aaload
    //   6399: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   6402: aload_3
    //   6403: invokevirtual getCry : ()Ljava/lang/String;
    //   6406: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   6409: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   6412: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   6415: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   6418: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6421: bipush #14
    //   6423: iaload
    //   6424: aaload
    //   6425: invokevirtual length : ()I
    //   6428: ldc ''
    //   6430: invokevirtual length : ()I
    //   6433: pop2
    //   6434: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   6437: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6440: bipush #15
    //   6442: iaload
    //   6443: aaload
    //   6444: invokevirtual length : ()I
    //   6447: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   6450: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6453: bipush #16
    //   6455: iaload
    //   6456: aaload
    //   6457: invokevirtual length : ()I
    //   6460: invokestatic lllIllllllIl : (II)Z
    //   6463: ifeq -> 6500
    //   6466: aconst_null
    //   6467: areturn
    //   6468: aload_0
    //   6469: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6472: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   6475: aload_3
    //   6476: invokevirtual getLanguage : ()Ljava/lang/String;
    //   6479: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   6482: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6485: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6488: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6491: sipush #153
    //   6494: iaload
    //   6495: iaload
    //   6496: aaload
    //   6497: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   6500: areturn
    //   6501: aload_2
    //   6502: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6505: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6508: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6511: sipush #154
    //   6514: iaload
    //   6515: iaload
    //   6516: aaload
    //   6517: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6520: invokestatic llllIIIlI : (I)Z
    //   6523: invokestatic lllIllllIlII : (I)Z
    //   6526: ifeq -> 6549
    //   6529: aload_0
    //   6530: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6533: invokevirtual getShopKeeperManager : ()Lcom/axeelheaven/hbedwars/cosmetics/shopkeeper/ShopKeeperManager;
    //   6536: aload_3
    //   6537: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   6540: invokeinterface size : ()I
    //   6545: invokestatic valueOf : (I)Ljava/lang/String;
    //   6548: areturn
    //   6549: aload_2
    //   6550: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6553: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6556: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6559: sipush #155
    //   6562: iaload
    //   6563: iaload
    //   6564: aaload
    //   6565: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6568: invokestatic llllIIIlI : (I)Z
    //   6571: invokestatic lllIllllIlII : (I)Z
    //   6574: ifeq -> 6594
    //   6577: aload_0
    //   6578: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6581: invokevirtual getShopKeeperManager : ()Lcom/axeelheaven/hbedwars/cosmetics/shopkeeper/ShopKeeperManager;
    //   6584: invokevirtual getShopKeepers : ()Ljava/util/HashMap;
    //   6587: invokevirtual size : ()I
    //   6590: invokestatic valueOf : (I)Ljava/lang/String;
    //   6593: areturn
    //   6594: aload_2
    //   6595: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6598: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6601: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6604: sipush #156
    //   6607: iaload
    //   6608: iaload
    //   6609: aaload
    //   6610: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6613: invokestatic llllIIIlI : (I)Z
    //   6616: invokestatic lllIllllIlII : (I)Z
    //   6619: ifeq -> 6667
    //   6622: aload_0
    //   6623: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6626: invokevirtual getShopKeeperManager : ()Lcom/axeelheaven/hbedwars/cosmetics/shopkeeper/ShopKeeperManager;
    //   6629: aload_3
    //   6630: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   6633: invokeinterface size : ()I
    //   6638: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6641: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6644: bipush #100
    //   6646: iaload
    //   6647: iaload
    //   6648: imul
    //   6649: aload_0
    //   6650: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6653: invokevirtual getShopKeeperManager : ()Lcom/axeelheaven/hbedwars/cosmetics/shopkeeper/ShopKeeperManager;
    //   6656: invokevirtual getShopKeepers : ()Ljava/util/HashMap;
    //   6659: invokevirtual size : ()I
    //   6662: idiv
    //   6663: invokestatic valueOf : (I)Ljava/lang/String;
    //   6666: areturn
    //   6667: aload_2
    //   6668: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6671: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6674: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6677: sipush #157
    //   6680: iaload
    //   6681: iaload
    //   6682: aaload
    //   6683: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6686: invokestatic llllIIIlI : (I)Z
    //   6689: invokestatic lllIllllIlII : (I)Z
    //   6692: ifeq -> 6748
    //   6695: aload_0
    //   6696: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6699: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   6702: aload_3
    //   6703: invokevirtual getLanguage : ()Ljava/lang/String;
    //   6706: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   6709: new java/lang/StringBuilder
    //   6712: dup
    //   6713: invokespecial <init> : ()V
    //   6716: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6719: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6722: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6725: sipush #158
    //   6728: iaload
    //   6729: iaload
    //   6730: aaload
    //   6731: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   6734: aload_3
    //   6735: invokevirtual getShopKeeper : ()Ljava/lang/String;
    //   6738: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   6741: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   6744: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   6747: areturn
    //   6748: aload_2
    //   6749: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6752: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6755: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6758: sipush #159
    //   6761: iaload
    //   6762: iaload
    //   6763: aaload
    //   6764: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6767: invokestatic llllIIIlI : (I)Z
    //   6770: invokestatic lllIllllIlII : (I)Z
    //   6773: ifeq -> 6796
    //   6776: aload_0
    //   6777: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6780: invokevirtual getKillMessageManager : ()Lcom/axeelheaven/hbedwars/cosmetics/killmessages/KillMessageManager;
    //   6783: aload_3
    //   6784: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   6787: invokeinterface size : ()I
    //   6792: invokestatic valueOf : (I)Ljava/lang/String;
    //   6795: areturn
    //   6796: aload_2
    //   6797: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6800: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6803: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6806: sipush #141
    //   6809: iaload
    //   6810: iaload
    //   6811: aaload
    //   6812: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6815: invokestatic llllIIIlI : (I)Z
    //   6818: invokestatic lllIllllIlII : (I)Z
    //   6821: ifeq -> 6841
    //   6824: aload_0
    //   6825: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6828: invokevirtual getKillMessageManager : ()Lcom/axeelheaven/hbedwars/cosmetics/killmessages/KillMessageManager;
    //   6831: invokevirtual getKillMessages : ()Ljava/util/HashMap;
    //   6834: invokevirtual size : ()I
    //   6837: invokestatic valueOf : (I)Ljava/lang/String;
    //   6840: areturn
    //   6841: aload_2
    //   6842: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6845: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6848: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6851: sipush #160
    //   6854: iaload
    //   6855: iaload
    //   6856: aaload
    //   6857: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6860: invokestatic llllIIIlI : (I)Z
    //   6863: invokestatic lllIllllIlII : (I)Z
    //   6866: ifeq -> 6914
    //   6869: aload_0
    //   6870: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6873: invokevirtual getKillMessageManager : ()Lcom/axeelheaven/hbedwars/cosmetics/killmessages/KillMessageManager;
    //   6876: aload_3
    //   6877: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   6880: invokeinterface size : ()I
    //   6885: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6888: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6891: bipush #100
    //   6893: iaload
    //   6894: iaload
    //   6895: imul
    //   6896: aload_0
    //   6897: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6900: invokevirtual getKillMessageManager : ()Lcom/axeelheaven/hbedwars/cosmetics/killmessages/KillMessageManager;
    //   6903: invokevirtual getKillMessages : ()Ljava/util/HashMap;
    //   6906: invokevirtual size : ()I
    //   6909: idiv
    //   6910: invokestatic valueOf : (I)Ljava/lang/String;
    //   6913: areturn
    //   6914: aload_2
    //   6915: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6918: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6921: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6924: sipush #128
    //   6927: iaload
    //   6928: iaload
    //   6929: aaload
    //   6930: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6933: invokestatic llllIIIlI : (I)Z
    //   6936: invokestatic lllIllllIlII : (I)Z
    //   6939: ifeq -> 7013
    //   6942: aload_0
    //   6943: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   6946: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   6949: aload_3
    //   6950: invokevirtual getLanguage : ()Ljava/lang/String;
    //   6953: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   6956: new java/lang/StringBuilder
    //   6959: dup
    //   6960: invokespecial <init> : ()V
    //   6963: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6966: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6969: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6972: sipush #161
    //   6975: iaload
    //   6976: iaload
    //   6977: aaload
    //   6978: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   6981: aload_3
    //   6982: invokevirtual getKillMessage : ()Ljava/lang/String;
    //   6985: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   6988: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   6991: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   6994: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   6997: sipush #162
    //   7000: iaload
    //   7001: iaload
    //   7002: aaload
    //   7003: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   7006: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   7009: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   7012: areturn
    //   7013: aload_2
    //   7014: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7017: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7020: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7023: sipush #163
    //   7026: iaload
    //   7027: iaload
    //   7028: aaload
    //   7029: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7032: invokestatic llllIIIlI : (I)Z
    //   7035: invokestatic lllIllllIlII : (I)Z
    //   7038: ifeq -> 7061
    //   7041: aload_0
    //   7042: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7045: invokevirtual getBedDestroyManager : ()Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyManager;
    //   7048: aload_3
    //   7049: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   7052: invokeinterface size : ()I
    //   7057: invokestatic valueOf : (I)Ljava/lang/String;
    //   7060: areturn
    //   7061: aload_2
    //   7062: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7065: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7068: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7071: sipush #164
    //   7074: iaload
    //   7075: iaload
    //   7076: aaload
    //   7077: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7080: invokestatic llllIIIlI : (I)Z
    //   7083: invokestatic lllIllllIlII : (I)Z
    //   7086: ifeq -> 7106
    //   7089: aload_0
    //   7090: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7093: invokevirtual getBedDestroyManager : ()Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyManager;
    //   7096: invokevirtual getBedDestroys : ()Ljava/util/HashMap;
    //   7099: invokevirtual size : ()I
    //   7102: invokestatic valueOf : (I)Ljava/lang/String;
    //   7105: areturn
    //   7106: aload_2
    //   7107: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7110: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7113: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7116: sipush #165
    //   7119: iaload
    //   7120: iaload
    //   7121: aaload
    //   7122: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7125: invokestatic llllIIIlI : (I)Z
    //   7128: invokestatic lllIllllIlII : (I)Z
    //   7131: ifeq -> 7179
    //   7134: aload_0
    //   7135: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7138: invokevirtual getBedDestroyManager : ()Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyManager;
    //   7141: aload_3
    //   7142: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   7145: invokeinterface size : ()I
    //   7150: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7153: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7156: bipush #100
    //   7158: iaload
    //   7159: iaload
    //   7160: imul
    //   7161: aload_0
    //   7162: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7165: invokevirtual getBedDestroyManager : ()Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyManager;
    //   7168: invokevirtual getBedDestroys : ()Ljava/util/HashMap;
    //   7171: invokevirtual size : ()I
    //   7174: idiv
    //   7175: invokestatic valueOf : (I)Ljava/lang/String;
    //   7178: areturn
    //   7179: aload_2
    //   7180: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7183: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7186: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7189: sipush #166
    //   7192: iaload
    //   7193: iaload
    //   7194: aaload
    //   7195: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7198: invokestatic llllIIIlI : (I)Z
    //   7201: invokestatic lllIllllIlII : (I)Z
    //   7204: ifeq -> 7368
    //   7207: aload_3
    //   7208: invokevirtual getBedDestroy : ()Ljava/lang/String;
    //   7211: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   7214: invokestatic lllIllllIlII : (I)Z
    //   7217: ifeq -> 7335
    //   7220: aload_0
    //   7221: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7224: invokevirtual getBedDestroyManager : ()Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyManager;
    //   7227: aload_3
    //   7228: invokevirtual getBedDestroy : ()Ljava/lang/String;
    //   7231: invokevirtual getBedDestroy : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroy;
    //   7234: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   7237: invokestatic lllIllllIlII : (I)Z
    //   7240: ifeq -> 7335
    //   7243: aload_0
    //   7244: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7247: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   7250: aload_3
    //   7251: invokevirtual getLanguage : ()Ljava/lang/String;
    //   7254: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   7257: new java/lang/StringBuilder
    //   7260: dup
    //   7261: invokespecial <init> : ()V
    //   7264: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7267: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7270: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7273: sipush #167
    //   7276: iaload
    //   7277: iaload
    //   7278: aaload
    //   7279: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   7282: aload_3
    //   7283: invokevirtual getBedDestroy : ()Ljava/lang/String;
    //   7286: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   7289: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   7292: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   7295: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   7298: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7301: bipush #17
    //   7303: iaload
    //   7304: aaload
    //   7305: invokevirtual length : ()I
    //   7308: ldc ''
    //   7310: invokevirtual length : ()I
    //   7313: pop2
    //   7314: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7317: bipush #50
    //   7319: iaload
    //   7320: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7323: bipush #55
    //   7325: iaload
    //   7326: ixor
    //   7327: invokestatic lllIlllllllI : (I)Z
    //   7330: ifeq -> 7367
    //   7333: aconst_null
    //   7334: areturn
    //   7335: aload_0
    //   7336: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7339: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   7342: aload_3
    //   7343: invokevirtual getLanguage : ()Ljava/lang/String;
    //   7346: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   7349: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7352: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7355: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7358: sipush #168
    //   7361: iaload
    //   7362: iaload
    //   7363: aaload
    //   7364: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   7367: areturn
    //   7368: aload_2
    //   7369: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7372: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7375: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7378: sipush #169
    //   7381: iaload
    //   7382: iaload
    //   7383: aaload
    //   7384: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7387: invokestatic llllIIIlI : (I)Z
    //   7390: invokestatic lllIllllIlII : (I)Z
    //   7393: ifeq -> 7416
    //   7396: aload_0
    //   7397: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7400: invokevirtual getWoodSkinManager : ()Lcom/axeelheaven/hbedwars/cosmetics/woodskins/WoodSkinManager;
    //   7403: aload_3
    //   7404: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   7407: invokeinterface size : ()I
    //   7412: invokestatic valueOf : (I)Ljava/lang/String;
    //   7415: areturn
    //   7416: aload_2
    //   7417: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7420: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7423: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7426: sipush #170
    //   7429: iaload
    //   7430: iaload
    //   7431: aaload
    //   7432: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7435: invokestatic llllIIIlI : (I)Z
    //   7438: invokestatic lllIllllIlII : (I)Z
    //   7441: ifeq -> 7461
    //   7444: aload_0
    //   7445: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7448: invokevirtual getWoodSkinManager : ()Lcom/axeelheaven/hbedwars/cosmetics/woodskins/WoodSkinManager;
    //   7451: invokevirtual getWoodSkins : ()Ljava/util/HashMap;
    //   7454: invokevirtual size : ()I
    //   7457: invokestatic valueOf : (I)Ljava/lang/String;
    //   7460: areturn
    //   7461: aload_2
    //   7462: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7465: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7468: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7471: sipush #171
    //   7474: iaload
    //   7475: iaload
    //   7476: aaload
    //   7477: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7480: invokestatic llllIIIlI : (I)Z
    //   7483: invokestatic lllIllllIlII : (I)Z
    //   7486: ifeq -> 7534
    //   7489: aload_0
    //   7490: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7493: invokevirtual getWoodSkinManager : ()Lcom/axeelheaven/hbedwars/cosmetics/woodskins/WoodSkinManager;
    //   7496: aload_3
    //   7497: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   7500: invokeinterface size : ()I
    //   7505: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7508: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7511: bipush #100
    //   7513: iaload
    //   7514: iaload
    //   7515: imul
    //   7516: aload_0
    //   7517: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7520: invokevirtual getWoodSkinManager : ()Lcom/axeelheaven/hbedwars/cosmetics/woodskins/WoodSkinManager;
    //   7523: invokevirtual getWoodSkins : ()Ljava/util/HashMap;
    //   7526: invokevirtual size : ()I
    //   7529: idiv
    //   7530: invokestatic valueOf : (I)Ljava/lang/String;
    //   7533: areturn
    //   7534: aload_2
    //   7535: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7538: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7541: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7544: bipush #125
    //   7546: iaload
    //   7547: iaload
    //   7548: aaload
    //   7549: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7552: invokestatic llllIIIlI : (I)Z
    //   7555: invokestatic lllIllllIlII : (I)Z
    //   7558: ifeq -> 7737
    //   7561: aload_3
    //   7562: invokevirtual getWoodSkin : ()Ljava/lang/String;
    //   7565: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   7568: invokestatic lllIllllIlII : (I)Z
    //   7571: ifeq -> 7704
    //   7574: aload_0
    //   7575: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7578: invokevirtual getWoodSkinManager : ()Lcom/axeelheaven/hbedwars/cosmetics/woodskins/WoodSkinManager;
    //   7581: aload_3
    //   7582: invokevirtual getWoodSkin : ()Ljava/lang/String;
    //   7585: invokevirtual getWoodSkin : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/cosmetics/woodskins/WoodSkin;
    //   7588: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   7591: invokestatic lllIllllIlII : (I)Z
    //   7594: ifeq -> 7704
    //   7597: aload_0
    //   7598: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7601: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   7604: aload_3
    //   7605: invokevirtual getLanguage : ()Ljava/lang/String;
    //   7608: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   7611: new java/lang/StringBuilder
    //   7614: dup
    //   7615: invokespecial <init> : ()V
    //   7618: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7621: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7624: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7627: sipush #172
    //   7630: iaload
    //   7631: iaload
    //   7632: aaload
    //   7633: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   7636: aload_3
    //   7637: invokevirtual getWoodSkin : ()Ljava/lang/String;
    //   7640: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   7643: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   7646: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   7649: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   7652: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7655: bipush #18
    //   7657: iaload
    //   7658: aaload
    //   7659: invokevirtual length : ()I
    //   7662: ldc ''
    //   7664: invokevirtual length : ()I
    //   7667: pop2
    //   7668: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7671: bipush #109
    //   7673: iaload
    //   7674: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7677: bipush #46
    //   7679: iaload
    //   7680: ixor
    //   7681: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7684: bipush #7
    //   7686: iaload
    //   7687: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7690: bipush #64
    //   7692: iaload
    //   7693: ixor
    //   7694: ixor
    //   7695: ineg
    //   7696: invokestatic lllIllllllII : (I)Z
    //   7699: ifeq -> 7736
    //   7702: aconst_null
    //   7703: areturn
    //   7704: aload_0
    //   7705: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7708: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   7711: aload_3
    //   7712: invokevirtual getLanguage : ()Ljava/lang/String;
    //   7715: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   7718: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7721: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7724: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7727: sipush #173
    //   7730: iaload
    //   7731: iaload
    //   7732: aaload
    //   7733: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   7736: areturn
    //   7737: aload_2
    //   7738: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7741: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7744: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7747: sipush #174
    //   7750: iaload
    //   7751: iaload
    //   7752: aaload
    //   7753: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7756: invokestatic llllIIIlI : (I)Z
    //   7759: invokestatic lllIllllIlII : (I)Z
    //   7762: ifeq -> 7785
    //   7765: aload_0
    //   7766: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7769: invokevirtual getTopperManager : ()Lcom/axeelheaven/hbedwars/cosmetics/toppers/TopperManager;
    //   7772: aload_3
    //   7773: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   7776: invokeinterface size : ()I
    //   7781: invokestatic valueOf : (I)Ljava/lang/String;
    //   7784: areturn
    //   7785: aload_2
    //   7786: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7789: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7792: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7795: sipush #175
    //   7798: iaload
    //   7799: iaload
    //   7800: aaload
    //   7801: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7804: invokestatic llllIIIlI : (I)Z
    //   7807: invokestatic lllIllllIlII : (I)Z
    //   7810: ifeq -> 7830
    //   7813: aload_0
    //   7814: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7817: invokevirtual getTopperManager : ()Lcom/axeelheaven/hbedwars/cosmetics/toppers/TopperManager;
    //   7820: invokevirtual getToppers : ()Ljava/util/HashMap;
    //   7823: invokevirtual size : ()I
    //   7826: invokestatic valueOf : (I)Ljava/lang/String;
    //   7829: areturn
    //   7830: aload_2
    //   7831: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7834: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7837: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7840: sipush #176
    //   7843: iaload
    //   7844: iaload
    //   7845: aaload
    //   7846: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7849: invokestatic llllIIIlI : (I)Z
    //   7852: invokestatic lllIllllIlII : (I)Z
    //   7855: ifeq -> 7903
    //   7858: aload_0
    //   7859: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7862: invokevirtual getTopperManager : ()Lcom/axeelheaven/hbedwars/cosmetics/toppers/TopperManager;
    //   7865: aload_3
    //   7866: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   7869: invokeinterface size : ()I
    //   7874: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7877: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7880: bipush #100
    //   7882: iaload
    //   7883: iaload
    //   7884: imul
    //   7885: aload_0
    //   7886: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7889: invokevirtual getTopperManager : ()Lcom/axeelheaven/hbedwars/cosmetics/toppers/TopperManager;
    //   7892: invokevirtual getToppers : ()Ljava/util/HashMap;
    //   7895: invokevirtual size : ()I
    //   7898: idiv
    //   7899: invokestatic valueOf : (I)Ljava/lang/String;
    //   7902: areturn
    //   7903: aload_2
    //   7904: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7907: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7910: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7913: sipush #177
    //   7916: iaload
    //   7917: iaload
    //   7918: aaload
    //   7919: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   7922: invokestatic llllIIIlI : (I)Z
    //   7925: invokestatic lllIllllIlII : (I)Z
    //   7928: ifeq -> 8240
    //   7931: aload_3
    //   7932: invokevirtual getTopper : ()Ljava/lang/String;
    //   7935: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   7938: invokestatic lllIllllIlII : (I)Z
    //   7941: ifeq -> 8207
    //   7944: aload_0
    //   7945: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7948: invokevirtual getTopperManager : ()Lcom/axeelheaven/hbedwars/cosmetics/toppers/TopperManager;
    //   7951: aload_3
    //   7952: invokevirtual getTopper : ()Ljava/lang/String;
    //   7955: invokevirtual getTopper : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/cosmetics/toppers/Topper;
    //   7958: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   7961: invokestatic lllIllllIlII : (I)Z
    //   7964: ifeq -> 8207
    //   7967: aload_0
    //   7968: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   7971: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   7974: aload_3
    //   7975: invokevirtual getLanguage : ()Ljava/lang/String;
    //   7978: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   7981: new java/lang/StringBuilder
    //   7984: dup
    //   7985: invokespecial <init> : ()V
    //   7988: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   7991: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   7994: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   7997: bipush #127
    //   7999: iaload
    //   8000: iaload
    //   8001: aaload
    //   8002: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   8005: aload_3
    //   8006: invokevirtual getTopper : ()Ljava/lang/String;
    //   8009: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   8012: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   8015: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   8018: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   8021: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8024: bipush #19
    //   8026: iaload
    //   8027: aaload
    //   8028: invokevirtual length : ()I
    //   8031: ldc ''
    //   8033: invokevirtual length : ()I
    //   8036: pop2
    //   8037: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8040: bipush #98
    //   8042: iaload
    //   8043: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8046: bipush #25
    //   8048: iaload
    //   8049: iadd
    //   8050: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8053: bipush #110
    //   8055: iaload
    //   8056: isub
    //   8057: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8060: sipush #178
    //   8063: iaload
    //   8064: iadd
    //   8065: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8068: bipush #35
    //   8070: iaload
    //   8071: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8074: bipush #32
    //   8076: iaload
    //   8077: iadd
    //   8078: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8081: sipush #179
    //   8084: iaload
    //   8085: isub
    //   8086: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8089: bipush #8
    //   8091: iaload
    //   8092: iadd
    //   8093: ixor
    //   8094: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8097: bipush #115
    //   8099: iaload
    //   8100: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8103: bipush #29
    //   8105: iaload
    //   8106: ixor
    //   8107: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8110: sipush #180
    //   8113: iaload
    //   8114: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8117: sipush #153
    //   8120: iaload
    //   8121: ixor
    //   8122: ixor
    //   8123: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8126: sipush #181
    //   8129: iaload
    //   8130: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8133: sipush #176
    //   8136: iaload
    //   8137: iadd
    //   8138: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8141: sipush #182
    //   8144: iaload
    //   8145: isub
    //   8146: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8149: bipush #106
    //   8151: iaload
    //   8152: iadd
    //   8153: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8156: bipush #97
    //   8158: iaload
    //   8159: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8162: bipush #75
    //   8164: iaload
    //   8165: iadd
    //   8166: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8169: sipush #137
    //   8172: iaload
    //   8173: isub
    //   8174: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8177: sipush #158
    //   8180: iaload
    //   8181: iadd
    //   8182: ixor
    //   8183: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   8186: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8189: bipush #20
    //   8191: iaload
    //   8192: aaload
    //   8193: invokevirtual length : ()I
    //   8196: ineg
    //   8197: ixor
    //   8198: iand
    //   8199: invokestatic lllIllllIllI : (II)Z
    //   8202: ifeq -> 8239
    //   8205: aconst_null
    //   8206: areturn
    //   8207: aload_0
    //   8208: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   8211: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   8214: aload_3
    //   8215: invokevirtual getLanguage : ()Ljava/lang/String;
    //   8218: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   8221: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   8224: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   8227: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8230: sipush #183
    //   8233: iaload
    //   8234: iaload
    //   8235: aaload
    //   8236: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   8239: areturn
    //   8240: aload_2
    //   8241: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   8244: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   8247: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8250: sipush #184
    //   8253: iaload
    //   8254: iaload
    //   8255: aaload
    //   8256: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   8259: invokestatic llllIIIlI : (I)Z
    //   8262: invokestatic lllIllllIlII : (I)Z
    //   8265: ifeq -> 8288
    //   8268: aload_0
    //   8269: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   8272: invokevirtual getGlyphManager : ()Lcom/axeelheaven/hbedwars/cosmetics/glyphs/GlyphManager;
    //   8275: aload_3
    //   8276: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   8279: invokeinterface size : ()I
    //   8284: invokestatic valueOf : (I)Ljava/lang/String;
    //   8287: areturn
    //   8288: aload_2
    //   8289: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   8292: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   8295: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8298: sipush #178
    //   8301: iaload
    //   8302: iaload
    //   8303: aaload
    //   8304: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   8307: invokestatic llllIIIlI : (I)Z
    //   8310: invokestatic lllIllllIlII : (I)Z
    //   8313: ifeq -> 8333
    //   8316: aload_0
    //   8317: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   8320: invokevirtual getGlyphManager : ()Lcom/axeelheaven/hbedwars/cosmetics/glyphs/GlyphManager;
    //   8323: invokevirtual getGlyphs : ()Ljava/util/HashMap;
    //   8326: invokevirtual size : ()I
    //   8329: invokestatic valueOf : (I)Ljava/lang/String;
    //   8332: areturn
    //   8333: aload_2
    //   8334: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   8337: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   8340: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8343: sipush #185
    //   8346: iaload
    //   8347: iaload
    //   8348: aaload
    //   8349: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   8352: invokestatic llllIIIlI : (I)Z
    //   8355: invokestatic lllIllllIlII : (I)Z
    //   8358: ifeq -> 8406
    //   8361: aload_0
    //   8362: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   8365: invokevirtual getGlyphManager : ()Lcom/axeelheaven/hbedwars/cosmetics/glyphs/GlyphManager;
    //   8368: aload_3
    //   8369: invokevirtual getPurchased : (Lcom/axeelheaven/hbedwars/database/profile/HData;)Ljava/util/List;
    //   8372: invokeinterface size : ()I
    //   8377: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   8380: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8383: bipush #100
    //   8385: iaload
    //   8386: iaload
    //   8387: imul
    //   8388: aload_0
    //   8389: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   8392: invokevirtual getGlyphManager : ()Lcom/axeelheaven/hbedwars/cosmetics/glyphs/GlyphManager;
    //   8395: invokevirtual getGlyphs : ()Ljava/util/HashMap;
    //   8398: invokevirtual size : ()I
    //   8401: idiv
    //   8402: invokestatic valueOf : (I)Ljava/lang/String;
    //   8405: areturn
    //   8406: aload_2
    //   8407: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   8410: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   8413: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8416: sipush #186
    //   8419: iaload
    //   8420: iaload
    //   8421: aaload
    //   8422: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   8425: invokestatic llllIIIlI : (I)Z
    //   8428: invokestatic lllIllllIlII : (I)Z
    //   8431: ifeq -> 8583
    //   8434: aload_3
    //   8435: invokevirtual getGlyph : ()Ljava/lang/String;
    //   8438: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   8441: invokestatic lllIllllIlII : (I)Z
    //   8444: ifeq -> 8550
    //   8447: aload_0
    //   8448: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   8451: invokevirtual getGlyphManager : ()Lcom/axeelheaven/hbedwars/cosmetics/glyphs/GlyphManager;
    //   8454: aload_3
    //   8455: invokevirtual getGlyph : ()Ljava/lang/String;
    //   8458: invokevirtual getGlyph : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/cosmetics/glyphs/Glyph;
    //   8461: invokestatic llllIIIll : (Ljava/lang/Object;)Z
    //   8464: invokestatic lllIllllIlII : (I)Z
    //   8467: ifeq -> 8550
    //   8470: aload_0
    //   8471: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   8474: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   8477: aload_3
    //   8478: invokevirtual getLanguage : ()Ljava/lang/String;
    //   8481: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   8484: new java/lang/StringBuilder
    //   8487: dup
    //   8488: invokespecial <init> : ()V
    //   8491: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   8494: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   8497: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8500: sipush #187
    //   8503: iaload
    //   8504: iaload
    //   8505: aaload
    //   8506: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   8509: aload_3
    //   8510: invokevirtual getGlyph : ()Ljava/lang/String;
    //   8513: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   8516: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   8519: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   8522: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   8525: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8528: bipush #21
    //   8530: iaload
    //   8531: aaload
    //   8532: invokevirtual length : ()I
    //   8535: ldc ''
    //   8537: invokevirtual length : ()I
    //   8540: pop2
    //   8541: aconst_null
    //   8542: invokestatic lllIllllllll : (Ljava/lang/Object;)Z
    //   8545: ifeq -> 8582
    //   8548: aconst_null
    //   8549: areturn
    //   8550: aload_0
    //   8551: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   8554: invokevirtual getLanguageManager : ()Lcom/axeelheaven/hbedwars/languague/LanguageManager;
    //   8557: aload_3
    //   8558: invokevirtual getLanguage : ()Ljava/lang/String;
    //   8561: invokevirtual getLanguage : (Ljava/lang/String;)Lcom/axeelheaven/hbedwars/languague/Language;
    //   8564: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIIlll : [Ljava/lang/String;
    //   8567: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   8570: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   8573: sipush #188
    //   8576: iaload
    //   8577: iaload
    //   8578: aaload
    //   8579: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   8582: areturn
    //   8583: aconst_null
    //   8584: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   17	8568	3	llllllllllllllllIlIlllIlIIlIlIlI	Lcom/axeelheaven/hbedwars/database/profile/HData;
    //   0	8585	6	llllllllllllllllIlIlllIlIIIllIIl	I
    //   0	8585	2	llllllllllllllllIlIlllIlIIlIlllI	Ljava/lang/String;
    //   3884	86	4	llllllllllllllllIlIlllIlIIlIIllI	Ljava/lang/String;
    //   0	8585	1	llllllllllllllllIlIlllIlIIIIIllI	Lorg/bukkit/entity/Player;
    //   1293	31	5	llllllllllllllllIlIlllIIlllIIlIl	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3939	31	5	llllllllllllllllIlIlllIlIIIlllll	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3204	31	5	llllllllllllllllIlIlllIlIIIllIll	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   4377	30	5	llllllllllllllllIlIlllIIlllIIIIl	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2855	86	4	llllllllllllllllIlIlllIlIIIIIlII	Ljava/lang/String;
    //   3590	86	4	llllllllllllllllIlIlllIlIIlIIIIl	Ljava/lang/String;
    //   2414	86	4	llllllllllllllllIlIlllIIllllllIl	Ljava/lang/String;
    //   1881	31	5	llllllllllllllllIlIlllIIlllIIIll	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   0	8585	2	llllllllllllllllIlIlllIIllIlllIl	F
    //   3498	31	5	llllllllllllllllIlIlllIIllllllll	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3296	86	4	llllllllllllllllIlIlllIlIIIllllI	Ljava/lang/String;
    //   3149	86	4	llllllllllllllllIlIlllIIllllllII	Ljava/lang/String;
    //   1238	86	4	llllllllllllllllIlIlllIlIIIlllII	Ljava/lang/String;
    //   3002	86	4	llllllllllllllllIlIlllIIlllIllII	Ljava/lang/String;
    //   0	8585	4	llllllllllllllllIlIlllIIllIllIIl	Ljava/lang/Exception;
    //   0	8585	0	llllllllllllllllIlIlllIIlllIIIII	I
    //   2616	31	5	llllllllllllllllIlIlllIIlllIlIlI	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   0	8585	1	llllllllllllllllIlIlllIIllIlllll	Ljava/lang/Exception;
    //   2708	86	4	llllllllllllllllIlIlllIIllllIlIl	Ljava/lang/String;
    //   4323	84	4	llllllllllllllllIlIlllIIllllIIll	Ljava/lang/String;
    //   3645	31	5	llllllllllllllllIlIlllIlIIIIllll	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   1973	86	4	llllllllllllllllIlIlllIlIIlIIIlI	Ljava/lang/String;
    //   0	8585	0	llllllllllllllllIlIlllIlIIlIIIII	Lcom/axeelheaven/hbedwars/api/hooks/PlaceholderHook;
    //   302	10	8	llllllllllllllllIlIlllIIlllIllIl	Lcom/axeelheaven/hbedwars/api/arena/ArenaData;
    //   107	273	5	llllllllllllllllIlIlllIIlllIlIII	I
    //   4178	84	4	llllllllllllllllIlIlllIlIIlIIlII	Ljava/lang/String;
    //   2028	31	5	llllllllllllllllIlIlllIlIIIlIlIl	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   85	295	4	llllllllllllllllIlIlllIIlllIlIIl	Lcom/axeelheaven/hbedwars/arena/groups/Group;
    //   116	264	6	llllllllllllllllIlIlllIIlllIlllI	Ljava/util/Collection;
    //   2910	31	5	llllllllllllllllIlIlllIlIIIlIlII	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2175	31	5	llllllllllllllllIlIlllIlIIIlllIl	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   0	8585	5	llllllllllllllllIlIlllIIlllIllll	Ljava/lang/String;
    //   2267	86	4	llllllllllllllllIlIlllIlIIIlIIII	Ljava/lang/String;
    //   1587	31	5	llllllllllllllllIlIlllIlIIlIllIl	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   1826	86	4	llllllllllllllllIlIlllIlIIIlIIIl	Ljava/lang/String;
    //   1532	86	4	llllllllllllllllIlIlllIlIIlIIlll	Ljava/lang/String;
    //   4031	86	4	llllllllllllllllIlIlllIIllllIIIl	Ljava/lang/String;
    //   0	8585	7	llllllllllllllllIlIlllIlIIIllIII	Ljava/lang/String;
    //   0	8585	6	llllllllllllllllIlIlllIIllIlIllI	B
    //   0	8585	7	llllllllllllllllIlIlllIIllIlIlII	F
    //   3443	86	4	llllllllllllllllIlIlllIIlllIIllI	Ljava/lang/String;
    //   4232	30	5	llllllllllllllllIlIlllIlIIIlIlll	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   3792	31	5	llllllllllllllllIlIlllIlIIIIlllI	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2561	86	4	llllllllllllllllIlIlllIlIIIlIIlI	Ljava/lang/String;
    //   1440	31	5	llllllllllllllllIlIlllIlIIIIllIl	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   4086	31	5	llllllllllllllllIlIlllIlIIIIlIlI	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   1385	86	4	llllllllllllllllIlIlllIlIIIllIlI	Ljava/lang/String;
    //   2763	31	5	llllllllllllllllIlIlllIIlllllIIl	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   0	8585	0	llllllllllllllllIlIlllIIlllIlIll	S
    //   1091	86	4	llllllllllllllllIlIlllIIlllIIlII	Ljava/lang/String;
    //   0	8585	1	llllllllllllllllIlIlllIlIIIIIIlI	C
    //   3351	31	5	llllllllllllllllIlIlllIIllllIlll	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   2120	86	4	llllllllllllllllIlIlllIIlllIIlll	Ljava/lang/String;
    //   1734	31	5	llllllllllllllllIlIlllIlIIIIIlll	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   0	8585	8	llllllllllllllllIlIlllIlIIIIllII	D
    //   4522	30	5	llllllllllllllllIlIlllIlIIlIIlIl	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   1146	31	5	llllllllllllllllIlIlllIlIIIlIIll	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   0	8585	4	llllllllllllllllIlIlllIlIIlIllII	Ljava/lang/Exception;
    //   0	8585	3	llllllllllllllllIlIlllIlIIIlIllI	J
    //   1679	86	4	llllllllllllllllIlIlllIlIIlIIIll	Ljava/lang/String;
    //   2322	31	5	llllllllllllllllIlIlllIlIIlIlIIl	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   4468	84	4	llllllllllllllllIlIlllIlIIIIlIIl	Ljava/lang/String;
    //   3737	86	4	llllllllllllllllIlIlllIIlllllIll	Ljava/lang/String;
    //   3057	31	5	llllllllllllllllIlIlllIlIIlIlIll	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   0	8585	8	llllllllllllllllIlIlllIIllIlIIlI	Ljava/lang/String;
    //   0	8585	3	llllllllllllllllIlIlllIIllIllIll	Ljava/lang/String;
    //   0	8585	2	llllllllllllllllIlIlllIlIIIIIIIl	D
    //   2469	31	5	llllllllllllllllIlIlllIlIIlIlIII	Lcom/axeelheaven/hbedwars/database/profile/GroupData;
    //   0	8585	5	llllllllllllllllIlIlllIIllIllIII	Ljava/lang/Exception;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   116	264	6	llllllllllllllllIlIlllIIlllIlllI	Ljava/util/Collection<Lcom/axeelheaven/hbedwars/api/arena/ArenaData;>;
  }
  
  private static String lllIlllll(String llllllllllllllllIlIlllIIIIIlllll, String llllllllllllllllIlIlllIIIIIllIll) {
    try {
      SecretKeySpec llllllllllllllllIlIlllIIIIlIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(llIIlIllll[llIIllIlII[437]]).digest(llllllllllllllllIlIlllIIIIIllIll.getBytes(StandardCharsets.UTF_8)), lIlIlIII[llIIllIlII[8]]), llIIlIllll[llIIllIlII[438]]);
      Cipher llllllllllllllllIlIlllIIIIIlllII = Cipher.getInstance(llIIlIllll[llIIllIlII[439]]);
      llllllllllllllllIlIlllIIIIIlllII.init(lIlIlIII[llIIllIlII[1]], llllllllllllllllIlIlllIIIIlIIIII);
      return new String(llllllllllllllllIlIlllIIIIIlllII.doFinal(Base64.getDecoder().decode(llllllllllllllllIlIlllIIIIIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception llllllllllllllllIlIlllIIIIlIIIIl) {
      Exception exception1;
      exception1.printStackTrace();
      return null;
    } 
  }
  
  private static boolean lllIlllllllI(int llllllllllllllllIlIllIlllIIIlIIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 <= null);
  }
  
  private static void lIllIIIIllIl() {
    llIIlIllll = new String[llIIllIlII[445]];
    llIIlIllll[llIIllIlII[3]] = lIlIllllIlIl("", "BKEWg");
    llIIlIllll[llIIllIlII[0]] = lIlIllllIllI("cSiNifHo1/E=", "cksBE");
    llIIlIllll[llIIllIlII[1]] = lIlIllllIllI("GV/SCN++eaA=", "eOswV");
    llIIlIllll[llIIllIlII[2]] = lIlIllllIlIl("", "UiGTA");
    llIIlIllll[llIIllIlII[4]] = lIlIllllIlll("lgKKaunbCD8=", "AFWWR");
    llIIlIllll[llIIllIlII[5]] = lIlIllllIllI("L1Z9TBaYULE=", "QDNxJ");
    llIIlIllll[llIIllIlII[6]] = lIlIllllIlll("34n1iuWeSv8=", "UtJbh");
    llIIlIllll[llIIllIlII[7]] = lIlIllllIlIl("", "zLBti");
    llIIlIllll[llIIllIlII[8]] = lIlIllllIllI("KuQvK/fln7o=", "nQSVM");
    llIIlIllll[llIIllIlII[9]] = lIlIllllIllI("mNDD76vzNM0=", "DcGgh");
    llIIlIllll[llIIllIlII[10]] = lIlIllllIlIl("", "WyyEQ");
    llIIlIllll[llIIllIlII[11]] = lIlIllllIllI("pITS4RfOPho=", "smBYx");
    llIIlIllll[llIIllIlII[12]] = lIlIllllIlll("NIqvUuldGUY=", "cZJBf");
    llIIlIllll[llIIllIlII[13]] = lIlIllllIllI("HclyCOk2Src=", "DqMxn");
    llIIlIllll[llIIllIlII[14]] = lIlIllllIllI("nKedaz7gwQE=", "Mfbbz");
    llIIlIllll[llIIllIlII[15]] = lIlIllllIlIl("UkI=", "rbtOZ");
    llIIlIllll[llIIllIlII[16]] = lIlIllllIlll("iM6YPmjRkwk=", "CynnF");
    llIIlIllll[llIIllIlII[17]] = lIlIllllIlll("0ltUIJLVEQM=", "yBabF");
    llIIlIllll[llIIllIlII[18]] = lIlIllllIlll("L8XtFvDiVnk=", "uaolx");
    llIIlIllll[llIIllIlII[19]] = lIlIllllIlll("J9ztHuKpmc4=", "jaKxO");
    llIIlIllll[llIIllIlII[20]] = lIlIllllIlll("vJNSFgAwZy0=", "RHccT");
    llIIlIllll[llIIllIlII[21]] = lIlIllllIllI("KYHViNa4Su8=", "nWHJV");
    llIIlIllll[llIIllIlII[22]] = lIlIllllIlll("2JADxK1fJfM=", "uoggX");
    llIIlIllll[llIIllIlII[23]] = lIlIllllIlll("TWJQ8ilhUQQ=", "QjoZT");
    llIIlIllll[llIIllIlII[24]] = lIlIllllIlll("2DZevWKYrWU=", "xWfip");
    llIIlIllll[llIIllIlII[25]] = lIlIllllIllI("M2WgH5h6hOZWDODTw07c48sLOS9HbcEGcSqlPPBOWGU=", "UKHoB");
    llIIlIllll[llIIllIlII[26]] = lIlIllllIllI("YuMITEQmCds=", "ZwnLJ");
    llIIlIllll[llIIllIlII[27]] = lIlIllllIlll("uvbsC8EwRQgpnwePzy1Rzp7D3k+vqwwmb69+/bkK/as=", "WXcUh");
    llIIlIllll[llIIllIlII[28]] = lIlIllllIlIl("OBYmERU=", "iwLWM");
    llIIlIllll[llIIllIlII[29]] = lIlIllllIllI("+tcSdIqkcru0Tdxnmt3QOQ==", "NYzaf");
    llIIlIllll[llIIllIlII[30]] = lIlIllllIllI("LGOnnexx8es=", "eoahW");
    llIIlIllll[llIIllIlII[31]] = lIlIllllIlll("g4OL5grVVuRh5qrpVA4GDdAJINbHWYc+i5sNt0RcaQ1dD/lNs3ACQA==", "kKvFX");
    llIIlIllll[llIIllIlII[32]] = lIlIllllIlIl("OwYADAo=", "QPhHg");
    llIIlIllll[llIIllIlII[33]] = lIlIllllIlIl("PQcoPh4LKVU0MBg3LxBqTg==", "sFawW");
    llIIlIllll[llIIllIlII[34]] = lIlIllllIlIl("GzkcEiE=", "HZyTd");
    llIIlIllll[llIIllIlII[35]] = lIlIllllIlll("axLYN3GUH8UQZ8QElf3wEelFCSQ7HC4tHB1OkduKNGw=", "zYWVr");
    llIIlIllll[llIIllIlII[36]] = lIlIllllIllI("IjmH9NApeMo=", "PbVMC");
    llIIlIllll[llIIllIlII[37]] = lIlIllllIlIl("EjofciAfLTJlIRU5MiQLMS8AfC8kGmd3", "tKZJE");
    llIIlIllll[llIIllIlII[38]] = lIlIllllIlIl("PSQsGzc=", "xfebN");
    llIIlIllll[llIIllIlII[39]] = lIlIllllIlll("LR9MoY/VLIpKQNA7Z01iPQ==", "rpwNz");
    llIIlIllll[llIIllIlII[40]] = lIlIllllIlll("wML9dsdlAKk=", "hPmRH");
    llIIlIllll[llIIllIlII[41]] = lIlIllllIllI("qnaIodcYhw/sQU4Yjk+E8LPxpxzrACayT3O6MAnzBzU=", "izPDS");
    llIIlIllll[llIIllIlII[42]] = lIlIllllIllI("1LJIprzDAE8=", "Jpznl");
    llIIlIllll[llIIllIlII[43]] = lIlIllllIllI("Ga9obm/YixjZqbxRMjretg==", "KGfUe");
    llIIlIllll[llIIllIlII[44]] = lIlIllllIllI("bD83DRmlHsc=", "zWmOi");
    llIIlIllll[llIIllIlII[45]] = lIlIllllIllI("9qWX4h8Jj/bSLryOZoclZA==", "LhyHb");
    llIIlIllll[llIIllIlII[46]] = lIlIllllIlll("PnzTlgh3ex0=", "AVIEF");
    llIIlIllll[llIIllIlII[47]] = lIlIllllIllI("/T0dnmaRJphta9Ps/B2twC271Poqqnn520m8ck4Rwxw=", "NrcwK");
    llIIlIllll[llIIllIlII[48]] = lIlIllllIlll("B8A8MOLDVMQ=", "QsVqP");
    llIIlIllll[llIIllIlII[49]] = lIlIllllIlIl("DCgjDhU3CTE=", "MzTWW");
    llIIlIllll[llIIllIlII[50]] = lIlIllllIlIl("JTY4Cg4=", "WSMoZ");
    llIIlIllll[llIIllIlII[51]] = lIlIllllIlIl("TghnCA==", "zxUfB");
    llIIlIllll[llIIllIlII[52]] = lIlIllllIllI("0CboGY8bxYs=", "alwIE");
    llIIlIllll[llIIllIlII[53]] = lIlIllllIllI("s22GebqiGKe7p9uz0K7eIXkNKtKS4iuICDuCEGiBsYI=", "PzdmE");
    llIIlIllll[llIIllIlII[54]] = lIlIllllIllI("RzQrLIrYYz4=", "blFBb");
    llIIlIllll[llIIllIlII[55]] = lIlIllllIlIl("IzgHLgwREBUMET89NjgiUAEkdQItFRd4CCQyEg==", "fQpAE");
    llIIlIllll[llIIllIlII[56]] = lIlIllllIllI("uiexekptmcM=", "IGqjA");
    llIIlIllll[llIIllIlII[57]] = lIlIllllIlll("QVKJ74LXd1nUCoR9Az/2AFS+UVb1ogGB", "bVkvr");
    llIIlIllll[llIIllIlII[58]] = lIlIllllIllI("ZFsjopwkYC0=", "PXPXi");
    llIIlIllll[llIIllIlII[59]] = lIlIllllIlIl("EDohMgU3OxUKAAFv", "bRRdN");
    llIIlIllll[llIIllIlII[60]] = lIlIllllIlll("u/X3iF9YMGQ=", "bpHJk");
    llIIlIllll[llIIllIlII[61]] = lIlIllllIlIl("IR9vGikRJS8SJQVx", "DLYuB");
    llIIlIllll[llIIllIlII[62]] = lIlIllllIlll("vNrFXFD8hTg=", "GsJlR");
    llIIlIllll[llIIllIlII[63]] = lIlIllllIlll("tJfef6ggSnhodSQmFiuOvvaytpIZydMi", "ticER");
    llIIlIllll[llIIllIlII[64]] = lIlIllllIllI("7jngueURQ04=", "gFgST");
    llIIlIllll[llIIllIlII[65]] = lIlIllllIllI("kxr0qcn+DJN9tTx1DckzOg==", "iKPiY");
    llIIlIllll[llIIllIlII[66]] = lIlIllllIlIl("FAAeEgY=", "DKZyE");
    llIIlIllll[llIIllIlII[67]] = lIlIllllIlIl("Yi1hCDYDFjgRPiEWNRsBOgFgDz4eKWp8", "IxWAW");
    llIIlIllll[llIIllIlII[68]] = lIlIllllIllI("SHOZw0VnGOw=", "PrHsf");
    llIIlIllll[llIIllIlII[69]] = lIlIllllIllI("X4SFVGA3MZ/hagaK8PpnBmm5amHeEZxfuL230TUkDFk=", "pIxZI");
    llIIlIllll[llIIllIlII[70]] = lIlIllllIlIl("MA4UCBM=", "IgRFe");
    llIIlIllll[llIIllIlII[71]] = lIlIllllIllI("wf/kCrUACmjKgGGtG4Y1Fw==", "ttKTS");
    llIIlIllll[llIIllIlII[72]] = lIlIllllIlll("sxrDK4sR2pY=", "wqpyq");
    llIIlIllll[llIIllIlII[73]] = lIlIllllIlll("D3CkrUOeQxN4QqRqiQF92w==", "CkbEN");
    llIIlIllll[llIIllIlII[74]] = lIlIllllIlIl("DT4XHzo=", "wvyOu");
    llIIlIllll[llIIllIlII[75]] = lIlIllllIlIl("FRx+ICw6ETYsCGo4AD0EIw==", "RvFno");
    llIIlIllll[llIIllIlII[76]] = lIlIllllIlIl("ABMyHiM=", "EJVzZ");
    llIIlIllll[llIIllIlII[77]] = lIlIllllIllI("LM0Exeb5AOY8eEcDgVnrINWAbBvGo8bQ", "pvLuf");
    llIIlIllll[llIIllIlII[78]] = lIlIllllIlIl("HhsAKws=", "LSLcJ");
    llIIlIllll[llIIllIlII[79]] = lIlIllllIlIl("ECk7LV8UXwQMGTZQ", "gmSUi");
    llIIlIllll[llIIllIlII[80]] = lIlIllllIllI("YjVODLd9it4=", "EhkSH");
    llIIlIllll[llIIllIlII[81]] = lIlIllllIlll("PWkCl4ULdqtxic+JShhhIA==", "bJdGj");
    llIIlIllll[llIIllIlII[82]] = lIlIllllIlIl("ISwpFjQ=", "BkgnF");
    llIIlIllll[llIIllIlII[83]] = lIlIllllIlIl("LwoQHD4AHFc=", "hIgsp");
    llIIlIllll[llIIllIlII[84]] = lIlIllllIlll("Cd7JL2Yp0I8=", "VOMMX");
    llIIlIllll[llIIllIlII[85]] = lIlIllllIlll("pjb8h0ZI+EcioEcboWEVjQ==", "KezqB");
    llIIlIllll[llIIllIlII[86]] = lIlIllllIllI("3sFagf/jEwE=", "PoPpq");
    llIIlIllll[llIIllIlII[87]] = lIlIllllIllI("SDDTC2Vg2rHShPsH8l3KWQ==", "YgKDK");
    llIIlIllll[llIIllIlII[88]] = lIlIllllIlIl("IAMiPis=", "svUth");
    llIIlIllll[llIIllIlII[89]] = lIlIllllIlIl("FxkZAAg5A2EbBSp8", "cATvk");
    llIIlIllll[llIIllIlII[90]] = lIlIllllIlll("SkaCc+NipsM=", "QZTPd");
    llIIlIllll[llIIllIlII[91]] = lIlIllllIlll("oA6N/526lalvBERB63QzR0vJGMgORVQe0NxEH8xDO9g=", "PNnfJ");
    llIIlIllll[llIIllIlII[92]] = lIlIllllIlIl("MCAqNCo=", "bPHMz");
    llIIlIllll[llIIllIlII[93]] = lIlIllllIlll("OpkO05awj9GR9jtiY+GXH78KSmxY1BlTs9wKZw+ucTM=", "gRKmo");
    llIIlIllll[llIIllIlII[94]] = lIlIllllIllI("eZ15yMO+5Cw=", "vWkkH");
    llIIlIllll[llIIllIlII[95]] = lIlIllllIlIl("DQMKKB8DKQkwPzBk", "aYpCk");
    llIIlIllll[llIIllIlII[96]] = lIlIllllIlIl("HjIVDiE=", "XPEfD");
    llIIlIllll[llIIllIlII[97]] = lIlIllllIllI("8xREy1V9Pa2/n1ey4SB2nQ==", "vNxmF");
    llIIlIllll[llIIllIlII[98]] = lIlIllllIllI("mTHQHTcM6aE=", "ivKBN");
    llIIlIllll[llIIllIlII[99]] = lIlIllllIlll("NqTsMMftoamML/mku+1PwA==", "qkPXN");
    llIIlIllll[llIIllIlII[100]] = lIlIllllIllI("Whl10K7VckA=", "gQYko");
    llIIlIllll[llIIllIlII[101]] = lIlIllllIlll("Iz/n91iCY9UXrdIYSypUZA==", "mLYJN");
    llIIlIllll[llIIllIlII[102]] = lIlIllllIlIl("IAA0OjY=", "MKRlU");
    llIIlIllll[llIIllIlII[103]] = lIlIllllIlIl("KB8nEWU/DA81FVxa", "lgfeP");
    llIIlIllll[llIIllIlII[104]] = lIlIllllIlll("W9UEZMbu1Gw=", "Kumet");
    llIIlIllll[llIIllIlII[105]] = lIlIllllIlll("5UAM5bl99sQ+nJfELsZvpA==", "TynrP");
    llIIlIllll[llIIllIlII[106]] = lIlIllllIlll("JP7TJgICl9g=", "UZhuy");
    llIIlIllll[llIIllIlII[107]] = lIlIllllIlIl("Ix8uJS0BLws+HiZcaEcgIjkMOgIBPWRO", "VlYsz");
    llIIlIllll[llIIllIlII[108]] = lIlIllllIlll("arAO8cEenYQ=", "iwtSy");
    llIIlIllll[llIIllIlII[109]] = lIlIllllIlll("FbA9BT5RWs0tou2PHw4oPACymWLXwEGtypoG/8ZkZCM=", "JivEL");
    llIIlIllll[llIIllIlII[110]] = lIlIllllIlll("mVCZzLZo9ek=", "AjUuC");
    llIIlIllll[llIIllIlII[111]] = lIlIllllIlll("Acqp/I2+KChSAMPFWo8akw==", "zSWuZ");
    llIIlIllll[llIIllIlII[112]] = lIlIllllIllI("3zJWRTyfzgY=", "vLGGh");
    llIIlIllll[llIIllIlII[113]] = lIlIllllIllI("RBXaV2uynzpe8fXUNW9kMA==", "WenJp");
    llIIlIllll[llIIllIlII[114]] = lIlIllllIlll("qgvhZbk7E0I=", "UEIdy");
    llIIlIllll[llIIllIlII[115]] = lIlIllllIllI("H17Mg8nbVipoGYYz8uJwprjEc94+NnbzqfdqPoqP2qU=", "Lmygh");
    llIIlIllll[llIIllIlII[116]] = lIlIllllIlIl("DCQWIAU=", "zJbyO");
    llIIlIllll[llIIllIlII[117]] = lIlIllllIllI("PDVXhCojId8+xru1fzwBFjnmK4YfdsnEvFHeWWds1Bw=", "qWSbU");
    llIIlIllll[llIIllIlII[118]] = lIlIllllIlll("M3MYE4oS2/s=", "LBaCc");
    llIIlIllll[llIIllIlII[119]] = lIlIllllIlll("Ekmr6cRZbT4=", "VnxWq");
    llIIlIllll[llIIllIlII[120]] = lIlIllllIllI("kggXTZYwCiM=", "TJJKi");
    llIIlIllll[llIIllIlII[121]] = lIlIllllIlll("G59HIcbK2ZS3q1sZvGE1RQ==", "sElXL");
    llIIlIllll[llIIllIlII[122]] = lIlIllllIllI("LlSwzFurpyw=", "FJzAP");
    llIIlIllll[llIIllIlII[129]] = lIlIllllIlll("pw70fmxqQHo/LwqA6heyWA==", "geZZm");
    llIIlIllll[llIIllIlII[130]] = lIlIllllIlll("OqevsfZU2uM=", "ckEqS");
    llIIlIllll[llIIllIlII[131]] = lIlIllllIlll("Y6OM/kHX9OcEuVsIq/WkHQ==", "CGufm");
    llIIlIllll[llIIllIlII[132]] = lIlIllllIllI("vv4ZxN2aSms=", "IHpHw");
    llIIlIllll[llIIllIlII[133]] = lIlIllllIllI("MDg1DHkdrQ4ttSbKI4g49w==", "RoeAz");
    llIIlIllll[llIIllIlII[134]] = lIlIllllIlll("bOXrmYfoy6Q=", "eLWmy");
    llIIlIllll[llIIllIlII[136]] = lIlIllllIlll("ii/4lk67HfbQaSKW+vDMBA==", "qCPkT");
    llIIlIllll[llIIllIlII[123]] = lIlIllllIlIl("ARglHSY=", "xaGud");
    llIIlIllll[llIIllIlII[137]] = lIlIllllIlll("JFHmjUC+nDAe32STPxAekPHsuzKEJlzCgaJTYYJjVlA=", "NbnNh");
    llIIlIllll[llIIllIlII[138]] = lIlIllllIllI("O78pttggzJ4=", "GUfYF");
    llIIlIllll[llIIllIlII[139]] = lIlIllllIllI("6AbdeSi+kvCslcdXe6ebpg==", "CzXbV");
    llIIlIllll[llIIllIlII[140]] = lIlIllllIllI("Qbhzzg5+sz4=", "wNeaR");
    llIIlIllll[llIIllIlII[143]] = lIlIllllIlll("4EFC+0QliDpdazbOCiQcgw==", "lmWsy");
    llIIlIllll[llIIllIlII[144]] = lIlIllllIllI("9wPLMg8AJA0=", "kDLzr");
    llIIlIllll[llIIllIlII[145]] = lIlIllllIlIl("MxcRfxItFDYfSTRb", "ufyMb");
    llIIlIllll[llIIllIlII[146]] = lIlIllllIlll("FgxEP39PEfM=", "uXmqd");
    llIIlIllll[llIIllIlII[142]] = lIlIllllIllI("oq83uzsr/Zifr75+CAI1ig==", "Hoqkn");
    llIIlIllll[llIIllIlII[147]] = lIlIllllIlIl("Aj8QGC0=", "pGgSl");
    llIIlIllll[llIIllIlII[148]] = lIlIllllIllI("8YvkUoU2isOGhYB05zHZxQ==", "beAVT");
    llIIlIllll[llIIllIlII[149]] = lIlIllllIlIl("HxYtCS0=", "Gynpu");
    llIIlIllll[llIIllIlII[126]] = lIlIllllIllI("hOgNQ4rswAf9eQ8XkiHmTQ==", "QaPFP");
    llIIlIllll[llIIllIlII[150]] = lIlIllllIlIl("PAIeKDo=", "ORrBy");
    llIIlIllll[llIIllIlII[151]] = lIlIllllIllI("AVf6y+C8qMfswnfZw7nDhQ==", "mOwaF");
    llIIlIllll[llIIllIlII[152]] = lIlIllllIlll("kmJBtnK24Y8=", "FFMDY");
    llIIlIllll[llIIllIlII[153]] = lIlIllllIlll("suiM+pQsNil+gU/ivUmhOmiT4I+CaXbj3jV7thvk8JI=", "CFVaF");
    llIIlIllll[llIIllIlII[154]] = lIlIllllIllI("HQxZ2TrhHDo=", "dskYJ");
    llIIlIllll[llIIllIlII[155]] = lIlIllllIlll("JLXNg1IUoTGaumcKzNZUqsGsK+4a0cg+rCF9XJPmrYk=", "fFfaW");
    llIIlIllll[llIIllIlII[156]] = lIlIllllIlll("/YtKw25H5sE=", "aAUQI");
    llIIlIllll[llIIllIlII[157]] = lIlIllllIlll("jThQ9VxseHU=", "zgmBf");
    llIIlIllll[llIIllIlII[158]] = lIlIllllIllI("utThACfLKVA=", "ImYNI");
    llIIlIllll[llIIllIlII[159]] = lIlIllllIllI("oHcLbUac8UCK+TCwNE4LDg==", "XbwoG");
    llIIlIllll[llIIllIlII[141]] = lIlIllllIlll("6UhenmkXwrI=", "OHoSX");
    llIIlIllll[llIIllIlII[160]] = lIlIllllIlll("inNxfuNRhoVIWC0gZwWUo0D60pj03xMS", "oVYvP");
    llIIlIllll[llIIllIlII[128]] = lIlIllllIlll("EjynG45aGYE=", "xeqzh");
    llIIlIllll[llIIllIlII[161]] = lIlIllllIllI("4obb0x0NHdlueDRvF9+NhnWcKrWxkKjJ", "GoMGZ");
    llIIlIllll[llIIllIlII[162]] = lIlIllllIllI("Yzy60ICB8qg=", "AfOLK");
    llIIlIllll[llIIllIlII[163]] = lIlIllllIllI("iVdr59iEEcw=", "unhDb");
    llIIlIllll[llIIllIlII[164]] = lIlIllllIlll("v3XYXg+yWpo=", "rTsnR");
    llIIlIllll[llIIllIlII[165]] = lIlIllllIlIl("OCQZLhkqIU8=", "hNraU");
    llIIlIllll[llIIllIlII[166]] = lIlIllllIlll("Zpcw0Gz9JuY=", "mJbmd");
    llIIlIllll[llIIllIlII[167]] = lIlIllllIlIl("PA8nLG0bKy4MEjgzMFw/DkMAXzkbK1VX", "HzhjX");
    llIIlIllll[llIIllIlII[168]] = lIlIllllIlIl("OD0wAzY=", "WQULW");
    llIIlIllll[llIIllIlII[169]] = lIlIllllIllI("/Sjl5cLzFdqHhpftDEWlblg1Giv5pEY3Sw+o8h15+3s=", "XQBOA");
    llIIlIllll[llIIllIlII[170]] = lIlIllllIlIl("AyAeBQA=", "qEFio");
    llIIlIllll[llIIllIlII[171]] = lIlIllllIlll("qmLSZG3WPlX0Bu+lXwBRRw==", "KrZWV");
    llIIlIllll[llIIllIlII[125]] = lIlIllllIlIl("PygkHBE=", "PrekZ");
    llIIlIllll[llIIllIlII[172]] = lIlIllllIlll("Id5CfUj4FT0f48Dyy1RpYg==", "Qwsvq");
    llIIlIllll[llIIllIlII[173]] = lIlIllllIlll("bhH6B9T/lfg=", "XseKJ");
    llIIlIllll[llIIllIlII[174]] = lIlIllllIlll("FifPruvHibeWvYP84Jn4BBim+DQfulxrD70Ni2YkmuA=", "RXEeE");
    llIIlIllll[llIIllIlII[175]] = lIlIllllIllI("Gu4z5eiYgcM=", "OFWQD");
    llIIlIllll[llIIllIlII[176]] = lIlIllllIlll("EZkNYY144uNT2MKWXzw/WVOg3czMZLMHi89ainxTgyk=", "cwuFI");
    llIIlIllll[llIIllIlII[177]] = lIlIllllIlll("B3F0BCtOqSY=", "WOVBC");
    llIIlIllll[llIIllIlII[127]] = lIlIllllIllI("o9dqIxxUOTc=", "sRjnf");
    llIIlIllll[llIIllIlII[183]] = lIlIllllIllI("0o0Zy7Ox3uY=", "DKaFe");
    llIIlIllll[llIIllIlII[184]] = lIlIllllIlIl("Ox8BEy4eCScJBRRH", "UzbPa");
    llIIlIllll[llIIllIlII[178]] = lIlIllllIllI("LFuU0PjWpEg=", "ZvwoG");
    llIIlIllll[llIIllIlII[185]] = lIlIllllIlll("4X1+22b0CYmbz0P5H9eyreLHhEsOEBYDRs2gPzTgato=", "OgDzH");
    llIIlIllll[llIIllIlII[186]] = lIlIllllIlll("ucWGDpBQAmE=", "ruNzg");
    llIIlIllll[llIIllIlII[187]] = lIlIllllIllI("UedwFnFO28qfXQd1hiNt+SjErPvA2Ryhts1vCQFLykw=", "FgSfr");
    llIIlIllll[llIIllIlII[188]] = lIlIllllIlll("ec1r6IJpB2Y=", "SNfDd");
    llIIlIllll[llIIllIlII[190]] = lIlIllllIlIl("", "okERB");
    llIIlIllll[llIIllIlII[191]] = lIlIllllIlIl("HDoVIyw=", "nvoyh");
    llIIlIllll[llIIllIlII[181]] = lIlIllllIlIl("JzVgPhQZHGQrLx5y", "WOSRz");
    llIIlIllll[llIIllIlII[192]] = lIlIllllIlIl("CjAwPxk=", "kFFmj");
    llIIlIllll[llIIllIlII[193]] = lIlIllllIlll("TyTvZpdZXGyy6Zlqf7qP3mYy5ldN4RjHeVcieDcqRSo=", "TpnVe");
    llIIlIllll[llIIllIlII[194]] = lIlIllllIllI("OlQDR+51VBM=", "YqIcd");
    llIIlIllll[llIIllIlII[189]] = lIlIllllIlll("rr1PYEDft+tENhmmvW27+zmOvUs1e1UMco2nRaQGEr0=", "YgKnW");
    llIIlIllll[llIIllIlII[195]] = lIlIllllIlll("zRjEPCHudls=", "cCBeE");
    llIIlIllll[llIIllIlII[196]] = lIlIllllIllI("NOrfy3v7JSjDB5WIEOE3qg==", "UOBlU");
    llIIlIllll[llIIllIlII[197]] = lIlIllllIlll("cgUALiuotGA=", "XbeCW");
    llIIlIllll[llIIllIlII[124]] = lIlIllllIlll("2jNnEj+DhJWeHaNQS7qLxw==", "QpUmt");
    llIIlIllll[llIIllIlII[198]] = lIlIllllIlll("pXu1lkv2a4A=", "AxxDn");
    llIIlIllll[llIIllIlII[199]] = lIlIllllIlll("ET9c5UpPs90pz2BdI8m/Ak4V23njdd7Z8WL9stqRkTL7jlol+FXZWA==", "KUXbU");
    llIIlIllll[llIIllIlII[200]] = lIlIllllIlIl("Fh4hADA=", "FItcg");
    llIIlIllll[llIIllIlII[201]] = lIlIllllIlll("kBAMjeXFN77uKqq5FD4VIZJzJSBf60UhAb3CXZgN2kA=", "oiBMU");
    llIIlIllll[llIIllIlII[202]] = lIlIllllIlll("FYGmir/voMc=", "XopHg");
    llIIlIllll[llIIllIlII[203]] = lIlIllllIlIl("", "rdlqX");
    llIIlIllll[llIIllIlII[204]] = lIlIllllIllI("EgBUbb036gQ=", "jLmji");
    llIIlIllll[llIIllIlII[205]] = lIlIllllIlll("2XpxirenFpiu2VnWAlbj0w==", "zgfMz");
    llIIlIllll[llIIllIlII[206]] = lIlIllllIlll("l20WbP4oo3I=", "xyJav");
    llIIlIllll[llIIllIlII[207]] = lIlIllllIllI("cVbpwJOIdBG5RW/0yvwZY4jiXcjIeVwdITgBxc2oo14=", "ZsyVX");
    llIIlIllll[llIIllIlII[208]] = lIlIllllIllI("CGxsXs+muCU=", "zPZGP");
    llIIlIllll[llIIllIlII[209]] = lIlIllllIllI("P8HUg335Ug5NEzvJNrZyPQ86RMze/r49yUpYOnHsdQw=", "vhKYU");
    llIIlIllll[llIIllIlII[210]] = lIlIllllIlll("BgGuaomGTcY=", "bBnqv");
    llIIlIllll[llIIllIlII[211]] = lIlIllllIlIl("OxkiK0dTJDN+GQxK", "kwkFv");
    llIIlIllll[llIIllIlII[212]] = lIlIllllIllI("hfqWAP2zkbQ=", "BTRfs");
    llIIlIllll[llIIllIlII[213]] = lIlIllllIlll("8MDllGhBGvdKP5u1DbvbpQ==", "NowSx");
    llIIlIllll[llIIllIlII[214]] = lIlIllllIlll("jWqM9YJyD24=", "aUoaV");
    llIIlIllll[llIIllIlII[215]] = lIlIllllIllI("o+0c5B+XYfS4pDlH7TkAkwhzO9vMS+xb", "HMvYO");
    llIIlIllll[llIIllIlII[216]] = lIlIllllIllI("0GhFUXMDt/w=", "NDcyd");
    llIIlIllll[llIIllIlII[217]] = lIlIllllIlll("AD/FK3YiaVaT26Ep78tkEY62DyrFF6IC+DFlqCcFlRc=", "ILNPP");
    llIIlIllll[llIIllIlII[218]] = lIlIllllIlIl("EjcjIxw=", "jnZqt");
    llIIlIllll[llIIllIlII[219]] = lIlIllllIlll("N7CNyqVd19U=", "tcvAy");
    llIIlIllll[llIIllIlII[220]] = lIlIllllIlll("6X/x0ncdV5M=", "szXgF");
    llIIlIllll[llIIllIlII[221]] = lIlIllllIlll("+NWNG6Juk1bl+V5NdW4jpg==", "YpNuj");
    llIIlIllll[llIIllIlII[222]] = lIlIllllIlIl("Oj4WMjk=", "HXlTq");
    llIIlIllll[llIIllIlII[223]] = lIlIllllIlll("ZVqeW1uWOcbqrHma7QhQDRVf+Zohs+0J", "rzSrm");
    llIIlIllll[llIIllIlII[224]] = lIlIllllIlll("mjzRO5nVROQ=", "FtRCP");
    llIIlIllll[llIIllIlII[225]] = lIlIllllIllI("RDrrlfsHnVlvxK+E5z/LYCZ+J9tCXAva6VeMhGBdL0U=", "HhDRW");
    llIIlIllll[llIIllIlII[226]] = lIlIllllIlIl("OSI1ABc=", "RQgdz");
    llIIlIllll[llIIllIlII[227]] = lIlIllllIlIl("MAIrdQsBPSs8EQtP", "drfEY");
    llIIlIllll[llIIllIlII[180]] = lIlIllllIlll("CJokxsjvaYQ=", "JOIAJ");
    llIIlIllll[llIIllIlII[228]] = lIlIllllIlll("sOVeUB3Hl9Wg6jQ54elOmA==", "OiLHJ");
    llIIlIllll[llIIllIlII[229]] = lIlIllllIllI("ujZgFH+hyzQ=", "MDOZu");
    llIIlIllll[llIIllIlII[230]] = lIlIllllIllI("BynpPjzoRCP3rH6Ija/5/rqz+wgptc2f5zMkRk/gi6Q=", "YIUQi");
    llIIlIllll[llIIllIlII[231]] = lIlIllllIllI("hwn7Nzi8q5I=", "WXVjz");
    llIIlIllll[llIIllIlII[232]] = lIlIllllIlIl("BDEcfTkYGGoULiUPGhNKCA==", "JIYRz");
    llIIlIllll[llIIllIlII[233]] = lIlIllllIlIl("PRMxFTc=", "UvgqF");
    llIIlIllll[llIIllIlII[234]] = lIlIllllIlll("fwA0UDxJ/6U=", "rapCN");
    llIIlIllll[llIIllIlII[235]] = lIlIllllIllI("11y0o0aZgz0=", "BLAjZ");
    llIIlIllll[llIIllIlII[236]] = lIlIllllIlIl("KxQ5eikGEmc=", "lGZOc");
    llIIlIllll[llIIllIlII[237]] = lIlIllllIlll("Xcs/bvUXLIQ=", "SJqKY");
    llIIlIllll[llIIllIlII[238]] = lIlIllllIlIl("WmU4BHlcMxgSfQZ3", "mJybJ");
    llIIlIllll[llIIllIlII[239]] = lIlIllllIlll("+rOFqRknjhw=", "GGpUD");
    llIIlIllll[llIIllIlII[240]] = lIlIllllIllI("jcUJMuAyljUeuvwg+mqa2w==", "QbaQh");
    llIIlIllll[llIIllIlII[241]] = lIlIllllIllI("V1YnauARDq4=", "JXuQY");
    llIIlIllll[llIIllIlII[242]] = lIlIllllIlIl("KRUmGSBFHlQaFSd5", "jDdjm");
    llIIlIllll[llIIllIlII[243]] = lIlIllllIlIl("MBoPGyY=", "wbyAP");
    llIIlIllll[llIIllIlII[244]] = lIlIllllIllI("yBZ3a/lJOIc9ZbZ+ZjiANg==", "UdIGX");
    llIIlIllll[llIIllIlII[245]] = lIlIllllIlIl("IAAWFis=", "SerTB");
    llIIlIllll[llIIllIlII[246]] = lIlIllllIllI("ObRYAHVcZddJM5pYhpM365n92b9cD3yhgwa37gqGAx8=", "TjDvo");
    llIIlIllll[llIIllIlII[182]] = lIlIllllIlIl("EyM9FSk=", "cNeYx");
    llIIlIllll[llIIllIlII[247]] = lIlIllllIllI("zbKrZU9b5550nKMIpemtlUbXdZUzzNAcFDFyiqqcLUI=", "iKewV");
    llIIlIllll[llIIllIlII[248]] = lIlIllllIlll("0Tir7aptqLk=", "UnTZC");
    llIIlIllll[llIIllIlII[249]] = lIlIllllIlIl("PhM/JnEzHgcwHjJU", "giktI");
    llIIlIllll[llIIllIlII[250]] = lIlIllllIllI("wz3/l8vgxHw=", "roxNq");
    llIIlIllll[llIIllIlII[251]] = lIlIllllIlIl("NwMSXAUgVFg=", "rdesK");
    llIIlIllll[llIIllIlII[252]] = lIlIllllIlIl("BRYIJxI=", "cuCsc");
    llIIlIllll[llIIllIlII[253]] = lIlIllllIllI("EKJcdS+KCSM=", "xpHSQ");
    llIIlIllll[llIIllIlII[254]] = lIlIllllIlIl("KRQ3GwU=", "dNOLr");
    llIIlIllll[llIIllIlII[255]] = lIlIllllIlIl("IwM3A0l+Kj5+SH58", "NAqNq");
    llIIlIllll[llIIllIlII[256]] = lIlIllllIllI("cpbHnJJKohc=", "PHrhN");
    llIIlIllll[llIIllIlII[257]] = lIlIllllIlll("lA9flJTdyM+LjoG+0IKv5g==", "FxuvW");
    llIIlIllll[llIIllIlII[258]] = lIlIllllIllI("VWRRbT3WhHw=", "MhiNM");
    llIIlIllll[llIIllIlII[259]] = lIlIllllIlll("pTbA15z1hdkchNFCBW3svw==", "zsUSB");
    llIIlIllll[llIIllIlII[260]] = lIlIllllIllI("zRTx+ka4T2M=", "wZqEv");
    llIIlIllll[llIIllIlII[261]] = lIlIllllIlll("5scPdV42TI01ZeDvkSp2EY7KXzY3daQhSWySLAKdQLw=", "ditAk");
    llIIlIllll[llIIllIlII[262]] = lIlIllllIllI("uvI01A3ko5k=", "ZDcKP");
    llIIlIllll[llIIllIlII[263]] = lIlIllllIlIl("OzUFBiYROxosIRZbeStuOAN/PBtDQikDESMVLCgkEDg=", "smOOV");
    llIIlIllll[llIIllIlII[264]] = lIlIllllIlIl("BwEUEBY=", "qjgyt");
    llIIlIllll[llIIllIlII[265]] = lIlIllllIlIl("NyQzKio2dUICcxwMOSR1CzQYPDUkehg9N3A6Rg4GMh8=", "EMvHA");
    llIIlIllll[llIIllIlII[266]] = lIlIllllIlll("Wo9U3hfPX9s=", "LYLov");
    llIIlIllll[llIIllIlII[267]] = lIlIllllIllI("ZpCHdooN263Lm56naQGswrrD4QTJ15o6e65YhL45o1Y=", "hKoQH");
    llIIlIllll[llIIllIlII[268]] = lIlIllllIlIl("GScEAgE=", "UsjZh");
    llIIlIllll[llIIllIlII[269]] = lIlIllllIllI("/rXHdVkHxRIAtWlyBGlSsrJuOWFDVe3vrjszzdiukqGOwi8R2WxzHg==", "pCaLD");
    llIIlIllll[llIIllIlII[270]] = lIlIllllIllI("FKh5WoSYYaM=", "VZEbB");
    llIIlIllll[llIIllIlII[271]] = lIlIllllIllI("JE01aEDZA5OT8opWddRYcDgwIf2RC2assTEz3PJNrYQQilnsdToSmA==", "gwdpz");
    llIIlIllll[llIIllIlII[272]] = lIlIllllIlIl("Oh0tCRk=", "hZdgA");
    llIIlIllll[llIIllIlII[273]] = lIlIllllIlIl("DA4XKgwmDRE0IDYhCQ4cDAgaFTVHI0k3QhccCCYrJjw=", "tJbEm");
    llIIlIllll[llIIllIlII[274]] = lIlIllllIlll("tEb67Hb1+Tk=", "EqiPH");
    llIIlIllll[llIIllIlII[275]] = lIlIllllIllI("qdZY5DPCqR383+AiH/ex4tU3AcrEPE6rpollqQKU/+g=", "yDhjJ");
    llIIlIllll[llIIllIlII[276]] = lIlIllllIlll("1QnKDsi5On8=", "pWLOV");
    llIIlIllll[llIIllIlII[277]] = lIlIllllIlIl("AikVMRAtIxYcBhUwEBUZMisvPDkAPmxq", "DjXWT");
    llIIlIllll[llIIllIlII[278]] = lIlIllllIlll("acO/78ZFB44=", "iUBjl");
    llIIlIllll[llIIllIlII[279]] = lIlIllllIllI("WeurjPvAehnBfOWRYygzSarEJ7Nd74RypxenSEoNFAlM3TzrZJfitA==", "OEBwU");
    llIIlIllll[llIIllIlII[280]] = lIlIllllIlll("B4BiMgot90E=", "QSMYV");
    llIIlIllll[llIIllIlII[281]] = lIlIllllIlll("DMKvd+CaqMUaRJ06L6PX29C+DaRMGw6xDOfjzLB59FUXgSbz3C3Aow==", "fUthB");
    llIIlIllll[llIIllIlII[282]] = lIlIllllIlIl("HjMAIyo=", "vFdBn");
    llIIlIllll[llIIllIlII[283]] = lIlIllllIlll("mbse8DWaNSCalfx3oOBp3ws7dObiO/fctqQ7uJGP9F6NUCu7wj522H5hGCPocte9", "sPVEe");
    llIIlIllll[llIIllIlII[284]] = lIlIllllIlll("7lkIjpLnDOo=", "RyGbn");
    llIIlIllll[llIIllIlII[285]] = lIlIllllIlll("umOEJY5HpVGEF9rjbUISyNu/Dawg2uCQXYHYcaagyCaXCXGoRpe76A==", "BvTcu");
    llIIlIllll[llIIllIlII[286]] = lIlIllllIlIl("BRYAKyE=", "orkQq");
    llIIlIllll[llIIllIlII[287]] = lIlIllllIlll("Ma0nQtOilhN5WSfGMJDtvqOejE4kr/S8+w1/UMHnNiAqePkfEPTpeA==", "Fauwd");
    llIIlIllll[llIIllIlII[288]] = lIlIllllIlIl("DCQ3LwA=", "XjzNb");
    llIIlIllll[llIIllIlII[289]] = lIlIllllIlll("5r3mo/fJ03AQS186d7F/wFsCxk2Is6DRHFP3iAczqLA=", "xZGRq");
    llIIlIllll[llIIllIlII[290]] = lIlIllllIlll("cUGrTjaLsec=", "sgHrI");
    llIIlIllll[llIIllIlII[291]] = lIlIllllIlll("xR1OrJ8n8jNJon7Y814UG4aFIcYQOIgnwi8gK7sCws5DBsA+SeXwDQ==", "EoRSK");
    llIIlIllll[llIIllIlII[292]] = lIlIllllIllI("yFnFeUWhCVE=", "iWzfV");
    llIIlIllll[llIIllIlII[293]] = lIlIllllIlll("G9qruFBandIKZUvRaTcanIpPuktGFLUW/HtqHnON1AGHNcmIZRNaxQ==", "biJST");
    llIIlIllll[llIIllIlII[294]] = lIlIllllIllI("PgY9G9Itisw=", "lXDPu");
    llIIlIllll[llIIllIlII[295]] = lIlIllllIlll("sY2qXV/UWukTKXR7cZVzsLcaoA1zE8/6sTF1NnYmaVgX60hqmht1/jS5KN8mSBob", "oRUuZ");
    llIIlIllll[llIIllIlII[296]] = lIlIllllIllI("UJpxOMDQyqY=", "lSsja");
    llIIlIllll[llIIllIlII[297]] = lIlIllllIllI("eoBOnYENHg8CuC5AIXtpA4XkQ7u9532xYYJMU8La08M=", "ienKL");
    llIIlIllll[llIIllIlII[298]] = lIlIllllIllI("pb24d+lwyyE=", "Xcfqc");
    llIIlIllll[llIIllIlII[299]] = lIlIllllIlll("7YaAhWO3UQPcp5uiRB6fIz5ikOhjWwcVXDgCUt681N0=", "fanPf");
    llIIlIllll[llIIllIlII[300]] = lIlIllllIllI("cWpHSu65z94=", "UnBEf");
    llIIlIllll[llIIllIlII[301]] = lIlIllllIlIl("AzYqNBQEAhgYO3EbXzUAeCYFAVoHNFBL", "Humvu");
    llIIlIllll[llIIllIlII[302]] = lIlIllllIllI("ntyNzGTpgeE=", "CNeTN");
    llIIlIllll[llIIllIlII[303]] = lIlIllllIlll("Kel04fDBq4deoZDgBs/0HrhcEA5UTT/k", "YOWqF");
    llIIlIllll[llIIllIlII[304]] = lIlIllllIlll("dXk541N0/zQ=", "XKtje");
    llIIlIllll[llIIllIlII[305]] = lIlIllllIlIl("Oz1AFik3EBg/IxUkJxEuNB8eHwM/OUxF", "vUtxg");
    llIIlIllll[llIIllIlII[306]] = lIlIllllIlll("NGxVXVCPzHs=", "uXkpJ");
    llIIlIllll[llIIllIlII[307]] = lIlIllllIlll("96LUF6CkhkjoSo7BiB4eSkAZy5Sa0xZZzT+n21ybbmQQF42r0PKm7A==", "ZhCMa");
    llIIlIllll[llIIllIlII[308]] = lIlIllllIlIl("CAAtAiE=", "ktNrk");
    llIIlIllll[llIIllIlII[309]] = lIlIllllIlll("gqmWjCJCDgutXuq7pVmoPnhcAVyCssqw66XVzwSPJuU=", "tgYTn");
    llIIlIllll[llIIllIlII[310]] = lIlIllllIllI("gUi1oA2rCqE=", "YIZUd");
    llIIlIllll[llIIllIlII[311]] = lIlIllllIlll("mO9x2RMUYV/C3xQ6YIwsFhVIHSaW7n0qLlUmkl6UA2kXRGum6Y7zrw==", "CUMCs");
    llIIlIllll[llIIllIlII[312]] = lIlIllllIllI("Zwyzndp2iFU=", "viuIj");
    llIIlIllll[llIIllIlII[313]] = lIlIllllIllI("B7FXZ1MWDkmznV4nKWlL/HJE88IEjSoSBe6vCVXBJIKeeloRM0HEOQ==", "pHUuQ");
    llIIlIllll[llIIllIlII[314]] = lIlIllllIlIl("PhwFMzg=", "hUrFL");
    llIIlIllll[llIIllIlII[315]] = lIlIllllIlIl("JlgabyACHgAeVT0gDiVUCj1BDghxXBtkOiYpLzMWJVk=", "DoxWl");
    llIIlIllll[llIIllIlII[316]] = lIlIllllIlIl("GzwvDjA=", "iuugt");
    llIIlIllll[llIIllIlII[317]] = lIlIllllIlll("8FNYhsZc8hV2h+7zHqzndHaN7Lm0ih2cdE1+Vm6/F0hHLOcRkc8jYQ==", "YopvT");
    llIIlIllll[llIIllIlII[318]] = lIlIllllIlll("zlE2AMfHQAE=", "OXeCT");
    llIIlIllll[llIIllIlII[319]] = lIlIllllIlIl("LQg+FDwMXB0iLxkNJg0xEiIUNAp/ADQTKBswFxMIAg8=", "TiSfK");
    llIIlIllll[llIIllIlII[320]] = lIlIllllIlll("8SOyucH8qKY=", "RzSAD");
    llIIlIllll[llIIllIlII[321]] = lIlIllllIlIl("KhYEYwMnPisyKBshMBwnOg8zGV5XLzEbXAQocwM+VCE=", "cFFPl");
    llIIlIllll[llIIllIlII[322]] = lIlIllllIlll("ZaE/3lAOlk8=", "tTzhY");
    llIIlIllll[llIIllIlII[323]] = lIlIllllIllI("hB4J5Fx61GFidkmR2BjQJoOOz6LTFKX5XT3RdSWD4B0=", "pAqQe");
    llIIlIllll[llIIllIlII[324]] = lIlIllllIlll("LK7FUdVAPgQ=", "hdRqB");
    llIIlIllll[llIIllIlII[325]] = lIlIllllIllI("djj1WwxNdMAab1hMeAU2YVeCgNoKvjqF+0Z8xKCU8ac=", "IfgaG");
    llIIlIllll[llIIllIlII[326]] = lIlIllllIlIl("DB8tJRM=", "NpGWG");
    llIIlIllll[llIIllIlII[327]] = lIlIllllIllI("A/uKlYM8nrddSt4yvhqJ4wsY8XJGiV6OQrQE8RuhhLY81Iw4yfNtGQ==", "rxsCT");
    llIIlIllll[llIIllIlII[328]] = lIlIllllIllI("MfwCyiA/rOI=", "LQLQN");
    llIIlIllll[llIIllIlII[329]] = lIlIllllIlIl("IRYxFDUQGAQVelsRBzAaGSA0CHYrECgADCYtAxcSJgw=", "itfEC");
    llIIlIllll[llIIllIlII[330]] = lIlIllllIllI("CoBOOM3AWcs=", "iBXFT");
    llIIlIllll[llIIllIlII[331]] = lIlIllllIlIl("OB47RXIUIBsyey0CJgFyFxs2KCxoGFwuLRAnGw4rLzg=", "YjljJ");
    llIIlIllll[llIIllIlII[332]] = lIlIllllIlIl("AyYEJhs=", "LgNmV");
    llIIlIllll[llIIllIlII[333]] = lIlIllllIllI("2WUuSlhiFOuhJbLuL05ifwGPNR1zkCk4TB4ifPQbDrtXOVXRTgZgJw==", "POwjy");
    llIIlIllll[llIIllIlII[334]] = lIlIllllIlIl("NwocADc=", "urJDV");
    llIIlIllll[llIIllIlII[335]] = lIlIllllIlll("VQc4YOWvY8LJDyWAmlPXvSwExujMD2Lfay8krw/Baw2YNe76UgER0Q==", "nwHnI");
    llIIlIllll[llIIllIlII[336]] = lIlIllllIlll("TIYcs0Y/KOY=", "CIuEu");
    llIIlIllll[llIIllIlII[337]] = lIlIllllIllI("kodkFhQd8bmCI4+ODmA4HO9KQugLQhqU8rHoQ/63lzEUmWB9/jRlIw==", "gTtPb");
    llIIlIllll[llIIllIlII[338]] = lIlIllllIllI("sTB3JpR/TYU=", "PUOnJ");
    llIIlIllll[llIIllIlII[339]] = lIlIllllIllI("gtYNRXuQ1oBUSpIPv3q6x42GqF7+mGewuSwCjKYLoBYrdghwV89N7w==", "jsJnP");
    llIIlIllll[llIIllIlII[340]] = lIlIllllIllI("cLYF8QKSYqI=", "uRloR");
    llIIlIllll[llIIllIlII[341]] = lIlIllllIllI("GGnDkgymFclo6MmbUrEQ8g==", "bnyQx");
    llIIlIllll[llIIllIlII[342]] = lIlIllllIllI("5EcecmkO4Vw=", "xoHLD");
    llIIlIllll[llIIllIlII[343]] = lIlIllllIlIl("NyQMFzAkDzEuESAJG0kxRgpNOyghNi0jCiAvFihOOik=", "snybe");
    llIIlIllll[llIIllIlII[344]] = lIlIllllIlIl("LgMXGTU=", "GMdsq");
    llIIlIllll[llIIllIlII[345]] = lIlIllllIllI("O97DkYGSiltv5bhrn+Lm+sKAu+ru0li8ERZDp0J53L72o8VuQyvmmQ==", "IvzHb");
    llIIlIllll[llIIllIlII[346]] = lIlIllllIllI("5k81ft8kPkU=", "efiFm");
    llIIlIllll[llIIllIlII[347]] = lIlIllllIllI("m7s5hiA9cwt0jOA1iH4AG91Yba1TZ0nLMxysz0niZ9Va333P/39kgg==", "pFjti");
    llIIlIllll[llIIllIlII[348]] = lIlIllllIlIl("CwUXHBQ=", "RDOTm");
    llIIlIllll[llIIllIlII[349]] = lIlIllllIllI("7t/If9RKm45Qga4daVGG3VnYmEWGh76Lt5XD5mnhGVOe/SEpPJq99Q==", "zRNcn");
    llIIlIllll[llIIllIlII[350]] = lIlIllllIllI("sRhaF3gGQvE=", "fNLIX");
    llIIlIllll[llIIllIlII[351]] = lIlIllllIlll("WfsYXfit5VXZmVMCqPdaeUMPcBWQyHwZqUnfA2uI97xLi6F/yTg5DA==", "huqaH");
    llIIlIllll[llIIllIlII[352]] = lIlIllllIlIl("PRgnAi0=", "YjrGo");
    llIIlIllll[llIIllIlII[353]] = lIlIllllIlll("gVhlcsROr5dsgNuj3qWNNZnu3CCADHgDPCCS6XZCNCYUJtwSXPr/bg==", "aIRXg");
    llIIlIllll[llIIllIlII[354]] = lIlIllllIlll("DZPHi4ns9tI=", "PfTwZ");
    llIIlIllll[llIIllIlII[355]] = lIlIllllIlll("c69oui6uBqEjELbIQ6wTTaVLEvLE3VhEyMa91z249NU=", "gEdeZ");
    llIIlIllll[llIIllIlII[356]] = lIlIllllIlIl("EBobCDQ=", "XUnFX");
    llIIlIllll[llIIllIlII[357]] = lIlIllllIlll("pRisbehqerrLZDH6B7YixeoKvLeZBoUR", "aPuSf");
    llIIlIllll[llIIllIlII[358]] = lIlIllllIlIl("LgcdGS4=", "XHEWv");
    llIIlIllll[llIIllIlII[359]] = lIlIllllIlll("n3h8cY4pelJ911bDuY86B/bNBqAF6YOgODmWHx20jMtOUmW96B9oGA==", "ZCPrb");
    llIIlIllll[llIIllIlII[360]] = lIlIllllIlll("yl7MJ7qibB0=", "iLhck");
    llIIlIllll[llIIllIlII[361]] = lIlIllllIlIl("Hy49Lz1jcTYvOzM+BS8xLXEeGjZhHz8KYg8FEnZiFhM=", "WIqCW");
    llIIlIllll[llIIllIlII[362]] = lIlIllllIllI("ys7ZmljiTuU=", "qwEUH");
    llIIlIllll[llIIllIlII[363]] = lIlIllllIlIl("JhIMABI3Fj4oAS0tNisYLDUHKGwgEipGF1YkUg==", "deoiU");
    llIIlIllll[llIIllIlII[364]] = lIlIllllIlll("+fxczsSI16M=", "jTKRs");
    llIIlIllll[llIIllIlII[365]] = lIlIllllIllI("HTwUFhH2R4O93UCqAmsDXZMT3yOgdaTFmiWP1SOO3yjdZvvLAiy91+xYiGMqKfCY", "ZmmKd");
    llIIlIllll[llIIllIlII[366]] = lIlIllllIllI("Zs7wGmZ6R4w=", "tHosW");
    llIIlIllll[llIIllIlII[367]] = lIlIllllIllI("v+2ZTpeE4uA7dVN5wl+2JcVWrbQmN3tWorqai5im1R0=", "sGNjQ");
    llIIlIllll[llIIllIlII[368]] = lIlIllllIllI("BmPHUQ5RPt0=", "vAVzO");
    llIIlIllll[llIIllIlII[369]] = lIlIllllIlll("NpvBugSbs8qjTfXQOshTnyJisRuf6XO8b2PSIyGI4rI=", "ioiNl");
    llIIlIllll[llIIllIlII[370]] = lIlIllllIllI("pIzMEzHxTZM=", "RHieG");
    llIIlIllll[llIIllIlII[371]] = lIlIllllIlIl("Hyo7BTQHCSUZHjlXCxA9ZS8LHj4=", "VnHSd");
    llIIlIllll[llIIllIlII[372]] = lIlIllllIllI("bpEpYc06Tr4=", "MYWaZ");
    llIIlIllll[llIIllIlII[373]] = lIlIllllIllI("fmN/ODVpzrK94uGtv8uYnOtduo3CAwwjSXlZQegNX0c=", "RIAXO");
    llIIlIllll[llIIllIlII[374]] = lIlIllllIllI("Bv66lljNQm8=", "unjnf");
    llIIlIllll[llIIllIlII[375]] = lIlIllllIllI("yYYVfxgJt4sQtz8h+WdCfyvmdwKfN/YAKfZWHnLiLVT/2/yvkcKeRQ==", "MuTXx");
    llIIlIllll[llIIllIlII[376]] = lIlIllllIlIl("Nhs7OQg=", "nZwxb");
    llIIlIllll[llIIllIlII[377]] = lIlIllllIlll("1v7KX+RWelGKfetV6d5d4RRIcRVe/9PqVQRFIPk19y0IYZufaO5A1w==", "QGPwF");
    llIIlIllll[llIIllIlII[378]] = lIlIllllIllI("XxVBV5F6rm8=", "jYWbr");
    llIIlIllll[llIIllIlII[379]] = lIlIllllIlIl("SwMnAEUgPyQ5RUgaIDECKVsnED4PHSArEA1aLjhDHzw=", "xiwAv");
    llIIlIllll[llIIllIlII[380]] = lIlIllllIlll("1hvFJ3iSt9g=", "tvWqJ");
    llIIlIllll[llIIllIlII[381]] = lIlIllllIlIl("BwF2DwgCcQ8AByI3AywPbg==", "AENDF");
    llIIlIllll[llIIllIlII[382]] = lIlIllllIllI("JlDlQ8hVbVE=", "TgZXT");
    llIIlIllll[llIIllIlII[383]] = lIlIllllIllI("C6BylpWPdv0ZzFHpDWDBbhGtiiUFklmA3wxB7xDGFTo=", "EiuDA");
    llIIlIllll[llIIllIlII[384]] = lIlIllllIllI("bWcR5vj0+gY=", "RyJRz");
    llIIlIllll[llIIllIlII[385]] = lIlIllllIllI("OSUb8cnwhv5t/OR1NN4tt2vxeoqolgOHH0zJuwTZVrg=", "VQzua");
    llIIlIllll[llIIllIlII[386]] = lIlIllllIlll("6tlIaa/Ror8=", "HHuJn");
    llIIlIllll[llIIllIlII[387]] = lIlIllllIllI("Asu8LonnUptX+MIub218d73dQkoYh3gZlJcsnb2BznK/auwZihg6ZA==", "NKLoX");
    llIIlIllll[llIIllIlII[388]] = lIlIllllIllI("gIHNG3jMbFU=", "pNpVr");
    llIIlIllll[llIIllIlII[389]] = lIlIllllIlIl("AiolGzcILBkqCAkyFgk0ITYHCEUGLiEQNyZNCg==", "Lypcq");
    llIIlIllll[llIIllIlII[390]] = lIlIllllIlIl("PD8SAwk=", "juPzY");
    llIIlIllll[llIIllIlII[391]] = lIlIllllIllI("3DibXzrnmia+r+V0d3tZccnmoUaBSnjQIB0Er8jGXMqfMRd9VSZHEQ==", "FrYss");
    llIIlIllll[llIIllIlII[392]] = lIlIllllIlIl("GDomCBU=", "jmnmY");
    llIIlIllll[llIIllIlII[393]] = lIlIllllIllI("XeDSJpIJvODIgA62QQFm4Q==", "BEFST");
    llIIlIllll[llIIllIlII[394]] = lIlIllllIllI("qdGf33ixxKg=", "veoHk");
    llIIlIllll[llIIllIlII[395]] = lIlIllllIllI("Yx7ncrcaMVGO8rwWNdWGTQ==", "jwuQr");
    llIIlIllll[llIIllIlII[396]] = lIlIllllIllI("/Cv7wfzd9JE=", "niKcd");
    llIIlIllll[llIIllIlII[397]] = lIlIllllIlIl("NwACRgQsPC0XBQA7NgAwFwk7EEElHhIrHzg7Fx8fFzw=", "bjXqv");
    llIIlIllll[llIIllIlII[398]] = lIlIllllIllI("7b+6spi2XTk=", "DwuGd");
    llIIlIllll[llIIllIlII[399]] = lIlIllllIllI("85Y3xp8YJGeeLhoTMIHNdw==", "NHNZE");
    llIIlIllll[llIIllIlII[400]] = lIlIllllIllI("OPTESXNvjAI=", "MgUNc");
    llIIlIllll[llIIllIlII[401]] = lIlIllllIlIl("", "oEHtc");
    llIIlIllll[llIIllIlII[402]] = lIlIllllIllI("Z2fKAUBCLWQ=", "XMRAb");
    llIIlIllll[llIIllIlII[403]] = lIlIllllIlIl("VmY=", "vFXUR");
    llIIlIllll[llIIllIlII[404]] = lIlIllllIllI("POYTxwAtoA4=", "RiZwW");
    llIIlIllll[llIIllIlII[405]] = lIlIllllIllI("08VxZKSxgco=", "yZQBv");
    llIIlIllll[llIIllIlII[406]] = lIlIllllIllI("l0LPPJSj/Z0hVacOGE62QQ==", "iUJvV");
    llIIlIllll[llIIllIlII[407]] = lIlIllllIllI("0HbbTLJ5N8+ivksTFAFWsw==", "WWSWX");
    llIIlIllll[llIIllIlII[408]] = lIlIllllIllI("LmujL+tgGoI=", "aMhqp");
    llIIlIllll[llIIllIlII[409]] = lIlIllllIlIl("TFU=", "lutoC");
    llIIlIllll[llIIllIlII[410]] = lIlIllllIlll("aS8iJsNMyA8=", "xBmpz");
    llIIlIllll[llIIllIlII[424]] = lIlIllllIllI("V9KPj8bKV4Q=", "qEfza");
    llIIlIllll[llIIllIlII[429]] = lIlIllllIlll("KtCN+fZYfWo=", "ftQtN");
    llIIlIllll[llIIllIlII[431]] = lIlIllllIllI("Egk9BmzgojM=", "oobgW");
    llIIlIllll[llIIllIlII[432]] = lIlIllllIlll("/gXIyLpoJBg=", "Bdzvr");
    llIIlIllll[llIIllIlII[433]] = lIlIllllIlIl("RXRF", "eTecd");
    llIIlIllll[llIIllIlII[434]] = lIlIllllIlll("G0fBSGBhAv8=", "ptoYD");
    llIIlIllll[llIIllIlII[435]] = lIlIllllIlll("IDU2b8aT3K8=", "oxVYI");
    llIIlIllll[llIIllIlII[436]] = lIlIllllIllI("MARNxQ67OPQ=", "yRSBL");
    llIIlIllll[llIIllIlII[437]] = lIlIllllIllI("EbDtZSjsrzY=", "RLiup");
    llIIlIllll[llIIllIlII[438]] = lIlIllllIllI("whMzJpKdppY=", "cZitX");
    llIIlIllll[llIIllIlII[439]] = lIlIllllIlIl("NygD", "smPDR");
    llIIlIllll[llIIllIlII[440]] = lIlIllllIllI("AICM9LkRkGY=", "YjOIT");
    llIIlIllll[llIIllIlII[441]] = lIlIllllIllI("v4GLc+8kctg=", "KHOWq");
    llIIlIllll[llIIllIlII[442]] = lIlIllllIllI("OTVW1V759+I=", "VSkTV");
    llIIlIllll[llIIllIlII[443]] = lIlIllllIlIl("RA==", "dJCwm");
    llIIlIllll[llIIllIlII[444]] = lIlIllllIlIl("", "gPhlM");
  }
  
  private static boolean lllIllllIllI(char llllllllllllllllIlIllIlllIIlllIl, byte llllllllllllllllIlIllIlllIIllIll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean llllIIllI(int llllllllllllllllIlIllIlllllIIIIl) {
    if (llllIIIIlIll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (null != null)
        return (0x8B ^ 0x95) & (0x92 ^ 0x8C ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIIllIlII[3];
  }
  
  private static boolean lllIllllllIl(byte llllllllllllllllIlIllIllIllllllI, String llllllllllllllllIlIllIllIlllllII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static void lllIllllIIIl() {
    llIIllIlII = new int[446];
    llIIllIlII[0] = " ".length();
    llIIllIlII[1] = "  ".length();
    llIIllIlII[2] = "   ".length();
    llIIllIlII[3] = (0x79 ^ 0x2D) & (0x2 ^ 0x56 ^ 0xFFFFFFFF);
    llIIllIlII[4] = 163 + 131 - 246 + 122 ^ 53 + 17 - 58 + 162;
    llIIllIlII[5] = 0x8 ^ 0xD;
    llIIllIlII[6] = 0xA8 ^ 0xAE;
    llIIllIlII[7] = " ".length() ^ 0x46 ^ 0x40;
    llIIllIlII[8] = 0x5B ^ 0x5D ^ 0x1A ^ 0x14;
    llIIllIlII[9] = 0x2D ^ 0x24;
    llIIllIlII[10] = 0xCE ^ 0x8E ^ 0xC7 ^ 0x8D;
    llIIllIlII[11] = 0xA1 ^ 0xAA;
    llIIllIlII[12] = " ".length() ^ 0x2F ^ 0x22;
    llIIllIlII[13] = 0xDC ^ 0x8C ^ 0x61 ^ 0x3C;
    llIIllIlII[14] = 0x9C ^ 0x92;
    llIIllIlII[15] = 0xBD ^ 0xB2;
    llIIllIlII[16] = 0x34 ^ 0x24;
    llIIllIlII[17] = 111 + 104 - 141 + 81 ^ 26 + 58 - 68 + 122;
    llIIllIlII[18] = 0x7F ^ 0x15 ^ 0x4 ^ 0x7C;
    llIIllIlII[19] = 0x2C ^ 0x3F;
    llIIllIlII[20] = 0x7C ^ 0x5B ^ 0xBA ^ 0x89;
    llIIllIlII[21] = 0x32 ^ 0x27;
    llIIllIlII[22] = 0x5B ^ 0x69 ^ 0x5 ^ 0x21;
    llIIllIlII[23] = 0x89 ^ 0xA2 ^ 0x8A ^ 0xB6;
    llIIllIlII[24] = 0x59 ^ 0x41;
    llIIllIlII[25] = 0x35 ^ 0x2C;
    llIIllIlII[26] = 16 + 213 - 128 + 115 ^ 54 + 182 - 208 + 166;
    llIIllIlII[27] = 0x8D ^ 0x96;
    llIIllIlII[28] = 0x5E ^ 0x42;
    llIIllIlII[29] = 0x49 ^ 0x54;
    llIIllIlII[30] = 0x21 ^ 0x3F;
    llIIllIlII[31] = 0x73 ^ 0xF ^ 0x79 ^ 0x1A;
    llIIllIlII[32] = 0xC ^ 0x2C;
    llIIllIlII[33] = 17 + 125 - 5 + 6 ^ 83 + 83 - 161 + 169;
    llIIllIlII[34] = 4 + 10 - -30 + 115 ^ 174 + 34 - 25 + 6;
    llIIllIlII[35] = 0x3A ^ 0x51 ^ 0xF4 ^ 0xBC;
    llIIllIlII[36] = 0x82 ^ 0xA6;
    llIIllIlII[37] = 0xC ^ 0x29;
    llIIllIlII[38] = 0x98 ^ 0xC0 ^ 0x79 ^ 0x7;
    llIIllIlII[39] = 34 + 13 - -34 + 82 ^ 30 + 85 - 99 + 116;
    llIIllIlII[40] = 0x31 ^ 0x59 ^ 0xF4 ^ 0xB4;
    llIIllIlII[41] = 56 + 34 - 63 + 103 ^ 15 + 47 - -64 + 45;
    llIIllIlII[42] = 73 + 47 - 27 + 61 ^ 157 + 81 - 176 + 114;
    llIIllIlII[43] = 0x18 ^ 0x27 ^ 0x82 ^ 0x96;
    llIIllIlII[44] = 0x67 ^ 0x4B;
    llIIllIlII[45] = 0xB9 ^ 0x87 ^ 0x1C ^ 0xF;
    llIIllIlII[46] = 0xA3 ^ 0x90 ^ 0xBB ^ 0xA6;
    llIIllIlII[47] = 187 + 141 - 150 + 61 ^ 25 + 43 - -90 + 34;
    llIIllIlII[48] = 0x3D ^ 0xD;
    llIIllIlII[49] = 0x83 ^ 0x99 ^ 0x5E ^ 0x75;
    llIIllIlII[50] = 0x81 ^ 0xB3;
    llIIllIlII[51] = 135 + 46 - 112 + 91 ^ 23 + 110 - 54 + 68;
    llIIllIlII[52] = 0x12 ^ 0x37 ^ 0x4D ^ 0x5C;
    llIIllIlII[53] = 0x4E ^ 0x7B;
    llIIllIlII[54] = 0xB ^ 0x3D;
    llIIllIlII[55] = 0x67 ^ 0x27 ^ 0x78 ^ 0xF;
    llIIllIlII[56] = 0x73 ^ 0x4B;
    llIIllIlII[57] = 0xBF ^ 0xC4 ^ 0x4F ^ 0xD;
    llIIllIlII[58] = 0x77 ^ 0x66 ^ 0x41 ^ 0x6A;
    llIIllIlII[59] = 0x67 ^ 0x5C;
    llIIllIlII[60] = 0x74 ^ 0x48;
    llIIllIlII[61] = 0xFA ^ 0xC7;
    llIIllIlII[62] = 0xFD ^ 0xC3;
    llIIllIlII[63] = 0xFB ^ 0xC4;
    llIIllIlII[64] = 31 + 107 - 74 + 69 ^ 27 + 43 - 5 + 132;
    llIIllIlII[65] = 0x75 ^ 0x28 ^ 0xA1 ^ 0xBD;
    llIIllIlII[66] = 0x9 ^ 0x4B;
    llIIllIlII[67] = 0xDC ^ 0x9F;
    llIIllIlII[68] = 76 + 78 - 88 + 63 ^ 47 + 123 - 43 + 70;
    llIIllIlII[69] = 0xB ^ 0x4E;
    llIIllIlII[70] = 0xD3 ^ 0xA6 ^ 0x43 ^ 0x70;
    llIIllIlII[71] = 0x38 ^ 0x62 ^ 0xBF ^ 0xA2;
    llIIllIlII[72] = 0x53 ^ 0x1B;
    llIIllIlII[73] = 13 + 209 - 178 + 182 ^ 85 + 131 - 100 + 55;
    llIIllIlII[74] = 0xC ^ 0x46;
    llIIllIlII[75] = 0x4 ^ 0x4F;
    llIIllIlII[76] = 0xA5 ^ 0x99 ^ 0x58 ^ 0x28;
    llIIllIlII[77] = (0x2F ^ 0xE) & (0x79 ^ 0x58 ^ 0xFFFFFFFF) ^ 0xEA ^ 0xA7;
    llIIllIlII[78] = 0x3A ^ 0x5B ^ 0x85 ^ 0xAA;
    llIIllIlII[79] = 0x2C ^ 0x63;
    llIIllIlII[80] = 0x7D ^ 0x71 ^ 0x61 ^ 0x3D;
    llIIllIlII[81] = 0x17 ^ 0x46;
    llIIllIlII[82] = 0x75 ^ 0x27;
    llIIllIlII[83] = 0x2C ^ 0x7F;
    llIIllIlII[84] = 0x49 ^ 0x1D;
    llIIllIlII[85] = 210 + 141 - 314 + 176 ^ 104 + 14 - 111 + 121;
    llIIllIlII[86] = 0 + 14 - -50 + 165 ^ 59 + 113 - 41 + 48;
    llIIllIlII[87] = 0x56 ^ 0x2C ^ 0xB4 ^ 0x99;
    llIIllIlII[88] = 0x44 ^ 0x73 ^ 0x4 ^ 0x6B;
    llIIllIlII[89] = 0x21 ^ 0x72 ^ 0x1B ^ 0x11;
    llIIllIlII[90] = 0xE ^ 0x3A ^ 0x39 ^ 0x57;
    llIIllIlII[91] = 0x7 ^ 0x5C;
    llIIllIlII[92] = 50 + 144 - 125 + 146 ^ 103 + 35 - 101 + 102;
    llIIllIlII[93] = 0xD6 ^ 0x8B;
    llIIllIlII[94] = 0x4B ^ 0x15;
    llIIllIlII[95] = 0x37 ^ 0xB ^ 0x68 ^ 0xB;
    llIIllIlII[96] = 0x72 ^ 0x12;
    llIIllIlII[97] = 0x46 ^ 0x27;
    llIIllIlII[98] = 152 + 132 - 159 + 35 ^ 162 + 162 - 215 + 85;
    llIIllIlII[99] = 0x7 ^ 0x46 ^ 0xB5 ^ 0x97;
    llIIllIlII[100] = 0xFB ^ 0x9F;
    llIIllIlII[101] = 0x53 ^ 0x65 ^ 0x72 ^ 0x21;
    llIIllIlII[102] = 0x2E ^ 0x48;
    llIIllIlII[103] = 0x8 ^ 0x41 ^ 0x45 ^ 0x6B;
    llIIllIlII[104] = 0xEB ^ 0xC6 ^ 0x66 ^ 0x23;
    llIIllIlII[105] = 173 + 86 - 209 + 152 ^ 116 + 31 - 81 + 97;
    llIIllIlII[106] = 0x25 ^ 0x4F;
    llIIllIlII[107] = " ".length() ^ 0xDE ^ 0xB4;
    llIIllIlII[108] = 0x6F ^ 0x3;
    llIIllIlII[109] = 0x11 ^ 0x7C;
    llIIllIlII[110] = 0x47 ^ 0x1A ^ 0x68 ^ 0x5B;
    llIIllIlII[111] = 23 + 201 - 112 + 113 ^ 14 + 69 - -38 + 21;
    llIIllIlII[112] = 0xC7 ^ 0xB7;
    llIIllIlII[113] = 0x61 ^ 0x10;
    llIIllIlII[114] = 0xA6 ^ 0xC2 ^ 0x10 ^ 0x6;
    llIIllIlII[115] = 0x6E ^ 0x5F ^ 0xCB ^ 0x89;
    llIIllIlII[116] = 0xF ^ 0x7B;
    llIIllIlII[117] = 0xDE ^ 0xAB;
    llIIllIlII[118] = 28 + 138 - 81 + 117 ^ 176 + 82 - 185 + 115;
    llIIllIlII[119] = 0x31 ^ 0x46;
    llIIllIlII[120] = "  ".length() ^ 0x1 ^ 0x7B;
    llIIllIlII[121] = 0x45 ^ 0x3C;
    llIIllIlII[122] = 119 + 84 - 57 + 42 ^ 27 + 180 - 197 + 188;
    llIIllIlII[123] = (0x96 ^ 0x8C) + (0x32 ^ 0x4E) - (0xBE ^ 0x9A) + (0x5B ^ 0x4B);
    llIIllIlII[124] = 12 + 156 - -19 + 6;
    llIIllIlII[125] = 140 + 83 - 117 + 62;
    llIIllIlII[126] = (0x7A ^ 0x9) + (0x5A ^ 0x64) - 112 + 103 - 182 + 118 + (0xC ^ 0x79);
    llIIllIlII[127] = 96 + 162 - 193 + 110;
    llIIllIlII[128] = (0x29 ^ 0x79) + (0x9A ^ 0xAB) - (0x2D ^ 0x17) + (0xE ^ 0x5B);
    llIIllIlII[129] = 0x69 ^ 0x1D ^ 0xB5 ^ 0xBA;
    llIIllIlII[130] = 0x10 ^ 0x6C;
    llIIllIlII[131] = 0xD4 ^ 0xA9;
    llIIllIlII[132] = 0xF4 ^ 0x8A;
    llIIllIlII[133] = 34 + 1 - -80 + 12;
    llIIllIlII[134] = (0x1F ^ 0x66) + (0x24 ^ 0x50) - 68 + 51 - 75 + 137 + (0x6C ^ 0x24);
    llIIllIlII[135] = -" ".length();
    llIIllIlII[136] = 66 + 69 - 63 + 57;
    llIIllIlII[137] = (0x33 ^ 0x4F) + (0xE9 ^ 0x94) - 110 + 13 - 43 + 112 + (0x33 ^ 0x79);
    llIIllIlII[138] = 38 + 129 - 104 + 69;
    llIIllIlII[139] = (0x5F ^ 0xB) + (0x3C ^ 0x24) - (0x40 ^ 0x5A) + (0x60 ^ 0x53);
    llIIllIlII[140] = 11 + 21 - -79 + 23;
    llIIllIlII[141] = 82 + 126 - 80 + 0 + (0x99 ^ 0x97) - (0x30 ^ 0x25) + (0xBC ^ 0x9D);
    llIIllIlII[142] = 136 + 112 - 199 + 90;
    llIIllIlII[143] = (0xCC ^ 0x92) + "  ".length() - (0x64 ^ 0x28) + (0x2B ^ 0x58);
    llIIllIlII[144] = 47 + 67 - -22 + 0;
    llIIllIlII[145] = 75 + 59 - -1 + 2;
    llIIllIlII[146] = 73 + 63 - 112 + 114;
    llIIllIlII[147] = 35 + 75 - 77 + 107;
    llIIllIlII[148] = 84 + 4 - 69 + 122;
    llIIllIlII[149] = 107 + 18 - 30 + 47;
    llIIllIlII[150] = (0x9B ^ 0xAF) + (0xD0 ^ 0x88) - (0xF0 ^ 0xAB) + (0xC3 ^ 0x9C);
    llIIllIlII[151] = (0x84 ^ 0xC7) + (0x57 ^ 0x5A) - -(0xA1 ^ 0xAF) + (0x76 ^ 0x45);
    llIIllIlII[152] = 116 + 119 - 196 + 107;
    llIIllIlII[153] = (0xB3 ^ 0x8C) + (0x6D ^ 0x67) - (0x4B ^ 0x45) + (0xC7 ^ 0x9F);
    llIIllIlII[154] = 109 + 79 - 99 + 59;
    llIIllIlII[155] = (0x58 ^ 0xF) + (0xAD ^ 0x98) - (0x53 ^ 0x4B) + (0xB ^ 0x2A);
    llIIllIlII[156] = (0xB ^ 0x22) + "  ".length() - -(0xA7 ^ 0xAD) + (0x3E ^ 0x5F);
    llIIllIlII[157] = (0x3B ^ 0x5A) + 140 + 117 - 165 + 58 - 37 + 105 - -56 + 41 + 129 + 133 - 196 + 77;
    llIIllIlII[158] = 23 + 121 - 84 + 91 + (0x2 ^ 0x56) - 18 + 73 - -37 + 88 + 111 + 50 - 144 + 116;
    llIIllIlII[159] = 91 + 88 - 53 + 27;
    llIIllIlII[160] = 146 + 93 - 104 + 20;
    llIIllIlII[161] = (0x10 ^ 0x68) + (0x7A ^ 0x72) - (0xD ^ 0x64) + 85 + 15 - 2 + 36;
    llIIllIlII[162] = 130 + 137 - 224 + 115;
    llIIllIlII[163] = (0xCE ^ 0xBB) + (0x76 ^ 0x7F) - (0x41 ^ 0xD) + (0x79 ^ 0x14);
    llIIllIlII[164] = 110 + 43 - 50 + 57;
    llIIllIlII[165] = 56 + 86 - 49 + 68;
    llIIllIlII[166] = (0xF8 ^ 0xA6) + 55 + 146 - 111 + 71 - (0xDB ^ 0xAE) + (0x44 ^ 0x5C);
    llIIllIlII[167] = 159 + 14 - 58 + 48;
    llIIllIlII[168] = (0x2A ^ 0x60) + (0x59 ^ 0x5C) - -(0x9B ^ 0x8A) + (0x42 ^ 0x6);
    llIIllIlII[169] = 17 + 35 - -81 + 32;
    llIIllIlII[170] = 71 + 18 - 77 + 154;
    llIIllIlII[171] = 12 + 115 - 44 + 72 + (0x85 ^ 0x9E) - 141 + 58 - 83 + 33 + 113 + 122 - 214 + 113;
    llIIllIlII[172] = 108 + 81 - 128 + 79 + 58 + 110 - 70 + 66 - (0xFFFFABBD & 0x554A) + 36 + 100 - 46 + 39;
    llIIllIlII[173] = (0x20 ^ 0x65) + (0x6F ^ 0x59) - (0x84 ^ 0x9E) + (0xDD ^ 0x94);
    llIIllIlII[174] = (0x21 ^ 0x35) + 118 + 141 - 253 + 153 - (0x9A ^ 0x90) + "  ".length();
    llIIllIlII[175] = 40 + 70 - 48 + 110;
    llIIllIlII[176] = (0x44 ^ 0x5) + 118 + 84 - 161 + 116 - 41 + 175 - 10 + 15 + 51 + 158 - 80 + 43;
    llIIllIlII[177] = 48 + 96 - 107 + 137;
    llIIllIlII[178] = (0xC9 ^ 0x92) + (0x7D ^ 0x33) - 114 + 51 - 66 + 39 + 24 + 84 - 72 + 111;
    llIIllIlII[179] = -(0x64 ^ 0x14);
    llIIllIlII[180] = 175 + 168 - 337 + 218;
    llIIllIlII[181] = 55 + 91 - -25 + 14;
    llIIllIlII[182] = 224 + 192 - 197 + 25;
    llIIllIlII[183] = (0x4B ^ 0x11) + (0x81 ^ 0x99) - -(0x81 ^ 0xA1) + (0x5C ^ 0x42);
    llIIllIlII[184] = 15 + 123 - 132 + 157 + (0x75 ^ 0x1B) - 51 + 12 - 47 + 118 + (0x38 ^ 0x1E);
    llIIllIlII[185] = (0x2B ^ 0x3) + 98 + 38 - 82 + 74 - (0xED ^ 0xB7) + (0xD ^ 0x68);
    llIIllIlII[186] = 126 + 102 - 145 + 97;
    llIIllIlII[187] = (0xA4 ^ 0xB8) + (0x4A ^ 0x65) - -(0x45 ^ 0x2D) + "  ".length();
    llIIllIlII[188] = (0x18 ^ 0x4E) + (0xCC ^ 0xC0) - (0x47 ^ 0x48) + (0x13 ^ 0x70);
    llIIllIlII[189] = 114 + 170 - 239 + 144;
    llIIllIlII[190] = 35 + 151 - 122 + 119;
    llIIllIlII[191] = 23 + 53 - -44 + 11 + 60 + 9 - -71 + 37 - 20 + 64 - 30 + 93 + (0xB9 ^ 0xAE);
    llIIllIlII[192] = 72 + 47 - 77 + 144;
    llIIllIlII[193] = 70 + 131 - 85 + 71;
    llIIllIlII[194] = 112 + 151 - 98 + 23;
    llIIllIlII[195] = 40 + 120 - -11 + 19;
    llIIllIlII[196] = (0xA2 ^ 0xA7) + (0xE1 ^ 0xAD) - ((0xFD ^ 0xB1) & (0x22 ^ 0x6E ^ 0xFFFFFFFF)) + (0xE ^ 0x60);
    llIIllIlII[197] = 94 + 94 - 187 + 152 + 30 + 4 - -13 + 85 - 180 + 39 - 43 + 21 + (0x35 ^ 0x5D);
    llIIllIlII[198] = (0xC0 ^ 0xBC) + (0xFF ^ 0xC1) - 89 + 105 - 193 + 143 + 123 + 19 - 121 + 131;
    llIIllIlII[199] = 132 + 137 - 172 + 80 + (0xAB ^ 0x8D) - 163 + 148 - 111 + 8 + 82 + 56 - -32 + 18;
    llIIllIlII[200] = (0xE4 ^ 0xAC) + 37 + 26 - 43 + 122 - (0xCF ^ 0xBB) + (0xFA ^ 0x98);
    llIIllIlII[201] = 65 + 80 - 29 + 81;
    llIIllIlII[202] = (0x38 ^ 0x1A) + (0x77 ^ 0x15) - -(0xB ^ 0x1C) + (0x1 ^ 0x2A);
    llIIllIlII[203] = 82 + 125 - 11 + 3;
    llIIllIlII[204] = 154 + 138 - 127 + 22 + (0x7D ^ 0x28) - (0x61 ^ 0x11) + (0x33 ^ 0x1B);
    llIIllIlII[205] = 34 + 74 - -11 + 82;
    llIIllIlII[206] = 120 + 116 - 150 + 116;
    llIIllIlII[207] = (0xA ^ 0x55) + 39 + 15 - -9 + 75 - 142 + 8 - 114 + 112 + (0xD0 ^ 0xA6);
    llIIllIlII[208] = (0x4E ^ 0x14) + (0xC4 ^ 0x80) - (0xF0 ^ 0xBC) + (0x2B ^ 0x51);
    llIIllIlII[209] = (0x4C ^ 0x44) + (0x67 ^ 0x6E) - -(0x12 ^ 0x4E) + (0x2C ^ 0x4C);
    llIIllIlII[210] = 129 + 189 - 178 + 66;
    llIIllIlII[211] = 97 + 196 - 224 + 138;
    llIIllIlII[212] = 59 + 50 - -55 + 44;
    llIIllIlII[213] = 191 + 193 - 344 + 169;
    llIIllIlII[214] = 148 + 100 - 226 + 188;
    llIIllIlII[215] = 79 + 123 - 93 + 102;
    llIIllIlII[216] = (0xD4 ^ 0xB2) + (0x56 ^ 0x12) - (0x71 ^ 0x37) + (0x20 ^ 0x50);
    llIIllIlII[217] = 195 + 64 - 138 + 92;
    llIIllIlII[218] = 174 + 94 - 247 + 193;
    llIIllIlII[219] = (0x40 ^ 0x2E) + (0xBC ^ 0xA7) - (0x64 ^ 0x19) + 48 + 201 - 55 + 9;
    llIIllIlII[220] = 161 + 83 - 91 + 63;
    llIIllIlII[221] = (0x5F ^ 0x27) + 45 + 121 - 78 + 47 - 78 + 212 - 164 + 92 + 58 + 123 - 12 + 11;
    llIIllIlII[222] = (0x29 ^ 0x68) + 95 + 62 - 58 + 38 - 24 + 135 - 103 + 84 + 39 + 79 - -23 + 15;
    llIIllIlII[223] = 94 + 15 - -16 + 94;
    llIIllIlII[224] = 152 + 167 - 197 + 81 + 106 + 8 - 98 + 142 - (0xFFFF832F & 0x7DFA) + 21 + 143 - 28 + 21;
    llIIllIlII[225] = 48 + 22 - -147 + 4;
    llIIllIlII[226] = 138 + 73 - 179 + 115 + (0x79 ^ 0x57) - 85 + 29 - 65 + 90 + 93 + 166 - 244 + 153;
    llIIllIlII[227] = 22 + 173 - 164 + 148 + (0x43 ^ 0x6D) - (0x25 ^ 0x3A) + (0xB ^ 0x16);
    llIIllIlII[228] = (0x67 ^ 0x47) + (0x7C ^ 0x6B) - -(0x45 ^ 0x2F) + (0x2C ^ 0x6C);
    llIIllIlII[229] = 162 + 179 - 296 + 166 + " ".length() - 60 + 112 - 133 + 103 + 23 + 108 - 13 + 38;
    llIIllIlII[230] = 222 + 197 - 252 + 60;
    llIIllIlII[231] = 1 + 69 - -51 + 107;
    llIIllIlII[232] = 136 + 219 - 166 + 40;
    llIIllIlII[233] = 96 + 96 - 35 + 73;
    llIIllIlII[234] = 153 + 195 - 172 + 35 + 0 + 87 - 68 + 204 - (0xFFFFA1FC & 0x5F9F) + 128 + 158 - 243 + 166;
    llIIllIlII[235] = 140 + 9 - 28 + 111;
    llIIllIlII[236] = 65 + 150 - 95 + 82 + (0x5F ^ 0x4D) - (0x7B ^ 0x1D) + (0xB2 ^ 0xC1);
    llIIllIlII[237] = (0x4D ^ 0x21) + (0x7 ^ 0x65) - (0x13 ^ 0x53) + (0x75 ^ 0x29);
    llIIllIlII[238] = 170 + 9 - -26 + 30;
    llIIllIlII[239] = 118 + 75 - 118 + 161;
    llIIllIlII[240] = (0x9 ^ 0x16) + (0x6A ^ 0x4B) - (0x31 ^ 0x2B) + 183 + 56 - 162 + 122;
    llIIllIlII[241] = 158 + 52 - 57 + 85;
    llIIllIlII[242] = 217 + 114 - 265 + 173;
    llIIllIlII[243] = (0x5 ^ 0x75) + 113 + 220 - 310 + 202 - (0xFFFFC75F & 0x39F0) + 118 + 59 - 146 + 208;
    llIIllIlII[244] = 108 + 54 - 122 + 201;
    llIIllIlII[245] = 174 + 154 - 154 + 68;
    llIIllIlII[246] = 164 + 69 - 86 + 41 + (0xAA ^ 0x83) - 70 + 0 - -63 + 67 + 6 + 105 - -93 + 10;
    llIIllIlII[247] = (0x4B ^ 0x4C) + 45 + 68 - -21 + 3 - " ".length() + (0x61 ^ 0x7);
    llIIllIlII[248] = 151 + 239 - 300 + 156;
    llIIllIlII[249] = 11 + 137 - 75 + 165 + (0xA ^ 0x63) - (0xFFFFA507 & 0x5BFE) + 132 + 121 - 105 + 18;
    llIIllIlII[250] = 6 + 209 - 35 + 43 + 21 + 12 - -35 + 78 - (0xFFFFA5FD & 0x5B6F) + 198 + 42 - 65 + 69;
    llIIllIlII[251] = 212 + 165 - 303 + 175;
    llIIllIlII[252] = 178 + 129 - 233 + 116 + 158 + 117 - 271 + 218 - (0xFFFFE5FD & 0x1B62) + 107 + 8 - -15 + 60;
    llIIllIlII[253] = 184 + 14 - -2 + 6 + 19 + 59 - -59 + 44 - (0xFFFFB1DF & 0x4F6E) + 179 + 137 - 310 + 192;
    llIIllIlII[254] = (0xC1 ^ 0x9C) + (0x36 ^ 0x4C) - (0x23 ^ 0x76) + (0xC ^ 0x76);
    llIIllIlII[255] = 26 + 29 - 29 + 129 + (0x21 ^ 0x33) - 91 + 86 - 23 + 3 + 31 + 84 - 51 + 173;
    llIIllIlII[256] = 22 + 29 - -53 + 73 + 101 + 199 - 202 + 115 - (0xFFFFE5FF & 0x1B2F) + 147 + 94 - 213 + 139;
    llIIllIlII[257] = 111 + 144 - 81 + 56 + (0x38 ^ 0x5E) - (0xFFFFDF0F & 0x21F7) + 113 + 30 - -13 + 30;
    llIIllIlII[258] = -(0xFFFFF77F & 0x7EFB) & 0xFFFFF77F & 0x7FFA;
    llIIllIlII[259] = 0xFFFF91C3 & 0x6F3D;
    llIIllIlII[260] = -(0xFFFFEFEA & 0x7EFF) & 0xFFFFFFFF & 0x6FEB;
    llIIllIlII[261] = 0xFFFF9D9B & 0x6367;
    llIIllIlII[262] = -(0xFFFFFCFB & 0x1FF5) & 0xFFFFFFFF & 0x1DF4;
    llIIllIlII[263] = 0xFFFFAD35 & 0x53CF;
    llIIllIlII[264] = 0xFFFFEB66 & 0x159F;
    llIIllIlII[265] = -(0xFFFFB3FB & 0x7E9D) & 0xFFFFBBDF & 0x77BF;
    llIIllIlII[266] = -(0xFFFFE4FD & 0x7FD7) & 0xFFFFE7DD & 0x7DFE;
    llIIllIlII[267] = 0xFFFFC599 & 0x3B6F;
    llIIllIlII[268] = -(0xFFFFC9BF & 0x7675) & 0xFFFFF93E & 0x47FF;
    llIIllIlII[269] = 0xFFFF8D9B & 0x736F;
    llIIllIlII[270] = 0xFFFF8D7C & 0x738F;
    llIIllIlII[271] = 0xFFFFAB1D & 0x55EF;
    llIIllIlII[272] = 0xFFFFFDFF & 0x30E;
    llIIllIlII[273] = 0xFFFFC35F & 0x3DAF;
    llIIllIlII[274] = -(0xFFFFF46F & 0x6FBE) & 0xFFFFF5BD & 0x6F7F;
    llIIllIlII[275] = -(0xFFFFFEEF & 0x677B) & 0xFFFFFF7F & 0x67FB;
    llIIllIlII[276] = 0xFFFFCDB3 & 0x335E;
    llIIllIlII[277] = 0xFFFF811F & 0x7FF3;
    llIIllIlII[278] = 0xFFFFB11F & 0x4FF4;
    llIIllIlII[279] = -(0xFFFFF4FF & 0x4BA9) & 0xFFFFE9FF & 0x57BD;
    llIIllIlII[280] = 0xFFFFFD1F & 0x3F6;
    llIIllIlII[281] = 0xFFFFE1FF & 0x1F17;
    llIIllIlII[282] = 0xFFFFA37D & 0x5D9A;
    llIIllIlII[283] = -(0xFFFFD767 & 0x6CDF) & 0xFFFFF55F & 0x4FFF;
    llIIllIlII[284] = 0xFFFFA91E & 0x57FB;
    llIIllIlII[285] = 0xFFFFDB7F & 0x259B;
    llIIllIlII[286] = -(0xFFFFAE27 & 0x7DFB) & 0xFFFFFDFF & 0x2F3E;
    llIIllIlII[287] = -(0xFFFFFDCF & 0x3EB3) & 0xFFFFFDFF & 0x3F9F;
    llIIllIlII[288] = 0xFFFF877E & 0x799F;
    llIIllIlII[289] = 0xFFFFEB7F & 0x159F;
    llIIllIlII[290] = -(0xFFFFBB5F & 0x6EFE) & 0xFFFFAFFD & 0x7B7F;
    llIIllIlII[291] = 0xFFFFC773 & 0x39AD;
    llIIllIlII[292] = 0xFFFFFBB3 & 0x56E;
    llIIllIlII[293] = -(0xFFFFBED7 & 0x6F3D) & 0xFFFFBFFF & 0x6F37;
    llIIllIlII[294] = -(0xFFFFDF77 & 0x3C89) & 0xFFFFDFBD & 0x3D66;
    llIIllIlII[295] = 0xFFFFCFBF & 0x3165;
    llIIllIlII[296] = 0xFFFFD7BE & 0x2967;
    llIIllIlII[297] = 0xFFFFE5F7 & 0x1B2F;
    llIIllIlII[298] = 0xFFFFD129 & 0x2FFE;
    llIIllIlII[299] = -(0xFFFFD7E1 & 0x7E5F) & 0xFFFFF77B & 0x5FED;
    llIIllIlII[300] = 0xFFFF9D6B & 0x63BE;
    llIIllIlII[301] = -(0xFFFFDBF7 & 0x7C1D) & 0xFFFFFB3F & 0x5DFF;
    llIIllIlII[302] = 0xFFFFF57D & 0xBAE;
    llIIllIlII[303] = 0xFFFF8D7D & 0x73AF;
    llIIllIlII[304] = 0xFFFFD52E & 0x2BFF;
    llIIllIlII[305] = 0xFFFFF16F & 0xFBF;
    llIIllIlII[306] = 0xFFFFC378 & 0x3DB7;
    llIIllIlII[307] = -(0xFFFFD6FF & 0x7FCF) & 0xFFFFDFFF & 0x77FF;
    llIIllIlII[308] = 0xFFFFBF3A & 0x41F7;
    llIIllIlII[309] = 0xFFFFA53B & 0x5BF7;
    llIIllIlII[310] = -(0xFFFFFDDF & 0x46E2) & 0xFFFFFFF7 & 0x45FD;
    llIIllIlII[311] = 0xFFFFE13F & 0x1FF5;
    llIIllIlII[312] = -(0xFFFFF4A9 & 0x7F5F) & 0xFFFFF73F & 0x7DFE;
    llIIllIlII[313] = -(0xFFFFFF81 & 0x76FF) & 0xFFFFF7B7 & Short.MAX_VALUE;
    llIIllIlII[314] = 0xFFFFCB7B & 0x35BC;
    llIIllIlII[315] = 0xFFFFB779 & 0x49BF;
    llIIllIlII[316] = -(0xFFFFFC06 & Short.MAX_VALUE) & 0xFFFFFFBF & 0x7D7F;
    llIIllIlII[317] = -(0xFFFFCC75 & 0x7F8F) & 0xFFFFDFBF & 0x6D7F;
    llIIllIlII[318] = 0xFFFFB1BC & 0x4F7F;
    llIIllIlII[319] = 0xFFFFBBBD & 0x457F;
    llIIllIlII[320] = 0xFFFF857E & 0x7BBF;
    llIIllIlII[321] = -(0xFFFFF281 & 0x5FFF) & 0xFFFFF7FF & 0x5BBF;
    llIIllIlII[322] = 0xFFFF875E & 0x79E1;
    llIIllIlII[323] = 0xFFFF85ED & 0x7B53;
    llIIllIlII[324] = 0xFFFFC353 & 0x3DEE;
    llIIllIlII[325] = 0xFFFFFFF3 & 0x14F;
    llIIllIlII[326] = 0xFFFFC5EF & 0x3B54;
    llIIllIlII[327] = -(0xFFFFFE89 & 0x657F) & 0xFFFFFDDF & 0x676D;
    llIIllIlII[328] = -(0xFFFF9EFB & 0x7715) & 0xFFFF9F7F & 0x77D6;
    llIIllIlII[329] = -(0xFFFFF2B3 & 0x2FED) & 0xFFFFE7EF & 0x3BF7;
    llIIllIlII[330] = -(0xFFFFEEFF & 0x7BB4) & 0xFFFFFFFF & 0x6BFB;
    llIIllIlII[331] = -(0xFFFFEFEF & 0x36B7) & 0xFFFFFFFF & 0x27EF;
    llIIllIlII[332] = 0xFFFFC16B & 0x3FDE;
    llIIllIlII[333] = 0xFFFFD35F & 0x2DEB;
    llIIllIlII[334] = 0xFFFF877D & 0x79CE;
    llIIllIlII[335] = -(0xFFFFEDA9 & 0x3AF7) & 0xFFFFBDFD & 0x6BEF;
    llIIllIlII[336] = -(0xFFFFF25F & 0x3FB1) & 0xFFFFF35F & 0x3FFE;
    llIIllIlII[337] = 0xFFFFE76F & 0x19DF;
    llIIllIlII[338] = -(0xFFFFDCE9 & 0x7B3E) & 0xFFFFDD77 & 0x7BFF;
    llIIllIlII[339] = -(0xFFFFFEBF & 0x7FE3) & 0xFFFFFFF7 & 0x7FFB;
    llIIllIlII[340] = 0xFFFFD956 & 0x27FB;
    llIIllIlII[341] = 0xFFFFDB5B & 0x25F7;
    llIIllIlII[342] = -(0xFFFFFF33 & 0x2CED) & 0xFFFFFF7E & 0x2DF5;
    llIIllIlII[343] = 0xFFFFDFDF & 0x2175;
    llIIllIlII[344] = -(0xFFFFB5BA & 0x6E67) & 0xFFFFFF7F & 0x25F7;
    llIIllIlII[345] = -(0xFFFFFFAF & 0x6C51) & 0xFFFFEFD7 & 0x7D7F;
    llIIllIlII[346] = -(0xFFFFED9C & 0x3A6B) & 0xFFFFFF7F & 0x29DF;
    llIIllIlII[347] = -(0xFFFFDFF7 & 0x3E2F) & 0xFFFFDF7F & 0x3FFF;
    llIIllIlII[348] = 0xFFFF957B & 0x6BDE;
    llIIllIlII[349] = -(0xFFFFBE73 & 0x7F8D) & 0xFFFFFFFB & 0x3F5F;
    llIIllIlII[350] = 0xFFFFBD5E & 0x43FD;
    llIIllIlII[351] = -(0xFFFFFCA1 & 0x5BFF) & 0xFFFFF9FD & 0x5FFF;
    llIIllIlII[352] = 0xFFFF957F & 0x6BDE;
    llIIllIlII[353] = 0xFFFF8B5F & 0x75FF;
    llIIllIlII[354] = 0xFFFFB76E & 0x49F1;
    llIIllIlII[355] = -(0xFFFFDEF7 & 0x3B89) & 0xFFFFDFFF & 0x3BE1;
    llIIllIlII[356] = 0xFFFFFDE3 & 0x37E;
    llIIllIlII[357] = 0xFFFFCD7B & 0x33E7;
    llIIllIlII[358] = -(0xFFFFACDC & 0x572F) & 0xFFFFB7EF & 0x4D7F;
    llIIllIlII[359] = 0xFFFF9FED & 0x6177;
    llIIllIlII[360] = 0xFFFFFDE7 & 0x37E;
    llIIllIlII[361] = -(0xFFFFE84D & 0x3FBB) & 0xFFFFA9EF & 0x7F7F;
    llIIllIlII[362] = 0xFFFFFBFF & 0x568;
    llIIllIlII[363] = 0xFFFF8FED & 0x717B;
    llIIllIlII[364] = -(0xFFFFBEB1 & 0x77DF) & 0xFFFFBFFF & 0x77FA;
    llIIllIlII[365] = 0xFFFFABFF & 0x556B;
    llIIllIlII[366] = -(0xFFFFF9DE & 0x6EB5) & 0xFFFFEBFF & 0x7DFF;
    llIIllIlII[367] = -(0xFFFFF0E3 & 0x6F9D) & 0xFFFFF1FD & 0x6FEF;
    llIIllIlII[368] = -(0xFFFFDD72 & 0x769F) & 0xFFFFD77F & 0x7DFF;
    llIIllIlII[369] = -(0xFFFFE8B5 & 0x7FDB) & 0xFFFFEDFF & 0x7BFF;
    llIIllIlII[370] = -(0xFFFFEB87 & 0x3EFD) & 0xFFFFABF4 & Short.MAX_VALUE;
    llIIllIlII[371] = 0xFFFFABF9 & 0x5577;
    llIIllIlII[372] = 0xFFFF8573 & 0x7BFE;
    llIIllIlII[373] = 0xFFFFF5F7 & 0xB7B;
    llIIllIlII[374] = -(0xFFFF8AB7 & 0x7FCB) & 0xFFFFEBFE & 0x1FF7;
    llIIllIlII[375] = -(0xFFFFFF9D & 0x26E3) & 0xFFFFFFF7 & 0x27FD;
    llIIllIlII[376] = 0xFFFF8DFF & 0x7376;
    llIIllIlII[377] = -(0xFFFFFEEF & 0x2991) & 0xFFFFEDF7 & 0x3BFF;
    llIIllIlII[378] = -(0xFFFFFCBB & 0x5FC5) & 0xFFFFDDF8 & Short.MAX_VALUE;
    llIIllIlII[379] = -(0xFFFFFED7 & 0xBAD) & 0xFFFF8BFF & 0x7FFD;
    llIIllIlII[380] = 0xFFFFB97F & 0x47FA;
    llIIllIlII[381] = -(0xFFFFFEE7 & 0x7B9D) & 0xFFFFFFFF & 0x7BFF;
    llIIllIlII[382] = 0xFFFFDFFD & 0x217E;
    llIIllIlII[383] = 0xFFFFC5FF & 0x3B7D;
    llIIllIlII[384] = -(0xFFFFE6F1 & 0x7B8F) & 0xFFFFF7FF & 0x6BFE;
    llIIllIlII[385] = 0xFFFFB97F & 0x47FF;
    llIIllIlII[386] = -(0xFFFFFD5F & 0x4AF7) & 0xFFFFEDF7 & 0x5BDE;
    llIIllIlII[387] = -(0xFFFFDCF7 & 0x731D) & 0xFFFFFBF7 & 0x559D;
    llIIllIlII[388] = -(0xFFFFBF6B & 0x5EDE) & 0xFFFF9FCF & 0x7FFB;
    llIIllIlII[389] = 0xFFFFEDD7 & 0x13AB;
    llIIllIlII[390] = -(0xFFFFFEC3 & 0x777F) & 0xFFFFF7D6 & 0x7FEF;
    llIIllIlII[391] = 0xFFFFE7E7 & 0x199D;
    llIIllIlII[392] = 0xFFFF85CF & 0x7BB6;
    llIIllIlII[393] = 0xFFFFE9E7 & 0x179F;
    llIIllIlII[394] = -(0xFFFFBFD3 & 0x7C7E) & 0xFFFFBFFF & 0x7DD9;
    llIIllIlII[395] = -(0xFFFFF6A9 & 0x7F77) & 0xFFFFF7B9 & 0x7FEF;
    llIIllIlII[396] = 0xFFFF87EA & 0x799F;
    llIIllIlII[397] = 0xFFFF9BEB & 0x659F;
    llIIllIlII[398] = 0xFFFFBBDE & 0x45AD;
    llIIllIlII[399] = -(0xFFFFB7D5 & 0x6C7B) & 0xFFFFBDFD & 0x67DF;
    llIIllIlII[400] = -(0xFFFFFEB6 & 0x3B4B) & 0xFFFFFB9F & 0x3FEF;
    llIIllIlII[401] = -(0xFFFFD77F & 0x6EA1) & 0xFFFFE7BF & 0x5FEF;
    llIIllIlII[402] = -(0xFFFFFEF3 & 0x1F0D) & 0xFFFFDFD6 & 0x3FB9;
    llIIllIlII[403] = 0xFFFFBFB7 & 0x41D9;
    llIIllIlII[404] = -(0xFFFFF8F6 & 0x3F6B) & 0xFFFFF9F3 & 0x3FFF;
    llIIllIlII[405] = -(0xFFFFAE4D & 0x7FF3) & 0xFFFFBFDB & 0x6FF7;
    llIIllIlII[406] = 0xFFFFAF96 & 0x51FD;
    llIIllIlII[407] = 0xFFFFD99F & 0x27F5;
    llIIllIlII[408] = -(0xFFFFDEFD & 0x3723) & 0xFFFFBFB7 & 0x57FE;
    llIIllIlII[409] = -(0xFFFF97DB & 0x7C65) & 0xFFFFDFD7 & 0x35FF;
    llIIllIlII[410] = -(0xFFFFD8AB & 0x6F57) & 0xFFFFCBDA & 0x7DBF;
    llIIllIlII[411] = -(0x2D ^ 0x35);
    llIIllIlII[412] = -(0x31 ^ 0x16 ^ 0x66 ^ 0x3C);
    llIIllIlII[413] = -(0x13 ^ 0x8);
    llIIllIlII[414] = -(0xD7 ^ 0xB8 ^ 0xC3 ^ 0xA4);
    llIIllIlII[415] = -(0xE1 ^ 0xB4 ^ 0x60 ^ 0x3A);
    llIIllIlII[416] = -(0x1A ^ 0x59);
    llIIllIlII[417] = -(24 + 166 - 119 + 116 ^ 55 + 38 - 67 + 145);
    llIIllIlII[418] = -(0x61 ^ 0x18 ^ 0x69 ^ 0xF);
    llIIllIlII[419] = -(0x34 ^ 0x3A);
    llIIllIlII[420] = -(44 + 60 - 45 + 172 ^ 112 + 97 - 204 + 178);
    llIIllIlII[421] = -(0x82 ^ 0x87);
    llIIllIlII[422] = -(0x3E ^ 0x17);
    llIIllIlII[423] = -(0x16 ^ 0x2E);
    llIIllIlII[424] = -(0xFFFFEAE3 & 0x5D1F) & 0xFFFFFFBF & 0x49DB;
    llIIllIlII[425] = -(0x90 ^ 0xA0 ^ 0x64 ^ 0x1C);
    llIIllIlII[426] = -(0xFFFFF65F & 0x19BB);
    llIIllIlII[427] = -(0xFFFFCE89 & 0x7F77) & 0xFFFFFFDF & 0x5F3F;
    llIIllIlII[428] = -((0x5D ^ 0x26) + (0x83 ^ 0x8A) - (0x94 ^ 0xC2) + (0xCE ^ 0x91));
    llIIllIlII[429] = -(0xFFFFDFF7 & 0x3C6A) & 0xFFFF9FFF & 0x7DFB;
    llIIllIlII[430] = -" ".length() & 0xFFFFFFFF & Integer.MAX_VALUE;
    llIIllIlII[431] = 0xFFFFE39F & 0x1DFB;
    llIIllIlII[432] = 0xFFFFD5FF & 0x2B9C;
    llIIllIlII[433] = -(0xFFFFF733 & 0x4EED) & 0xFFFFFFFD & 0x47BF;
    llIIllIlII[434] = -(0xFFFFFE67 & 0x1FB9) & 0xFFFFFFFE & 0x1FBF;
    llIIllIlII[435] = 0xFFFFBD9F & 0x43FF;
    llIIllIlII[436] = 0xFFFFD5E1 & 0x2BBE;
    llIIllIlII[437] = -(0xFFFFFCEF & 0x135B) & 0xFFFFFDEB & 0x13FF;
    llIIllIlII[438] = 0xFFFF8FFB & 0x71A6;
    llIIllIlII[439] = 0xFFFFF3A3 & 0xDFF;
    llIIllIlII[440] = 0xFFFFBFFC & 0x41A7;
    llIIllIlII[441] = 0xFFFFC5EF & 0x3BB5;
    llIIllIlII[442] = -(0xFFFFEA42 & 0x77FF) & 0xFFFFE3F7 & 0x7FEF;
    llIIllIlII[443] = 0xFFFFDDEF & 0x23B7;
    llIIllIlII[444] = -(0xFFFFB4D2 & 0x7F7F) & 0xFFFFFFF9 & 0x35FF;
    llIIllIlII[445] = -(0xFFFFFB61 & 0x3EDF) & 0xFFFFFFFD & 0x3BEB;
  }
  
  private static boolean lllIllllllII(String llllllllllllllllIlIllIlllIIIIlIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > null);
  }
  
  private static boolean llllIIIIlIll(Exception llllllllllllllllIlIllIlllIIlIIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  @NotNull
  public String getAuthor() {
    return String.valueOf(this.plugin.getDescription().getAuthors());
  }
  
  private static void llllIIIIl() {
    lIlIlIII = new int[llIIllIlII[195]];
    lIlIlIII[llIIllIlII[3]] = (llIIllIlII[90] ^ llIIllIlII[112]) & (llIIllIlII[128] ^ llIIllIlII[188] ^ llIIllIlII[135]);
    lIlIlIII[llIIllIlII[0]] = llIIlIllll[llIIllIlII[408]].length();
    lIlIlIII[llIIllIlII[1]] = llIIlIllll[llIIllIlII[409]].length();
    lIlIlIII[llIIllIlII[2]] = llIIlIllll[llIIllIlII[410]].length();
    lIlIlIII[llIIllIlII[4]] = llIIllIlII[85] ^ llIIllIlII[81];
    lIlIlIII[llIIllIlII[5]] = llIIllIlII[5] ^ llIIllIlII[3];
    lIlIlIII[llIIllIlII[6]] = llIIllIlII[146] ^ llIIllIlII[147];
    lIlIlIII[llIIllIlII[7]] = llIIllIlII[28] ^ llIIllIlII[6] ^ llIIllIlII[155] ^ llIIllIlII[144];
    lIlIlIII[llIIllIlII[8]] = llIIllIlII[130] ^ llIIllIlII[102] ^ llIIllIlII[183] ^ llIIllIlII[166];
    lIlIlIII[llIIllIlII[9]] = llIIllIlII[73] ^ llIIllIlII[64];
    lIlIlIII[llIIllIlII[10]] = llIIllIlII[171] ^ llIIllIlII[176];
    lIlIlIII[llIIllIlII[11]] = llIIllIlII[33] ^ llIIllIlII[42];
    lIlIlIII[llIIllIlII[12]] = llIIllIlII[127] ^ llIIllIlII[167];
    lIlIlIII[llIIllIlII[13]] = llIIllIlII[89] ^ llIIllIlII[84];
    lIlIlIII[llIIllIlII[14]] = llIIllIlII[168] + llIIllIlII[90] - llIIllIlII[211] + llIIllIlII[118] ^ llIIllIlII[25] + llIIllIlII[56] - llIIllIlII[411] + llIIllIlII[66];
    lIlIlIII[llIIllIlII[15]] = llIIllIlII[167] ^ llIIllIlII[175];
    lIlIlIII[llIIllIlII[16]] = llIIllIlII[143] ^ llIIllIlII[157];
    lIlIlIII[llIIllIlII[17]] = llIIllIlII[186] ^ llIIllIlII[169];
    lIlIlIII[llIIllIlII[18]] = llIIllIlII[190] ^ llIIllIlII[161] ^ llIIllIlII[101] ^ llIIllIlII[93];
    lIlIlIII[llIIllIlII[19]] = llIIllIlII[177] ^ llIIllIlII[189];
    lIlIlIII[llIIllIlII[20]] = llIIllIlII[226] ^ llIIllIlII[198] ^ llIIllIlII[12] ^ llIIllIlII[4];
    lIlIlIII[llIIllIlII[21]] = llIIllIlII[113] ^ llIIllIlII[100];
    lIlIlIII[llIIllIlII[22]] = llIIllIlII[66] ^ llIIllIlII[132] ^ llIIllIlII[51] ^ llIIllIlII[25];
    lIlIlIII[llIIllIlII[23]] = llIIllIlII[74] ^ llIIllIlII[93];
    lIlIlIII[llIIllIlII[24]] = llIIllIlII[195] ^ llIIllIlII[187] ^ llIIllIlII[16] ^ llIIllIlII[2];
    lIlIlIII[llIIllIlII[25]] = llIIllIlII[128] ^ llIIllIlII[139];
    lIlIlIII[llIIllIlII[26]] = llIIllIlII[4] ^ llIIllIlII[30];
    lIlIlIII[llIIllIlII[27]] = llIIllIlII[5] ^ llIIllIlII[74] ^ llIIllIlII[199] ^ llIIllIlII[157];
    lIlIlIII[llIIllIlII[28]] = llIIllIlII[33] ^ llIIllIlII[61];
    lIlIlIII[llIIllIlII[29]] = llIIllIlII[8] + llIIllIlII[216] - llIIllIlII[10] + llIIllIlII[12] ^ llIIllIlII[186] + llIIllIlII[108] - llIIllIlII[279] + llIIllIlII[191];
    lIlIlIII[llIIllIlII[30]] = llIIllIlII[93] ^ llIIllIlII[67];
    lIlIlIII[llIIllIlII[31]] = llIIllIlII[229] ^ llIIllIlII[171] ^ llIIllIlII[76] ^ llIIllIlII[22];
    lIlIlIII[llIIllIlII[32]] = llIIllIlII[7] ^ llIIllIlII[103] ^ llIIllIlII[78] ^ llIIllIlII[14];
    lIlIlIII[llIIllIlII[33]] = llIIllIlII[63] ^ llIIllIlII[30];
    lIlIlIII[llIIllIlII[34]] = llIIllIlII[104] ^ llIIllIlII[74];
    lIlIlIII[llIIllIlII[35]] = llIIllIlII[9] + llIIllIlII[119] - llIIllIlII[48] + llIIllIlII[78] ^ llIIllIlII[9] + llIIllIlII[74] - llIIllIlII[19] + llIIllIlII[131];
    lIlIlIII[llIIllIlII[36]] = llIIllIlII[186] ^ llIIllIlII[150];
    lIlIlIII[llIIllIlII[37]] = llIIllIlII[53] + llIIllIlII[3] - llIIllIlII[31] + llIIllIlII[110] ^ llIIllIlII[69] + llIIllIlII[61] - llIIllIlII[81] + llIIllIlII[112];
    lIlIlIII[llIIllIlII[38]] = llIIllIlII[161] ^ llIIllIlII[193];
    lIlIlIII[llIIllIlII[39]] = llIIllIlII[101] ^ llIIllIlII[66];
    lIlIlIII[llIIllIlII[40]] = llIIllIlII[112] ^ llIIllIlII[88];
    lIlIlIII[llIIllIlII[41]] = llIIllIlII[48] + llIIllIlII[5] - llIIllIlII[412] + llIIllIlII[2] ^ llIIllIlII[5] + llIIllIlII[115] - llIIllIlII[66] + llIIllIlII[102];
    lIlIlIII[llIIllIlII[42]] = llIIllIlII[92] ^ llIIllIlII[118];
    lIlIlIII[llIIllIlII[43]] = llIIllIlII[88] ^ llIIllIlII[115];
    lIlIlIII[llIIllIlII[44]] = llIIllIlII[13] ^ llIIllIlII[33];
    lIlIlIII[llIIllIlII[45]] = llIIllIlII[66] ^ llIIllIlII[94] ^ llIIllIlII[83] ^ llIIllIlII[98];
    lIlIlIII[llIIllIlII[46]] = llIIllIlII[121] ^ llIIllIlII[87];
    lIlIlIII[llIIllIlII[47]] = llIIllIlII[142] + llIIllIlII[90] - llIIllIlII[139] + llIIllIlII[48] ^ llIIllIlII[4] + llIIllIlII[77] - llIIllIlII[413] + llIIllIlII[83];
    lIlIlIII[llIIllIlII[48]] = llIIllIlII[81] + llIIllIlII[86] - llIIllIlII[132] + llIIllIlII[144] ^ llIIllIlII[94] + llIIllIlII[33] - llIIllIlII[70] + llIIllIlII[72];
    lIlIlIII[llIIllIlII[49]] = llIIllIlII[184] ^ llIIllIlII[134];
    lIlIlIII[llIIllIlII[50]] = llIIllIlII[137] ^ llIIllIlII[144] ^ llIIllIlII[55] ^ llIIllIlII[14];
    lIlIlIII[llIIllIlII[51]] = llIIllIlII[70] ^ llIIllIlII[117];
    lIlIlIII[llIIllIlII[52]] = llIIllIlII[24] ^ llIIllIlII[67] ^ llIIllIlII[44] ^ llIIllIlII[67];
    lIlIlIII[llIIllIlII[53]] = llIIllIlII[247] ^ llIIllIlII[144] ^ llIIllIlII[120] ^ llIIllIlII[48];
    lIlIlIII[llIIllIlII[54]] = llIIllIlII[77] ^ llIIllIlII[129];
    lIlIlIII[llIIllIlII[55]] = llIIllIlII[104] ^ llIIllIlII[122] ^ llIIllIlII[131] ^ llIIllIlII[88];
    lIlIlIII[llIIllIlII[56]] = llIIllIlII[63] + llIIllIlII[68] - llIIllIlII[414] + llIIllIlII[1] ^ llIIllIlII[14] + llIIllIlII[88] - llIIllIlII[69] + llIIllIlII[154];
    lIlIlIII[llIIllIlII[57]] = llIIllIlII[108] ^ llIIllIlII[85];
    lIlIlIII[llIIllIlII[58]] = llIIllIlII[86] ^ llIIllIlII[1] ^ llIIllIlII[202] ^ llIIllIlII[125];
    lIlIlIII[llIIllIlII[59]] = llIIllIlII[136] + llIIllIlII[171] - llIIllIlII[138] + llIIllIlII[15] ^ llIIllIlII[89] + llIIllIlII[26] - llIIllIlII[415] + llIIllIlII[6];
    lIlIlIII[llIIllIlII[60]] = llIIllIlII[82] ^ llIIllIlII[42] ^ llIIllIlII[224] ^ llIIllIlII[158];
    lIlIlIII[llIIllIlII[61]] = llIIllIlII[176] ^ llIIllIlII[150];
    lIlIlIII[llIIllIlII[62]] = llIIllIlII[150] ^ llIIllIlII[177];
    lIlIlIII[llIIllIlII[63]] = llIIllIlII[25] + llIIllIlII[22] - llIIllIlII[21] + llIIllIlII[122] ^ llIIllIlII[72] + llIIllIlII[106] - llIIllIlII[39] + llIIllIlII[32];
    lIlIlIII[llIIllIlII[64]] = llIIllIlII[38] ^ llIIllIlII[110] ^ llIIllIlII[208] ^ llIIllIlII[200];
    lIlIlIII[llIIllIlII[65]] = llIIllIlII[228] ^ llIIllIlII[164];
    lIlIlIII[llIIllIlII[66]] = llIIllIlII[139] ^ llIIllIlII[203];
    lIlIlIII[llIIllIlII[67]] = llIIllIlII[215] ^ llIIllIlII[150];
    lIlIlIII[llIIllIlII[68]] = llIIllIlII[212] ^ llIIllIlII[154];
    lIlIlIII[llIIllIlII[69]] = llIIllIlII[105] ^ llIIllIlII[44];
    lIlIlIII[llIIllIlII[70]] = llIIllIlII[26] ^ llIIllIlII[66] ^ llIIllIlII[42] ^ llIIllIlII[52];
    lIlIlIII[llIIllIlII[71]] = llIIllIlII[215] ^ llIIllIlII[154];
    lIlIlIII[llIIllIlII[72]] = llIIllIlII[116] ^ llIIllIlII[60];
    lIlIlIII[llIIllIlII[73]] = llIIllIlII[138] ^ llIIllIlII[161] ^ llIIllIlII[78] ^ llIIllIlII[30];
    lIlIlIII[llIIllIlII[74]] = llIIllIlII[114] ^ llIIllIlII[56];
    lIlIlIII[llIIllIlII[75]] = llIIllIlII[233] ^ llIIllIlII[176];
    lIlIlIII[llIIllIlII[76]] = llIIllIlII[91] ^ llIIllIlII[103] ^ llIIllIlII[243] ^ llIIllIlII[134];
    lIlIlIII[llIIllIlII[77]] = llIIllIlII[182] ^ llIIllIlII[181];
    lIlIlIII[llIIllIlII[78]] = llIIllIlII[116] ^ llIIllIlII[16] ^ llIIllIlII[8] ^ llIIllIlII[34];
    lIlIlIII[llIIllIlII[79]] = llIIllIlII[155] ^ llIIllIlII[158] ^ llIIllIlII[220] ^ llIIllIlII[141];
    lIlIlIII[llIIllIlII[80]] = llIIllIlII[216] ^ llIIllIlII[138];
    lIlIlIII[llIIllIlII[81]] = llIIllIlII[118] ^ llIIllIlII[39];
    lIlIlIII[llIIllIlII[82]] = llIIllIlII[112] + llIIllIlII[126] - llIIllIlII[256] + llIIllIlII[150] ^ llIIllIlII[120] + llIIllIlII[196] - llIIllIlII[258] + llIIllIlII[147];
    lIlIlIII[llIIllIlII[83]] = llIIllIlII[211] ^ llIIllIlII[128];
    lIlIlIII[llIIllIlII[84]] = llIIllIlII[106] ^ llIIllIlII[62];
    lIlIlIII[llIIllIlII[85]] = llIIllIlII[50] ^ llIIllIlII[103];
    lIlIlIII[llIIllIlII[86]] = llIIllIlII[39] ^ llIIllIlII[113];
    lIlIlIII[llIIllIlII[87]] = llIIllIlII[5] ^ llIIllIlII[82];
    lIlIlIII[llIIllIlII[88]] = llIIllIlII[89] ^ llIIllIlII[78] ^ llIIllIlII[96] ^ llIIllIlII[47];
    lIlIlIII[llIIllIlII[89]] = llIIllIlII[28] ^ llIIllIlII[104] ^ llIIllIlII[102] ^ llIIllIlII[75];
    lIlIlIII[llIIllIlII[90]] = llIIllIlII[27] ^ llIIllIlII[7] ^ llIIllIlII[245] ^ llIIllIlII[186];
    lIlIlIII[llIIllIlII[91]] = llIIllIlII[256] ^ llIIllIlII[169];
    lIlIlIII[llIIllIlII[92]] = llIIllIlII[143] ^ llIIllIlII[149] ^ llIIllIlII[120] ^ llIIllIlII[45];
    lIlIlIII[llIIllIlII[93]] = llIIllIlII[256] ^ llIIllIlII[167];
    lIlIlIII[llIIllIlII[94]] = llIIllIlII[232] ^ llIIllIlII[193];
    lIlIlIII[llIIllIlII[95]] = llIIllIlII[60] ^ llIIllIlII[99];
    lIlIlIII[llIIllIlII[96]] = llIIllIlII[114] ^ llIIllIlII[62] ^ llIIllIlII[111] ^ llIIllIlII[67];
    lIlIlIII[llIIllIlII[97]] = llIIllIlII[80] ^ llIIllIlII[49];
    lIlIlIII[llIIllIlII[98]] = llIIllIlII[246] ^ llIIllIlII[151];
    lIlIlIII[llIIllIlII[99]] = llIIllIlII[132] + llIIllIlII[44] - llIIllIlII[10] + llIIllIlII[88] ^ llIIllIlII[91] + llIIllIlII[54] - llIIllIlII[101] + llIIllIlII[111];
    lIlIlIII[llIIllIlII[100]] = llIIllIlII[172] ^ llIIllIlII[124] ^ llIIllIlII[77] ^ llIIllIlII[65];
    lIlIlIII[llIIllIlII[101]] = llIIllIlII[57] ^ llIIllIlII[92];
    lIlIlIII[llIIllIlII[102]] = llIIllIlII[163] + llIIllIlII[75] - llIIllIlII[39] + llIIllIlII[29] ^ llIIllIlII[109] + llIIllIlII[76] - llIIllIlII[68] + llIIllIlII[17];
    lIlIlIII[llIIllIlII[103]] = llIIllIlII[25] + llIIllIlII[92] - llIIllIlII[73] + llIIllIlII[155] ^ llIIllIlII[51] + llIIllIlII[2] - llIIllIlII[415] + llIIllIlII[97];
    lIlIlIII[llIIllIlII[104]] = llIIllIlII[237] ^ llIIllIlII[123];
    lIlIlIII[llIIllIlII[105]] = llIIllIlII[73] ^ llIIllIlII[80] ^ llIIllIlII[200] ^ llIIllIlII[186];
    lIlIlIII[llIIllIlII[106]] = llIIllIlII[42] + llIIllIlII[66] - llIIllIlII[98] + llIIllIlII[234] ^ llIIllIlII[39] + llIIllIlII[90] - llIIllIlII[14] + llIIllIlII[40];
    lIlIlIII[llIIllIlII[107]] = llIIllIlII[97] ^ llIIllIlII[26] ^ llIIllIlII[152] ^ llIIllIlII[123];
    lIlIlIII[llIIllIlII[108]] = llIIllIlII[89] ^ llIIllIlII[57] ^ llIIllIlII[109] ^ llIIllIlII[97];
    lIlIlIII[llIIllIlII[109]] = llIIllIlII[0] + llIIllIlII[106] - llIIllIlII[416] + llIIllIlII[42] ^ llIIllIlII[9] + llIIllIlII[93] - llIIllIlII[417] + llIIllIlII[63];
    lIlIlIII[llIIllIlII[110]] = llIIllIlII[238] ^ llIIllIlII[139];
    lIlIlIII[llIIllIlII[111]] = (llIIllIlII[137] ^ llIIllIlII[167]) & (llIIllIlII[163] ^ llIIllIlII[196] ^ llIIllIlII[135]) ^ llIIllIlII[82] ^ llIIllIlII[61];
    lIlIlIII[llIIllIlII[112]] = llIIllIlII[29] ^ llIIllIlII[120] ^ llIIllIlII[216] ^ llIIllIlII[124];
    lIlIlIII[llIIllIlII[113]] = llIIllIlII[211] ^ llIIllIlII[124] ^ llIIllIlII[103] + llIIllIlII[45] - llIIllIlII[115] + llIIllIlII[94];
    lIlIlIII[llIIllIlII[114]] = llIIllIlII[76] ^ llIIllIlII[62];
    lIlIlIII[llIIllIlII[115]] = llIIllIlII[26] ^ llIIllIlII[12] ^ llIIllIlII[24] ^ llIIllIlII[131];
    lIlIlIII[llIIllIlII[116]] = llIIllIlII[112] ^ llIIllIlII[65] ^ llIIllIlII[28] ^ llIIllIlII[89];
    lIlIlIII[llIIllIlII[117]] = llIIllIlII[119] ^ llIIllIlII[48] ^ llIIllIlII[69] ^ llIIllIlII[119];
    lIlIlIII[llIIllIlII[118]] = llIIllIlII[29] ^ llIIllIlII[17] ^ llIIllIlII[12] ^ llIIllIlII[118];
    lIlIlIII[llIIllIlII[119]] = llIIllIlII[3] ^ llIIllIlII[119];
    lIlIlIII[llIIllIlII[120]] = llIIllIlII[110] + llIIllIlII[158] - llIIllIlII[237] + llIIllIlII[128] ^ llIIllIlII[82] + llIIllIlII[18] - llIIllIlII[418] + llIIllIlII[61];
    lIlIlIII[llIIllIlII[121]] = llIIllIlII[21] ^ llIIllIlII[108];
    lIlIlIII[llIIllIlII[122]] = llIIllIlII[107] ^ llIIllIlII[47] ^ llIIllIlII[75] ^ llIIllIlII[117];
    lIlIlIII[llIIllIlII[129]] = llIIllIlII[243] ^ llIIllIlII[192] ^ llIIllIlII[190] ^ llIIllIlII[140];
    lIlIlIII[llIIllIlII[130]] = llIIllIlII[253] ^ llIIllIlII[143];
    lIlIlIII[llIIllIlII[131]] = llIIllIlII[100] ^ llIIllIlII[25];
    lIlIlIII[llIIllIlII[132]] = llIIllIlII[204] + llIIllIlII[14] - llIIllIlII[140] + llIIllIlII[130] ^ llIIllIlII[75] + llIIllIlII[8] - llIIllIlII[18] + llIIllIlII[113];
    lIlIlIII[llIIllIlII[133]] = (llIIllIlII[5] ^ llIIllIlII[78]) + (llIIllIlII[25] ^ llIIllIlII[22]) - -(llIIllIlII[206] ^ llIIllIlII[198]) + (llIIllIlII[24] ^ llIIllIlII[5]);
    lIlIlIII[llIIllIlII[134]] = llIIllIlII[90] + llIIllIlII[82] - llIIllIlII[98] + llIIllIlII[54];
    lIlIlIII[llIIllIlII[136]] = (llIIllIlII[113] ^ llIIllIlII[109]) + (llIIllIlII[54] ^ llIIllIlII[45]) - -(llIIllIlII[26] ^ llIIllIlII[48]) + (llIIllIlII[41] ^ llIIllIlII[9]);
    lIlIlIII[llIIllIlII[123]] = llIIllIlII[0] + llIIllIlII[69] - llIIllIlII[48] + llIIllIlII[108];
    lIlIlIII[llIIllIlII[137]] = (llIIllIlII[24] ^ llIIllIlII[59]) + (llIIllIlII[171] ^ llIIllIlII[186]) - (llIIllIlII[193] ^ llIIllIlII[167]) + (llIIllIlII[223] ^ llIIllIlII[195]);
    lIlIlIII[llIIllIlII[138]] = llIIllIlII[31] + llIIllIlII[40] - llIIllIlII[419] + llIIllIlII[47];
    lIlIlIII[llIIllIlII[139]] = llIIllIlII[15] + llIIllIlII[57] - llIIllIlII[31] + llIIllIlII[92];
    lIlIlIII[llIIllIlII[140]] = llIIllIlII[59] + llIIllIlII[76] - llIIllIlII[85] + llIIllIlII[84];
    lIlIlIII[llIIllIlII[143]] = (llIIllIlII[63] ^ llIIllIlII[70]) + (llIIllIlII[209] ^ llIIllIlII[138]) - (llIIllIlII[235] ^ llIIllIlII[136]) + (llIIllIlII[157] ^ llIIllIlII[181]);
    lIlIlIII[llIIllIlII[144]] = (llIIllIlII[65] ^ llIIllIlII[120]) + (llIIllIlII[225] ^ llIIllIlII[147]) - (llIIllIlII[129] ^ llIIllIlII[113]) + (llIIllIlII[107] ^ llIIllIlII[99]);
    lIlIlIII[llIIllIlII[145]] = llIIllIlII[54] + llIIllIlII[68] - llIIllIlII[8] + llIIllIlII[23];
    lIlIlIII[llIIllIlII[146]] = (llIIllIlII[73] ^ llIIllIlII[60]) + (llIIllIlII[257] ^ llIIllIlII[163]) - llIIllIlII[60] + llIIllIlII[59] - llIIllIlII[35] + llIIllIlII[75] + (llIIllIlII[47] ^ llIIllIlII[129]);
    lIlIlIII[llIIllIlII[142]] = (llIIllIlII[1] ^ llIIllIlII[49]) + (llIIllIlII[130] ^ llIIllIlII[11]) - llIIllIlII[92] + llIIllIlII[14] - llIIllIlII[84] + llIIllIlII[110] + (llIIllIlII[62] ^ llIIllIlII[91]);
    lIlIlIII[llIIllIlII[147]] = llIIllIlII[93] + llIIllIlII[29] - llIIllIlII[62] + llIIllIlII[80];
    lIlIlIII[llIIllIlII[148]] = (llIIllIlII[34] ^ llIIllIlII[105]) + (llIIllIlII[83] ^ llIIllIlII[42]) - llIIllIlII[85] + llIIllIlII[70] - llIIllIlII[22] + llIIllIlII[18] + (llIIllIlII[254] ^ llIIllIlII[128]);
    lIlIlIII[llIIllIlII[149]] = (llIIllIlII[17] ^ llIIllIlII[85]) + (llIIllIlII[6] ^ llIIllIlII[51]) - (llIIllIlII[13] ^ llIIllIlII[121]) + llIIllIlII[55] + llIIllIlII[97] - llIIllIlII[105] + llIIllIlII[90];
    lIlIlIII[llIIllIlII[126]] = llIIllIlII[93] + llIIllIlII[56] - llIIllIlII[63] + llIIllIlII[43] + (llIIllIlII[85] ^ llIIllIlII[27]) - llIIllIlII[60] + llIIllIlII[40] - llIIllIlII[39] + llIIllIlII[104] + (llIIllIlII[240] ^ llIIllIlII[144]);
    lIlIlIII[llIIllIlII[150]] = (llIIllIlII[78] ^ llIIllIlII[65]) + llIIllIlII[0] + llIIllIlII[16] - llIIllIlII[420] + llIIllIlII[30] - (llIIllIlII[235] ^ llIIllIlII[172]) + (llIIllIlII[32] ^ llIIllIlII[99]);
    lIlIlIII[llIIllIlII[151]] = llIIllIlII[37] + llIIllIlII[105] - llIIllIlII[56] + llIIllIlII[59];
    lIlIlIII[llIIllIlII[152]] = llIIllIlII[117] + llIIllIlII[58] - llIIllIlII[61] + llIIllIlII[32];
    lIlIlIII[llIIllIlII[153]] = (llIIllIlII[182] ^ llIIllIlII[195]) + (llIIllIlII[229] ^ llIIllIlII[159]) - (llIIllIlII[223] ^ llIIllIlII[174]) + (llIIllIlII[91] ^ llIIllIlII[101]);
    lIlIlIII[llIIllIlII[154]] = (llIIllIlII[78] ^ llIIllIlII[59]) + (llIIllIlII[92] ^ llIIllIlII[61]) - (llIIllIlII[36] ^ llIIllIlII[88]) + (llIIllIlII[163] ^ llIIllIlII[169]);
    lIlIlIII[llIIllIlII[155]] = llIIllIlII[101] + llIIllIlII[88] - llIIllIlII[90] + llIIllIlII[50];
    lIlIlIII[llIIllIlII[156]] = llIIllIlII[69] + llIIllIlII[38] - llIIllIlII[105] + llIIllIlII[154];
    lIlIlIII[llIIllIlII[157]] = llIIllIlII[154] + llIIllIlII[91] - llIIllIlII[228] + llIIllIlII[145];
    lIlIlIII[llIIllIlII[158]] = (llIIllIlII[211] ^ llIIllIlII[149]) + (llIIllIlII[217] ^ llIIllIlII[174]) - llIIllIlII[63] + llIIllIlII[47] - llIIllIlII[421] + llIIllIlII[24] + (llIIllIlII[51] ^ llIIllIlII[87]);
    lIlIlIII[llIIllIlII[159]] = (llIIllIlII[99] ^ llIIllIlII[114]) + (llIIllIlII[204] ^ llIIllIlII[160]) - (llIIllIlII[113] ^ llIIllIlII[118]) + (llIIllIlII[131] ^ llIIllIlII[65]);
    lIlIlIII[llIIllIlII[141]] = (llIIllIlII[37] ^ llIIllIlII[28]) + (llIIllIlII[163] ^ llIIllIlII[147]) - (llIIllIlII[111] ^ llIIllIlII[85]) + llIIllIlII[130] + llIIllIlII[21] - llIIllIlII[90] + llIIllIlII[81];
    lIlIlIII[llIIllIlII[160]] = (llIIllIlII[97] ^ llIIllIlII[104]) + (llIIllIlII[13] ^ llIIllIlII[131]) - (llIIllIlII[34] ^ llIIllIlII[3]) + (llIIllIlII[229] ^ llIIllIlII[170]);
    lIlIlIII[llIIllIlII[128]] = (llIIllIlII[139] ^ llIIllIlII[170]) + (llIIllIlII[168] ^ llIIllIlII[137]) - -(llIIllIlII[183] ^ llIIllIlII[193]) + (llIIllIlII[121] ^ llIIllIlII[62]);
    lIlIlIII[llIIllIlII[161]] = llIIllIlII[121] + llIIllIlII[91] - llIIllIlII[144] + llIIllIlII[81];
    lIlIlIII[llIIllIlII[162]] = llIIllIlII[82] + llIIllIlII[66] - llIIllIlII[40] + llIIllIlII[50];
    lIlIlIII[llIIllIlII[163]] = (llIIllIlII[101] ^ llIIllIlII[37]) + (llIIllIlII[173] ^ llIIllIlII[168]) - ((llIIllIlII[163] ^ llIIllIlII[136]) & (llIIllIlII[46] ^ llIIllIlII[48] ^ llIIllIlII[135])) + (llIIllIlII[237] ^ llIIllIlII[193]);
    lIlIlIII[llIIllIlII[164]] = llIIllIlII[88] + llIIllIlII[50] - llIIllIlII[33] + llIIllIlII[55];
    lIlIlIII[llIIllIlII[165]] = llIIllIlII[100] + llIIllIlII[53] - llIIllIlII[113] + llIIllIlII[121];
    lIlIlIII[llIIllIlII[166]] = llIIllIlII[24] + llIIllIlII[26] - llIIllIlII[422] + llIIllIlII[71];
    lIlIlIII[llIIllIlII[167]] = llIIllIlII[128] + llIIllIlII[100] - llIIllIlII[211] + llIIllIlII[114];
    lIlIlIII[llIIllIlII[168]] = llIIllIlII[154] + llIIllIlII[39] - llIIllIlII[102] + llIIllIlII[79];
    lIlIlIII[llIIllIlII[169]] = (llIIllIlII[83] ^ llIIllIlII[14]) + (llIIllIlII[15] ^ llIIllIlII[115]) - llIIllIlII[14] + llIIllIlII[0] - llIIllIlII[423] + llIIllIlII[73] + (llIIllIlII[49] ^ llIIllIlII[109]);
    lIlIlIII[llIIllIlII[170]] = llIIllIlII[46] + llIIllIlII[63] - llIIllIlII[95] + llIIllIlII[158];
    lIlIlIII[llIIllIlII[171]] = (llIIllIlII[250] ^ llIIllIlII[136]) + (llIIllIlII[107] ^ llIIllIlII[39]) - (llIIllIlII[30] ^ llIIllIlII[95]) + (llIIllIlII[187] ^ llIIllIlII[156]);
    lIlIlIII[llIIllIlII[125]] = llIIllIlII[34] + llIIllIlII[122] - llIIllIlII[120] + llIIllIlII[138];
    lIlIlIII[llIIllIlII[172]] = (llIIllIlII[26] ^ llIIllIlII[53]) + (llIIllIlII[70] ^ llIIllIlII[3]) - -llIIlIllll[llIIllIlII[424]].length() + (llIIllIlII[42] ^ llIIllIlII[27]);
    lIlIlIII[llIIllIlII[173]] = llIIllIlII[28] + llIIllIlII[24] - llIIllIlII[413] + llIIllIlII[91];
    lIlIlIII[llIIllIlII[174]] = llIIllIlII[25] + llIIllIlII[129] - llIIllIlII[122] + llIIllIlII[108] + (llIIllIlII[162] ^ llIIllIlII[169]) - llIIllIlII[7] + llIIllIlII[129] - llIIllIlII[5] + llIIllIlII[62] + llIIllIlII[16] + llIIllIlII[38] - llIIllIlII[425] + llIIllIlII[39];
    lIlIlIII[llIIllIlII[175]] = (llIIllIlII[98] ^ llIIllIlII[85]) + (llIIllIlII[92] ^ llIIllIlII[28]) - (llIIllIlII[36] ^ llIIllIlII[6]) + (llIIllIlII[95] ^ llIIllIlII[8]);
    lIlIlIII[llIIllIlII[176]] = (llIIllIlII[104] ^ llIIllIlII[13]) + llIIllIlII[115] + llIIllIlII[78] - llIIllIlII[125] + llIIllIlII[115] - llIIllIlII[84] + llIIllIlII[202] - llIIllIlII[226] + llIIllIlII[165] + llIIllIlII[132] + llIIllIlII[96] - llIIllIlII[162] + llIIllIlII[89];
    lIlIlIII[llIIllIlII[177]] = (llIIllIlII[113] ^ llIIllIlII[131]) + llIIllIlII[2] + llIIllIlII[107] - llIIllIlII[0] + llIIllIlII[47] - (llIIllIlII[49] ^ llIIllIlII[39]) + (llIIllIlII[51] ^ llIIllIlII[47]);
    lIlIlIII[llIIllIlII[127]] = llIIllIlII[62] + llIIllIlII[175] - llIIllIlII[121] + llIIllIlII[62];
    lIlIlIII[llIIllIlII[183]] = llIIllIlII[114] + llIIllIlII[16] - llIIllIlII[60] + llIIllIlII[106];
    lIlIlIII[llIIllIlII[184]] = llIIllIlII[95] + llIIllIlII[2] - llIIllIlII[96] + llIIllIlII[127];
    lIlIlIII[llIIllIlII[178]] = llIIllIlII[79] + llIIllIlII[130] - llIIllIlII[159] + llIIllIlII[89] + llIIllIlII[102] + llIIllIlII[71] - llIIllIlII[84] + llIIllIlII[59] - (llIIllIlII[426] & llIIllIlII[427]) + llIIllIlII[40] + llIIllIlII[130] - llIIllIlII[17] + llIIllIlII[5];
    lIlIlIII[llIIllIlII[185]] = (llIIllIlII[139] ^ llIIllIlII[172]) + llIIllIlII[128] + llIIllIlII[162] - llIIllIlII[258] + llIIllIlII[120] - (llIIllIlII[201] ^ llIIllIlII[172]) + (llIIllIlII[133] ^ llIIllIlII[62]);
    lIlIlIII[llIIllIlII[186]] = llIIllIlII[38] + llIIllIlII[118] - llIIllIlII[87] + llIIllIlII[58] + (llIIllIlII[142] ^ llIIllIlII[141]) - (llIIllIlII[51] ^ llIIllIlII[111]) + llIIllIlII[106] + llIIllIlII[23] - llIIllIlII[22] + llIIllIlII[21];
    lIlIlIII[llIIllIlII[187]] = llIIllIlII[142] + llIIllIlII[131] - llIIllIlII[246] + llIIllIlII[164];
    lIlIlIII[llIIllIlII[188]] = llIIllIlII[109] + llIIllIlII[54] - llIIllIlII[8] + llIIllIlII[27];
    lIlIlIII[llIIllIlII[190]] = llIIllIlII[7] + llIIllIlII[4] - llIIllIlII[428] + llIIllIlII[31];
    lIlIlIII[llIIllIlII[191]] = (llIIllIlII[54] ^ llIIllIlII[81]) + llIIllIlII[106] + llIIllIlII[22] - llIIllIlII[18] + llIIllIlII[24] - llIIllIlII[26] + llIIllIlII[151] - llIIllIlII[92] + llIIllIlII[69] + (llIIllIlII[58] ^ llIIllIlII[101]);
    lIlIlIII[llIIllIlII[181]] = llIIllIlII[129] + llIIllIlII[151] - llIIllIlII[109] + llIIllIlII[26];
    lIlIlIII[llIIllIlII[192]] = -llIIlIllll[llIIllIlII[429]].length() & llIIllIlII[135] & llIIllIlII[430];
    lIlIlIII[llIIllIlII[193]] = (llIIllIlII[42] ^ llIIllIlII[107]) + llIIllIlII[63] + llIIllIlII[112] - llIIllIlII[116] + llIIllIlII[71] - (llIIllIlII[204] ^ llIIllIlII[193]) + (llIIllIlII[254] ^ llIIllIlII[156]);
    lIlIlIII[llIIllIlII[194]] = (llIIllIlII[77] ^ llIIllIlII[132]) + (llIIllIlII[75] ^ llIIllIlII[0]) - -(llIIllIlII[156] ^ llIIllIlII[144]) + (llIIllIlII[121] ^ llIIllIlII[89]);
    lIlIlIII[llIIllIlII[189]] = (llIIllIlII[2] ^ llIIllIlII[115]) + (llIIllIlII[32] ^ llIIllIlII[105]) - (llIIllIlII[175] ^ llIIllIlII[140]) + (llIIllIlII[239] ^ llIIllIlII[124]);
  }
  
  private static boolean llllIIIlI(byte llllllllllllllllIlIlllIIIlIIlIII) {
    if (lllIllllIlII(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ("  ".length() == 0)
        return (47 + 157 - 26 + 35 ^ 32 + 134 - 20 + 7) & (0x90 ^ 0x82 ^ 0x10 ^ 0x4E ^ -" ".length()); 
    } else {
    
    } 
    return llIIllIlII[3];
  }
  
  private static String lllIllllI(String llllllllllllllllIlIlllIIIlllllll, float llllllllllllllllIlIlllIIIllllIlI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   10: sipush #405
    //   13: iaload
    //   14: aaload
    //   15: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   18: aload_1
    //   19: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   22: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   25: invokevirtual digest : ([B)[B
    //   28: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   31: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   34: sipush #406
    //   37: iaload
    //   38: aaload
    //   39: invokespecial <init> : ([BLjava/lang/String;)V
    //   42: astore_2
    //   43: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIlIllll : [Ljava/lang/String;
    //   46: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   49: sipush #407
    //   52: iaload
    //   53: aaload
    //   54: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   57: astore_3
    //   58: aload_3
    //   59: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.lIlIlIII : [I
    //   62: getstatic com/axeelheaven/hbedwars/api/hooks/PlaceholderHook.llIIllIlII : [I
    //   65: iconst_1
    //   66: iaload
    //   67: iaload
    //   68: aload_2
    //   69: invokevirtual init : (ILjava/security/Key;)V
    //   72: new java/lang/String
    //   75: dup
    //   76: aload_3
    //   77: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   80: aload_0
    //   81: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   84: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   87: invokevirtual decode : ([B)[B
    //   90: invokevirtual doFinal : ([B)[B
    //   93: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   96: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   99: areturn
    //   100: astore_2
    //   101: aload_2
    //   102: invokevirtual printStackTrace : ()V
    //   105: aconst_null
    //   106: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	107	0	llllllllllllllllIlIlllIIIllllIll	D
    //   0	107	2	llllllllllllllllIlIlllIIIllllIIl	Ljava/lang/Exception;
    //   0	107	1	llllllllllllllllIlIlllIIlIIIIIll	Ljava/lang/String;
    //   0	107	0	llllllllllllllllIlIlllIIIlllllll	Ljava/lang/String;
    //   0	107	0	llllllllllllllllIlIlllIIlIIIIlII	F
    //   58	42	3	llllllllllllllllIlIlllIIlIIIIIIl	Ljavax/crypto/Cipher;
    //   43	57	2	llllllllllllllllIlIlllIIlIIIIIlI	Ljavax/crypto/spec/SecretKeySpec;
    //   0	107	1	llllllllllllllllIlIlllIIIllllIlI	F
    //   0	107	3	llllllllllllllllIlIlllIIIllllIII	B
    //   0	107	1	llllllllllllllllIlIlllIIIlllllIl	Z
    //   0	107	3	llllllllllllllllIlIlllIIlIIIIIII	Ljava/lang/Exception;
    //   101	4	2	llllllllllllllllIlIlllIIIlllllII	Ljava/lang/Exception;
    //   0	107	2	llllllllllllllllIlIlllIIIllllllI	D
    // Exception table:
    //   from	to	target	type
    //   0	99	100	java/lang/Exception
  }
  
  public PlaceholderHook(BedWars llllllllllllllllIlIlllIIIIllIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   9: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	10	1	llllllllllllllllIlIlllIIIIllIIIl	Z
    //   0	10	1	llllllllllllllllIlIlllIIIIllIIlI	Lcom/axeelheaven/hbedwars/BedWars;
    //   0	10	1	llllllllllllllllIlIlllIIIIlIllll	B
    //   0	10	0	llllllllllllllllIlIlllIIIIllIIII	S
    //   0	10	0	llllllllllllllllIlIlllIIIIllIlII	J
    //   0	10	0	llllllllllllllllIlIlllIIIIllIIll	Lcom/axeelheaven/hbedwars/api/hooks/PlaceholderHook;
  }
  
  private static boolean llllIIIIlIlI(float llllllllllllllllIlIllIlllIlIIllI, float llllllllllllllllIlIllIlllIlIIlII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lllIllllIlII(long llllllllllllllllIlIllIlllIIlIlIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\hooks\PlaceholderHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */