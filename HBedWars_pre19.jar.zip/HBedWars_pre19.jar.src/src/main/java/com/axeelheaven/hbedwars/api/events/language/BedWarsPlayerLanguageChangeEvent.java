/*    */ package com.axeelheaven.hbedwars.api.events.language;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsPlayerLanguageChangeEvent extends Event {
/*    */   private final Player player;
/*    */   private final String language;
/* 10 */   private static final HandlerList handlerList = new HandlerList(); public Player getPlayer() {
/* 11 */     return this.player; } public String getLanguage() {
/* 12 */     return this.language;
/*    */   }
/*    */   public BedWarsPlayerLanguageChangeEvent(Player player, String language) {
/* 15 */     this.player = player;
/* 16 */     this.language = language;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 21 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 25 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\language\BedWarsPlayerLanguageChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */