/*    */ package com.axeelheaven.hbedwars.api.events.party;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsPartyCreateEvent
/*    */   extends Event {
/*    */   private final Player player;
/* 10 */   private static final HandlerList handlerList = new HandlerList(); public Player getPlayer() {
/* 11 */     return this.player;
/*    */   }
/*    */   public BedWarsPartyCreateEvent(Player player) {
/* 14 */     this.player = player;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 19 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 23 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\party\BedWarsPartyCreateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */