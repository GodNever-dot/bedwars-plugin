package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;

public interface HyperLogLogPipelineCommands {
  Response<Long> pfadd(String paramString, String... paramVarArgs);
  
  Response<String> pfmerge(String paramString, String... paramVarArgs);
  
  Response<Long> pfcount(String paramString);
  
  Response<Long> pfcount(String... paramVarArgs);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\HyperLogLogPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */