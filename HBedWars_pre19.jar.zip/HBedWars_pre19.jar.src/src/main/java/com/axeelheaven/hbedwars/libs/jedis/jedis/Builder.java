package com.axeelheaven.hbedwars.libs.jedis.jedis;

public abstract class Builder<T> {
  public abstract T build(Object paramObject);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\Builder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */