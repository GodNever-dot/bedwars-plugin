/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.args;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public enum GeoUnit
/*    */   implements Rawable {
/*  8 */   M, KM, MI, FT;
/*    */   
/*    */   private final byte[] raw;
/*    */   
/*    */   GeoUnit() {
/* 13 */     this.raw = SafeEncoder.encode(name().toLowerCase(Locale.ENGLISH));
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] getRaw() {
/* 18 */     return this.raw;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\args\GeoUnit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */