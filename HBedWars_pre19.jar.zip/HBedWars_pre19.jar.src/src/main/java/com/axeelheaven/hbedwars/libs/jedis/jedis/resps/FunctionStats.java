/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Builder;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.BuilderFactory;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class FunctionStats
/*    */ {
/*    */   private final Map<String, Object> runningScript;
/*    */   private final Map<String, Map<String, Object>> engines;
/*    */   
/*    */   public FunctionStats(Map<String, Object> script, Map<String, Map<String, Object>> engines) {
/* 15 */     this.runningScript = script;
/* 16 */     this.engines = engines;
/*    */   }
/*    */   
/*    */   public Map<String, Object> getRunningScript() {
/* 20 */     return this.runningScript;
/*    */   }
/*    */   
/*    */   public Map<String, Map<String, Object>> getEngines() {
/* 24 */     return this.engines;
/*    */   }
/*    */   
/* 27 */   public static final Builder<FunctionStats> FUNCTION_STATS_BUILDER = new Builder<FunctionStats>()
/*    */     {
/*    */       public FunctionStats build(Object data)
/*    */       {
/* 31 */         List<Object> superMapList = (List<Object>)data;
/*    */ 
/*    */         
/* 34 */         Map<String, Object> runningScriptMap = (superMapList.get(1) == null) ? null : (Map<String, Object>)BuilderFactory.ENCODED_OBJECT_MAP.build(superMapList.get(1));
/*    */         
/* 36 */         List<Object> enginesList = (List<Object>)superMapList.get(3);
/*    */         
/* 38 */         Map<String, Map<String, Object>> enginesMap = new LinkedHashMap<>(enginesList.size() / 2);
/* 39 */         for (int i = 0; i < enginesList.size(); i += 2) {
/* 40 */           enginesMap.put(BuilderFactory.STRING.build(enginesList.get(i)), BuilderFactory.ENCODED_OBJECT_MAP
/* 41 */               .build(enginesList.get(i + 1)));
/*    */         }
/*    */         
/* 44 */         return new FunctionStats(runningScriptMap, enginesMap);
/*    */       }
/*    */     };
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\FunctionStats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */