/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.Rawable;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.commands.ProtocolCommand;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisConnectionException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisDataException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.IOUtils;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.RedisInputStream;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.RedisOutputStream;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Connection
/*     */   implements Closeable
/*     */ {
/*     */   private ConnectionPool memberOf;
/*     */   private final JedisSocketFactory socketFactory;
/*     */   private Socket socket;
/*     */   private RedisOutputStream outputStream;
/*     */   private RedisInputStream inputStream;
/*  27 */   private int soTimeout = 0;
/*  28 */   private int infiniteSoTimeout = 0;
/*     */   private boolean broken = false;
/*     */   
/*     */   public Connection() {
/*  32 */     this("127.0.0.1", 6379);
/*     */   }
/*     */   
/*     */   public Connection(String host, int port) {
/*  36 */     this(new HostAndPort(host, port));
/*     */   }
/*     */   
/*     */   public Connection(HostAndPort hostAndPort) {
/*  40 */     this(new DefaultJedisSocketFactory(hostAndPort));
/*     */   }
/*     */   
/*     */   public Connection(HostAndPort hostAndPort, JedisClientConfig clientConfig) {
/*  44 */     this(new DefaultJedisSocketFactory(hostAndPort, clientConfig));
/*  45 */     this.infiniteSoTimeout = clientConfig.getBlockingSocketTimeoutMillis();
/*  46 */     initializeFromClientConfig(clientConfig);
/*     */   }
/*     */   
/*     */   public Connection(JedisSocketFactory socketFactory, JedisClientConfig clientConfig) {
/*  50 */     this.socketFactory = socketFactory;
/*  51 */     this.soTimeout = clientConfig.getSocketTimeoutMillis();
/*  52 */     this.infiniteSoTimeout = clientConfig.getBlockingSocketTimeoutMillis();
/*  53 */     initializeFromClientConfig(clientConfig);
/*     */   }
/*     */   
/*     */   public Connection(JedisSocketFactory socketFactory) {
/*  57 */     this.socketFactory = socketFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  62 */     return "Connection{" + this.socketFactory + "}";
/*     */   }
/*     */   
/*     */   public final void setHandlingPool(ConnectionPool pool) {
/*  66 */     this.memberOf = pool;
/*     */   }
/*     */   
/*     */   final HostAndPort getHostAndPort() {
/*  70 */     return ((DefaultJedisSocketFactory)this.socketFactory).getHostAndPort();
/*     */   }
/*     */   
/*     */   public int getSoTimeout() {
/*  74 */     return this.soTimeout;
/*     */   }
/*     */   
/*     */   public void setSoTimeout(int soTimeout) {
/*  78 */     this.soTimeout = soTimeout;
/*  79 */     if (this.socket != null) {
/*     */       try {
/*  81 */         this.socket.setSoTimeout(soTimeout);
/*  82 */       } catch (SocketException ex) {
/*  83 */         this.broken = true;
/*  84 */         throw new JedisConnectionException(ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void setTimeoutInfinite() {
/*     */     try {
/*  91 */       if (!isConnected()) {
/*  92 */         connect();
/*     */       }
/*  94 */       this.socket.setSoTimeout(this.infiniteSoTimeout);
/*  95 */     } catch (SocketException ex) {
/*  96 */       this.broken = true;
/*  97 */       throw new JedisConnectionException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void rollbackTimeout() {
/*     */     try {
/* 103 */       this.socket.setSoTimeout(this.soTimeout);
/* 104 */     } catch (SocketException ex) {
/* 105 */       this.broken = true;
/* 106 */       throw new JedisConnectionException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object executeCommand(ProtocolCommand cmd) {
/* 111 */     return executeCommand(new CommandArguments(cmd));
/*     */   }
/*     */   
/*     */   public Object executeCommand(CommandArguments args) {
/* 115 */     sendCommand(args);
/* 116 */     return getOne();
/*     */   }
/*     */   
/*     */   public <T> T executeCommand(CommandObject<T> commandObject) {
/* 120 */     CommandArguments args = commandObject.getArguments();
/* 121 */     sendCommand(args);
/* 122 */     if (!args.isBlocking()) {
/* 123 */       return commandObject.getBuilder().build(getOne());
/*     */     }
/*     */     try {
/* 126 */       setTimeoutInfinite();
/* 127 */       return (T)commandObject.getBuilder().build(getOne());
/*     */     } finally {
/* 129 */       rollbackTimeout();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendCommand(ProtocolCommand cmd) {
/* 135 */     sendCommand(new CommandArguments(cmd));
/*     */   }
/*     */   
/*     */   public void sendCommand(ProtocolCommand cmd, Rawable keyword) {
/* 139 */     sendCommand((new CommandArguments(cmd)).add(keyword));
/*     */   }
/*     */   
/*     */   public void sendCommand(ProtocolCommand cmd, String... args) {
/* 143 */     sendCommand((new CommandArguments(cmd)).addObjects((Object[])args));
/*     */   }
/*     */   
/*     */   public void sendCommand(ProtocolCommand cmd, byte[]... args) {
/* 147 */     sendCommand((new CommandArguments(cmd)).addObjects((Object[])args));
/*     */   }
/*     */   
/*     */   public void sendCommand(CommandArguments args) {
/*     */     try {
/* 152 */       connect();
/* 153 */       Protocol.sendCommand(this.outputStream, args);
/* 154 */     } catch (JedisConnectionException ex) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 160 */         String errorMessage = Protocol.readErrorLineIfPossible(this.inputStream);
/* 161 */         if (errorMessage != null && errorMessage.length() > 0) {
/* 162 */           ex = new JedisConnectionException(errorMessage, ex.getCause());
/*     */         }
/* 164 */       } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 172 */       this.broken = true;
/* 173 */       throw ex;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void connect() throws JedisConnectionException {
/* 178 */     if (!isConnected()) {
/*     */       try {
/* 180 */         this.socket = this.socketFactory.createSocket();
/* 181 */         this.soTimeout = this.socket.getSoTimeout();
/*     */         
/* 183 */         this.outputStream = new RedisOutputStream(this.socket.getOutputStream());
/* 184 */         this.inputStream = new RedisInputStream(this.socket.getInputStream());
/* 185 */       } catch (JedisConnectionException jce) {
/* 186 */         this.broken = true;
/* 187 */         throw jce;
/* 188 */       } catch (IOException ioe) {
/* 189 */         this.broken = true;
/* 190 */         throw new JedisConnectionException("Failed to create input/output stream", ioe);
/*     */       } finally {
/* 192 */         if (this.broken) {
/* 193 */           IOUtils.closeQuietly(this.socket);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 201 */     if (this.memberOf != null) {
/* 202 */       ConnectionPool pool = this.memberOf;
/* 203 */       this.memberOf = null;
/* 204 */       if (isBroken()) {
/* 205 */         pool.returnBrokenResource(this);
/*     */       } else {
/* 207 */         pool.returnResource(this);
/*     */       } 
/*     */     } else {
/* 210 */       disconnect();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void disconnect() {
/* 215 */     if (isConnected()) {
/*     */       try {
/* 217 */         this.outputStream.flush();
/* 218 */         this.socket.close();
/* 219 */       } catch (IOException ex) {
/* 220 */         this.broken = true;
/* 221 */         throw new JedisConnectionException(ex);
/*     */       } finally {
/* 223 */         IOUtils.closeQuietly(this.socket);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isConnected() {
/* 229 */     return (this.socket != null && this.socket.isBound() && !this.socket.isClosed() && this.socket.isConnected() && 
/* 230 */       !this.socket.isInputShutdown() && !this.socket.isOutputShutdown());
/*     */   }
/*     */   
/*     */   public boolean isBroken() {
/* 234 */     return this.broken;
/*     */   }
/*     */   
/*     */   public void setBroken() {
/* 238 */     this.broken = true;
/*     */   }
/*     */   
/*     */   public String getStatusCodeReply() {
/* 242 */     flush();
/* 243 */     byte[] resp = (byte[])readProtocolWithCheckingBroken();
/* 244 */     if (null == resp) {
/* 245 */       return null;
/*     */     }
/* 247 */     return SafeEncoder.encode(resp);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBulkReply() {
/* 252 */     byte[] result = getBinaryBulkReply();
/* 253 */     if (null != result) {
/* 254 */       return SafeEncoder.encode(result);
/*     */     }
/* 256 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBinaryBulkReply() {
/* 261 */     flush();
/* 262 */     return (byte[])readProtocolWithCheckingBroken();
/*     */   }
/*     */   
/*     */   public Long getIntegerReply() {
/* 266 */     flush();
/* 267 */     return (Long)readProtocolWithCheckingBroken();
/*     */   }
/*     */   
/*     */   public List<String> getMultiBulkReply() {
/* 271 */     return BuilderFactory.STRING_LIST.build(getBinaryMultiBulkReply());
/*     */   }
/*     */ 
/*     */   
/*     */   public List<byte[]> getBinaryMultiBulkReply() {
/* 276 */     flush();
/* 277 */     return (List<byte[]>)readProtocolWithCheckingBroken();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Object> getUnflushedObjectMultiBulkReply() {
/* 282 */     return (List<Object>)readProtocolWithCheckingBroken();
/*     */   }
/*     */   
/*     */   public List<Object> getObjectMultiBulkReply() {
/* 286 */     flush();
/* 287 */     return getUnflushedObjectMultiBulkReply();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Long> getIntegerMultiBulkReply() {
/* 292 */     flush();
/* 293 */     return (List<Long>)readProtocolWithCheckingBroken();
/*     */   }
/*     */   
/*     */   public Object getOne() {
/* 297 */     flush();
/* 298 */     return readProtocolWithCheckingBroken();
/*     */   }
/*     */   
/*     */   protected void flush() {
/*     */     try {
/* 303 */       this.outputStream.flush();
/* 304 */     } catch (IOException ex) {
/* 305 */       this.broken = true;
/* 306 */       throw new JedisConnectionException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Object readProtocolWithCheckingBroken() {
/* 311 */     if (this.broken) {
/* 312 */       throw new JedisConnectionException("Attempting to read from a broken connection");
/*     */     }
/*     */     
/*     */     try {
/* 316 */       return Protocol.read(this.inputStream);
/* 317 */     } catch (JedisConnectionException exc) {
/* 318 */       this.broken = true;
/* 319 */       throw exc;
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<Object> getMany(int count) {
/* 324 */     flush();
/* 325 */     List<Object> responses = new ArrayList(count);
/* 326 */     for (int i = 0; i < count; i++) {
/*     */       try {
/* 328 */         responses.add(readProtocolWithCheckingBroken());
/* 329 */       } catch (JedisDataException e) {
/* 330 */         responses.add(e);
/*     */       } 
/*     */     } 
/* 333 */     return responses;
/*     */   }
/*     */   
/*     */   private void initializeFromClientConfig(JedisClientConfig config) {
/*     */     try {
/* 338 */       connect();
/* 339 */       String password = config.getPassword();
/* 340 */       if (password != null) {
/* 341 */         String user = config.getUser();
/* 342 */         if (user != null) {
/* 343 */           auth(user, password);
/*     */         } else {
/* 345 */           auth(password);
/*     */         } 
/*     */       } 
/* 348 */       int dbIndex = config.getDatabase();
/* 349 */       if (dbIndex > 0) {
/* 350 */         select(dbIndex);
/*     */       }
/* 352 */       String clientName = config.getClientName();
/* 353 */       if (clientName != null)
/*     */       {
/* 355 */         clientSetname(clientName);
/*     */       }
/* 357 */     } catch (JedisException je) {
/*     */       try {
/* 359 */         if (isConnected()) {
/* 360 */           quit();
/*     */         }
/* 362 */         disconnect();
/* 363 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 366 */       throw je;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String auth(String password) {
/* 371 */     sendCommand(Protocol.Command.AUTH, new String[] { password });
/* 372 */     return getStatusCodeReply();
/*     */   }
/*     */   
/*     */   private String auth(String user, String password) {
/* 376 */     sendCommand(Protocol.Command.AUTH, new String[] { user, password });
/* 377 */     return getStatusCodeReply();
/*     */   }
/*     */   
/*     */   public String select(int index) {
/* 381 */     sendCommand(Protocol.Command.SELECT, new byte[][] { Protocol.toByteArray(index) });
/* 382 */     return getStatusCodeReply();
/*     */   }
/*     */   
/*     */   private String clientSetname(String name) {
/* 386 */     sendCommand(Protocol.Command.CLIENT, new String[] { Protocol.Keyword.SETNAME.name(), name });
/* 387 */     return getStatusCodeReply();
/*     */   }
/*     */   
/*     */   public String quit() {
/* 391 */     sendCommand(Protocol.Command.QUIT);
/* 392 */     String quitReturn = getStatusCodeReply();
/* 393 */     disconnect();
/* 394 */     setBroken();
/* 395 */     return quitReturn;
/*     */   }
/*     */   
/*     */   public boolean ping() {
/* 399 */     sendCommand(Protocol.Command.PING);
/* 400 */     String status = getStatusCodeReply();
/* 401 */     if (!"PONG".equals(status)) {
/* 402 */       throw new JedisException(status);
/*     */     }
/* 404 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\Connection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */