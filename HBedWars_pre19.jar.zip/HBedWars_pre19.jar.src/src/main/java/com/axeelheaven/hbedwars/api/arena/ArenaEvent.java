/*   */ package com.axeelheaven.hbedwars.api.arena;
/*   */ 
/*   */ public enum ArenaEvent
/*   */ {
/* 5 */   GENERATOR, BED_DESTRUCTION, SUDDEN_DEATH, FINAL_GAME, NONE;
/*   */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\arena\ArenaEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */