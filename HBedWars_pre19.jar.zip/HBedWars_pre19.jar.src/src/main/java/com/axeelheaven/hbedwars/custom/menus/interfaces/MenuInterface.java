package com.axeelheaven.hbedwars.custom.menus.interfaces;

import java.util.HashMap;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public interface MenuInterface {
  HashMap<Integer, MenuIconInterface> getIcons();
  
  String getName();
  
  void open(Player player);
  
  void onClose(Player paramPlayer, Inventory paramInventory);
  
  void update(Player player);
  
  boolean isEditing();
  
  void setEditing(boolean paramBoolean);
  
  void click(Player player, ItemStack item, int slot);
  
  void close(Player player);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\menus\interfaces\MenuInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */