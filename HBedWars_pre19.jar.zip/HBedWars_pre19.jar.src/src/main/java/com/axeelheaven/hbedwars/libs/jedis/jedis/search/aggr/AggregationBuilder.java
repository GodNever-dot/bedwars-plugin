/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.search.aggr;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.search.FieldName;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.StringJoiner;
/*     */ 
/*     */ public class AggregationBuilder {
/*  12 */   private final List<String> args = new ArrayList<>();
/*     */   private boolean isWithCursor = false;
/*     */   
/*     */   public AggregationBuilder(String query) {
/*  16 */     this.args.add(query);
/*     */   }
/*     */   
/*     */   public AggregationBuilder() {
/*  20 */     this("*");
/*     */   }
/*     */   
/*     */   public AggregationBuilder load(String... fields) {
/*  24 */     return load(FieldName.convert(fields));
/*     */   }
/*     */   
/*     */   public AggregationBuilder load(FieldName... fields) {
/*  28 */     this.args.add("LOAD");
/*  29 */     int loadCountIndex = this.args.size();
/*  30 */     this.args.add(null);
/*  31 */     int loadCount = 0;
/*  32 */     for (FieldName fn : fields) {
/*  33 */       loadCount += fn.addCommandEncodedArguments(this.args);
/*     */     }
/*  35 */     this.args.set(loadCountIndex, Integer.toString(loadCount));
/*  36 */     return this;
/*     */   }
/*     */   
/*     */   public AggregationBuilder limit(int offset, int count) {
/*  40 */     Limit limit = new Limit(offset, count);
/*  41 */     limit.addArgs(this.args);
/*  42 */     return this;
/*     */   }
/*     */   
/*     */   public AggregationBuilder limit(int count) {
/*  46 */     return limit(0, count);
/*     */   }
/*     */   
/*     */   public AggregationBuilder sortBy(SortedField... fields) {
/*  50 */     this.args.add("SORTBY");
/*  51 */     this.args.add(Integer.toString(fields.length * 2));
/*  52 */     for (SortedField field : fields) {
/*  53 */       this.args.add(field.getField());
/*  54 */       this.args.add(field.getOrder());
/*     */     } 
/*     */     
/*  57 */     return this;
/*     */   }
/*     */   
/*     */   public AggregationBuilder sortBy(int max, SortedField... fields) {
/*  61 */     sortBy(fields);
/*  62 */     if (max > 0) {
/*  63 */       this.args.add("MAX");
/*  64 */       this.args.add(Integer.toString(max));
/*     */     } 
/*  66 */     return this;
/*     */   }
/*     */   
/*     */   public AggregationBuilder sortByAsc(String field) {
/*  70 */     return sortBy(new SortedField[] { SortedField.asc(field) });
/*     */   }
/*     */   
/*     */   public AggregationBuilder sortByDesc(String field) {
/*  74 */     return sortBy(new SortedField[] { SortedField.desc(field) });
/*     */   }
/*     */   
/*     */   public AggregationBuilder apply(String projection, String alias) {
/*  78 */     this.args.add("APPLY");
/*  79 */     this.args.add(projection);
/*  80 */     this.args.add("AS");
/*  81 */     this.args.add(alias);
/*  82 */     return this;
/*     */   }
/*     */   
/*     */   public AggregationBuilder groupBy(Collection<String> fields, Collection<Reducer> reducers) {
/*  86 */     String[] fieldsArr = new String[fields.size()];
/*  87 */     Group g = new Group(fields.<String>toArray(fieldsArr));
/*  88 */     for (Reducer r : reducers) {
/*  89 */       g.reduce(r);
/*     */     }
/*  91 */     groupBy(g);
/*  92 */     return this;
/*     */   }
/*     */   
/*     */   public AggregationBuilder groupBy(String field, Reducer... reducers) {
/*  96 */     return groupBy(Collections.singletonList(field), Arrays.asList(reducers));
/*     */   }
/*     */   
/*     */   public AggregationBuilder groupBy(Group group) {
/* 100 */     this.args.add("GROUPBY");
/* 101 */     group.addArgs(this.args);
/* 102 */     return this;
/*     */   }
/*     */   
/*     */   public AggregationBuilder filter(String expression) {
/* 106 */     this.args.add("FILTER");
/* 107 */     this.args.add(expression);
/* 108 */     return this;
/*     */   }
/*     */   
/*     */   public AggregationBuilder cursor(int count, long maxIdle) {
/* 112 */     this.isWithCursor = true;
/* 113 */     if (count > 0) {
/* 114 */       this.args.add("WITHCURSOR");
/* 115 */       this.args.add("COUNT");
/* 116 */       this.args.add(Integer.toString(count));
/* 117 */       if (maxIdle < Long.MAX_VALUE && maxIdle >= 0L) {
/* 118 */         this.args.add("MAXIDLE");
/* 119 */         this.args.add(Long.toString(maxIdle));
/*     */       } 
/*     */     } 
/* 122 */     return this;
/*     */   }
/*     */   
/*     */   public List<String> getArgs() {
/* 126 */     return Collections.unmodifiableList(this.args);
/*     */   }
/*     */   
/*     */   public void serializeRedisArgs(List<byte[]> redisArgs) {
/* 130 */     for (String s : getArgs()) {
/* 131 */       redisArgs.add(SafeEncoder.encode(s));
/*     */     }
/*     */   }
/*     */   
/*     */   public String getArgsString() {
/* 136 */     StringJoiner sj = new StringJoiner(" ");
/* 137 */     for (String s : getArgs()) {
/* 138 */       sj.add(s);
/*     */     }
/* 140 */     return sj.toString();
/*     */   }
/*     */   
/*     */   public boolean isWithCursor() {
/* 144 */     return this.isWithCursor;
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\search\aggr\AggregationBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */