/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.args;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ 
/*    */ 
/*    */ public enum FunctionRestorePolicy
/*    */   implements Rawable
/*    */ {
/*  9 */   FLUSH,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 15 */   APPEND,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 22 */   REPLACE;
/*    */   
/*    */   private final byte[] raw;
/*    */   
/*    */   FunctionRestorePolicy() {
/* 27 */     this.raw = SafeEncoder.encode(name());
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] getRaw() {
/* 32 */     return this.raw;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\args\FunctionRestorePolicy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */