/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XReadGroupParams
/*    */   implements IParams
/*    */ {
/* 12 */   private Integer count = null;
/* 13 */   private Integer block = null;
/*    */   private boolean noack = false;
/*    */   
/*    */   public static XReadGroupParams xReadGroupParams() {
/* 17 */     return new XReadGroupParams();
/*    */   }
/*    */   
/*    */   public XReadGroupParams count(int count) {
/* 21 */     this.count = Integer.valueOf(count);
/* 22 */     return this;
/*    */   }
/*    */   
/*    */   public XReadGroupParams block(int block) {
/* 26 */     this.block = Integer.valueOf(block);
/* 27 */     return this;
/*    */   }
/*    */   
/*    */   public XReadGroupParams noAck() {
/* 31 */     this.noack = true;
/* 32 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 37 */     if (this.count != null) {
/* 38 */       args.add(Protocol.Keyword.COUNT);
/* 39 */       args.add(Protocol.toByteArray(this.count.intValue()));
/*    */     } 
/* 41 */     if (this.block != null) {
/* 42 */       args.add(Protocol.Keyword.BLOCK);
/* 43 */       args.add(Protocol.toByteArray(this.block.intValue()));
/* 44 */       args.blocking();
/*    */     } 
/* 46 */     if (this.noack)
/* 47 */       args.add(Protocol.Keyword.NOACK); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\XReadGroupParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */