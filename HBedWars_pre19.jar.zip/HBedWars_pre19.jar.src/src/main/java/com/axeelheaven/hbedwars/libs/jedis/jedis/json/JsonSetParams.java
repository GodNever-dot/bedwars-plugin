/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.json;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.IParams;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonSetParams
/*    */   implements IParams
/*    */ {
/*    */   private boolean nx = false;
/*    */   private boolean xx = false;
/*    */   
/*    */   public static JsonSetParams jsonSetParams() {
/* 15 */     return new JsonSetParams();
/*    */   }
/*    */   
/*    */   public JsonSetParams nx() {
/* 19 */     this.nx = true;
/* 20 */     this.xx = false;
/* 21 */     return this;
/*    */   }
/*    */   
/*    */   public JsonSetParams xx() {
/* 25 */     this.nx = false;
/* 26 */     this.xx = true;
/* 27 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 32 */     if (this.nx) {
/* 33 */       args.add("NX");
/*    */     }
/* 35 */     if (this.xx)
/* 36 */       args.add("XX"); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\json\JsonSetParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */