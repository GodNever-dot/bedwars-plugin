package com.axeelheaven.hbedwars.cosmetics.beddestroys;

import com.axeelheaven.hbedwars.BedWars;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class BedDestroyThief extends BedDestroy {
  private static String llllIIIllIII(float llllllllllllllllIlIlIlllIlllIIIl, String llllllllllllllllIlIlIlllIllllIIl) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   40: iconst_0
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   58: iconst_0
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic llllIIlIlIlI : (II)Z
    //   69: ifeq -> 127
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: ldc ' '
    //   114: invokevirtual length : ()I
    //   117: ldc ' '
    //   119: invokevirtual length : ()I
    //   122: if_icmpeq -> 62
    //   125: aconst_null
    //   126: areturn
    //   127: aload_2
    //   128: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   131: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	132	7	llllllllllllllllIlIlIlllIllIIlII	J
    //   0	132	0	llllllllllllllllIlIlIlllIllllIlI	Ljava/lang/String;
    //   32	100	2	llllllllllllllllIlIlIlllIlllIlll	Ljava/lang/StringBuilder;
    //   44	88	4	llllllllllllllllIlIlIlllIlllIIll	I
    //   0	132	6	llllllllllllllllIlIlIlllIllIIllI	Ljava/lang/Exception;
    //   0	132	5	llllllllllllllllIlIlIlllIllIlIII	D
    //   0	132	4	llllllllllllllllIlIlIlllIllIlIlI	S
    //   0	132	1	llllllllllllllllIlIlIlllIlllIIII	D
    //   37	95	3	llllllllllllllllIlIlIlllIlllIlIl	[C
    //   79	24	8	llllllllllllllllIlIlIlllIlllllIl	C
    //   0	132	1	llllllllllllllllIlIlIlllIllllIIl	Ljava/lang/String;
    //   0	132	8	llllllllllllllllIlIlIlllIllIIIlI	Ljava/lang/Exception;
    //   0	132	3	llllllllllllllllIlIlIlllIllIllII	C
    //   0	132	2	llllllllllllllllIlIlIlllIllIlllI	F
    //   0	132	0	llllllllllllllllIlIlIlllIlllIIIl	F
  }
  
  private static String llllIIIllIIl(String llllllllllllllllIlIlIllllIlIIIII, char llllllllllllllllIlIlIllllIIllIIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   22: bipush #8
    //   24: iaload
    //   25: invokestatic copyOf : ([BI)[B
    //   28: ldc 'DES'
    //   30: invokespecial <init> : ([BLjava/lang/String;)V
    //   33: astore_2
    //   34: ldc 'DES'
    //   36: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   39: astore_3
    //   40: aload_3
    //   41: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   44: iconst_2
    //   45: iaload
    //   46: aload_2
    //   47: invokevirtual init : (ILjava/security/Key;)V
    //   50: new java/lang/String
    //   53: dup
    //   54: aload_3
    //   55: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   58: aload_0
    //   59: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   62: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   65: invokevirtual decode : ([B)[B
    //   68: invokevirtual doFinal : ([B)[B
    //   71: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   74: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   77: areturn
    //   78: astore_2
    //   79: aload_2
    //   80: invokevirtual printStackTrace : ()V
    //   83: aconst_null
    //   84: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	85	1	llllllllllllllllIlIlIllllIIllllI	Ljava/lang/String;
    //   0	85	0	llllllllllllllllIlIlIllllIIlllII	F
    //   0	85	1	llllllllllllllllIlIlIllllIIllIIl	C
    //   34	44	2	llllllllllllllllIlIlIllllIlIIllI	Ljavax/crypto/spec/SecretKeySpec;
    //   0	85	3	llllllllllllllllIlIlIllllIIlIlll	F
    //   0	85	2	llllllllllllllllIlIlIllllIIllIII	S
    //   79	4	2	llllllllllllllllIlIlIllllIlIIIlI	Ljava/lang/Exception;
    //   40	38	3	llllllllllllllllIlIlIllllIlIIlII	Ljavax/crypto/Cipher;
    //   0	85	0	llllllllllllllllIlIlIllllIlIIIII	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	77	78	java/lang/Exception
  }
  
  public BedDestroyThief(BedWars llllllllllllllllIlIllIIIIIllIllI, String llllllllllllllllIlIllIIIIIlllIIl, boolean llllllllllllllllIlIllIIIIIlllIII, byte llllllllllllllllIlIllIIIIIlIlIIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: iload_3
    //   3: iload #4
    //   5: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   8: aload_0
    //   9: aload_1
    //   10: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   13: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	14	1	llllllllllllllllIlIllIIIIIllIlII	C
    //   0	14	2	llllllllllllllllIlIllIIIIIlIllIl	F
    //   0	14	4	llllllllllllllllIlIllIIIIIllIlll	Z
    //   0	14	0	llllllllllllllllIlIllIIIIIllllIl	Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief;
    //   0	14	2	llllllllllllllllIlIllIIIIIlllIIl	Ljava/lang/String;
    //   0	14	4	llllllllllllllllIlIllIIIIIlIlIIl	B
    //   0	14	0	llllllllllllllllIlIllIIIIIlllIll	C
    //   0	14	3	llllllllllllllllIlIllIIIIIllIIlI	I
    //   0	14	2	llllllllllllllllIlIllIIIIIllIlIl	Ljava/lang/String;
    //   0	14	1	llllllllllllllllIlIllIIIIIllIllI	Lcom/axeelheaven/hbedwars/BedWars;
    //   0	14	3	llllllllllllllllIlIllIIIIIlllIII	Z
    //   0	14	3	llllllllllllllllIlIllIIIIIlIlIll	C
    //   0	14	1	llllllllllllllllIlIllIIIIIlIllll	D
    //   0	14	4	llllllllllllllllIlIllIIIIIlllIlI	I
    //   0	14	0	llllllllllllllllIlIllIIIIIllIIII	C
  }
  
  static {
    llllIIlIlIII();
    llllIIIllllI();
    lIIlIIIIlII();
    lIIlIIIIIll();
  }
  
  private static boolean llllIIlIlIlI(String llllllllllllllllIlIlIlllIlIlIlII, int llllllllllllllllIlIlIlllIlIlIIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean llllIIlIlIIl(byte llllllllllllllllIlIlIlllIlIIllIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static String llllIIIlllIl(Exception llllllllllllllllIlIlIllllIlllIII, String llllllllllllllllIlIlIllllIlllIIl) {
    try {
      SecretKeySpec llllllllllllllllIlIlIlllllIIIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIlIllllIlllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIlIlIllllIlllllI = Cipher.getInstance("Blowfish");
      llllllllllllllllIlIlIllllIlllllI.init(lIIIIIIIllI[2], llllllllllllllllIlIlIlllllIIIIIl);
      return new String(llllllllllllllllIlIlIllllIlllllI.doFinal(Base64.getDecoder().decode(llllllllllllllllIlIlIllllIlllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception llllllllllllllllIlIlIllllIllllII) {
      llllllllllllllllIlIlIllllIllllII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIlIIIIIlI(String llllllllllllllllIlIllIIIIIIIllIl, boolean llllllllllllllllIlIlIlllllllIIlI) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllIl : [I
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   43: iconst_0
    //   44: iaload
    //   45: iaload
    //   46: istore #4
    //   48: aload_0
    //   49: invokevirtual toCharArray : ()[C
    //   52: astore #5
    //   54: aload #5
    //   56: arraylength
    //   57: istore #6
    //   59: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllIl : [I
    //   62: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   65: iconst_0
    //   66: iaload
    //   67: iaload
    //   68: istore #7
    //   70: iload #7
    //   72: iload #6
    //   74: invokestatic lIIlIIIIlIl : (II)Z
    //   77: invokestatic llllIIlIlIIl : (I)Z
    //   80: ifeq -> 221
    //   83: aload #5
    //   85: iload #7
    //   87: caload
    //   88: istore #8
    //   90: aload_2
    //   91: iload #8
    //   93: aload_3
    //   94: iload #4
    //   96: aload_3
    //   97: arraylength
    //   98: irem
    //   99: caload
    //   100: ixor
    //   101: i2c
    //   102: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   105: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIlIl : [Ljava/lang/String;
    //   108: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   111: bipush #7
    //   113: iaload
    //   114: aaload
    //   115: invokevirtual length : ()I
    //   118: pop2
    //   119: iinc #4, 1
    //   122: iinc #7, 1
    //   125: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIlIl : [Ljava/lang/String;
    //   128: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   131: bipush #8
    //   133: iaload
    //   134: aaload
    //   135: invokevirtual length : ()I
    //   138: ldc ''
    //   140: invokevirtual length : ()I
    //   143: pop2
    //   144: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   147: bipush #9
    //   149: iaload
    //   150: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   153: bipush #10
    //   155: iaload
    //   156: ixor
    //   157: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   160: bipush #6
    //   162: iaload
    //   163: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   166: bipush #11
    //   168: iaload
    //   169: ixor
    //   170: ixor
    //   171: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   174: iconst_4
    //   175: iaload
    //   176: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   179: bipush #12
    //   181: iaload
    //   182: ixor
    //   183: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   186: bipush #13
    //   188: iaload
    //   189: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   192: bipush #14
    //   194: iaload
    //   195: ixor
    //   196: ixor
    //   197: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIlIl : [Ljava/lang/String;
    //   200: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   203: bipush #15
    //   205: iaload
    //   206: aaload
    //   207: invokevirtual length : ()I
    //   210: ineg
    //   211: ixor
    //   212: iand
    //   213: invokestatic llllIIlIlIIl : (I)Z
    //   216: ifeq -> 70
    //   219: aconst_null
    //   220: areturn
    //   221: aload_2
    //   222: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   225: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	226	0	llllllllllllllllIlIllIIIIIIIIIlI	B
    //   0	226	3	llllllllllllllllIlIlIllllllllIIl	I
    //   0	226	1	llllllllllllllllIlIllIIIIIIIlIll	Ljava/lang/String;
    //   90	32	8	llllllllllllllllIlIlIllllllllIll	C
    //   0	226	3	llllllllllllllllIlIlIlllllllIIII	I
    //   0	226	4	llllllllllllllllIlIllIIIIIIIIlIl	J
    //   0	226	0	llllllllllllllllIlIllIIIIIIIllIl	Ljava/lang/String;
    //   0	226	5	llllllllllllllllIlIlIllllllIllII	F
    //   0	226	0	llllllllllllllllIlIlIlllllllIlII	S
    //   0	226	6	llllllllllllllllIlIlIlllllllIllI	C
    //   0	226	2	llllllllllllllllIlIlIlllllllIIIl	Ljava/lang/Exception;
    //   0	226	8	llllllllllllllllIlIlIllllllllllI	F
    //   0	226	4	llllllllllllllllIlIlIllllllIlllI	B
    //   0	226	8	llllllllllllllllIlIlIllllllIIlll	D
    //   0	226	7	llllllllllllllllIlIllIIIIIIIIlII	J
    //   48	178	4	llllllllllllllllIlIllIIIIIIIlllI	I
    //   32	194	2	llllllllllllllllIlIlIlllllllllII	Ljava/lang/StringBuilder;
    //   0	226	2	llllllllllllllllIlIllIIIIIIIIIII	J
    //   0	226	1	llllllllllllllllIlIlIlllllllIIlI	Z
    //   0	226	1	llllllllllllllllIlIlIllllllllIII	Ljava/lang/String;
    //   0	226	7	llllllllllllllllIlIlIllllllIlIIl	Ljava/lang/Exception;
    //   0	226	5	llllllllllllllllIlIllIIIIIIIlIIl	Ljava/lang/String;
    //   0	226	6	llllllllllllllllIlIlIllllllIlIlI	S
    //   37	189	3	llllllllllllllllIlIllIIIIIIIIlll	[C
  }
  
  private static void lIIlIIIIIll() {
    lIlllllII = new String[lIlllllIl[lIIIIIIIllI[3]]];
    lIlllllII[lIlllllIl[lIIIIIIIllI[0]]] = lIIlIIIIIlI(lIIIIIIIlIl[lIIIIIIIllI[3]], lIIIIIIIlIl[lIIIIIIIllI[4]]);
    lIlllllII[lIlllllIl[lIIIIIIIllI[2]]] = lIIlIIIIIlI(lIIIIIIIlIl[lIIIIIIIllI[5]], lIIIIIIIlIl[lIIIIIIIllI[6]]);
  }
  
  public void execute(byte llllllllllllllllIlIllIIIIlIlIIII) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getWorld : ()Lorg/bukkit/World;
    //   4: aload_1
    //   5: ldc_w org/bukkit/entity/Enderman
    //   8: invokeinterface spawn : (Lorg/bukkit/Location;Ljava/lang/Class;)Lorg/bukkit/entity/Entity;
    //   13: checkcast org/bukkit/entity/Enderman
    //   16: astore_2
    //   17: aload_2
    //   18: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllII : [Ljava/lang/String;
    //   21: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllIl : [I
    //   24: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   27: iconst_0
    //   28: iaload
    //   29: iaload
    //   30: aaload
    //   31: new org/bukkit/metadata/FixedMetadataValue
    //   34: dup
    //   35: aload_0
    //   36: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   39: aload_0
    //   40: invokevirtual getId : ()Ljava/lang/String;
    //   43: invokespecial <init> : (Lorg/bukkit/plugin/Plugin;Ljava/lang/Object;)V
    //   46: invokeinterface setMetadata : (Ljava/lang/String;Lorg/bukkit/metadata/MetadataValue;)V
    //   51: aload_2
    //   52: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllIl : [I
    //   55: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   58: iconst_1
    //   59: iaload
    //   60: iaload
    //   61: invokeinterface setNoDamageTicks : (I)V
    //   66: aload_2
    //   67: ldc2_w 2.147483647E9
    //   70: invokeinterface setMaxHealth : (D)V
    //   75: aload_2
    //   76: aload_2
    //   77: invokeinterface getMaxHealth : ()D
    //   82: invokeinterface setHealth : (D)V
    //   87: aload_2
    //   88: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllIl : [I
    //   91: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   94: iconst_0
    //   95: iaload
    //   96: iaload
    //   97: invokeinterface setRemoveWhenFarAway : (Z)V
    //   102: aload_2
    //   103: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllIl : [I
    //   106: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   109: iconst_2
    //   110: iaload
    //   111: iaload
    //   112: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   115: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllIl : [I
    //   118: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   121: iconst_2
    //   122: iaload
    //   123: iaload
    //   124: anewarray java/lang/Object
    //   127: dup
    //   128: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllIl : [I
    //   131: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   134: iconst_0
    //   135: iaload
    //   136: iaload
    //   137: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllII : [Ljava/lang/String;
    //   140: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIlllllIl : [I
    //   143: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   146: iconst_2
    //   147: iaload
    //   148: iaload
    //   149: aaload
    //   150: aastore
    //   151: invokestatic set : (Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   154: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIlIl : [Ljava/lang/String;
    //   157: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   160: iconst_0
    //   161: iaload
    //   162: aaload
    //   163: invokevirtual length : ()I
    //   166: pop2
    //   167: aload_2
    //   168: getstatic com/axeelheaven/hbedwars/libs/xseries/XMaterial.CHEST : Lcom/axeelheaven/hbedwars/libs/xseries/XMaterial;
    //   171: invokevirtual parseItem : ()Lorg/bukkit/inventory/ItemStack;
    //   174: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   177: checkcast org/bukkit/inventory/ItemStack
    //   180: invokevirtual getData : ()Lorg/bukkit/material/MaterialData;
    //   183: invokeinterface setCarriedMaterial : (Lorg/bukkit/material/MaterialData;)V
    //   188: aload_0
    //   189: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   192: invokevirtual getServer : ()Lorg/bukkit/Server;
    //   195: invokeinterface getScheduler : ()Lorg/bukkit/scheduler/BukkitScheduler;
    //   200: aload_0
    //   201: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   204: aload_2
    //   205: dup
    //   206: invokevirtual getClass : ()Ljava/lang/Class;
    //   209: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIlIl : [Ljava/lang/String;
    //   212: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   215: iconst_1
    //   216: iaload
    //   217: aaload
    //   218: invokevirtual length : ()I
    //   221: pop2
    //   222: <illegal opcode> run : (Lorg/bukkit/entity/Enderman;)Ljava/lang/Runnable;
    //   227: ldc2_w 40
    //   230: invokeinterface scheduleSyncDelayedTask : (Lorg/bukkit/plugin/Plugin;Ljava/lang/Runnable;J)I
    //   235: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIlIl : [Ljava/lang/String;
    //   238: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief.lIIIIIIIllI : [I
    //   241: iconst_2
    //   242: iaload
    //   243: aaload
    //   244: invokevirtual length : ()I
    //   247: pop2
    //   248: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	249	1	llllllllllllllllIlIllIIIIlIlIlII	Lorg/bukkit/Location;
    //   0	249	2	llllllllllllllllIlIllIIIIlIllIII	Z
    //   0	249	1	llllllllllllllllIlIllIIIIlIlIIII	B
    //   0	249	0	llllllllllllllllIlIllIIIIlIlIlIl	Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyThief;
    //   0	249	0	llllllllllllllllIlIllIIIIlIlIIll	Z
    //   17	232	2	llllllllllllllllIlIllIIIIlIlllII	Lorg/bukkit/entity/Enderman;
    //   0	249	1	llllllllllllllllIlIllIIIIlIlIllI	Ljava/lang/String;
    //   0	249	0	llllllllllllllllIlIllIIIIlIlIIlI	D
    //   0	249	2	llllllllllllllllIlIllIIIIlIIlllI	Ljava/lang/String;
  }
  
  private static void llllIIIllllI() {
    lIIIIIIIlIl = new String[lIIIIIIIllI[24]];
    lIIIIIIIlIl[lIIIIIIIllI[0]] = llllIIIllIII("", "MPmpX");
    lIIIIIIIlIl[lIIIIIIIllI[1]] = llllIIIllIIl("Rbh0c+QvUWE=", "TPbum");
    lIIIIIIIlIl[lIIIIIIIllI[2]] = llllIIIllIII("", "VVOlj");
    lIIIIIIIlIl[lIIIIIIIllI[3]] = llllIIIllIIl("UfzunaTor7b2LDfjnbfOzxIgoCgA/wJl", "BemCr");
    lIIIIIIIlIl[lIIIIIIIllI[4]] = llllIIIllIIl("aS2XaANsy3U=", "jfmCF");
    lIIIIIIIlIl[lIIIIIIIllI[5]] = llllIIIllIII("BiInCDUFdlc=", "DKjdy");
    lIIIIIIIlIl[lIIIIIIIllI[6]] = llllIIIllIIl("DegR2g572OY=", "WvRoY");
    lIIIIIIIlIl[lIIIIIIIllI[7]] = llllIIIllIII("", "gIiEM");
    lIIIIIIIlIl[lIIIIIIIllI[8]] = llllIIIlllIl("YkyhdpR93oI=", "BQXwr");
    lIIIIIIIlIl[lIIIIIIIllI[15]] = llllIIIllIIl("JfnmvoJkB74=", "aUClE");
    lIIIIIIIlIl[lIIIIIIIllI[22]] = llllIIIllIII("cw==", "SLxBy");
    lIIIIIIIlIl[lIIIIIIIllI[23]] = llllIIIlllIl("2EDL8ws9Bpg=", "DfurP");
  }
  
  private static void llllIIlIlIII() {
    lIIIIIIIllI = new int[25];
    lIIIIIIIllI[0] = (0x7B ^ 0x76 ^ 0xA1 ^ 0xB4) & (0xEF ^ 0x8E ^ 0xFD ^ 0x84 ^ -" ".length());
    lIIIIIIIllI[1] = " ".length();
    lIIIIIIIllI[2] = "  ".length();
    lIIIIIIIllI[3] = "   ".length();
    lIIIIIIIllI[4] = 0x9 ^ 0xD;
    lIIIIIIIllI[5] = 0x4D ^ 0x48;
    lIIIIIIIllI[6] = 87 + 184 - 181 + 95 ^ 42 + 53 - -24 + 72;
    lIIIIIIIllI[7] = "   ".length() ^ 0x88 ^ 0x8C;
    lIIIIIIIllI[8] = 0x66 ^ 0x6E;
    lIIIIIIIllI[9] = 0xF7 ^ 0xAA;
    lIIIIIIIllI[10] = 0x8C ^ 0x81;
    lIIIIIIIllI[11] = 0x9E ^ 0xC7;
    lIIIIIIIllI[12] = 0xC7 ^ 0x93 ^ 0xEF ^ 0x96;
    lIIIIIIIllI[13] = 123 + 198 - 272 + 181;
    lIIIIIIIllI[14] = 164 + 13 - 174 + 189;
    lIIIIIIIllI[15] = 34 + 122 - 0 + 17 ^ 19 + 54 - 11 + 102;
    lIIIIIIIllI[16] = 0xB ^ 0x26 ^ 0x89 ^ 0x9E;
    lIIIIIIIllI[17] = 0x5F ^ 0x39;
    lIIIIIIIllI[18] = 74 + 113 - 107 + 51 ^ 62 + 159 - 130 + 69;
    lIIIIIIIllI[19] = (0x60 ^ 0x13) + (0x9A ^ 0xC3) - 31 + 83 - -37 + 47 + (0x71 ^ 0x8);
    lIIIIIIIllI[20] = -" ".length();
    lIIIIIIIllI[21] = -" ".length() & 0xFFFFFFFF & Integer.MAX_VALUE;
    lIIIIIIIllI[22] = 0x1B ^ 0x11;
    lIIIIIIIllI[23] = 0x19 ^ 0x37 ^ 0x6B ^ 0x4E;
    lIIIIIIIllI[24] = 0x7E ^ 0x72;
  }
  
  private static void lIIlIIIIlII() {
    lIlllllIl = new int[lIIIIIIIllI[4]];
    lIlllllIl[lIIIIIIIllI[0]] = (lIIIIIIIllI[16] ^ lIIIIIIIllI[17]) & (lIIIIIIIllI[18] ^ lIIIIIIIllI[19] ^ lIIIIIIIllI[20]);
    lIlllllIl[lIIIIIIIllI[1]] = lIIIIIIIllI[20] & lIIIIIIIllI[21];
    lIlllllIl[lIIIIIIIllI[2]] = lIIIIIIIlIl[lIIIIIIIllI[22]].length();
    lIlllllIl[lIIIIIIIllI[3]] = lIIIIIIIlIl[lIIIIIIIllI[23]].length();
  }
  
  private static boolean lIIlIIIIlIl(int llllllllllllllllIlIlIlllllIllIII, boolean llllllllllllllllIlIlIlllllIllIlI) {
    if (llllIIlIlIlI(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if ("  ".length() != "  ".length())
        return (" ".length() ^ 0x1F ^ 0x5F) & (114 + 21 - 52 + 111 ^ 17 + 90 - -3 + 21 ^ -" ".length()); 
    } else {
    
    } 
    return lIIIIIIIllI[0];
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\beddestroys\BedDestroyThief.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */