/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.InvalidURIException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.JedisURIHelper;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.PooledObject;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.PooledObjectFactory;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.impl.DefaultPooledObject;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.Logger;
/*     */ import com.axeelheaven.hbedwars.libs.slf4j.LoggerFactory;
/*     */ import java.net.URI;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLParameters;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JedisFactory
/*     */   implements PooledObjectFactory<Jedis>
/*     */ {
/*  25 */   private static final Logger logger = LoggerFactory.getLogger(JedisFactory.class);
/*     */   
/*     */   private final JedisSocketFactory jedisSocketFactory;
/*     */   
/*     */   private final JedisClientConfig clientConfig;
/*     */ 
/*     */   
/*     */   protected JedisFactory(String host, int port, int connectionTimeout, int soTimeout, String password, int database, String clientName) {
/*  33 */     this(host, port, connectionTimeout, soTimeout, password, database, clientName, false, (SSLSocketFactory)null, (SSLParameters)null, (HostnameVerifier)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JedisFactory(String host, int port, int connectionTimeout, int soTimeout, String user, String password, int database, String clientName) {
/*  38 */     this(host, port, connectionTimeout, soTimeout, 0, user, password, database, clientName);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JedisFactory(String host, int port, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String user, String password, int database, String clientName) {
/*  43 */     this(host, port, connectionTimeout, soTimeout, infiniteSoTimeout, user, password, database, clientName, false, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JedisFactory(int connectionTimeout, int soTimeout, int infiniteSoTimeout, String user, String password, int database, String clientName) {
/*  51 */     this(connectionTimeout, soTimeout, infiniteSoTimeout, user, password, database, clientName, false, (SSLSocketFactory)null, (SSLParameters)null, (HostnameVerifier)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JedisFactory(String host, int port, int connectionTimeout, int soTimeout, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  58 */     this(host, port, connectionTimeout, soTimeout, null, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JedisFactory(String host, int port, int connectionTimeout, int soTimeout, String user, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  65 */     this(host, port, connectionTimeout, soTimeout, 0, user, password, database, clientName, ssl, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */   
/*     */   protected JedisFactory(HostAndPort hostAndPort, JedisClientConfig clientConfig) {
/*  69 */     this.clientConfig = DefaultJedisClientConfig.copyConfig(clientConfig);
/*  70 */     this.jedisSocketFactory = new DefaultJedisSocketFactory(hostAndPort, this.clientConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JedisFactory(String host, int port, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String user, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  77 */     this
/*     */ 
/*     */ 
/*     */       
/*  81 */       .clientConfig = DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout).socketTimeoutMillis(soTimeout).blockingSocketTimeoutMillis(infiniteSoTimeout).user(user).password(password).database(database).clientName(clientName).ssl(ssl).sslSocketFactory(sslSocketFactory).sslParameters(sslParameters).hostnameVerifier(hostnameVerifier).build();
/*  82 */     this.jedisSocketFactory = new DefaultJedisSocketFactory(new HostAndPort(host, port), this.clientConfig);
/*     */   }
/*     */   
/*     */   protected JedisFactory(JedisSocketFactory jedisSocketFactory, JedisClientConfig clientConfig) {
/*  86 */     this.clientConfig = DefaultJedisClientConfig.copyConfig(clientConfig);
/*  87 */     this.jedisSocketFactory = jedisSocketFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JedisFactory(int connectionTimeout, int soTimeout, int infiniteSoTimeout, String user, String password, int database, String clientName, boolean ssl, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/*  96 */     this(DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout)
/*  97 */         .socketTimeoutMillis(soTimeout).blockingSocketTimeoutMillis(infiniteSoTimeout).user(user)
/*  98 */         .password(password).database(database).clientName(clientName)
/*  99 */         .ssl(ssl).sslSocketFactory(sslSocketFactory)
/* 100 */         .sslParameters(sslParameters).hostnameVerifier(hostnameVerifier).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JedisFactory(JedisClientConfig clientConfig) {
/* 107 */     this.clientConfig = clientConfig;
/* 108 */     this.jedisSocketFactory = new DefaultJedisSocketFactory(clientConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JedisFactory(URI uri, int connectionTimeout, int soTimeout, String clientName) {
/* 113 */     this(uri, connectionTimeout, soTimeout, clientName, (SSLSocketFactory)null, (SSLParameters)null, (HostnameVerifier)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JedisFactory(URI uri, int connectionTimeout, int soTimeout, String clientName, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 119 */     this(uri, connectionTimeout, soTimeout, 0, clientName, sslSocketFactory, sslParameters, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JedisFactory(URI uri, int connectionTimeout, int soTimeout, int infiniteSoTimeout, String clientName, SSLSocketFactory sslSocketFactory, SSLParameters sslParameters, HostnameVerifier hostnameVerifier) {
/* 125 */     if (!JedisURIHelper.isValid(uri)) {
/* 126 */       throw new InvalidURIException(String.format("Cannot open Redis connection due invalid URI. %s", new Object[] { uri
/* 127 */               .toString() }));
/*     */     }
/* 129 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 134 */       .clientConfig = DefaultJedisClientConfig.builder().connectionTimeoutMillis(connectionTimeout).socketTimeoutMillis(soTimeout).blockingSocketTimeoutMillis(infiniteSoTimeout).user(JedisURIHelper.getUser(uri)).password(JedisURIHelper.getPassword(uri)).database(JedisURIHelper.getDBIndex(uri)).clientName(clientName).ssl(JedisURIHelper.isRedisSSLScheme(uri)).sslSocketFactory(sslSocketFactory).sslParameters(sslParameters).hostnameVerifier(hostnameVerifier).build();
/* 135 */     this.jedisSocketFactory = new DefaultJedisSocketFactory(new HostAndPort(uri.getHost(), uri.getPort()), this.clientConfig);
/*     */   }
/*     */   
/*     */   void setHostAndPort(HostAndPort hostAndPort) {
/* 139 */     if (!(this.jedisSocketFactory instanceof DefaultJedisSocketFactory)) {
/* 140 */       throw new IllegalStateException("setHostAndPort method has limited capability.");
/*     */     }
/* 142 */     ((DefaultJedisSocketFactory)this.jedisSocketFactory).updateHostAndPort(hostAndPort);
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 146 */     this.clientConfig.updatePassword(password);
/*     */   }
/*     */ 
/*     */   
/*     */   public void activateObject(PooledObject<Jedis> pooledJedis) throws Exception {
/* 151 */     Jedis jedis = (Jedis)pooledJedis.getObject();
/* 152 */     if (jedis.getDB() != this.clientConfig.getDatabase()) {
/* 153 */       jedis.select(this.clientConfig.getDatabase());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroyObject(PooledObject<Jedis> pooledJedis) throws Exception {
/* 159 */     Jedis jedis = (Jedis)pooledJedis.getObject();
/* 160 */     if (jedis.isConnected()) {
/*     */       
/*     */       try {
/* 163 */         if (!jedis.isBroken()) {
/* 164 */           jedis.quit();
/*     */         }
/* 166 */       } catch (RuntimeException e) {
/* 167 */         logger.warn("Error while QUIT", e);
/*     */       } 
/*     */       try {
/* 170 */         jedis.close();
/* 171 */       } catch (RuntimeException e) {
/* 172 */         logger.warn("Error while close", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PooledObject<Jedis> makeObject() throws Exception {
/* 179 */     Jedis jedis = null;
/*     */     try {
/* 181 */       jedis = new Jedis(this.jedisSocketFactory, this.clientConfig);
/* 182 */       jedis.connect();
/* 183 */       return (PooledObject<Jedis>)new DefaultPooledObject(jedis);
/* 184 */     } catch (JedisException je) {
/* 185 */       if (jedis != null) {
/*     */         try {
/* 187 */           jedis.quit();
/* 188 */         } catch (RuntimeException e) {
/* 189 */           logger.warn("Error while QUIT", e);
/*     */         } 
/*     */         try {
/* 192 */           jedis.close();
/* 193 */         } catch (RuntimeException e) {
/* 194 */           logger.warn("Error while close", e);
/*     */         } 
/*     */       } 
/* 197 */       throw je;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void passivateObject(PooledObject<Jedis> pooledJedis) throws Exception {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean validateObject(PooledObject<Jedis> pooledJedis) {
/* 208 */     Jedis jedis = (Jedis)pooledJedis.getObject();
/*     */     
/*     */     try {
/* 211 */       return (jedis.getConnection().isConnected() && jedis.ping().equals("PONG"));
/* 212 */     } catch (Exception e) {
/* 213 */       logger.error("Error while validating pooled Jedis object.", e);
/* 214 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\JedisFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */