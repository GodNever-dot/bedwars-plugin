package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import java.util.List;

public interface ConfigCommands {
  List<String> configGet(String paramString);
  
  List<String> configGet(String... paramVarArgs);
  
  List<byte[]> configGet(byte[] paramArrayOfbyte);
  
  List<byte[]> configGet(byte[]... paramVarArgs);
  
  String configSet(String paramString1, String paramString2);
  
  String configSet(String... paramVarArgs);
  
  String configSet(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  String configSet(byte[]... paramVarArgs);
  
  String configResetStat();
  
  String configRewrite();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\ConfigCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */