/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.Rawable;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class ZParams
/*    */   implements IParams
/*    */ {
/*    */   public enum Aggregate
/*    */     implements Rawable
/*    */   {
/* 17 */     SUM, MIN, MAX;
/*    */     
/*    */     private final byte[] raw;
/*    */     
/*    */     Aggregate() {
/* 22 */       this.raw = SafeEncoder.encode(name());
/*    */     }
/*    */ 
/*    */     
/*    */     public byte[] getRaw() {
/* 27 */       return this.raw;
/*    */     }
/*    */   }
/*    */   
/* 31 */   private final List<Object> params = new ArrayList();
/*    */   
/*    */   public ZParams weights(double... weights) {
/* 34 */     this.params.add(Protocol.Keyword.WEIGHTS);
/* 35 */     for (double weight : weights) {
/* 36 */       this.params.add(Double.valueOf(weight));
/*    */     }
/*    */     
/* 39 */     return this;
/*    */   }
/*    */   
/*    */   public ZParams aggregate(Aggregate aggregate) {
/* 43 */     this.params.add(Protocol.Keyword.AGGREGATE);
/* 44 */     this.params.add(aggregate);
/* 45 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 50 */     this.params.forEach(param -> args.add(param));
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\ZParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */