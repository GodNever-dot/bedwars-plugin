/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.args;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ 
/*    */ public enum SortedSetOption
/*    */   implements Rawable {
/*  7 */   MIN, MAX;
/*    */   
/*    */   private final byte[] raw;
/*    */   
/*    */   SortedSetOption() {
/* 12 */     this.raw = SafeEncoder.encode(name());
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] getRaw() {
/* 17 */     return this.raw;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\args\SortedSetOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */