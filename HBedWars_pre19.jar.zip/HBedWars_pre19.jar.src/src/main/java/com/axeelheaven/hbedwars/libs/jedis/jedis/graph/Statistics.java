package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;

public interface Statistics {
  int nodesCreated();
  
  int nodesDeleted();
  
  int indicesCreated();
  
  int indicesDeleted();
  
  int labelsAdded();
  
  int relationshipsDeleted();
  
  int relationshipsCreated();
  
  int propertiesSet();
  
  boolean cachedExecution();
  
  String queryIntervalExecutionTime();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\Statistics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */