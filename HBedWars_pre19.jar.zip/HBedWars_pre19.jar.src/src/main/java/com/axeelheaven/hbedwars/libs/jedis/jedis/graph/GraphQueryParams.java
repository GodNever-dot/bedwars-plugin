/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.IParams;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GraphQueryParams
/*    */   implements IParams
/*    */ {
/*    */   private boolean readonly;
/*    */   private String query;
/*    */   private Map<String, Object> params;
/*    */   private Long timeout;
/*    */   
/*    */   public GraphQueryParams() {}
/*    */   
/*    */   public static GraphQueryParams queryParams() {
/* 28 */     return new GraphQueryParams();
/*    */   }
/*    */   
/*    */   public GraphQueryParams(String query) {
/* 32 */     this.query = query;
/*    */   }
/*    */   
/*    */   public static GraphQueryParams queryParams(String query) {
/* 36 */     return new GraphQueryParams(query);
/*    */   }
/*    */   
/*    */   public GraphQueryParams readonly() {
/* 40 */     return readonly(true);
/*    */   }
/*    */   
/*    */   public GraphQueryParams readonly(boolean readonly) {
/* 44 */     this.readonly = readonly;
/* 45 */     return this;
/*    */   }
/*    */   
/*    */   public GraphQueryParams query(String queryStr) {
/* 49 */     this.query = queryStr;
/* 50 */     return this;
/*    */   }
/*    */   
/*    */   public GraphQueryParams params(Map<String, Object> params) {
/* 54 */     this.params = params;
/* 55 */     return this;
/*    */   }
/*    */   
/*    */   public GraphQueryParams addParam(String key, Object value) {
/* 59 */     if (this.params == null) this.params = new HashMap<>(); 
/* 60 */     this.params.put(key, value);
/* 61 */     return this;
/*    */   }
/*    */   
/*    */   public GraphQueryParams timeout(long timeout) {
/* 65 */     this.timeout = Long.valueOf(timeout);
/* 66 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 71 */     if (this.query == null) throw new JedisException("Query string must be set.");
/*    */     
/* 73 */     if (this.params == null) {
/* 74 */       args.add(this.query);
/*    */     } else {
/* 76 */       args.add(RedisGraphQueryUtil.prepareQuery(this.query, this.params));
/*    */     } 
/*    */     
/* 79 */     args.add(GraphProtocol.GraphKeyword.__COMPACT);
/*    */     
/* 81 */     if (this.timeout != null) {
/* 82 */       args.add(GraphProtocol.GraphKeyword.TIMEOUT).add(this.timeout).blocking();
/*    */     }
/*    */   }
/*    */   
/*    */   public CommandArguments getArguments(String graphName) {
/* 87 */     return (new CommandArguments(!this.readonly ? GraphProtocol.GraphCommand.QUERY : GraphProtocol.GraphCommand.RO_QUERY))
/* 88 */       .key(graphName).addParams(this);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\GraphQueryParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */