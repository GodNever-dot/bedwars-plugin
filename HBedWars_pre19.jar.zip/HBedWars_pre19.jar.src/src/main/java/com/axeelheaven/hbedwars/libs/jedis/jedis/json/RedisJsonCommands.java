/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.json;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.json.JSONArray;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public interface RedisJsonCommands
/*    */ {
/*    */   default String jsonSet(String key, Object object) {
/* 10 */     return jsonSet(key, Path2.ROOT_PATH, object);
/*    */   }
/*    */   
/*    */   default String jsonSetWithEscape(String key, Object object) {
/* 14 */     return jsonSetWithEscape(key, Path2.ROOT_PATH, object);
/*    */   }
/*    */   
/*    */   default String jsonSetLegacy(String key, Object pojo) {
/* 18 */     return jsonSet(key, Path.ROOT_PATH, pojo);
/*    */   }
/*    */   
/*    */   default String jsonSet(String key, Object object, JsonSetParams params) {
/* 22 */     return jsonSet(key, Path2.ROOT_PATH, object, params);
/*    */   }
/*    */   
/*    */   default String jsonSetWithEscape(String key, Object object, JsonSetParams params) {
/* 26 */     return jsonSetWithEscape(key, Path2.ROOT_PATH, object, params);
/*    */   }
/*    */   
/*    */   default String jsonSetLegacy(String key, Object pojo, JsonSetParams params) {
/* 30 */     return jsonSet(key, Path.ROOT_PATH, pojo, params);
/*    */   }
/*    */   
/*    */   String jsonSet(String paramString, Path2 paramPath2, Object paramObject);
/*    */   
/*    */   String jsonSetWithEscape(String paramString, Path2 paramPath2, Object paramObject);
/*    */   
/*    */   String jsonSet(String paramString, Path paramPath, Object paramObject);
/*    */   
/*    */   String jsonSet(String paramString, Path2 paramPath2, Object paramObject, JsonSetParams paramJsonSetParams);
/*    */   
/*    */   String jsonSetWithEscape(String paramString, Path2 paramPath2, Object paramObject, JsonSetParams paramJsonSetParams);
/*    */   
/*    */   String jsonSet(String paramString, Path paramPath, Object paramObject, JsonSetParams paramJsonSetParams);
/*    */   
/*    */   Object jsonGet(String paramString);
/*    */   
/*    */   <T> T jsonGet(String paramString, Class<T> paramClass);
/*    */   
/*    */   Object jsonGet(String paramString, Path2... paramVarArgs);
/*    */   
/*    */   Object jsonGet(String paramString, Path... paramVarArgs);
/*    */   
/*    */   <T> T jsonGet(String paramString, Class<T> paramClass, Path... paramVarArgs);
/*    */   
/*    */   List<JSONArray> jsonMGet(String... keys) {
/* 56 */     return jsonMGet(Path2.ROOT_PATH, keys);
/*    */   }
/*    */   
/*    */   <T> List<T> jsonMGet(Class<T> clazz, String... keys) {
/* 60 */     return jsonMGet(Path.ROOT_PATH, clazz, keys);
/*    */   }
/*    */   
/*    */   List<JSONArray> jsonMGet(Path2 paramPath2, String... paramVarArgs);
/*    */   
/*    */   <T> List<T> jsonMGet(Path paramPath, Class<T> paramClass, String... paramVarArgs);
/*    */   
/*    */   long jsonDel(String paramString);
/*    */   
/*    */   long jsonDel(String paramString, Path2 paramPath2);
/*    */   
/*    */   long jsonDel(String paramString, Path paramPath);
/*    */   
/*    */   long jsonClear(String paramString);
/*    */   
/*    */   long jsonClear(String paramString, Path2 paramPath2);
/*    */   
/*    */   long jsonClear(String paramString, Path paramPath);
/*    */   
/*    */   List<Boolean> jsonToggle(String paramString, Path2 paramPath2);
/*    */   
/*    */   String jsonToggle(String paramString, Path paramPath);
/*    */   
/*    */   Class<?> jsonType(String paramString);
/*    */   
/*    */   List<Class<?>> jsonType(String paramString, Path2 paramPath2);
/*    */   
/*    */   Class<?> jsonType(String paramString, Path paramPath);
/*    */   
/*    */   long jsonStrAppend(String paramString, Object paramObject);
/*    */   
/*    */   List<Long> jsonStrAppend(String paramString, Path2 paramPath2, Object paramObject);
/*    */   
/*    */   long jsonStrAppend(String paramString, Path paramPath, Object paramObject);
/*    */   
/*    */   Long jsonStrLen(String paramString);
/*    */   
/*    */   List<Long> jsonStrLen(String paramString, Path2 paramPath2);
/*    */   
/*    */   Long jsonStrLen(String paramString, Path paramPath);
/*    */   
/*    */   List<Long> jsonArrAppend(String paramString, Path2 paramPath2, Object... paramVarArgs);
/*    */   
/*    */   List<Long> jsonArrAppendWithEscape(String paramString, Path2 paramPath2, Object... paramVarArgs);
/*    */   
/*    */   Long jsonArrAppend(String paramString, Path paramPath, Object... paramVarArgs);
/*    */   
/*    */   List<Long> jsonArrIndex(String paramString, Path2 paramPath2, Object paramObject);
/*    */   
/*    */   List<Long> jsonArrIndexWithEscape(String paramString, Path2 paramPath2, Object paramObject);
/*    */   
/*    */   long jsonArrIndex(String paramString, Path paramPath, Object paramObject);
/*    */   
/*    */   List<Long> jsonArrInsert(String paramString, Path2 paramPath2, int paramInt, Object... paramVarArgs);
/*    */   
/*    */   List<Long> jsonArrInsertWithEscape(String paramString, Path2 paramPath2, int paramInt, Object... paramVarArgs);
/*    */   
/*    */   long jsonArrInsert(String paramString, Path paramPath, int paramInt, Object... paramVarArgs);
/*    */   
/*    */   Object jsonArrPop(String paramString);
/*    */   
/*    */   <T> T jsonArrPop(String paramString, Class<T> paramClass);
/*    */   
/*    */   List<Object> jsonArrPop(String paramString, Path2 paramPath2);
/*    */   
/*    */   Object jsonArrPop(String paramString, Path paramPath);
/*    */   
/*    */   <T> T jsonArrPop(String paramString, Class<T> paramClass, Path paramPath);
/*    */   
/*    */   List<Object> jsonArrPop(String paramString, Path2 paramPath2, int paramInt);
/*    */   
/*    */   Object jsonArrPop(String paramString, Path paramPath, int paramInt);
/*    */   
/*    */   <T> T jsonArrPop(String paramString, Class<T> paramClass, Path paramPath, int paramInt);
/*    */   
/*    */   Long jsonArrLen(String paramString);
/*    */   
/*    */   List<Long> jsonArrLen(String paramString, Path2 paramPath2);
/*    */   
/*    */   Long jsonArrLen(String paramString, Path paramPath);
/*    */   
/*    */   List<Long> jsonArrTrim(String paramString, Path2 paramPath2, int paramInt1, int paramInt2);
/*    */   
/*    */   Long jsonArrTrim(String paramString, Path paramPath, int paramInt1, int paramInt2);
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\json\RedisJsonCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */