/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Path
/*    */ {
/*  8 */   public static final Path ROOT_PATH = new Path(".");
/*    */   
/*    */   private final String strPath;
/*    */   
/*    */   public Path(String strPath) {
/* 13 */     this.strPath = strPath;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 18 */     return this.strPath;
/*    */   }
/*    */   
/*    */   public static Path of(String strPath) {
/* 22 */     return new Path(strPath);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 27 */     if (obj == null) {
/* 28 */       return false;
/*    */     }
/* 30 */     if (!(obj instanceof Path)) {
/* 31 */       return false;
/*    */     }
/* 33 */     if (obj == this) {
/* 34 */       return true;
/*    */     }
/* 36 */     return toString().equals(((Path)obj).toString());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 41 */     return this.strPath.hashCode();
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\json\Path.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */