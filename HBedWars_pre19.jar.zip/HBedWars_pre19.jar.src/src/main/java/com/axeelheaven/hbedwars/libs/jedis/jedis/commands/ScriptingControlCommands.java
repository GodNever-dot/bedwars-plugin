package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import java.util.List;

public interface ScriptingControlCommands {
  Boolean scriptExists(String paramString);
  
  List<Boolean> scriptExists(String... paramVarArgs);
  
  Boolean scriptExists(byte[] paramArrayOfbyte);
  
  List<Boolean> scriptExists(byte[]... paramVarArgs);
  
  String scriptLoad(String paramString);
  
  byte[] scriptLoad(byte[] paramArrayOfbyte);
  
  String scriptFlush();
  
  String scriptFlush(FlushMode paramFlushMode);
  
  String scriptKill();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\ScriptingControlCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */