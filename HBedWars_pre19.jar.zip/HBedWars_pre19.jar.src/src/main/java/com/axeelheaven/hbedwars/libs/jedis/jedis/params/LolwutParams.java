/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ 
/*    */ public class LolwutParams
/*    */   implements IParams
/*    */ {
/*    */   private int version;
/*    */   private String[] args;
/*    */   
/*    */   public LolwutParams version(int version) {
/* 12 */     this.version = version;
/* 13 */     return this;
/*    */   }
/*    */   
/*    */   public LolwutParams args(String... args) {
/* 17 */     this.args = args;
/* 18 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 23 */     if (this.version != 0) {
/* 24 */       args.add(Integer.valueOf(this.version));
/*    */     }
/*    */     
/* 27 */     if (this.args != null)
/* 28 */       args.add(this.args); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\LolwutParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */