package com.axeelheaven.hbedwars.libs.jedis.jedis.bloom;

import java.util.List;
import java.util.Map;

public interface TopKFilterCommands {
  String topkReserve(String paramString, long paramLong);
  
  String topkReserve(String paramString, long paramLong1, long paramLong2, long paramLong3, double paramDouble);
  
  List<String> topkAdd(String paramString, String... paramVarArgs);
  
  List<String> topkIncrBy(String paramString, Map<String, Long> paramMap);
  
  List<Boolean> topkQuery(String paramString, String... paramVarArgs);
  
  List<Long> topkCount(String paramString, String... paramVarArgs);
  
  List<String> topkList(String paramString);
  
  Map<String, Object> topkInfo(String paramString);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\bloom\TopKFilterCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */