/*    */ package com.axeelheaven.hbedwars.api.events.levels;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsLevelUpgradeEvent extends Event {
/*    */   private final Player player;
/*    */   private final int level;
/* 10 */   private static final HandlerList handlerList = new HandlerList(); public Player getPlayer() {
/* 11 */     return this.player; } public int getLevel() {
/* 12 */     return this.level;
/*    */   }
/*    */   public BedWarsLevelUpgradeEvent(Player player, int level) {
/* 15 */     this.player = player;
/* 16 */     this.level = level;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 21 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 25 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\levels\BedWarsLevelUpgradeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */