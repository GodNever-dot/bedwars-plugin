/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ 
/*    */ 
/*    */ public class GetExParams
/*    */   extends Params
/*    */   implements IParams
/*    */ {
/*    */   private static final String PX = "px";
/*    */   private static final String EX = "ex";
/*    */   private static final String EXAT = "exat";
/*    */   private static final String PXAT = "pxat";
/*    */   private static final String PERSIST = "persist";
/*    */   
/*    */   public static GetExParams getExParams() {
/* 19 */     return new GetExParams();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GetExParams ex(long secondsToExpire) {
/* 27 */     addParam("ex", Long.valueOf(secondsToExpire));
/* 28 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GetExParams px(long millisecondsToExpire) {
/* 36 */     addParam("px", Long.valueOf(millisecondsToExpire));
/* 37 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GetExParams exAt(long seconds) {
/* 46 */     addParam("exat", Long.valueOf(seconds));
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GetExParams pxAt(long milliseconds) {
/* 56 */     addParam("pxat", Long.valueOf(milliseconds));
/* 57 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GetExParams persist() {
/* 65 */     addParam("persist");
/* 66 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 71 */     if (contains("ex")) {
/* 72 */       args.add(SafeEncoder.encode("ex"));
/* 73 */       args.add(Protocol.toByteArray(((Long)getParam("ex")).longValue()));
/* 74 */     } else if (contains("px")) {
/* 75 */       args.add(SafeEncoder.encode("px"));
/* 76 */       args.add(Protocol.toByteArray(((Long)getParam("px")).longValue()));
/* 77 */     } else if (contains("exat")) {
/* 78 */       args.add(SafeEncoder.encode("exat"));
/* 79 */       args.add(Protocol.toByteArray(((Long)getParam("exat")).longValue()));
/* 80 */     } else if (contains("pxat")) {
/* 81 */       args.add(SafeEncoder.encode("pxat"));
/* 82 */       args.add(Protocol.toByteArray(((Long)getParam("pxat")).longValue()));
/* 83 */     } else if (contains("persist")) {
/* 84 */       args.add(SafeEncoder.encode("persist"));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\GetExParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */