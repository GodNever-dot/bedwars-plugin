/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisConnectionException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JedisPubSub
/*     */ {
/*     */   private static final String JEDIS_SUBSCRIPTION_MESSAGE = "JedisPubSub is not subscribed to a Jedis instance.";
/*  16 */   private int subscribedChannels = 0;
/*     */   
/*     */   private volatile Connection client;
/*     */ 
/*     */   
/*     */   public void onMessage(String channel, String message) {}
/*     */ 
/*     */   
/*     */   public void onPMessage(String pattern, String channel, String message) {}
/*     */ 
/*     */   
/*     */   public void onSubscribe(String channel, int subscribedChannels) {}
/*     */ 
/*     */   
/*     */   public void onUnsubscribe(String channel, int subscribedChannels) {}
/*     */ 
/*     */   
/*     */   public void onPUnsubscribe(String pattern, int subscribedChannels) {}
/*     */ 
/*     */   
/*     */   public void onPSubscribe(String pattern, int subscribedChannels) {}
/*     */ 
/*     */   
/*     */   public void onPong(String pattern) {}
/*     */   
/*     */   public void unsubscribe() {
/*  42 */     if (this.client == null) {
/*  43 */       throw new JedisConnectionException("JedisPubSub is not subscribed to a Jedis instance.");
/*     */     }
/*  45 */     this.client.sendCommand(Protocol.Command.UNSUBSCRIBE);
/*  46 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void unsubscribe(String... channels) {
/*  50 */     if (this.client == null) {
/*  51 */       throw new JedisConnectionException("JedisPubSub is not subscribed to a Jedis instance.");
/*     */     }
/*  53 */     this.client.sendCommand(Protocol.Command.UNSUBSCRIBE, channels);
/*  54 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void subscribe(String... channels) {
/*  58 */     if (this.client == null) {
/*  59 */       throw new JedisConnectionException("JedisPubSub is not subscribed to a Jedis instance.");
/*     */     }
/*  61 */     this.client.sendCommand(Protocol.Command.SUBSCRIBE, channels);
/*  62 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void psubscribe(String... patterns) {
/*  66 */     if (this.client == null) {
/*  67 */       throw new JedisConnectionException("JedisPubSub is not subscribed to a Jedis instance.");
/*     */     }
/*  69 */     this.client.sendCommand(Protocol.Command.PSUBSCRIBE, patterns);
/*  70 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void punsubscribe() {
/*  74 */     if (this.client == null) {
/*  75 */       throw new JedisConnectionException("JedisPubSub is not subscribed to a Jedis instance.");
/*     */     }
/*  77 */     this.client.sendCommand(Protocol.Command.PUNSUBSCRIBE);
/*  78 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void punsubscribe(String... patterns) {
/*  82 */     if (this.client == null) {
/*  83 */       throw new JedisConnectionException("JedisPubSub is not subscribed to a Jedis instance.");
/*     */     }
/*  85 */     this.client.sendCommand(Protocol.Command.PUNSUBSCRIBE, patterns);
/*  86 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void ping() {
/*  90 */     if (this.client == null) {
/*  91 */       throw new JedisConnectionException("JedisPubSub is not subscribed to a Jedis instance.");
/*     */     }
/*  93 */     this.client.sendCommand(Protocol.Command.PING);
/*  94 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public void ping(String argument) {
/*  98 */     if (this.client == null) {
/*  99 */       throw new JedisConnectionException("JedisPubSub is not subscribed to a Jedis instance.");
/*     */     }
/* 101 */     this.client.sendCommand(Protocol.Command.PING, new String[] { argument });
/* 102 */     this.client.flush();
/*     */   }
/*     */   
/*     */   public boolean isSubscribed() {
/* 106 */     return (this.subscribedChannels > 0);
/*     */   }
/*     */   
/*     */   public void proceedWithPatterns(Connection client, String... patterns) {
/* 110 */     this.client = client;
/* 111 */     this.client.setTimeoutInfinite();
/*     */     try {
/* 113 */       psubscribe(patterns);
/* 114 */       process();
/*     */     } finally {
/* 116 */       this.client.rollbackTimeout();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void proceed(Connection client, String... channels) {
/* 121 */     this.client = client;
/* 122 */     this.client.setTimeoutInfinite();
/*     */     try {
/* 124 */       subscribe(channels);
/* 125 */       process();
/*     */     } finally {
/* 127 */       this.client.rollbackTimeout();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void process() {
/*     */     do {
/* 135 */       List<Object> reply = this.client.getUnflushedObjectMultiBulkReply();
/* 136 */       Object firstObj = reply.get(0);
/* 137 */       if (!(firstObj instanceof byte[])) {
/* 138 */         throw new JedisException("Unknown message type: " + firstObj);
/*     */       }
/* 140 */       byte[] resp = (byte[])firstObj;
/* 141 */       if (Arrays.equals(Protocol.ResponseKeyword.SUBSCRIBE.getRaw(), resp)) {
/* 142 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 143 */         byte[] bchannel = (byte[])reply.get(1);
/* 144 */         String strchannel = (bchannel == null) ? null : SafeEncoder.encode(bchannel);
/* 145 */         onSubscribe(strchannel, this.subscribedChannels);
/* 146 */       } else if (Arrays.equals(Protocol.ResponseKeyword.UNSUBSCRIBE.getRaw(), resp)) {
/* 147 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 148 */         byte[] bchannel = (byte[])reply.get(1);
/* 149 */         String strchannel = (bchannel == null) ? null : SafeEncoder.encode(bchannel);
/* 150 */         onUnsubscribe(strchannel, this.subscribedChannels);
/* 151 */       } else if (Arrays.equals(Protocol.ResponseKeyword.MESSAGE.getRaw(), resp)) {
/* 152 */         byte[] bchannel = (byte[])reply.get(1);
/* 153 */         byte[] bmesg = (byte[])reply.get(2);
/* 154 */         String strchannel = (bchannel == null) ? null : SafeEncoder.encode(bchannel);
/* 155 */         String strmesg = (bmesg == null) ? null : SafeEncoder.encode(bmesg);
/* 156 */         onMessage(strchannel, strmesg);
/* 157 */       } else if (Arrays.equals(Protocol.ResponseKeyword.PMESSAGE.getRaw(), resp)) {
/* 158 */         byte[] bpattern = (byte[])reply.get(1);
/* 159 */         byte[] bchannel = (byte[])reply.get(2);
/* 160 */         byte[] bmesg = (byte[])reply.get(3);
/* 161 */         String strpattern = (bpattern == null) ? null : SafeEncoder.encode(bpattern);
/* 162 */         String strchannel = (bchannel == null) ? null : SafeEncoder.encode(bchannel);
/* 163 */         String strmesg = (bmesg == null) ? null : SafeEncoder.encode(bmesg);
/* 164 */         onPMessage(strpattern, strchannel, strmesg);
/* 165 */       } else if (Arrays.equals(Protocol.ResponseKeyword.PSUBSCRIBE.getRaw(), resp)) {
/* 166 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 167 */         byte[] bpattern = (byte[])reply.get(1);
/* 168 */         String strpattern = (bpattern == null) ? null : SafeEncoder.encode(bpattern);
/* 169 */         onPSubscribe(strpattern, this.subscribedChannels);
/* 170 */       } else if (Arrays.equals(Protocol.ResponseKeyword.PUNSUBSCRIBE.getRaw(), resp)) {
/* 171 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 172 */         byte[] bpattern = (byte[])reply.get(1);
/* 173 */         String strpattern = (bpattern == null) ? null : SafeEncoder.encode(bpattern);
/* 174 */         onPUnsubscribe(strpattern, this.subscribedChannels);
/* 175 */       } else if (Arrays.equals(Protocol.ResponseKeyword.PONG.getRaw(), resp)) {
/* 176 */         byte[] bpattern = (byte[])reply.get(1);
/* 177 */         String strpattern = (bpattern == null) ? null : SafeEncoder.encode(bpattern);
/* 178 */         onPong(strpattern);
/*     */       } else {
/* 180 */         throw new JedisException("Unknown message type: " + firstObj);
/*     */       } 
/* 182 */     } while (isSubscribed());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSubscribedChannels() {
/* 189 */     return this.subscribedChannels;
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\JedisPubSub.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */