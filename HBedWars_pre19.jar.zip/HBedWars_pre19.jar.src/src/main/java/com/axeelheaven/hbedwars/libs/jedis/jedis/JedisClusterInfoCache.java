/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisConnectionException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*     */ import com.axeelheaven.hbedwars.libs.pool2.impl.GenericObjectPoolConfig;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JedisClusterInfoCache
/*     */ {
/*  23 */   private final Map<String, ConnectionPool> nodes = new HashMap<>();
/*  24 */   private final Map<Integer, ConnectionPool> slots = new HashMap<>();
/*  25 */   private final Map<Integer, HostAndPort> slotNodes = new HashMap<>();
/*     */   
/*  27 */   private final ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
/*  28 */   private final Lock r = this.rwl.readLock();
/*  29 */   private final Lock w = this.rwl.writeLock();
/*  30 */   private final Lock rediscoverLock = new ReentrantLock();
/*     */   
/*     */   private final GenericObjectPoolConfig<Connection> poolConfig;
/*     */   
/*     */   private final JedisClientConfig clientConfig;
/*     */   private final Set<HostAndPort> startNodes;
/*     */   private static final int MASTER_NODE_INDEX = 2;
/*     */   
/*     */   @Deprecated
/*     */   public JedisClusterInfoCache(JedisClientConfig clientConfig) {
/*  40 */     this(clientConfig, new GenericObjectPoolConfig());
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JedisClusterInfoCache(JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig) {
/*  46 */     this(clientConfig, poolConfig, null);
/*     */   }
/*     */   
/*     */   public JedisClusterInfoCache(JedisClientConfig clientConfig, Set<HostAndPort> startNodes) {
/*  50 */     this(clientConfig, new GenericObjectPoolConfig(), startNodes);
/*     */   }
/*     */ 
/*     */   
/*     */   public JedisClusterInfoCache(JedisClientConfig clientConfig, GenericObjectPoolConfig<Connection> poolConfig, Set<HostAndPort> startNodes) {
/*  55 */     this.poolConfig = poolConfig;
/*  56 */     this.clientConfig = clientConfig;
/*  57 */     this.startNodes = startNodes;
/*     */   }
/*     */   
/*     */   public void discoverClusterNodesAndSlots(Connection jedis) {
/*  61 */     List<Object> slotsInfo = executeClusterSlots(jedis);
/*  62 */     this.w.lock();
/*     */     try {
/*  64 */       reset();
/*  65 */       for (Object slotInfoObj : slotsInfo) {
/*  66 */         List<Object> slotInfo = (List<Object>)slotInfoObj;
/*     */         
/*  68 */         if (slotInfo.size() <= 2) {
/*     */           continue;
/*     */         }
/*     */         
/*  72 */         List<Integer> slotNums = getAssignedSlotArray(slotInfo);
/*     */ 
/*     */         
/*  75 */         int size = slotInfo.size();
/*  76 */         for (int i = 2; i < size; i++) {
/*  77 */           List<Object> hostInfos = (List<Object>)slotInfo.get(i);
/*  78 */           if (!hostInfos.isEmpty()) {
/*     */ 
/*     */ 
/*     */             
/*  82 */             HostAndPort targetNode = generateHostAndPort(hostInfos);
/*  83 */             setupNodeIfNotExist(targetNode);
/*  84 */             if (i == 2)
/*  85 */               assignSlotsToNode(slotNums, targetNode); 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } finally {
/*  90 */       this.w.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renewClusterSlots(Connection jedis) {
/*  96 */     if (this.rediscoverLock.tryLock()) {
/*     */       
/*     */       try {
/*  99 */         if (jedis != null) {
/*     */           try {
/* 101 */             discoverClusterSlots(jedis);
/*     */             return;
/* 103 */           } catch (JedisException jedisException) {}
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 110 */         if (this.startNodes != null) {
/* 111 */           for (HostAndPort hostAndPort : this.startNodes) {
/* 112 */             try (Connection j = new Connection(hostAndPort, this.clientConfig)) {
/* 113 */               discoverClusterSlots(j);
/*     */               return;
/* 115 */             } catch (JedisConnectionException jedisConnectionException) {}
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 122 */         for (ConnectionPool jp : getShuffledNodesPool()) {
/* 123 */           try (Connection j = jp.getResource())
/*     */           
/* 125 */           { if (this.startNodes != null && this.startNodes.contains(j.getHostAndPort()))
/*     */             
/*     */             { 
/*     */ 
/*     */               
/* 130 */               if (j != null) { if (null != null) { try { j.close(); } catch (Throwable throwable) { null.addSuppressed(throwable); }  continue; }  j.close(); }  continue; }  discoverClusterSlots(j); return; } catch (JedisConnectionException jedisConnectionException) {}
/*     */         }
/*     */       
/*     */       }
/*     */       finally {
/*     */         
/* 136 */         this.rediscoverLock.unlock();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void discoverClusterSlots(Connection jedis) {
/* 142 */     List<Object> slotsInfo = executeClusterSlots(jedis);
/* 143 */     this.w.lock();
/*     */     try {
/* 145 */       this.slots.clear();
/* 146 */       this.slotNodes.clear();
/* 147 */       Set<String> hostAndPortKeys = new HashSet<>();
/*     */       
/* 149 */       for (Object slotInfoObj : slotsInfo) {
/* 150 */         List<Object> slotInfo = (List<Object>)slotInfoObj;
/*     */         
/* 152 */         if (slotInfo.size() <= 2) {
/*     */           continue;
/*     */         }
/*     */         
/* 156 */         List<Integer> slotNums = getAssignedSlotArray(slotInfo);
/*     */         
/* 158 */         int size = slotInfo.size();
/* 159 */         for (int i = 2; i < size; i++) {
/* 160 */           List<Object> hostInfos = (List<Object>)slotInfo.get(i);
/* 161 */           if (!hostInfos.isEmpty()) {
/*     */ 
/*     */ 
/*     */             
/* 165 */             HostAndPort targetNode = generateHostAndPort(hostInfos);
/* 166 */             hostAndPortKeys.add(getNodeKey(targetNode));
/* 167 */             setupNodeIfNotExist(targetNode);
/* 168 */             if (i == 2) {
/* 169 */               assignSlotsToNode(slotNums, targetNode);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 175 */       Iterator<Map.Entry<String, ConnectionPool>> entryIt = this.nodes.entrySet().iterator();
/* 176 */       while (entryIt.hasNext()) {
/* 177 */         Map.Entry<String, ConnectionPool> entry = entryIt.next();
/* 178 */         if (!hostAndPortKeys.contains(entry.getKey())) {
/* 179 */           ConnectionPool pool = entry.getValue();
/*     */           try {
/* 181 */             if (pool != null) {
/* 182 */               pool.destroy();
/*     */             }
/* 184 */           } catch (Exception exception) {}
/*     */ 
/*     */           
/* 187 */           entryIt.remove();
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 191 */       this.w.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private HostAndPort generateHostAndPort(List<Object> hostInfos) {
/* 196 */     String host = SafeEncoder.encode((byte[])hostInfos.get(0));
/* 197 */     int port = ((Long)hostInfos.get(1)).intValue();
/* 198 */     return new HostAndPort(host, port);
/*     */   }
/*     */   
/*     */   public ConnectionPool setupNodeIfNotExist(HostAndPort node) {
/* 202 */     this.w.lock();
/*     */     try {
/* 204 */       String nodeKey = getNodeKey(node);
/* 205 */       ConnectionPool existingPool = this.nodes.get(nodeKey);
/* 206 */       if (existingPool != null) return existingPool;
/*     */       
/* 208 */       ConnectionPool nodePool = new ConnectionPool(node, this.clientConfig, this.poolConfig);
/* 209 */       this.nodes.put(nodeKey, nodePool);
/* 210 */       return nodePool;
/*     */     } finally {
/* 212 */       this.w.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void assignSlotToNode(int slot, HostAndPort targetNode) {
/* 217 */     this.w.lock();
/*     */     try {
/* 219 */       ConnectionPool targetPool = setupNodeIfNotExist(targetNode);
/* 220 */       this.slots.put(Integer.valueOf(slot), targetPool);
/* 221 */       this.slotNodes.put(Integer.valueOf(slot), targetNode);
/*     */     } finally {
/* 223 */       this.w.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void assignSlotsToNode(List<Integer> targetSlots, HostAndPort targetNode) {
/* 228 */     this.w.lock();
/*     */     try {
/* 230 */       ConnectionPool targetPool = setupNodeIfNotExist(targetNode);
/* 231 */       for (Integer slot : targetSlots) {
/* 232 */         this.slots.put(slot, targetPool);
/* 233 */         this.slotNodes.put(slot, targetNode);
/*     */       } 
/*     */     } finally {
/* 236 */       this.w.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public ConnectionPool getNode(String nodeKey) {
/* 241 */     this.r.lock();
/*     */     try {
/* 243 */       return this.nodes.get(nodeKey);
/*     */     } finally {
/* 245 */       this.r.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public ConnectionPool getNode(HostAndPort node) {
/* 250 */     return getNode(getNodeKey(node));
/*     */   }
/*     */   
/*     */   public ConnectionPool getSlotPool(int slot) {
/* 254 */     this.r.lock();
/*     */     try {
/* 256 */       return this.slots.get(Integer.valueOf(slot));
/*     */     } finally {
/* 258 */       this.r.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public HostAndPort getSlotNode(int slot) {
/* 263 */     this.r.lock();
/*     */     try {
/* 265 */       return this.slotNodes.get(Integer.valueOf(slot));
/*     */     } finally {
/* 267 */       this.r.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Map<String, ConnectionPool> getNodes() {
/* 272 */     this.r.lock();
/*     */     try {
/* 274 */       return new HashMap<>(this.nodes);
/*     */     } finally {
/* 276 */       this.r.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<ConnectionPool> getShuffledNodesPool() {
/* 281 */     this.r.lock();
/*     */     try {
/* 283 */       List<ConnectionPool> pools = new ArrayList<>(this.nodes.values());
/* 284 */       Collections.shuffle(pools);
/* 285 */       return pools;
/*     */     } finally {
/* 287 */       this.r.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 295 */     this.w.lock();
/*     */     try {
/* 297 */       for (ConnectionPool pool : this.nodes.values()) {
/*     */         try {
/* 299 */           if (pool != null) {
/* 300 */             pool.destroy();
/*     */           }
/* 302 */         } catch (RuntimeException runtimeException) {}
/*     */       } 
/*     */ 
/*     */       
/* 306 */       this.nodes.clear();
/* 307 */       this.slots.clear();
/* 308 */       this.slotNodes.clear();
/*     */     } finally {
/* 310 */       this.w.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getNodeKey(HostAndPort hnp) {
/* 316 */     return hnp.toString();
/*     */   }
/*     */   
/*     */   private List<Object> executeClusterSlots(Connection jedis) {
/* 320 */     jedis.sendCommand(Protocol.Command.CLUSTER, new String[] { "SLOTS" });
/* 321 */     return jedis.getObjectMultiBulkReply();
/*     */   }
/*     */   
/*     */   private List<Integer> getAssignedSlotArray(List<Object> slotInfo) {
/* 325 */     List<Integer> slotNums = new ArrayList<>();
/* 326 */     int slot = ((Long)slotInfo.get(0)).intValue(); for (; slot <= ((Long)slotInfo.get(1))
/* 327 */       .intValue(); slot++) {
/* 328 */       slotNums.add(Integer.valueOf(slot));
/*     */     }
/* 330 */     return slotNums;
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\JedisClusterInfoCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */