package com.axeelheaven.hbedwars.database.cache;

import com.axeelheaven.hbedwars.libs.json.simple.JSONObject;
import com.axeelheaven.hbedwars.libs.json.simple.parser.JSONParser;
import java.util.UUID;

public class HDataCache {
  public HDataCache(Exception llllllllllllllllllIIlIlIlllIIllI, float llllllllllllllllllIIlIlIlllIIlIl, int llllllllllllllllllIIlIlIlllIllll) {
    this.name = (String)llllllllllllllllllIIlIlIlllIIllI;
    this.uuid = UUID.fromString(llllllllllllllllllIIlIlIlllIIlIl);
    this.jsonObject = llllllllllllllllllIIlIlIlllIllll;
  }
  
  public UUID getUuid() {
    return this.uuid;
  }
  
  private JSONObject getJson(String llllllllllllllllllIIlIlIlllllIIl) {
    try {
      return (JSONObject)(new JSONParser()).parse(llllllllllllllllllIIlIlIlllllIIl);
    } catch (Exception llllllllllllllllllIIlIlIllllllII) {
      return new JSONObject();
    } 
  }
  
  public JSONObject getJsonObject() {
    // Byte code:
    //   0: aload_0
    //   1: getfield jsonObject : Lcom/axeelheaven/hbedwars/libs/json/simple/JSONObject;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	llllllllllllllllllIIlIlIllllIlII	J
    //   0	5	0	llllllllllllllllllIIlIlIllllIllI	J
    //   0	5	0	llllllllllllllllllIIlIlIllllIlIl	Lcom/axeelheaven/hbedwars/database/cache/HDataCache;
  }
  
  public HDataCache(String llllllllllllllllllIIlIllIIIIllII, char llllllllllllllllllIIlIllIIIIIIlI, String llllllllllllllllllIIlIllIIIIlIlI) {
    this.name = llllllllllllllllllIIlIllIIIIllII;
    this.uuid = UUID.fromString(llllllllllllllllllIIlIllIIIIIIlI);
    this.jsonObject = getJson(llllllllllllllllllIIlIllIIIIlIlI);
  }
  
  public String getName() {
    // Byte code:
    //   0: aload_0
    //   1: getfield name : Ljava/lang/String;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	llllllllllllllllllIIlIllIIIlIIIl	B
    //   0	5	0	llllllllllllllllllIIlIllIIIlIIlI	F
    //   0	5	0	llllllllllllllllllIIlIllIIIlIIll	Lcom/axeelheaven/hbedwars/database/cache/HDataCache;
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\database\cache\HDataCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */