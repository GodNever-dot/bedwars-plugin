package com.axeelheaven.hbedwars.database.profile;

import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class HData {
    private final UUID uuid;
    private final String name;
    private int coins;
    private int level;
    private int experience;
    private String selectedDeathCry;
    private String selectedKillEffect;
    private String selectedWinDance;
    private List<String> purchasedDeathCries;
    private List<String> purchasedKillEffects;
    private List<String> purchasedWinDances;

    public HData(Player player) {
        this.uuid = player.getUniqueId();
        this.name = player.getName();
        this.coins = 0;
        this.level = 1;
        this.experience = 0;
        this.selectedDeathCry = "default";
        this.selectedKillEffect = "default";
        this.selectedWinDance = "default";
        this.purchasedDeathCries = new ArrayList<>();
        this.purchasedKillEffects = new ArrayList<>();
        this.purchasedWinDances = new ArrayList<>();
        this.purchasedDeathCries.add("default");
        this.purchasedKillEffects.add("default");
        this.purchasedWinDances.add("default");
    }

    public UUID getUUID() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public int getCoins() {
        return coins;
    }

    public void setCoins(int coins) {
        this.coins = coins;
    }

    public void addCoins(int amount) {
        this.coins += amount;
    }

    public void removeCoins(int amount) {
        this.coins = Math.max(0, this.coins - amount);
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public void addExperience(int amount) {
        this.experience += amount;
    }

    public String getSelectedDeathCry() {
        return selectedDeathCry;
    }

    public void setSelectedDeathCry(String cry) {
        this.selectedDeathCry = cry;
    }

    public String getSelectedKillEffect() {
        return selectedKillEffect;
    }

    public void setSelectedKillEffect(String effect) {
        this.selectedKillEffect = effect;
    }

    public String getSelectedWinDance() {
        return selectedWinDance;
    }

    public void setSelectedWinDance(String dance) {
        this.selectedWinDance = dance;
    }

    public List<String> getPurchasedDeathCries() {
        return new ArrayList<>(purchasedDeathCries);
    }

    public void addPurchasedDeathCry(String cry) {
        if (!purchasedDeathCries.contains(cry)) {
            purchasedDeathCries.add(cry);
        }
    }

    public List<String> getPurchasedKillEffects() {
        return new ArrayList<>(purchasedKillEffects);
    }

    public void addPurchasedKillEffect(String effect) {
        if (!purchasedKillEffects.contains(effect)) {
            purchasedKillEffects.add(effect);
        }
    }

    public List<String> getPurchasedWinDances() {
        return new ArrayList<>(purchasedWinDances);
    }

    public void addPurchasedWinDance(String dance) {
        if (!purchasedWinDances.contains(dance)) {
            purchasedWinDances.add(dance);
        }
    }
}