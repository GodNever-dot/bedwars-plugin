/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.HostAndPort;
/*    */ 
/*    */ public class JedisRedirectionException
/*    */   extends JedisDataException
/*    */ {
/*    */   private static final long serialVersionUID = 3878126572474819403L;
/*    */   private final HostAndPort targetNode;
/*    */   private final int slot;
/*    */   
/*    */   public JedisRedirectionException(String message, HostAndPort targetNode, int slot) {
/* 13 */     super(message);
/* 14 */     this.targetNode = targetNode;
/* 15 */     this.slot = slot;
/*    */   }
/*    */   
/*    */   public JedisRedirectionException(Throwable cause, HostAndPort targetNode, int slot) {
/* 19 */     super(cause);
/* 20 */     this.targetNode = targetNode;
/* 21 */     this.slot = slot;
/*    */   }
/*    */   
/*    */   public JedisRedirectionException(String message, Throwable cause, HostAndPort targetNode, int slot) {
/* 25 */     super(message, cause);
/* 26 */     this.targetNode = targetNode;
/* 27 */     this.slot = slot;
/*    */   }
/*    */   
/*    */   public final HostAndPort getTargetNode() {
/* 31 */     return this.targetNode;
/*    */   }
/*    */   
/*    */   public final int getSlot() {
/* 35 */     return this.slot;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\JedisRedirectionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */