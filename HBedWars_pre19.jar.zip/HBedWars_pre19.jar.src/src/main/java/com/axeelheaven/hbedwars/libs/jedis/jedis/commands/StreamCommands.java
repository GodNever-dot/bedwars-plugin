/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.StreamEntryID;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XAddParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XAutoClaimParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XClaimParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XPendingParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XReadGroupParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XReadParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XTrimParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamConsumersInfo;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamEntry;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamFullInfo;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamGroupInfo;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamInfo;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamPendingEntry;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamPendingSummary;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface StreamCommands
/*    */ {
/*    */   StreamEntryID xadd(String paramString, StreamEntryID paramStreamEntryID, Map<String, String> paramMap);
/*    */   
/*    */   default StreamEntryID xadd(String key, Map<String, String> hash, XAddParams params) {
/* 32 */     return xadd(key, params, hash);
/*    */   }
/*    */   
/*    */   StreamEntryID xadd(String paramString, XAddParams paramXAddParams, Map<String, String> paramMap);
/*    */   
/*    */   long xlen(String paramString);
/*    */   
/*    */   List<StreamEntry> xrange(String paramString, StreamEntryID paramStreamEntryID1, StreamEntryID paramStreamEntryID2);
/*    */   
/*    */   List<StreamEntry> xrange(String paramString, StreamEntryID paramStreamEntryID1, StreamEntryID paramStreamEntryID2, int paramInt);
/*    */   
/*    */   List<StreamEntry> xrevrange(String paramString, StreamEntryID paramStreamEntryID1, StreamEntryID paramStreamEntryID2);
/*    */   
/*    */   List<StreamEntry> xrevrange(String paramString, StreamEntryID paramStreamEntryID1, StreamEntryID paramStreamEntryID2, int paramInt);
/*    */   
/*    */   List<StreamEntry> xrange(String paramString1, String paramString2, String paramString3);
/*    */   
/*    */   List<StreamEntry> xrange(String paramString1, String paramString2, String paramString3, int paramInt);
/*    */   
/*    */   List<StreamEntry> xrevrange(String paramString1, String paramString2, String paramString3);
/*    */   
/*    */   List<StreamEntry> xrevrange(String paramString1, String paramString2, String paramString3, int paramInt);
/*    */   
/*    */   long xack(String paramString1, String paramString2, StreamEntryID... paramVarArgs);
/*    */   
/*    */   String xgroupCreate(String paramString1, String paramString2, StreamEntryID paramStreamEntryID, boolean paramBoolean);
/*    */   
/*    */   String xgroupSetID(String paramString1, String paramString2, StreamEntryID paramStreamEntryID);
/*    */   
/*    */   long xgroupDestroy(String paramString1, String paramString2);
/*    */   
/*    */   boolean xgroupCreateConsumer(String paramString1, String paramString2, String paramString3);
/*    */   
/*    */   long xgroupDelConsumer(String paramString1, String paramString2, String paramString3);
/*    */   
/*    */   StreamPendingSummary xpending(String paramString1, String paramString2);
/*    */   
/*    */   @Deprecated
/*    */   List<StreamPendingEntry> xpending(String paramString1, String paramString2, StreamEntryID paramStreamEntryID1, StreamEntryID paramStreamEntryID2, int paramInt, String paramString3);
/*    */   
/*    */   List<StreamPendingEntry> xpending(String paramString1, String paramString2, XPendingParams paramXPendingParams);
/*    */   
/*    */   long xdel(String paramString, StreamEntryID... paramVarArgs);
/*    */   
/*    */   long xtrim(String paramString, long paramLong, boolean paramBoolean);
/*    */   
/*    */   long xtrim(String paramString, XTrimParams paramXTrimParams);
/*    */   
/*    */   List<StreamEntry> xclaim(String paramString1, String paramString2, String paramString3, long paramLong, XClaimParams paramXClaimParams, StreamEntryID... paramVarArgs);
/*    */   
/*    */   List<StreamEntryID> xclaimJustId(String paramString1, String paramString2, String paramString3, long paramLong, XClaimParams paramXClaimParams, StreamEntryID... paramVarArgs);
/*    */   
/*    */   Map.Entry<StreamEntryID, List<StreamEntry>> xautoclaim(String paramString1, String paramString2, String paramString3, long paramLong, StreamEntryID paramStreamEntryID, XAutoClaimParams paramXAutoClaimParams);
/*    */   
/*    */   Map.Entry<StreamEntryID, List<StreamEntryID>> xautoclaimJustId(String paramString1, String paramString2, String paramString3, long paramLong, StreamEntryID paramStreamEntryID, XAutoClaimParams paramXAutoClaimParams);
/*    */   
/*    */   StreamInfo xinfoStream(String paramString);
/*    */   
/*    */   StreamFullInfo xinfoStreamFull(String paramString);
/*    */   
/*    */   StreamFullInfo xinfoStreamFull(String paramString, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   List<StreamGroupInfo> xinfoGroup(String paramString);
/*    */   
/*    */   List<StreamGroupInfo> xinfoGroups(String paramString);
/*    */   
/*    */   List<StreamConsumersInfo> xinfoConsumers(String paramString1, String paramString2);
/*    */   
/*    */   List<Map.Entry<String, List<StreamEntry>>> xread(XReadParams paramXReadParams, Map<String, StreamEntryID> paramMap);
/*    */   
/*    */   List<Map.Entry<String, List<StreamEntry>>> xreadGroup(String paramString1, String paramString2, XReadGroupParams paramXReadGroupParams, Map<String, StreamEntryID> paramMap);
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\StreamCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */