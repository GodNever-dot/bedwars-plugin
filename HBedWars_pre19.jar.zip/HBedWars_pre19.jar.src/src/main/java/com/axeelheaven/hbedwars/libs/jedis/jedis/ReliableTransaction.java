/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ReliableTransaction
/*    */   extends TransactionBase {
/*    */   public ReliableTransaction(Connection connection) {
/*  9 */     super(connection);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReliableTransaction(Connection connection, boolean doMulti) {
/* 16 */     super(connection, doMulti);
/*    */   }
/*    */ 
/*    */   
/*    */   protected final void processMultiResponse() {
/* 21 */     String status = this.connection.getStatusCodeReply();
/* 22 */     if (!"OK".equals(status)) {
/* 23 */       throw new JedisException("MULTI command failed. Received response: " + status);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected final void processAppendStatus() {
/* 29 */     String status = this.connection.getStatusCodeReply();
/* 30 */     if (!"QUEUED".equals(status)) {
/* 31 */       throw new JedisException(status);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected final void processPipelinedResponses() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public final List<Object> exec() {
/* 42 */     return super.exec();
/*    */   }
/*    */ 
/*    */   
/*    */   public final String discard() {
/* 47 */     String status = super.discard();
/* 48 */     if (!"OK".equals(status)) {
/* 49 */       throw new JedisException("DISCARD command failed. Received response: " + status);
/*    */     }
/* 51 */     return status;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\ReliableTransaction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */