/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.StreamEntryID;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.Rawable;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.args.RawableFactory;
/*     */ 
/*     */ 
/*     */ public class XPendingParams
/*     */   implements IParams
/*     */ {
/*     */   private boolean legacy = true;
/*     */   private Long idle;
/*     */   private Rawable start;
/*     */   private Rawable end;
/*  17 */   private int count = Integer.MIN_VALUE;
/*     */ 
/*     */ 
/*     */   
/*     */   private Rawable consumer;
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public XPendingParams() {}
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static XPendingParams xPendingParams() {
/*  32 */     return new XPendingParams();
/*     */   }
/*     */   
/*     */   public XPendingParams(StreamEntryID start, StreamEntryID end, int count) {
/*  36 */     this(start.toString(), end.toString(), count);
/*     */   }
/*     */   
/*     */   public XPendingParams(String start, String end, int count) {
/*  40 */     this(RawableFactory.from(start), RawableFactory.from(end), count);
/*     */   }
/*     */   
/*     */   public XPendingParams(byte[] start, byte[] end, int count) {
/*  44 */     this(RawableFactory.from(start), RawableFactory.from(end), count);
/*     */   }
/*     */   
/*     */   private XPendingParams(Rawable start, Rawable end, int count) {
/*  48 */     this.legacy = false;
/*  49 */     this.start = start;
/*  50 */     this.end = end;
/*  51 */     this.count = count;
/*     */   }
/*     */   
/*     */   public static XPendingParams xPendingParams(StreamEntryID start, StreamEntryID end, int count) {
/*  55 */     return new XPendingParams(start, end, count);
/*     */   }
/*     */   
/*     */   public static XPendingParams xPendingParams(String start, String end, int count) {
/*  59 */     return new XPendingParams(start, end, count);
/*     */   }
/*     */   
/*     */   public static XPendingParams xPendingParams(byte[] start, byte[] end, int count) {
/*  63 */     return new XPendingParams(start, end, count);
/*     */   }
/*     */   
/*     */   public XPendingParams idle(long idle) {
/*  67 */     this.idle = Long.valueOf(idle);
/*  68 */     return this;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public XPendingParams start(StreamEntryID start) {
/*  73 */     this.start = RawableFactory.from(start.toString());
/*  74 */     return this;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public XPendingParams end(StreamEntryID end) {
/*  79 */     this.end = RawableFactory.from(end.toString());
/*  80 */     return this;
/*     */   }
/*     */   
/*     */   public XPendingParams count(int count) {
/*  84 */     this.count = count;
/*  85 */     return this;
/*     */   }
/*     */   
/*     */   public XPendingParams consumer(String consumer) {
/*  89 */     this.consumer = RawableFactory.from(consumer);
/*  90 */     return this;
/*     */   }
/*     */   
/*     */   public XPendingParams consumer(byte[] consumer) {
/*  94 */     this.consumer = RawableFactory.from(consumer);
/*  95 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParams(CommandArguments args) {
/* 101 */     if (this.idle != null) {
/* 102 */       args.add(Protocol.Keyword.IDLE).add(Protocol.toByteArray(this.idle.longValue()));
/*     */     }
/*     */     
/* 105 */     if (this.legacy) {
/* 106 */       if (this.start == null) {
/* 107 */         args.add("-");
/*     */       } else {
/* 109 */         args.add(this.start);
/*     */       } 
/*     */       
/* 112 */       if (this.end == null) {
/* 113 */         args.add("+");
/*     */       } else {
/* 115 */         args.add(this.end);
/*     */       } 
/*     */       
/* 118 */       if (this.count != Integer.MIN_VALUE) {
/* 119 */         args.add(Protocol.toByteArray(this.count));
/*     */       }
/*     */     } else {
/* 122 */       args.add(this.start).add(this.end).add(Protocol.toByteArray(this.count));
/*     */     } 
/*     */     
/* 125 */     if (this.consumer != null)
/* 126 */       args.add(this.consumer); 
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\XPendingParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */