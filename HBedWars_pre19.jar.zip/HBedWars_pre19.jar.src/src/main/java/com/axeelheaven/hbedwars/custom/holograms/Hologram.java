package com.axeelheaven.hbedwars.custom.holograms;

import java.util.HashMap;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public interface Hologram {
  HashMap<Player, List<Integer>> getIDS();
  
  void delete();
  
  Hologram delete(Player paramPlayer);
  
  void setLocation(Location paramLocation);
  
  Hologram display(Player paramPlayer);
  
  List<Player> getRender();
  
  List<String> getLines(Player paramPlayer);
  
  Location getLocation();
  
  Hologram update(Player paramPlayer);
  
  HashMap<String, Object> getData();
  
  Hologram setLines(Player paramPlayer, List<String> paramList);
  
  void spawn(Location location);
  
  void despawn();
  
  void show(Player player);
  
  void hide(Player player);
  
  boolean isSpawned();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\holograms\Hologram.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */