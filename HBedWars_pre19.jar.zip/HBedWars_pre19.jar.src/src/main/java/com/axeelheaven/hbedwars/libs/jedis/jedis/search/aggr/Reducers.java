/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.search.aggr;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Reducers
/*     */ {
/*     */   public static Reducer count() {
/*  11 */     return new Reducer()
/*     */       {
/*     */         public String getName() {
/*  14 */           return "COUNT";
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private static Reducer singleFieldReducer(final String name, String field) {
/*  20 */     return new Reducer(field)
/*     */       {
/*     */         public String getName() {
/*  23 */           return name;
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public static Reducer count_distinct(String field) {
/*  29 */     return singleFieldReducer("COUNT_DISTINCT", field);
/*     */   }
/*     */   
/*     */   public static Reducer count_distinctish(String field) {
/*  33 */     return singleFieldReducer("COUNT_DISTINCTISH", field);
/*     */   }
/*     */   
/*     */   public static Reducer sum(String field) {
/*  37 */     return singleFieldReducer("SUM", field);
/*     */   }
/*     */   
/*     */   public static Reducer min(String field) {
/*  41 */     return singleFieldReducer("MIN", field);
/*     */   }
/*     */   
/*     */   public static Reducer max(String field) {
/*  45 */     return singleFieldReducer("MAX", field);
/*     */   }
/*     */   
/*     */   public static Reducer avg(String field) {
/*  49 */     return singleFieldReducer("AVG", field);
/*     */   }
/*     */   
/*     */   public static Reducer stddev(String field) {
/*  53 */     return singleFieldReducer("STDDEV", field);
/*     */   }
/*     */   
/*     */   public static Reducer quantile(String field, final double percentile) {
/*  57 */     return new Reducer(field)
/*     */       {
/*     */         public String getName() {
/*  60 */           return "QUANTILE";
/*     */         }
/*     */ 
/*     */         
/*     */         protected List<String> getOwnArgs() {
/*  65 */           List<String> args = super.getOwnArgs();
/*  66 */           args.add(Double.toString(percentile));
/*  67 */           return args;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Reducer first_value(String field, final SortedField sortBy) {
/*  80 */     return new Reducer(field)
/*     */       {
/*     */         public String getName() {
/*  83 */           return "FIRST_VALUE";
/*     */         }
/*     */ 
/*     */         
/*     */         protected List<String> getOwnArgs() {
/*  88 */           List<String> args = super.getOwnArgs();
/*  89 */           if (sortBy != null) {
/*  90 */             args.add("BY");
/*  91 */             args.add(sortBy.getField());
/*  92 */             args.add(sortBy.getOrder());
/*     */           } 
/*  94 */           return args;
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public static Reducer first_value(String field) {
/* 100 */     return first_value(field, null);
/*     */   }
/*     */   
/*     */   public static Reducer to_list(String field) {
/* 104 */     return singleFieldReducer("TOLIST", field);
/*     */   }
/*     */   
/*     */   public static Reducer random_sample(String field, final int size) {
/* 108 */     return new Reducer(field)
/*     */       {
/*     */         public String getName() {
/* 111 */           return "RANDOM_SAMPLE";
/*     */         }
/*     */ 
/*     */         
/*     */         protected List<String> getOwnArgs() {
/* 116 */           List<String> args = super.getOwnArgs();
/* 117 */           args.add(Integer.toString(size));
/* 118 */           return args;
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\search\aggr\Reducers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */