/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph.entities;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ public abstract class GraphEntity
/*    */ {
/*    */   protected long id;
/* 12 */   protected final Map<String, Property<?>> propertyMap = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getId() {
/* 18 */     return this.id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setId(long id) {
/* 25 */     this.id = id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addProperty(String name, Object value) {
/* 35 */     addProperty(new Property(name, value));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<String> getEntityPropertyNames() {
/* 42 */     return this.propertyMap.keySet();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addProperty(Property<?> property) {
/* 51 */     this.propertyMap.put(property.getName(), property);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getNumberOfProperties() {
/* 58 */     return this.propertyMap.size();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Property getProperty(String propertyName) {
/* 66 */     return this.propertyMap.get(propertyName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeProperty(String name) {
/* 73 */     this.propertyMap.remove(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 78 */     if (this == o) {
/* 79 */       return true;
/*    */     }
/* 81 */     if (!(o instanceof GraphEntity)) {
/* 82 */       return false;
/*    */     }
/* 84 */     GraphEntity that = (GraphEntity)o;
/* 85 */     return (this.id == that.id && 
/* 86 */       Objects.equals(this.propertyMap, that.propertyMap));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 91 */     return Objects.hash(new Object[] { Long.valueOf(this.id), this.propertyMap });
/*    */   }
/*    */   
/*    */   public abstract String toString();
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\entities\GraphEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */