/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XClaimParams
/*    */   implements IParams
/*    */ {
/*    */   private Long idleTime;
/*    */   private Long idleUnixTime;
/*    */   private Integer retryCount;
/*    */   private boolean force;
/*    */   
/*    */   public static XClaimParams xClaimParams() {
/* 21 */     return new XClaimParams();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public XClaimParams idle(long idleTime) {
/* 30 */     this.idleTime = Long.valueOf(idleTime);
/* 31 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public XClaimParams time(long idleUnixTime) {
/* 40 */     this.idleUnixTime = Long.valueOf(idleUnixTime);
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public XClaimParams retryCount(int count) {
/* 50 */     this.retryCount = Integer.valueOf(count);
/* 51 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public XClaimParams force() {
/* 60 */     this.force = true;
/* 61 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 66 */     if (this.idleTime != null) {
/* 67 */       args.add(Protocol.Keyword.IDLE).add(this.idleTime);
/*    */     }
/* 69 */     if (this.idleUnixTime != null) {
/* 70 */       args.add(Protocol.Keyword.TIME).add(this.idleUnixTime);
/*    */     }
/* 72 */     if (this.retryCount != null) {
/* 73 */       args.add(Protocol.Keyword.RETRYCOUNT).add(this.retryCount);
/*    */     }
/* 75 */     if (this.force)
/* 76 */       args.add(Protocol.Keyword.FORCE); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\XClaimParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */