package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.FlushMode;
import java.util.List;

public interface SampleKeyedCommands {
  long waitReplicas(String paramString, int paramInt, long paramLong);
  
  Object eval(String paramString1, String paramString2);
  
  Object evalsha(String paramString1, String paramString2);
  
  Boolean scriptExists(String paramString1, String paramString2);
  
  List<Boolean> scriptExists(String paramString, String... paramVarArgs);
  
  String scriptLoad(String paramString1, String paramString2);
  
  String scriptFlush(String paramString);
  
  String scriptFlush(String paramString, FlushMode paramFlushMode);
  
  String scriptKill(String paramString);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\SampleKeyedCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */