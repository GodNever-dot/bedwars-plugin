package com.axeelheaven.hbedwars.api.arena;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import java.util.List;

public interface Arena {
    String getName();
    Location getSpawnLocation();
    List<Player> getPlayers();
    boolean isInGame();
    void addPlayer(Player player);
    void removePlayer(Player player);
    ArenaTask getArenaTask();
}