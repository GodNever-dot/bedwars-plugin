/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.search.aggr;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Group
/*    */ {
/* 12 */   private final List<Reducer> reducers = new ArrayList<>();
/* 13 */   private final List<String> fields = new ArrayList<>();
/* 14 */   private Limit limit = new Limit(0, 0);
/*    */   
/*    */   public Group(String... fields) {
/* 17 */     this.fields.addAll(Arrays.asList(fields));
/*    */   }
/*    */   
/*    */   public Group reduce(Reducer r) {
/* 21 */     this.reducers.add(r);
/* 22 */     return this;
/*    */   }
/*    */   
/*    */   public Group limit(Limit limit) {
/* 26 */     this.limit = limit;
/* 27 */     return this;
/*    */   }
/*    */   
/*    */   public void addArgs(List<String> args) {
/* 31 */     args.add(Integer.toString(this.fields.size()));
/* 32 */     args.addAll(this.fields);
/* 33 */     for (Reducer r : this.reducers) {
/* 34 */       args.add("REDUCE");
/* 35 */       args.add(r.getName());
/* 36 */       r.addArgs(args);
/* 37 */       String alias = r.getAlias();
/* 38 */       if (alias != null && !alias.isEmpty()) {
/* 39 */         args.add("AS");
/* 40 */         args.add(alias);
/*    */       } 
/*    */     } 
/* 43 */     args.addAll(this.limit.getArgs());
/*    */   }
/*    */   
/*    */   public List<String> getArgs() {
/* 47 */     List<String> args = new ArrayList<>();
/* 48 */     addArgs(args);
/* 49 */     return args;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\search\aggr\Group.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */