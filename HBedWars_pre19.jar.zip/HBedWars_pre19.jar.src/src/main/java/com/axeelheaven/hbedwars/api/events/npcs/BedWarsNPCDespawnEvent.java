/*    */ package com.axeelheaven.hbedwars.api.events.npcs;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.custom.npc.NPC;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsNPCDespawnEvent extends Event {
/*    */   private final Player player;
/*    */   private final NPC npc;
/* 11 */   private static final HandlerList handlerList = new HandlerList(); public Player getPlayer() {
/* 12 */     return this.player; } public NPC getNpc() {
/* 13 */     return this.npc;
/*    */   }
/*    */   public BedWarsNPCDespawnEvent(Player player, NPC npc) {
/* 16 */     this.player = player;
/* 17 */     this.npc = npc;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 22 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 26 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\npcs\BedWarsNPCDespawnEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */