/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.StreamEntryID;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XAddParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XAutoClaimParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XClaimParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XPendingParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XReadGroupParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XReadParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.XTrimParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamConsumersInfo;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamEntry;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamFullInfo;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamGroupInfo;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamInfo;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamPendingEntry;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.StreamPendingSummary;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface StreamPipelineCommands
/*    */ {
/*    */   Response<StreamEntryID> xadd(String paramString, StreamEntryID paramStreamEntryID, Map<String, String> paramMap);
/*    */   
/*    */   default Response<StreamEntryID> xadd(String key, Map<String, String> hash, XAddParams params) {
/* 33 */     return xadd(key, params, hash);
/*    */   }
/*    */   
/*    */   Response<StreamEntryID> xadd(String paramString, XAddParams paramXAddParams, Map<String, String> paramMap);
/*    */   
/*    */   Response<Long> xlen(String paramString);
/*    */   
/*    */   Response<List<StreamEntry>> xrange(String paramString, StreamEntryID paramStreamEntryID1, StreamEntryID paramStreamEntryID2);
/*    */   
/*    */   Response<List<StreamEntry>> xrange(String paramString, StreamEntryID paramStreamEntryID1, StreamEntryID paramStreamEntryID2, int paramInt);
/*    */   
/*    */   Response<List<StreamEntry>> xrevrange(String paramString, StreamEntryID paramStreamEntryID1, StreamEntryID paramStreamEntryID2);
/*    */   
/*    */   Response<List<StreamEntry>> xrevrange(String paramString, StreamEntryID paramStreamEntryID1, StreamEntryID paramStreamEntryID2, int paramInt);
/*    */   
/*    */   Response<List<StreamEntry>> xrange(String paramString1, String paramString2, String paramString3);
/*    */   
/*    */   Response<List<StreamEntry>> xrange(String paramString1, String paramString2, String paramString3, int paramInt);
/*    */   
/*    */   Response<List<StreamEntry>> xrevrange(String paramString1, String paramString2, String paramString3);
/*    */   
/*    */   Response<List<StreamEntry>> xrevrange(String paramString1, String paramString2, String paramString3, int paramInt);
/*    */   
/*    */   Response<Long> xack(String paramString1, String paramString2, StreamEntryID... paramVarArgs);
/*    */   
/*    */   Response<String> xgroupCreate(String paramString1, String paramString2, StreamEntryID paramStreamEntryID, boolean paramBoolean);
/*    */   
/*    */   Response<String> xgroupSetID(String paramString1, String paramString2, StreamEntryID paramStreamEntryID);
/*    */   
/*    */   Response<Long> xgroupDestroy(String paramString1, String paramString2);
/*    */   
/*    */   Response<Boolean> xgroupCreateConsumer(String paramString1, String paramString2, String paramString3);
/*    */   
/*    */   Response<Long> xgroupDelConsumer(String paramString1, String paramString2, String paramString3);
/*    */   
/*    */   Response<StreamPendingSummary> xpending(String paramString1, String paramString2);
/*    */   
/*    */   @Deprecated
/*    */   Response<List<StreamPendingEntry>> xpending(String paramString1, String paramString2, StreamEntryID paramStreamEntryID1, StreamEntryID paramStreamEntryID2, int paramInt, String paramString3);
/*    */   
/*    */   Response<List<StreamPendingEntry>> xpending(String paramString1, String paramString2, XPendingParams paramXPendingParams);
/*    */   
/*    */   Response<Long> xdel(String paramString, StreamEntryID... paramVarArgs);
/*    */   
/*    */   Response<Long> xtrim(String paramString, long paramLong, boolean paramBoolean);
/*    */   
/*    */   Response<Long> xtrim(String paramString, XTrimParams paramXTrimParams);
/*    */   
/*    */   Response<List<StreamEntry>> xclaim(String paramString1, String paramString2, String paramString3, long paramLong, XClaimParams paramXClaimParams, StreamEntryID... paramVarArgs);
/*    */   
/*    */   Response<List<StreamEntryID>> xclaimJustId(String paramString1, String paramString2, String paramString3, long paramLong, XClaimParams paramXClaimParams, StreamEntryID... paramVarArgs);
/*    */   
/*    */   Response<Map.Entry<StreamEntryID, List<StreamEntry>>> xautoclaim(String paramString1, String paramString2, String paramString3, long paramLong, StreamEntryID paramStreamEntryID, XAutoClaimParams paramXAutoClaimParams);
/*    */   
/*    */   Response<Map.Entry<StreamEntryID, List<StreamEntryID>>> xautoclaimJustId(String paramString1, String paramString2, String paramString3, long paramLong, StreamEntryID paramStreamEntryID, XAutoClaimParams paramXAutoClaimParams);
/*    */   
/*    */   Response<StreamInfo> xinfoStream(String paramString);
/*    */   
/*    */   Response<StreamFullInfo> xinfoStreamFull(String paramString);
/*    */   
/*    */   Response<StreamFullInfo> xinfoStreamFull(String paramString, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   Response<List<StreamGroupInfo>> xinfoGroup(String paramString);
/*    */   
/*    */   Response<List<StreamGroupInfo>> xinfoGroups(String paramString);
/*    */   
/*    */   Response<List<StreamConsumersInfo>> xinfoConsumers(String paramString1, String paramString2);
/*    */   
/*    */   Response<List<Map.Entry<String, List<StreamEntry>>>> xread(XReadParams paramXReadParams, Map<String, StreamEntryID> paramMap);
/*    */   
/*    */   Response<List<Map.Entry<String, List<StreamEntry>>>> xreadGroup(String paramString1, String paramString2, XReadGroupParams paramXReadGroupParams, Map<String, StreamEntryID> paramMap);
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\StreamPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */