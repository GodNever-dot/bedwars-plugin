/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ public class JedisException
/*    */   extends RuntimeException {
/*    */   private static final long serialVersionUID = -2946266495682282677L;
/*    */   
/*    */   public JedisException(String message) {
/*  8 */     super(message);
/*    */   }
/*    */   
/*    */   public JedisException(Throwable e) {
/* 12 */     super(e);
/*    */   }
/*    */   
/*    */   public JedisException(String message, Throwable cause) {
/* 16 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\JedisException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */