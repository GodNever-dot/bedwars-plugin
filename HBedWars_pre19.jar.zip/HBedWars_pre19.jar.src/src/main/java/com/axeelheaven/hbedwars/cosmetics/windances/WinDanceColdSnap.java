package com.axeelheaven.hbedwars.cosmetics.windances;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.api.arena.Arena;
import com.axeelheaven.hbedwars.libs.xseries.XMaterial;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class WinDanceColdSnap extends WinDance {
    private final BedWars plugin;
    private final HashMap<String, BukkitRunnable> tasks;
    
    public WinDanceColdSnap(BedWars plugin, String name, int cost, boolean purchasable) {
        super(name, cost, purchasable);
        this.plugin = plugin;
        this.tasks = new HashMap<>();
    }
    
    @Override
    public void play(Player player, Location location) {
        start(player, null);
    }
    
    @Override
    public void execute(Player player, Arena arena) {
        start(player, arena);
    }
    
    public void start(Player player, Arena arena) {
        if (tasks.containsKey(player.getName())) {
            return;
        }
        
        BukkitRunnable task = new BukkitRunnable() {
            private int radius = 1;
            private final int maxRadius = 5;
            
            @Override
            public void run() {
                if (radius > maxRadius) {
                    cancel();
                    tasks.remove(player.getName());
                    return;
                }
                
                List<Block> blocks = getBlocks(player.getLocation(), radius);
                for (Block block : blocks) {
                    Location loc = block.getLocation();
                    player.getWorld().playEffect(loc, Effect.SNOW_SHOVEL, 0);
                    if (XMaterial.SNOW.parseMaterial() != null) {
                        block.setType(XMaterial.SNOW.parseMaterial());
                    }
                }
                
                radius++;
            }
        };
        
        task.runTaskTimer(plugin, 0L, 10L);
        tasks.put(player.getName(), task);
    }
    
    public void stop(Player player) {
        BukkitRunnable task = tasks.remove(player.getName());
        if (task != null) {
            task.cancel();
        }
    }
    
    private List<Block> getBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                Block block = location.getBlock().getRelative(x, 0, z);
                if (block.getType().isSolid()) {
                    Block above = block.getRelative(0, 1, 0);
                    if (above.getType() == Material.AIR) {
                        blocks.add(above);
                    }
                }
            }
        }
        return blocks;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\windances\WinDanceColdSnap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */