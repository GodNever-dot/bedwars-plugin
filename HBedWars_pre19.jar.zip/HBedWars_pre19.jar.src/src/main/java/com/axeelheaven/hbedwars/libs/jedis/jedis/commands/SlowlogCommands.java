package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.Slowlog;
import java.util.List;

public interface SlowlogCommands {
  String slowlogReset();
  
  long slowlogLen();
  
  List<Slowlog> slowlogGet();
  
  List<Object> slowlogGetBinary();
  
  List<Slowlog> slowlogGet(long paramLong);
  
  List<Object> slowlogGetBinary(long paramLong);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\SlowlogCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */