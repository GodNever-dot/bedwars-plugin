package com.axeelheaven.hbedwars.libs.jedis.jedis.args;

public interface Rawable {
  byte[] getRaw();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\args\Rawable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */