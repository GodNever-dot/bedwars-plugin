package com.axeelheaven.hbedwars.custom.traps;

import com.axeelheaven.hbedwars.api.arena.Arena;
import com.axeelheaven.hbedwars.api.arena.ArenaTeam;
import org.bukkit.entity.Player;

public interface EnemyEnterBaseTrap {
    void execute(Arena arena, ArenaTeam team, Player player);
    String getName();
    String getDescription();
    int getCost();
} 