/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ public class AbortedTransactionException
/*    */   extends JedisDataException {
/*    */   public AbortedTransactionException(String message) {
/*  6 */     super(message);
/*    */   }
/*    */   
/*    */   public AbortedTransactionException(Throwable cause) {
/* 10 */     super(cause);
/*    */   }
/*    */   
/*    */   public AbortedTransactionException(String message, Throwable cause) {
/* 14 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\AbortedTransactionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */