package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Module;
import java.util.List;

public interface ModuleCommands {
  String moduleLoad(String paramString);
  
  String moduleLoad(String paramString, String... paramVarArgs);
  
  String moduleUnload(String paramString);
  
  List<Module> moduleList();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\ModuleCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */