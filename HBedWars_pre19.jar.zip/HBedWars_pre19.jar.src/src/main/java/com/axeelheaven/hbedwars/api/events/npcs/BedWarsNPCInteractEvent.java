/*    */ package com.axeelheaven.hbedwars.api.events.npcs;
/*    */ import com.axeelheaven.hbedwars.custom.npc.NPC;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsNPCInteractEvent extends Event {
/*    */   private final Player player;
/*    */   private final NPC npc;
/*    */   private final Click clickType;
/* 11 */   private static final HandlerList handlerList = new HandlerList(); public Player getPlayer() {
/* 12 */     return this.player; }
/* 13 */   public NPC getNpc() { return this.npc; } public Click getClickType() {
/* 14 */     return this.clickType;
/*    */   }
/*    */   public BedWarsNPCInteractEvent(Player player, NPC npc, Click clickType) {
/* 17 */     this.player = player;
/* 18 */     this.npc = npc;
/* 19 */     this.clickType = clickType;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 24 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 28 */     return handlerList;
/*    */   }
/*    */   
/*    */   public enum Click {
/* 32 */     LEFT, RIGHT;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\npcs\BedWarsNPCInteractEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */