/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ public class JedisClusterException
/*    */   extends JedisDataException {
/*    */   private static final long serialVersionUID = 3878126572474819403L;
/*    */   
/*    */   public JedisClusterException(Throwable cause) {
/*  8 */     super(cause);
/*    */   }
/*    */   
/*    */   public JedisClusterException(String message, Throwable cause) {
/* 12 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public JedisClusterException(String message) {
/* 16 */     super(message);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\JedisClusterException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */