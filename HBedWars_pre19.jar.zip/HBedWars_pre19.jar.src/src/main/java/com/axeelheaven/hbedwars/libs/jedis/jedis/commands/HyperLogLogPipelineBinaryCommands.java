package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;

public interface HyperLogLogPipelineBinaryCommands {
  Response<Long> pfadd(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  Response<String> pfmerge(byte[] paramArrayOfbyte, byte[]... paramVarArgs);
  
  Response<Long> pfcount(byte[] paramArrayOfbyte);
  
  Response<Long> pfcount(byte[]... paramVarArgs);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\HyperLogLogPipelineBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */