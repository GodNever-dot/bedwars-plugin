package com.axeelheaven.hbedwars.libs.jedis.jedis.bloom;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import java.util.List;
import java.util.Map;

public interface TopKFilterPipelineCommands {
  Response<String> topkReserve(String paramString, long paramLong);
  
  Response<String> topkReserve(String paramString, long paramLong1, long paramLong2, long paramLong3, double paramDouble);
  
  Response<List<String>> topkAdd(String paramString, String... paramVarArgs);
  
  Response<List<String>> topkIncrBy(String paramString, Map<String, Long> paramMap);
  
  Response<List<Boolean>> topkQuery(String paramString, String... paramVarArgs);
  
  Response<List<Long>> topkCount(String paramString, String... paramVarArgs);
  
  Response<List<String>> topkList(String paramString);
  
  Response<Map<String, Object>> topkInfo(String paramString);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\bloom\TopKFilterPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */