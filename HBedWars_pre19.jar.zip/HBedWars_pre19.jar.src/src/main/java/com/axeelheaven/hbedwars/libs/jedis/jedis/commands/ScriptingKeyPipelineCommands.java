package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import java.util.List;

public interface ScriptingKeyPipelineCommands {
  Response<Object> eval(String paramString);
  
  Response<Object> eval(String paramString, int paramInt, String... paramVarArgs);
  
  Response<Object> eval(String paramString, List<String> paramList1, List<String> paramList2);
  
  Response<Object> evalReadonly(String paramString, List<String> paramList1, List<String> paramList2);
  
  Response<Object> evalsha(String paramString);
  
  Response<Object> evalsha(String paramString, int paramInt, String... paramVarArgs);
  
  Response<Object> evalsha(String paramString, List<String> paramList1, List<String> paramList2);
  
  Response<Object> evalshaReadonly(String paramString, List<String> paramList1, List<String> paramList2);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\ScriptingKeyPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */