package com.axeelheaven.hbedwars.bungeemode.server;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.api.arena.Arena;
import com.axeelheaven.hbedwars.bungeemode.redis.RedisMessenger;
import com.axeelheaven.hbedwars.libs.json.simple.JSONObject;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.entity.Player;
import java.util.Map;

public class ServerManager {
  static {
    llIIIllllIIl();
    llIIIllllIII();
    lIlllllIIl();
    lIlllllIII();
  }
  
  private static boolean lIlllllIlI(double lllllllllllllllllIIIllIIIlIIlllI) {
    if (llIIIllllIll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (-"  ".length() >= 0)
        return (143 + 23 - 41 + 24 ^ 157 + 149 - 225 + 85) & (99 + 70 - 161 + 150 ^ 27 + 84 - -8 + 54 ^ -" ".length()); 
    } else {
    
    } 
    return lllIIIIIlI[0];
  }
  
  private static boolean llIIIllllllI(int lllllllllllllllllIIIllIIIIIIlIIl, long lllllllllllllllllIIIllIIIIIIlIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public HashMap<UUID, String> getQueue() {
    // Byte code:
    //   0: aload_0
    //   1: getfield queue : Ljava/util/HashMap;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllllIIIllIIIlllIIlI	Ljava/lang/Exception;
    //   0	5	0	lllllllllllllllllIIIllIIIlllIIII	I
    //   0	5	0	lllllllllllllllllIIIllIIIlllIIIl	Lcom/axeelheaven/hbedwars/bungeemode/server/ServerManager;
  }
  
  private static String llIIIlllIlIl(char lllllllllllllllllIIIllIIIIlIIIII, String lllllllllllllllllIIIllIIIIlIIIIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc 'Blowfish'
    //   21: invokespecial <init> : ([BLjava/lang/String;)V
    //   24: astore_2
    //   25: ldc 'Blowfish'
    //   27: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   30: astore_3
    //   31: aload_3
    //   32: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIlI : [I
    //   35: iconst_3
    //   36: iaload
    //   37: aload_2
    //   38: invokevirtual init : (ILjava/security/Key;)V
    //   41: new java/lang/String
    //   44: dup
    //   45: aload_3
    //   46: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   49: aload_0
    //   50: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   53: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   56: invokevirtual decode : ([B)[B
    //   59: invokevirtual doFinal : ([B)[B
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   68: areturn
    //   69: astore_2
    //   70: aload_2
    //   71: invokevirtual printStackTrace : ()V
    //   74: aconst_null
    //   75: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   70	4	2	lllllllllllllllllIIIllIIIIlIIIll	Ljava/lang/Exception;
    //   0	76	1	lllllllllllllllllIIIllIIIIIlllll	I
    //   0	76	3	lllllllllllllllllIIIllIIIIIlllIl	F
    //   0	76	2	lllllllllllllllllIIIllIIIIIllllI	Ljava/lang/Exception;
    //   25	44	2	lllllllllllllllllIIIllIIIIlIIlIl	Ljavax/crypto/spec/SecretKeySpec;
    //   0	76	1	lllllllllllllllllIIIllIIIIlIIIIl	Ljava/lang/String;
    //   31	38	3	lllllllllllllllllIIIllIIIIlIIlII	Ljavax/crypto/Cipher;
    //   0	76	0	lllllllllllllllllIIIllIIIIlIIIlI	Ljava/lang/String;
    //   0	76	0	lllllllllllllllllIIIllIIIIlIIIII	C
    // Exception table:
    //   from	to	target	type
    //   0	68	69	java/lang/Exception
  }
  
  private static boolean llIIIlllllIl(long lllllllllllllllllIIIllIIIIIIIIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < null);
  }
  
  public RedisMessenger getRedisMessenger() {
    return ((ServerManager)super).redisMessenger;
  }
  
  public void start() {
    // Byte code:
    //   0: aload_0
    //   1: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4: invokevirtual getServer : ()Lorg/bukkit/Server;
    //   7: invokeinterface getScheduler : ()Lorg/bukkit/scheduler/BukkitScheduler;
    //   12: aload_0
    //   13: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   16: aload_0
    //   17: <illegal opcode> run : (Lcom/axeelheaven/hbedwars/bungeemode/server/ServerManager;)Ljava/lang/Runnable;
    //   22: ldc2_w 20
    //   25: lconst_1
    //   26: invokeinterface runTaskTimerAsynchronously : (Lorg/bukkit/plugin/Plugin;Ljava/lang/Runnable;JJ)Lorg/bukkit/scheduler/BukkitTask;
    //   31: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIIl : [Ljava/lang/String;
    //   34: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIlI : [I
    //   37: bipush #16
    //   39: iaload
    //   40: aaload
    //   41: invokevirtual length : ()I
    //   44: pop2
    //   45: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	46	0	lllllllllllllllllIIIllIIIllIlIlI	Lcom/axeelheaven/hbedwars/bungeemode/server/ServerManager;
    //   0	46	0	lllllllllllllllllIIIllIIIllIlIII	B
    //   0	46	0	lllllllllllllllllIIIllIIIllIlIIl	Ljava/lang/Exception;
  }
  
  private static void lIlllllIIl() {
    llllIlll = new int[lllIIIIIlI[4]];
    llllIlll[lllIIIIIlI[0]] = (lllIIIIIlI[5] ^ lllIIIIIlI[6] ^ lllIIIIIlI[7] ^ lllIIIIIlI[8]) & (lllIIIIIlI[9] ^ lllIIIIIlI[10] ^ lllIIIIIlI[11] ^ lllIIIIIlI[12] ^ -lllIIIIIIl[lllIIIIIlI[1]].length());
    llllIlll[lllIIIIIlI[2]] = lllIIIIIIl[lllIIIIIlI[4]].length();
    llllIlll[lllIIIIIlI[3]] = lllIIIIIIl[lllIIIIIlI[13]].length();
    llllIlll[lllIIIIIlI[1]] = lllIIIIIlI[14] ^ lllIIIIIlI[15];
  }
  
  private static boolean lIlllllIll(short lllllllllllllllllIIIllIIIllllIIl) {
    if (llIIIllllIlI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ((0x55 ^ 0x51) <= -" ".length())
        return (0x30 ^ 0x16) & (0xAA ^ 0x8C ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lllIIIIIlI[0];
  }
  
  public HashMap<String, SRemote> getLobbies() {
    return this.lobbies;
  }
  
  private static String llIIIlllIllI(String lllllllllllllllllIIIllIIIIIlIlIl, String lllllllllllllllllIIIllIIIIIlIlII) {
    try {
      SecretKeySpec lllllllllllllllllIIIllIIIIIllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIllIIIIIlIlII.getBytes(StandardCharsets.UTF_8)), lllIIIIIlI[18]), "DES");
      Cipher lllllllllllllllllIIIllIIIIIlIlll = Cipher.getInstance("DES");
      lllllllllllllllllIIIllIIIIIlIlll.init(lllIIIIIlI[3], lllllllllllllllllIIIllIIIIIllIII);
      return new String(lllllllllllllllllIIIllIIIIIlIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIllIIIIIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllllIIIllIIIIIlIllI) {
      lllllllllllllllllIIIllIIIIIlIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIllllIlll(boolean lllllllllllllllllIIIllIIlIIIIlIl, String lllllllllllllllllIIIllIIlIIIIlII) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIIl : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIlI : [I
    //   10: iconst_0
    //   11: iaload
    //   12: aaload
    //   13: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   16: aload_1
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   23: invokevirtual digest : ([B)[B
    //   26: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.llllIlll : [I
    //   29: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIlI : [I
    //   32: iconst_1
    //   33: iaload
    //   34: iaload
    //   35: invokestatic copyOf : ([BI)[B
    //   38: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIIl : [Ljava/lang/String;
    //   41: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIlI : [I
    //   44: iconst_2
    //   45: iaload
    //   46: aaload
    //   47: invokespecial <init> : ([BLjava/lang/String;)V
    //   50: astore_2
    //   51: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIIl : [Ljava/lang/String;
    //   54: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIlI : [I
    //   57: iconst_3
    //   58: iaload
    //   59: aaload
    //   60: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   63: astore_3
    //   64: aload_3
    //   65: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.llllIlll : [I
    //   68: getstatic com/axeelheaven/hbedwars/bungeemode/server/ServerManager.lllIIIIIlI : [I
    //   71: iconst_3
    //   72: iaload
    //   73: iaload
    //   74: aload_2
    //   75: invokevirtual init : (ILjava/security/Key;)V
    //   78: new java/lang/String
    //   81: dup
    //   82: aload_3
    //   83: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   86: aload_0
    //   87: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   90: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   93: invokevirtual decode : ([B)[B
    //   96: invokevirtual doFinal : ([B)[B
    //   99: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   102: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   105: areturn
    //   106: astore_2
    //   107: aload_2
    //   108: invokevirtual printStackTrace : ()V
    //   111: aconst_null
    //   112: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   51	55	2	lllllllllllllllllIIIllIIlIIIlIlI	Ljavax/crypto/spec/SecretKeySpec;
    //   0	113	2	lllllllllllllllllIIIllIIlIIIIIII	S
    //   0	113	0	lllllllllllllllllIIIllIIlIIIlIll	Ljava/lang/String;
    //   107	4	2	lllllllllllllllllIIIllIIlIIIlIIl	Ljava/lang/Exception;
    //   64	42	3	lllllllllllllllllIIIllIIlIIIIlll	Ljavax/crypto/Cipher;
    //   0	113	0	lllllllllllllllllIIIllIIlIIIIlIl	Z
    //   0	113	3	lllllllllllllllllIIIllIIIlllllll	F
    //   0	113	1	lllllllllllllllllIIIllIIlIIIlIII	B
    //   0	113	2	lllllllllllllllllIIIllIIlIIIIIll	I
    //   0	113	0	lllllllllllllllllIIIllIIlIIIIIlI	D
    //   0	113	1	lllllllllllllllllIIIllIIlIIIIlII	Ljava/lang/String;
    //   0	113	1	lllllllllllllllllIIIllIIlIIIIIIl	I
    //   0	113	3	lllllllllllllllllIIIllIIlIIIIllI	B
    // Exception table:
    //   from	to	target	type
    //   0	105	106	java/lang/Exception
  }
  
  private static boolean llIIIllllIll(double lllllllllllllllllIIIllIIIIIIIllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean llIIIlllllII(boolean lllllllllllllllllIIIllIIIIIIllIl, float lllllllllllllllllIIIllIIIIIIllII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static String llIIIlllIlll(String lllllllllllllllllIIIllIIIIllIIlI, String lllllllllllllllllIIIllIIIIllIllI) {
    lllllllllllllllllIIIllIIIIllIlll = new String(Base64.getDecoder().decode(lllllllllllllllllIIIllIIIIllIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIIllIIIIllIlIl = new StringBuilder();
    char[] lllllllllllllllllIIIllIIIIllIlII = lllllllllllllllllIIIllIIIIllIllI.toCharArray();
    int lllllllllllllllllIIIllIIIIllIIll = lllIIIIIlI[0];
    char[] arrayOfChar1 = lllllllllllllllllIIIllIIIIllIlll.toCharArray();
    int i = arrayOfChar1.length;
    lllllllllllllllllIIIllIIIIlIlIll = lllIIIIIlI[0];
    while (llIIIllllllI(lllllllllllllllllIIIllIIIIlIlIll, i)) {
      char lllllllllllllllllIIIllIIIIlllIII = arrayOfChar1[lllllllllllllllllIIIllIIIIlIlIll];
      "".length();
      lllllllllllllllllIIIllIIIIllIIll++;
      lllllllllllllllllIIIllIIIIlIlIll++;
      "".length();
      if (" ".length() == ((0x53 ^ 0x13) & (0x7 ^ 0x47 ^ 0xFFFFFFFF)))
        return null; 
    } 
    return String.valueOf(lllllllllllllllllIIIllIIIIllIlIl);
  }
  
  private static void lIlllllIII() {
    llllIllI = new String[llllIlll[lllIIIIIlI[3]]];
    llllIllI[llllIlll[lllIIIIIlI[0]]] = lIllllIlll(lllIIIIIIl[lllIIIIIlI[17]], lllIIIIIIl[lllIIIIIlI[18]]);
    llllIllI[llllIlll[lllIIIIIlI[2]]] = lIllllIlll(lllIIIIIIl[lllIIIIIlI[19]], lllIIIIIIl[lllIIIIIlI[20]]);
  }
  
  private static boolean llIIIllllIlI(long lllllllllllllllllIIIllIIIIIIIlII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  public ServerManager(int lllllllllllllllllIIIllIIIlIlIIIl) {
    this.plugin = lllllllllllllllllIIIllIIIlIlIIIl;
    this.lobbies = new HashMap<>();
    this.lastMessages = new HashMap<>();
    this.queue = new HashMap<>();
    this.redisMessenger = new RedisMessenger(lllllllllllllllllIIIllIIIlIlIIIl);
    this.server = lllllIllI[llllIlll[lllIIIIIlI[0]]];
  }
  
  public HashMap<String, String> getLastMessages() {
    return this.lastMessages;
  }
  
  public SRemote getLobby() {
    List<SRemote> lllllllllllllllllIIIllIIIlIIlIIl = new ArrayList<>(this.lobbies.values());
    if (llIIIllllIll(lIlllllIlI(lllllllllllllllllIIIllIIIlIIlIIl.isEmpty())))
      return null; 
    Collections.shuffle(lllllllllllllllllIIIllIIIlIIlIIl);
    return lllllllllllllllllIIIllIIIlIIlIIl.get(llllIlll[lllIIIIIlI[0]]);
  }
  
  public String getServer() {
    return this.server;
  }
  
  private static void llIIIllllIIl() {
    lllIIIIIlI = new int[26];
    lllIIIIIlI[0] = (61 + 52 - 30 + 63 ^ 26 + 162 - 130 + 131) & (0xE3 ^ 0x96 ^ 0x50 ^ 0xA ^ -" ".length());
    lllIIIIIlI[1] = "   ".length();
    lllIIIIIlI[2] = " ".length();
    lllIIIIIlI[3] = "  ".length();
    lllIIIIIlI[4] = 0x2 ^ 0x6;
    lllIIIIIlI[5] = 0x96 ^ 0x81;
    lllIIIIIlI[6] = 0xB5 ^ 0x89 ^ 0x48 ^ 0x7F;
    lllIIIIIlI[7] = 0xCF ^ 0x8C ^ 0x39 ^ 0x11;
    lllIIIIIlI[8] = 0x68 ^ 0x14;
    lllIIIIIlI[9] = (0x4A ^ 0x2E) + (0x51 ^ 0x5D) - (0xA ^ 0x6A) + 71 + 34 - 4 + 30;
    lllIIIIIlI[10] = (0x79 ^ 0x54) + (0xED ^ 0xC5) - (0xEC ^ 0xA3) + 85 + 93 - 177 + 128;
    lllIIIIIlI[11] = 0xDF ^ 0xC7 ^ 0xD0 ^ 0xAA;
    lllIIIIIlI[12] = 0x79 ^ 0x64 ^ 0x3A ^ 0x5A;
    lllIIIIIlI[13] = 135 + 127 - 253 + 139 ^ 32 + 31 - -64 + 18;
    lllIIIIIlI[14] = 0x30 ^ 0x20;
    lllIIIIIlI[15] = 0x58 ^ 0x1E ^ 0x16 ^ 0x48;
    lllIIIIIlI[16] = 0x2D ^ 0x2B;
    lllIIIIIlI[17] = 130 + 82 - 83 + 31 ^ 2 + 39 - -86 + 40;
    lllIIIIIlI[18] = 0xC8 ^ 0xC0;
    lllIIIIIlI[19] = 0x97 ^ 0x80 ^ 0x62 ^ 0x7C;
    lllIIIIIlI[20] = 0xA2 ^ 0xA8;
    lllIIIIIlI[21] = 0x6B ^ 0x67;
    lllIIIIIlI[22] = 0xA3 ^ 0xAE;
    lllIIIIIlI[23] = 0x42 ^ 0x4C ^ (0x30 ^ 0x2A) & (0x49 ^ 0x53 ^ 0xFFFFFFFF);
    lllIIIIIlI[24] = 0x21 ^ 0x2E;
    lllIIIIIlI[25] = 0x39 ^ 0x5 ^ 0xE9 ^ 0xC4;
  }
  
  private static void llIIIllllIII() {
    lllIIIIIIl = new String[lllIIIIIlI[25]];
    lllIIIIIIl[lllIIIIIlI[0]] = llIIIlllIlIl("xOqbxjDXpjs=", "sgGOu");
    lllIIIIIIl[lllIIIIIlI[2]] = llIIIlllIllI("hgujH2waXpg=", "VckKf");
    lllIIIIIIl[lllIIIIIlI[3]] = llIIIlllIlIl("euTrqD58350=", "nHTMi");
    lllIIIIIIl[lllIIIIIlI[1]] = llIIIlllIllI("kMRSbbz/5vI=", "yebkP");
    lllIIIIIIl[lllIIIIIlI[4]] = llIIIlllIllI("kw8eyb3YlYI=", "lyNWs");
    lllIIIIIIl[lllIIIIIlI[13]] = llIIIlllIlll("WUc=", "ygjac");
    lllIIIIIIl[lllIIIIIlI[16]] = llIIIlllIlIl("+1KVFkExE+0=", "nmDbE");
    lllIIIIIIl[lllIIIIIlI[17]] = llIIIlllIlIl("rpdiG48sK+hx0xIUsNsSW4D87rQR9Q0TJnwhV9aX8OJF1xsx7vnd0w==", "vcnMP");
    lllIIIIIIl[lllIIIIIlI[18]] = llIIIlllIlll("DgIQEiI=", "tZAvP");
    lllIIIIIIl[lllIIIIIlI[19]] = llIIIlllIlll("XAweAxRZHDFQYx9L", "hvUaZ");
    lllIIIIIIl[lllIIIIIlI[20]] = llIIIlllIllI("Sl9VZ6fkGUM=", "yHwrv");
    lllIIIIIIl[lllIIIIIlI[6]] = llIIIlllIlIl("IQXOTqY67SE=", "tMqeA");
    lllIIIIIIl[lllIIIIIlI[21]] = llIIIlllIllI("lwQrMUef12E=", "XuLyV");
    lllIIIIIIl[lllIIIIIlI[22]] = llIIIlllIlll("Z20=", "GMnGQ");
    lllIIIIIIl[lllIIIIIlI[23]] = llIIIlllIlll("WXRS", "yTrcj");
    lllIIIIIIl[lllIIIIIlI[24]] = llIIIlllIllI("8ZQYU9GXqz4=", "xTdfn");
    lllIIIIIIl[lllIIIIIlI[14]] = llIIIlllIlll("UXY=", "qVJjt");
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\bungeemode\server\ServerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */