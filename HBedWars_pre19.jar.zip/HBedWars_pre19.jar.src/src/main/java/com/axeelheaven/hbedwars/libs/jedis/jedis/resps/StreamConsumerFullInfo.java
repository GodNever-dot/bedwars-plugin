/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamConsumerFullInfo
/*    */   implements Serializable
/*    */ {
/*    */   public static final String NAME = "name";
/*    */   public static final String SEEN_TIME = "seen-time";
/*    */   public static final String PEL_COUNT = "pel-count";
/*    */   public static final String PENDING = "pending";
/*    */   private final String name;
/*    */   private final Long seenTime;
/*    */   private final Long pelCount;
/*    */   private final List<Long> pending;
/*    */   private final Map<String, Object> consumerInfo;
/*    */   
/*    */   public StreamConsumerFullInfo(Map<String, Object> map) {
/* 27 */     this.consumerInfo = map;
/* 28 */     this.name = (String)map.get("name");
/* 29 */     this.seenTime = (Long)map.get("seen-time");
/* 30 */     this.pending = (List<Long>)map.get("pending");
/* 31 */     this.pelCount = (Long)map.get("pel-count");
/*    */   }
/*    */   
/*    */   public String getName() {
/* 35 */     return this.name;
/*    */   }
/*    */   
/*    */   public long getSeenTime() {
/* 39 */     return this.seenTime.longValue();
/*    */   }
/*    */   
/*    */   public Long getPelCount() {
/* 43 */     return this.pelCount;
/*    */   }
/*    */   
/*    */   public List<Long> getPending() {
/* 47 */     return this.pending;
/*    */   }
/*    */   
/*    */   public Map<String, Object> getConsumerInfo() {
/* 51 */     return this.consumerInfo;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\StreamConsumerFullInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */