package com.axeelheaven.hbedwars.bungeemode.lobby;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.Location;

public class LServer {
  private static String lIIllIlIIIIII(String lllllllllllllllIlllIlllIllIIIIII, String lllllllllllllllIlllIlllIlIlllllI) {
    try {
      SecretKeySpec lllllllllllllllIlllIlllIllIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlllIlIlllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlllIllIIIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlllIllIIIlII.init(lIIllIIlIlI[2], lllllllllllllllIlllIlllIllIIIllI);
      return new String(lllllllllllllllIlllIlllIllIIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlllIllIIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlllIllIIIIlI) {
      lllllllllllllllIlllIlllIllIIIIlI.printStackTrace();
      return null;
    } 
  }
  
  private final BedWars plugin;
  private final String name;
  private final Location location;
  
  public LServer(BedWars plugin, String name, Location location) {
    this.plugin = plugin;
    this.name = name;
    this.location = location;
    this.arenas = new HashMap<>();
  }
  
  public HashMap<String, LArena> getArenas() {
    // Byte code:
    //   0: aload_0
    //   1: getfield arenas : Ljava/util/HashMap;
    //   4: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	5	0	lllllllllllllllIlllIllllIIllIIlI	I
    //   0	5	0	lllllllllllllllIlllIllllIIllIIll	S
    //   0	5	0	lllllllllllllllIlllIllllIIllIlII	Lcom/axeelheaven/hbedwars/bungeemode/lobby/LServer;
  }
  
  private static void lIIllIllIlIIl() {
    lIIllIIlIlI = new int[14];
    lIIllIIlIlI[0] = "  ".length() & ("  ".length() ^ 0xFFFFFFFF);
    lIIllIIlIlI[1] = " ".length();
    lIIllIIlIlI[2] = "  ".length();
    lIIllIIlIlI[3] = "   ".length();
    lIIllIIlIlI[4] = 29 + 124 - 79 + 66;
    lIIllIIlIlI[5] = (0x31 ^ 0x1B) + (0xF9 ^ 0xA7) - (0x2C ^ 0x3F) + (0x5B ^ 0x19);
    lIIllIIlIlI[6] = 113 + 28 - 124 + 227 + (0x67 ^ 0xF) - 163 + 98 - 203 + 110 + (0xC7 ^ 0x82);
    lIIllIIlIlI[7] = (0xAB ^ 0x99) + 76 + 62 - 92 + 103 - (0x59 ^ 0x10) + (0x35 ^ 0x7D);
    lIIllIIlIlI[8] = 0xA0 ^ 0xA7;
    lIIllIIlIlI[9] = 0xC9 ^ 0xAD ^ 0xBB ^ 0xA2;
    lIIllIIlIlI[10] = 0x39 ^ 0x72;
    lIIllIIlIlI[11] = 135 + 125 - 234 + 148 ^ 53 + 75 - 71 + 98;
    lIIllIIlIlI[12] = 0xA8 ^ 0xAC;
    lIIllIIlIlI[13] = 0xAF ^ 0xA7;
  }
  
  private static boolean lllIIllIIlI(short lllllllllllllllIlllIlllIlllIlIlI) {
    if (lIIllIllIlIll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (((0x5C ^ 0x52) & (0xA1 ^ 0xAF ^ 0xFFFFFFFF)) < 0)
        return (0x20 ^ 0x10) & (0x91 ^ 0xA1 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIIllIIlIlI[0];
  }
  
  private static boolean lIIllIllIllIl(Exception lllllllllllllllIlllIlllIlIllIIII, Exception lllllllllllllllIlllIlllIlIlIllll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public String getName() {
    return this.name;
  }
  
  public Location getLocation() {
    return this.location;
  }
  
  private static void lIIllIlIIIIIl() {
    lIIllIIIIII = new String[lIIllIIlIlI[12]];
    lIIllIIIIII[lIIllIIlIlI[0]] = lIIllIIllllll("y36sMWbLkXE=", "hIWGV");
    lIIllIIIIII[lIIllIIlIlI[1]] = lIIllIlIIIIII("0fbZ68eubPk=", "MxQUB");
    lIIllIIIIII[lIIllIIlIlI[2]] = lIIllIIllllll("XBADwL4hwEc=", "iBmOB");
    lIIllIIIIII[lIIllIIlIlI[3]] = lIIllIIllllll("dEfoqWxWPhA=", "apfeo");
  }
  
  public LArena getArena(boolean lllllllllllllllIlllIllllIIIIllIl) {
    LArena lArena = null;
    Iterator<LArena> iterator = ((LServer)super).arenas.values().iterator();
    while (lIIllIllIlIll(lllIIllIIlI(iterator.hasNext()))) {
      LArena lllllllllllllllIlllIllllIIIlIIlI = iterator.next();
      if (lIIllIllIlIll(lllIIllIIlI(lllllllllllllllIlllIllllIIIlIIlI.getName().equalsIgnoreCase(lllllllllllllllIlllIllllIIIIllIl)))) {
        lArena = lllllllllllllllIlllIllllIIIlIIlI;
        "".length();
        if (lIIllIllIllII(-lIIllIIIIII[lIIllIIlIlI[1]].length(), -lIIllIIIIII[lIIllIIlIlI[2]].length()))
          return null; 
        break;
      } 
      "".length();
      if (lIIllIllIllIl(lIIllIIlIlI[4] ^ lIIllIIlIlI[5] ^ lIIllIIlIlI[6] ^ lIIllIIlIlI[7], lIIllIIlIlI[8] ^ lIIllIIlIlI[9] ^ lIIllIIlIlI[10] ^ lIIllIIlIlI[11]))
        return null; 
    } 
    return lArena;
  }
  
  private static boolean lIIllIllIlIll(double lllllllllllllllIlllIlllIlIlIllIl) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static String lIIllIIllllll(Exception lllllllllllllllIlllIlllIllIlIlIl, String lllllllllllllllIlllIlllIllIlIlll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlllIllIllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlllIllIlIlll.getBytes(StandardCharsets.UTF_8)), lIIllIIlIlI[13]), "DES");
      Cipher lllllllllllllllIlllIlllIllIlllII = Cipher.getInstance("DES");
      lllllllllllllllIlllIlllIllIlllII.init(lIIllIIlIlI[2], lllllllllllllllIlllIlllIllIllllI);
      return new String(lllllllllllllllIlllIlllIllIlllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlllIllIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlllIllIllIlI) {
      lllllllllllllllIlllIlllIllIllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static boolean lIIllIllIllII(short lllllllllllllllIlllIlllIlIlIlIIl, float lllllllllllllllIlllIlllIlIlIIlll) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  static {
    lIIllIllIlIIl();
    lIIllIlIIIIIl();
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\bungeemode\lobby\LServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */