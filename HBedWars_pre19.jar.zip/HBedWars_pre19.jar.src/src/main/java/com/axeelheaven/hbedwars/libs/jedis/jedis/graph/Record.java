package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;

import java.util.List;

public interface Record {
  <T> T getValue(int paramInt);
  
  <T> T getValue(String paramString);
  
  String getString(int paramInt);
  
  String getString(String paramString);
  
  List<String> keys();
  
  List<Object> values();
  
  boolean containsKey(String paramString);
  
  int size();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\Record.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */