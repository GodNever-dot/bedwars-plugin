/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class BitPosParams implements IParams {
/*  9 */   private List<byte[]> params = (List)new ArrayList<>();
/*    */ 
/*    */   
/*    */   public BitPosParams() {}
/*    */   
/*    */   public BitPosParams(long start) {
/* 15 */     this.params.add(Protocol.toByteArray(start));
/*    */   }
/*    */   
/*    */   public BitPosParams(long start, long end) {
/* 19 */     this(start);
/*    */     
/* 21 */     this.params.add(Protocol.toByteArray(end));
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 26 */     for (byte[] param : this.params)
/* 27 */       args.add(param); 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\BitPosParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */