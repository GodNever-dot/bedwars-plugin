/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Builder;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.BuilderFactory;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisDataException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions.JedisException;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.graph.entities.Edge;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.graph.entities.GraphEntity;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.graph.entities.Node;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.graph.entities.Path;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.graph.entities.Point;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ class ResultSetBuilder
/*     */   extends Builder<ResultSet>
/*     */ {
/*     */   private final GraphCache graphCache;
/*     */   
/*     */   ResultSetBuilder(GraphCache cache) {
/*  28 */     this.graphCache = cache;
/*     */   }
/*     */   
/*     */   public ResultSet build(Object data) {
/*     */     Object headerObject, recordsObject, statisticsObject;
/*  33 */     List<Object> rawResponse = (List<Object>)data;
/*     */ 
/*     */     
/*  36 */     if (rawResponse.get(rawResponse.size() - 1) instanceof JedisDataException) {
/*  37 */       throw (JedisDataException)rawResponse.get(rawResponse.size() - 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     if (rawResponse.size() == 1) {
/*  50 */       headerObject = Collections.emptyList();
/*  51 */       recordsObject = Collections.emptyList();
/*  52 */       statisticsObject = rawResponse.get(0);
/*  53 */     } else if (rawResponse.size() == 3) {
/*  54 */       headerObject = rawResponse.get(0);
/*  55 */       recordsObject = rawResponse.get(1);
/*  56 */       statisticsObject = rawResponse.get(2);
/*     */     } else {
/*  58 */       throw new JedisException("Unrecognized graph response format.");
/*     */     } 
/*     */     
/*  61 */     HeaderImpl header = parseHeader(headerObject);
/*  62 */     List<Record> records = parseRecords(header, recordsObject);
/*  63 */     StatisticsImpl statistics = parseStatistics(statisticsObject);
/*  64 */     return new ResultSetImpl(header, records, statistics);
/*     */   }
/*     */   
/*     */   private class ResultSetImpl
/*     */     implements ResultSet {
/*     */     private final Header header;
/*     */     private final List<Record> results;
/*     */     private final Statistics statistics;
/*     */     
/*     */     private ResultSetImpl(Header header, List<Record> results, Statistics statistics) {
/*  74 */       this.header = header;
/*  75 */       this.results = results;
/*  76 */       this.statistics = statistics;
/*     */     }
/*     */ 
/*     */     
/*     */     public Header getHeader() {
/*  81 */       return this.header;
/*     */     }
/*     */ 
/*     */     
/*     */     public Statistics getStatistics() {
/*  86 */       return this.statistics;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/*  91 */       return this.results.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/*  96 */       if (this == o) {
/*  97 */         return true;
/*     */       }
/*  99 */       if (!(o instanceof ResultSetImpl)) {
/* 100 */         return false;
/*     */       }
/* 102 */       ResultSetImpl resultSet = (ResultSetImpl)o;
/* 103 */       return (Objects.equals(getHeader(), resultSet.getHeader()) && 
/* 104 */         Objects.equals(getStatistics(), resultSet.getStatistics()) && 
/* 105 */         Objects.equals(this.results, resultSet.results));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 110 */       return Objects.hash(new Object[] { getHeader(), getStatistics(), this.results });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 115 */       StringBuilder sb = new StringBuilder("ResultSetImpl{");
/* 116 */       sb.append("header=").append(this.header);
/* 117 */       sb.append(", statistics=").append(this.statistics);
/* 118 */       sb.append(", results=").append(this.results);
/* 119 */       sb.append('}');
/* 120 */       return sb.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Record> iterator() {
/* 125 */       return this.results.iterator();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Record> parseRecords(Header header, Object data) {
/* 131 */     List<List<Object>> rawResultSet = (List<List<Object>>)data;
/* 132 */     List<Record> results = new ArrayList<>();
/* 133 */     if (rawResultSet == null || rawResultSet.isEmpty()) {
/* 134 */       return results;
/*     */     }
/*     */     
/* 137 */     for (List<Object> row : rawResultSet) {
/*     */       
/* 139 */       List<Object> parsedRow = new ArrayList(row.size());
/*     */       
/* 141 */       for (int i = 0; i < row.size(); i++) {
/*     */         
/* 143 */         List<Object> obj = (List<Object>)row.get(i);
/*     */         
/* 145 */         ResultSet.ColumnType objType = header.getSchemaTypes().get(i);
/*     */         
/* 147 */         switch (objType) {
/*     */           case NULL:
/* 149 */             parsedRow.add(deserializeNode(obj));
/*     */             break;
/*     */           case BOOLEAN:
/* 152 */             parsedRow.add(deserializeEdge(obj));
/*     */             break;
/*     */           case DOUBLE:
/* 155 */             parsedRow.add(deserializeScalar(obj));
/*     */             break;
/*     */           default:
/* 158 */             parsedRow.add((Object)null);
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/* 164 */       Record record = new RecordImpl(header.getSchemaNames(), parsedRow);
/* 165 */       results.add(record);
/*     */     } 
/*     */     
/* 168 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Node deserializeNode(List<Object> rawNodeData) {
/* 180 */     Node node = new Node();
/* 181 */     deserializeGraphEntityId((GraphEntity)node, rawNodeData.get(0));
/* 182 */     List<Long> labelsIndices = (List<Long>)rawNodeData.get(1);
/* 183 */     for (Long labelIndex : labelsIndices) {
/* 184 */       String label = this.graphCache.getLabel(labelIndex.intValue());
/* 185 */       node.addLabel(label);
/*     */     } 
/* 187 */     deserializeGraphEntityProperties((GraphEntity)node, (List<List<Object>>)rawNodeData.get(2));
/*     */     
/* 189 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void deserializeGraphEntityId(GraphEntity graphEntity, Object rawEntityId) {
/* 198 */     long id = ((Long)rawEntityId).longValue();
/* 199 */     graphEntity.setId(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Edge deserializeEdge(List<Object> rawEdgeData) {
/* 210 */     Edge edge = new Edge();
/* 211 */     deserializeGraphEntityId((GraphEntity)edge, rawEdgeData.get(0));
/*     */     
/* 213 */     String relationshipType = this.graphCache.getRelationshipType(((Long)rawEdgeData.get(1)).intValue());
/* 214 */     edge.setRelationshipType(relationshipType);
/*     */     
/* 216 */     edge.setSource(((Long)rawEdgeData.get(2)).longValue());
/* 217 */     edge.setDestination(((Long)rawEdgeData.get(3)).longValue());
/*     */     
/* 219 */     deserializeGraphEntityProperties((GraphEntity)edge, (List<List<Object>>)rawEdgeData.get(4));
/*     */     
/* 221 */     return edge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void deserializeGraphEntityProperties(GraphEntity entity, List<List<Object>> rawProperties) {
/* 232 */     for (List<Object> rawProperty : rawProperties) {
/* 233 */       String name = this.graphCache.getPropertyName(((Long)rawProperty.get(0)).intValue());
/*     */ 
/*     */       
/* 236 */       List<Object> propertyScalar = rawProperty.subList(1, rawProperty.size());
/*     */       
/* 238 */       entity.addProperty(name, deserializeScalar(propertyScalar));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object deserializeScalar(List<Object> rawScalarData) {
/* 250 */     ScalarType type = getValueTypeFromObject(rawScalarData.get(0));
/*     */     
/* 252 */     Object obj = rawScalarData.get(1);
/* 253 */     switch (type) {
/*     */       case NULL:
/* 255 */         return null;
/*     */       case BOOLEAN:
/* 257 */         return Boolean.valueOf(Boolean.parseBoolean(SafeEncoder.encode((byte[])obj)));
/*     */       case DOUBLE:
/* 259 */         return Double.valueOf(Double.parseDouble(SafeEncoder.encode((byte[])obj)));
/*     */       case INTEGER:
/* 261 */         return obj;
/*     */       case STRING:
/* 263 */         return SafeEncoder.encode((byte[])obj);
/*     */       case ARRAY:
/* 265 */         return deserializeArray(obj);
/*     */       case NODE:
/* 267 */         return deserializeNode((List<Object>)obj);
/*     */       case EDGE:
/* 269 */         return deserializeEdge((List<Object>)obj);
/*     */       case PATH:
/* 271 */         return deserializePath(obj);
/*     */       case MAP:
/* 273 */         return deserializeMap(obj);
/*     */       case POINT:
/* 275 */         return deserializePoint(obj);
/*     */     } 
/*     */     
/* 278 */     return obj;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object deserializePoint(Object rawScalarData) {
/* 283 */     return new Point((List)BuilderFactory.DOUBLE_LIST.build(rawScalarData));
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, Object> deserializeMap(Object rawScalarData) {
/* 288 */     List<Object> keyTypeValueEntries = (List<Object>)rawScalarData;
/* 289 */     Map<String, Object> map = new HashMap<>();
/* 290 */     for (int i = 0; i < keyTypeValueEntries.size(); i += 2) {
/* 291 */       String key = SafeEncoder.encode((byte[])keyTypeValueEntries.get(i));
/* 292 */       Object value = deserializeScalar((List<Object>)keyTypeValueEntries.get(i + 1));
/* 293 */       map.put(key, value);
/*     */     } 
/* 295 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   private Path deserializePath(Object rawScalarData) {
/* 300 */     List<List<Object>> array = (List<List<Object>>)rawScalarData;
/* 301 */     List<Node> nodes = (List<Node>)deserializeScalar(array.get(0));
/* 302 */     List<Edge> edges = (List<Edge>)deserializeScalar(array.get(1));
/* 303 */     return new Path(nodes, edges);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Object> deserializeArray(Object rawScalarData) {
/* 308 */     List<List<Object>> array = (List<List<Object>>)rawScalarData;
/* 309 */     List<Object> res = new ArrayList(array.size());
/* 310 */     for (List<Object> arrayValue : array) {
/* 311 */       res.add(deserializeScalar(arrayValue));
/*     */     }
/* 313 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ScalarType getValueTypeFromObject(Object rawScalarType) {
/* 323 */     return getScalarType(((Long)rawScalarType).intValue());
/*     */   }
/*     */   
/*     */   private enum ScalarType {
/* 327 */     UNKNOWN,
/* 328 */     NULL,
/* 329 */     STRING,
/* 330 */     INTEGER,
/* 331 */     BOOLEAN,
/* 332 */     DOUBLE,
/* 333 */     ARRAY,
/* 334 */     EDGE,
/* 335 */     NODE,
/* 336 */     PATH,
/* 337 */     MAP,
/* 338 */     POINT;
/*     */   }
/*     */   
/* 341 */   private static final ScalarType[] SCALAR_TYPES = ScalarType.values();
/*     */   
/*     */   private static ScalarType getScalarType(int index) {
/*     */     try {
/* 345 */       return SCALAR_TYPES[index];
/* 346 */     } catch (IndexOutOfBoundsException e) {
/* 347 */       throw new JedisException("Unrecognized response type");
/*     */     } 
/*     */   }
/*     */   
/*     */   private class RecordImpl
/*     */     implements Record {
/*     */     private final List<String> header;
/*     */     private final List<Object> values;
/*     */     
/*     */     public RecordImpl(List<String> header, List<Object> values) {
/* 357 */       this.header = header;
/* 358 */       this.values = values;
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T getValue(int index) {
/* 363 */       return (T)this.values.get(index);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T getValue(String key) {
/* 368 */       return getValue(this.header.indexOf(key));
/*     */     }
/*     */ 
/*     */     
/*     */     public String getString(int index) {
/* 373 */       return this.values.get(index).toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getString(String key) {
/* 378 */       return getString(this.header.indexOf(key));
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> keys() {
/* 383 */       return this.header;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Object> values() {
/* 388 */       return this.values;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsKey(String key) {
/* 393 */       return this.header.contains(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 398 */       return this.header.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 403 */       if (this == o) {
/* 404 */         return true;
/*     */       }
/* 406 */       if (!(o instanceof RecordImpl)) {
/* 407 */         return false;
/*     */       }
/* 409 */       RecordImpl record = (RecordImpl)o;
/* 410 */       return (Objects.equals(this.header, record.header) && 
/* 411 */         Objects.equals(this.values, record.values));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 416 */       return Objects.hash(new Object[] { this.header, this.values });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 421 */       StringBuilder sb = new StringBuilder("Record{");
/* 422 */       sb.append("values=").append(this.values);
/* 423 */       sb.append('}');
/* 424 */       return sb.toString();
/*     */     }
/*     */   }
/*     */   
/* 428 */   private static final ResultSet.ColumnType[] COLUMN_TYPES = ResultSet.ColumnType.values();
/*     */   
/*     */   private class HeaderImpl
/*     */     implements Header {
/*     */     private final List<ResultSet.ColumnType> schemaTypes;
/*     */     private final List<String> schemaNames;
/*     */     
/*     */     private HeaderImpl() {
/* 436 */       this.schemaTypes = Collections.emptyList();
/* 437 */       this.schemaNames = Collections.emptyList();
/*     */     }
/*     */     
/*     */     private HeaderImpl(List<ResultSet.ColumnType> schemaTypes, List<String> schemaNames) {
/* 441 */       this.schemaTypes = schemaTypes;
/* 442 */       this.schemaNames = schemaNames;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> getSchemaNames() {
/* 450 */       return this.schemaNames;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<ResultSet.ColumnType> getSchemaTypes() {
/* 458 */       return this.schemaTypes;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 463 */       if (this == o) {
/* 464 */         return true;
/*     */       }
/* 466 */       if (!(o instanceof HeaderImpl)) {
/* 467 */         return false;
/*     */       }
/* 469 */       HeaderImpl header = (HeaderImpl)o;
/* 470 */       return (Objects.equals(getSchemaTypes(), header.getSchemaTypes()) && 
/* 471 */         Objects.equals(getSchemaNames(), header.getSchemaNames()));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 476 */       return Objects.hash(new Object[] { getSchemaTypes(), getSchemaNames() });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 481 */       StringBuilder sb = new StringBuilder("HeaderImpl{");
/* 482 */       sb.append("schemaTypes=").append(this.schemaTypes);
/* 483 */       sb.append(", schemaNames=").append(this.schemaNames);
/* 484 */       sb.append('}');
/* 485 */       return sb.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private HeaderImpl parseHeader(Object data) {
/* 490 */     if (data == null) {
/* 491 */       return new HeaderImpl();
/*     */     }
/*     */     
/* 494 */     List<List<Object>> list = (List<List<Object>>)data;
/* 495 */     List<ResultSet.ColumnType> types = new ArrayList<>(list.size());
/* 496 */     List<String> texts = new ArrayList<>(list.size());
/* 497 */     for (List<Object> tuple : list) {
/* 498 */       types.add(COLUMN_TYPES[((Long)tuple.get(0)).intValue()]);
/* 499 */       texts.add(SafeEncoder.encode((byte[])tuple.get(1)));
/*     */     } 
/* 501 */     return new HeaderImpl(types, texts);
/*     */   }
/*     */   
/*     */   private class StatisticsImpl
/*     */     implements Statistics {
/*     */     private final Map<String, String> statistics;
/*     */     
/*     */     private StatisticsImpl(Map<String, String> statistics) {
/* 509 */       this.statistics = statistics;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getStringValue(String label) {
/* 518 */       return this.statistics.get(label);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int getIntValue(String label) {
/* 527 */       String value = getStringValue(label);
/* 528 */       return (value == null) ? 0 : Integer.parseInt(value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int nodesCreated() {
/* 537 */       return getIntValue("Nodes created");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int nodesDeleted() {
/* 546 */       return getIntValue("Nodes deleted");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int indicesCreated() {
/* 555 */       return getIntValue("Indices created");
/*     */     }
/*     */ 
/*     */     
/*     */     public int indicesDeleted() {
/* 560 */       return getIntValue("Indices deleted");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int labelsAdded() {
/* 569 */       return getIntValue("Labels added");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int relationshipsDeleted() {
/* 578 */       return getIntValue("Relationships deleted");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int relationshipsCreated() {
/* 587 */       return getIntValue("Relationships created");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int propertiesSet() {
/* 596 */       return getIntValue("Properties set");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean cachedExecution() {
/* 605 */       return "1".equals(getStringValue("Cached execution"));
/*     */     }
/*     */ 
/*     */     
/*     */     public String queryIntervalExecutionTime() {
/* 610 */       return getStringValue("Query internal execution time");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 615 */       if (this == o) {
/* 616 */         return true;
/*     */       }
/* 618 */       if (!(o instanceof StatisticsImpl)) {
/* 619 */         return false;
/*     */       }
/* 621 */       StatisticsImpl that = (StatisticsImpl)o;
/* 622 */       return Objects.equals(this.statistics, that.statistics);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 627 */       return Objects.hash(new Object[] { this.statistics });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 632 */       StringBuilder sb = new StringBuilder("Statistics{");
/* 633 */       sb.append(this.statistics);
/* 634 */       sb.append('}');
/* 635 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private StatisticsImpl parseStatistics(Object data) {
/* 642 */     Map<String, String> map = (Map<String, String>)((List)data).stream().map(SafeEncoder::encode).map(s -> s.split(": ")).collect(Collectors.toMap(sa -> sa[0], sa -> sa[1]));
/* 643 */     return new StatisticsImpl(map);
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\ResultSetBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */