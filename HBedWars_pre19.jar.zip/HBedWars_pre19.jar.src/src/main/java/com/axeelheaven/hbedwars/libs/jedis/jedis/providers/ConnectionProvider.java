package com.axeelheaven.hbedwars.libs.jedis.jedis.providers;

import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
import com.axeelheaven.hbedwars.libs.jedis.jedis.Connection;

public interface ConnectionProvider extends AutoCloseable {
  Connection getConnection();
  
  Connection getConnection(CommandArguments paramCommandArguments);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\providers\ConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */