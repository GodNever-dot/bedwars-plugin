/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph.entities;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Path
/*     */ {
/*     */   private final List<Node> nodes;
/*     */   private final List<Edge> edges;
/*     */   
/*     */   public Path(List<Node> nodes, List<Edge> edges) {
/*  21 */     this.nodes = nodes;
/*  22 */     this.edges = edges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Node> getNodes() {
/*  30 */     return this.nodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Edge> getEdges() {
/*  38 */     return this.edges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/*  46 */     return this.edges.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nodeCount() {
/*  54 */     return this.nodes.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node firstNode() {
/*  63 */     return this.nodes.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node lastNode() {
/*  72 */     return this.nodes.get(this.nodes.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getNode(int index) {
/*  82 */     return this.nodes.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Edge getEdge(int index) {
/*  92 */     return this.edges.get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  97 */     if (this == o) return true; 
/*  98 */     if (o == null || getClass() != o.getClass()) return false; 
/*  99 */     Path path = (Path)o;
/* 100 */     return (Objects.equals(this.nodes, path.nodes) && 
/* 101 */       Objects.equals(this.edges, path.edges));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 106 */     return Objects.hash(new Object[] { this.nodes, this.edges });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     StringBuilder sb = new StringBuilder("Path{");
/* 112 */     sb.append("nodes=").append(this.nodes);
/* 113 */     sb.append(", edges=").append(this.edges);
/* 114 */     sb.append('}');
/* 115 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\entities\Path.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */