/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.search.aggr;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Reducer
/*    */ {
/*    */   private String alias;
/*    */   private final String field;
/*    */   
/*    */   protected Reducer(String field) {
/* 18 */     this.field = field;
/* 19 */     this.alias = null;
/*    */   }
/*    */   
/*    */   protected Reducer() {
/* 23 */     this(null);
/*    */   }
/*    */   
/*    */   protected List<String> getOwnArgs() {
/* 27 */     if (this.field == null) {
/* 28 */       return Collections.emptyList();
/*    */     }
/* 30 */     List<String> ret = new ArrayList<>();
/* 31 */     ret.add(this.field);
/* 32 */     return ret;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract String getName();
/*    */ 
/*    */   
/*    */   public final String getAlias() {
/* 41 */     return this.alias;
/*    */   }
/*    */   
/*    */   public final Reducer setAlias(String alias) {
/* 45 */     this.alias = alias;
/* 46 */     return this;
/*    */   }
/*    */   
/*    */   public final Reducer as(String alias) {
/* 50 */     return setAlias(alias);
/*    */   }
/*    */   
/*    */   public final Reducer setAliasAsField() {
/* 54 */     if (this.field == null || this.field.isEmpty()) {
/* 55 */       throw new IllegalArgumentException("Cannot set to field name since no field exists");
/*    */     }
/* 57 */     return setAlias(this.field);
/*    */   }
/*    */   
/*    */   public void addArgs(List<String> args) {
/* 61 */     List<String> ownArgs = getOwnArgs();
/* 62 */     args.add(Integer.toString(ownArgs.size()));
/* 63 */     args.addAll(ownArgs);
/*    */   }
/*    */   
/*    */   public final List<String> getArgs() {
/* 67 */     List<String> args = new ArrayList<>();
/* 68 */     addArgs(args);
/* 69 */     return args;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\search\aggr\Reducer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */