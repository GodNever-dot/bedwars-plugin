package com.axeelheaven.hbedwars.bungeemode.redis;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Jedis;
import com.axeelheaven.hbedwars.libs.jedis.jedis.JedisPool;

public interface JedisResult {
  void onSuccess(String result);
  void onError(Throwable error);
  
  void close();
  
  JedisPool pool();
  
  Jedis listenerConnection();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\bungeemode\redis\JedisResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */