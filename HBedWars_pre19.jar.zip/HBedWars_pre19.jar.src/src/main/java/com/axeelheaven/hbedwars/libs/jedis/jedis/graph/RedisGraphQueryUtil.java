/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ public class RedisGraphQueryUtil
/*    */ {
/* 11 */   public static final List<String> DUMMY_LIST = Collections.emptyList();
/* 12 */   public static final Map<String, List<String>> DUMMY_MAP = Collections.emptyMap();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final String COMPACT_STRING = "--COMPACT";
/*    */ 
/*    */ 
/*    */   
/*    */   public static final String TIMEOUT_STRING = "TIMEOUT";
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String prepareQuery(String query, Map<String, Object> params) {
/* 27 */     StringBuilder sb = new StringBuilder("CYPHER ");
/* 28 */     for (Map.Entry<String, Object> entry : params.entrySet()) {
/* 29 */       sb
/* 30 */         .append(entry.getKey())
/* 31 */         .append('=')
/* 32 */         .append(valueToString(entry.getValue()))
/* 33 */         .append(' ');
/*    */     }
/* 35 */     sb.append(query);
/* 36 */     return sb.toString();
/*    */   }
/*    */   
/*    */   private static String valueToString(Object value) {
/* 40 */     if (value == null) {
/* 41 */       return "null";
/*    */     }
/*    */     
/* 44 */     if (value instanceof String) {
/* 45 */       return quoteString((String)value);
/*    */     }
/* 47 */     if (value instanceof Character) {
/* 48 */       return quoteString(((Character)value).toString());
/*    */     }
/*    */     
/* 51 */     if (value instanceof Object[]) {
/* 52 */       return arrayToString((Object[])value);
/*    */     }
/* 54 */     if (value instanceof List) {
/* 55 */       return arrayToString((List<Object>)value);
/*    */     }
/* 57 */     return value.toString();
/*    */   }
/*    */   
/*    */   private static String quoteString(String str) {
/* 61 */     StringBuilder sb = new StringBuilder(str.length() + 12);
/* 62 */     sb.append('"');
/* 63 */     sb.append(str.replace("\"", "\\\""));
/* 64 */     sb.append('"');
/* 65 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String arrayToString(Object[] arr) {
/* 73 */     return arrayToString(Arrays.asList(arr));
/*    */   }
/*    */   
/*    */   private static String arrayToString(List<Object> arr) {
/* 77 */     StringBuilder sb = (new StringBuilder()).append('[');
/* 78 */     sb.append(String.join(", ", (Iterable<? extends CharSequence>)arr.stream().map(RedisGraphQueryUtil::valueToString).collect(Collectors.toList())));
/* 79 */     sb.append(']');
/* 80 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\RedisGraphQueryUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */