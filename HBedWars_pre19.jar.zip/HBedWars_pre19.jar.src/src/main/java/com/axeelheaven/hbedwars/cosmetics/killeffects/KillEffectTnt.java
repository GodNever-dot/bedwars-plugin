package com.axeelheaven.hbedwars.cosmetics.killeffects;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.libs.xseries.XSound;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.util.Vector;

public class KillEffectTnt extends KillEffect {
  private static String lIlIIIIIIlIII(byte lllllllllllllllIlllIIIlIIlIlIlII, Exception lllllllllllllllIlllIIIlIIlIlIIll) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectTnt.lIIllllIllI : [I
    //   40: iconst_0
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectTnt.lIIllllIllI : [I
    //   58: iconst_0
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic lIlIIIIlIIIIl : (II)Z
    //   69: ifeq -> 127
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: ldc ' '
    //   114: invokevirtual length : ()I
    //   117: ldc '   '
    //   119: invokevirtual length : ()I
    //   122: if_icmpne -> 62
    //   125: aconst_null
    //   126: areturn
    //   127: aload_2
    //   128: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   131: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	132	6	lllllllllllllllIlllIIIlIIlIIlllI	B
    //   32	100	2	lllllllllllllllIlllIIIlIIlIlIlll	Ljava/lang/StringBuilder;
    //   37	95	3	lllllllllllllllIlllIIIlIIlIlIllI	[C
    //   79	24	8	lllllllllllllllIlllIIIlIIlIllIlI	C
    //   0	132	1	lllllllllllllllIlllIIIlIIlIllIII	Ljava/lang/String;
    //   0	132	4	lllllllllllllllIlllIIIlIIlIlIIII	J
    //   0	132	7	lllllllllllllllIlllIIIlIIlIIllIl	S
    //   0	132	5	lllllllllllllllIlllIIIlIIlIIllll	Z
    //   0	132	2	lllllllllllllllIlllIIIlIIlIlIIlI	S
    //   0	132	8	lllllllllllllllIlllIIIlIIlIIllII	S
    //   0	132	0	lllllllllllllllIlllIIIlIIlIllIIl	Ljava/lang/String;
    //   0	132	1	lllllllllllllllIlllIIIlIIlIlIIll	Ljava/lang/Exception;
    //   0	132	3	lllllllllllllllIlllIIIlIIlIlIIIl	Ljava/lang/String;
    //   0	132	0	lllllllllllllllIlllIIIlIIlIlIlII	B
    //   44	88	4	lllllllllllllllIlllIIIlIIlIlIlIl	I
  }
  
  static {
    lIlIIIIlIIIII();
    lIlIIIIIIlIIl();
    lllllIlIIIl();
  }
  
  private static void lllllIlIIIl() {
    lIIllIllll = new int[lIIllllIllI[2]];
    lIIllIllll[lIIllllIllI[0]] = -lIIlllIllll[lIIllllIllI[1]].length() & lIIllllIllI[3] & lIIllllIllI[4];
    lIIllIllll[lIIllllIllI[1]] = lIIllllIllI[5] ^ lIIllllIllI[6];
  }
  
  private static boolean lIlIIIIlIIIIl(short lllllllllllllllIlllIIIlIIlIIlIIl, float lllllllllllllllIlllIIIlIIlIIlIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static void lIlIIIIlIIIII() {
    lIIllllIllI = new int[8];
    lIIllllIllI[0] = (0x21 ^ 0x65) & (0xC2 ^ 0x86 ^ 0xFFFFFFFF);
    lIIllllIllI[1] = " ".length();
    lIIllllIllI[2] = "  ".length();
    lIIllllIllI[3] = -" ".length();
    lIIllllIllI[4] = -" ".length() & 0xFFFFFFFF & Integer.MAX_VALUE;
    lIIllllIllI[5] = (0x3D ^ 0x2B) + (0x12 ^ 0x75) - (0x7D ^ 0x1E) + 22 + 99 - 1 + 7;
    lIIllllIllI[6] = (0xCC ^ 0xAB) + (0x28 ^ 0x67) - (0x35 ^ 0x62) + (0x81 ^ 0xB5);
    lIIllllIllI[7] = 0x61 ^ 0x69;
  }
  
  private static void lIlIIIIIIlIIl() {
    lIIlllIllll = new String[lIIllllIllI[2]];
    lIIlllIllll[lIIllllIllI[0]] = lIlIIIIIIIlll("qCacuCZf/4o=", "HTWpB");
    lIIlllIllll[lIIllllIllI[1]] = lIlIIIIIIlIII("VQ==", "utpoV");
  }
  
  private final BedWars plugin;
  
  public KillEffectTnt(BedWars plugin) {
    super(plugin);
    this.plugin = plugin;
  }
  
  @Override
  public void play(Player killer, Player victim) {
    Location location = victim.getLocation();
    TNTPrimed tnt = location.getWorld().spawn(location, TNTPrimed.class);
    tnt.setFuseTicks(0);
  }
  
  private static String lIlIIIIIIIlll(boolean lllllllllllllllIlllIIIlIIllIIlll, Exception lllllllllllllllIlllIIIlIIllIIllI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectTnt.lIIllllIllI : [I
    //   23: bipush #7
    //   25: iaload
    //   26: invokestatic copyOf : ([BI)[B
    //   29: ldc_w 'DES'
    //   32: invokespecial <init> : ([BLjava/lang/String;)V
    //   35: astore_2
    //   36: ldc_w 'DES'
    //   39: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   42: astore_3
    //   43: aload_3
    //   44: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectTnt.lIIllllIllI : [I
    //   47: iconst_2
    //   48: iaload
    //   49: aload_2
    //   50: invokevirtual init : (ILjava/security/Key;)V
    //   53: new java/lang/String
    //   56: dup
    //   57: aload_3
    //   58: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   61: aload_0
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   68: invokevirtual decode : ([B)[B
    //   71: invokevirtual doFinal : ([B)[B
    //   74: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   77: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   80: areturn
    //   81: astore_2
    //   82: aload_2
    //   83: invokevirtual printStackTrace : ()V
    //   86: aconst_null
    //   87: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	88	3	lllllllllllllllIlllIIIlIIllIIlII	C
    //   0	88	1	lllllllllllllllIlllIIIlIIllIlIII	Ljava/lang/String;
    //   0	88	0	lllllllllllllllIlllIIIlIIllIlIIl	Ljava/lang/String;
    //   0	88	2	lllllllllllllllIlllIIIlIIllIIlIl	D
    //   0	88	0	lllllllllllllllIlllIIIlIIllIIlll	Z
    //   0	88	1	lllllllllllllllIlllIIIlIIllIIllI	Ljava/lang/Exception;
    //   43	38	3	lllllllllllllllIlllIIIlIIllIlIll	Ljavax/crypto/Cipher;
    //   36	45	2	lllllllllllllllIlllIIIlIIllIllII	Ljavax/crypto/spec/SecretKeySpec;
    //   82	4	2	lllllllllllllllIlllIIIlIIllIlIlI	Ljava/lang/Exception;
    // Exception table:
    //   from	to	target	type
    //   0	80	81	java/lang/Exception
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\killeffects\KillEffectTnt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */