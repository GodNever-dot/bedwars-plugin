package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ClientPauseMode;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.ClientType;
import com.axeelheaven.hbedwars.libs.jedis.jedis.args.UnblockType;
import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ClientKillParams;

public interface ClientCommands {
  String clientKill(String paramString);
  
  String clientKill(String paramString, int paramInt);
  
  long clientKill(ClientKillParams paramClientKillParams);
  
  String clientGetname();
  
  String clientList();
  
  String clientList(ClientType paramClientType);
  
  String clientList(long... paramVarArgs);
  
  String clientInfo();
  
  String clientSetname(String paramString);
  
  long clientId();
  
  long clientUnblock(long paramLong);
  
  long clientUnblock(long paramLong, UnblockType paramUnblockType);
  
  String clientPause(long paramLong);
  
  String clientPause(long paramLong, ClientPauseMode paramClientPauseMode);
  
  String clientNoEvictOn();
  
  String clientNoEvictOff();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\ClientCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */