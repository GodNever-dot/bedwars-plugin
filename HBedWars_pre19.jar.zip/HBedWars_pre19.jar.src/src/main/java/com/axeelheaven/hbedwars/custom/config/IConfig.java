package com.axeelheaven.hbedwars.custom.config;

import java.util.Collection;
import java.util.List;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.FileConfigurationOptions;
import java.io.File;

public interface IConfig {
  boolean isSet(String paramString);
  
  FileConfiguration getConfig();
  
  ConfigurationSection getConfigurationSection(String paramString1, String paramString2);
  
  <T> Object get(String paramString, T paramT);
  
  List<Double> getDoubleList(String paramString);
  
  short getShort(String paramString);
  
  long getLong(String paramString);
  
  List<Short> getShortList(String paramString);
  
  List<Character> getCharList(String paramString);
  
  boolean isConfigurationSection(String paramString);
  
  char getChar(String paramString, char paramChar);
  
  FileConfigurationOptions options();
  
  long getLong(String paramString, long paramLong);
  
  List<Float> getFloatList(String paramString);
  
  double getDouble(String paramString, double paramDouble);
  
  List<String> getStringList(String paramString);
  
  int getInt(String paramString);
  
  List<Byte> getByteList(String paramString);
  
  List<String> getComments(String paramString);
  
  String getString(String paramString);
  
  List<Long> getLongList(String paramString);
  
  Object getDefault(String paramString);
  
  int getInt(String paramString, int paramInt);
  
  boolean contains(String paramString);
  
  List<?> getList(String paramString, List<?> paramList);
  
  float getFloat(String paramString, float paramFloat);
  
  boolean getBoolean(String paramString, boolean paramBoolean);
  
  char getChar(String paramString);
  
  List<?> getList(String paramString);
  
  boolean getBoolean(String paramString);
  
  Collection<String> getKeys(boolean paramBoolean);
  
  List<Integer> getIntList(String paramString);
  
  float getFloat(String paramString);
  
  double getDouble(String paramString);
  
  Object get(String paramString);
  
  ConfigurationSection getConfigurationSection(String paramString);
  
  void addDefault(String paramString, Object paramObject);
  
  void addDefault(String paramString, Object paramObject, String... paramVarArgs);
  
  short getShort(String paramString, short paramShort);
  
  void set(String paramString, Object paramObject);
  
  List<Boolean> getBooleanList(String paramString);
  
  byte getByte(String paramString);
  
  String getString(String paramString1, String paramString2);
  
  byte getByte(String paramString, byte paramByte);
  
  Collection<String> getKeys();
  
  void set(String paramString, Object paramObject, String... paramVarArgs);
  
  void save();
  
  void reload();
  
  File getFile();
  
  String getName();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\config\IConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */