/*    */ package com.axeelheaven.hbedwars.api.events.game.player;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.api.arena.Arena;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsPlayerRejoinEvent extends Event {
/*    */   private final Arena arena;
/*    */   private final Player player;
/* 11 */   private static final HandlerList handlerList = new HandlerList(); public Arena getArena() {
/* 12 */     return this.arena; } public Player getPlayer() {
/* 13 */     return this.player;
/*    */   }
/*    */   public BedWarsPlayerRejoinEvent(Arena arena, Player player) {
/* 16 */     this.arena = arena;
/* 17 */     this.player = player;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 22 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 26 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\game\player\BedWarsPlayerRejoinEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */