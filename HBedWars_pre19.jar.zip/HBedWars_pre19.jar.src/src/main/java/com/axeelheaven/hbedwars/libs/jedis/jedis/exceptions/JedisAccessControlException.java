/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ public class JedisAccessControlException
/*    */   extends JedisDataException {
/*    */   public JedisAccessControlException(String message) {
/*  6 */     super(message);
/*    */   }
/*    */   
/*    */   public JedisAccessControlException(Throwable cause) {
/* 10 */     super(cause);
/*    */   }
/*    */   
/*    */   public JedisAccessControlException(String message, Throwable cause) {
/* 14 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\JedisAccessControlException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */