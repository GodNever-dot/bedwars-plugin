/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ public class LPosParams
/*    */   extends Params implements IParams {
/*    */   private static final String RANK = "RANK";
/*    */   private static final String MAXLEN = "MAXLEN";
/*    */   
/*    */   public static LPosParams lPosParams() {
/* 12 */     return new LPosParams();
/*    */   }
/*    */   
/*    */   public LPosParams rank(int rank) {
/* 16 */     addParam("RANK", Integer.valueOf(rank));
/* 17 */     return this;
/*    */   }
/*    */   
/*    */   public LPosParams maxlen(int maxLen) {
/* 21 */     addParam("MAXLEN", Integer.valueOf(maxLen));
/* 22 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 27 */     if (contains("RANK")) {
/* 28 */       args.add("RANK");
/* 29 */       args.add(Protocol.toByteArray(((Integer)getParam("RANK")).intValue()));
/*    */     } 
/*    */     
/* 32 */     if (contains("MAXLEN")) {
/* 33 */       args.add("MAXLEN");
/* 34 */       args.add(Protocol.toByteArray(((Integer)getParam("MAXLEN")).intValue()));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\LPosParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */