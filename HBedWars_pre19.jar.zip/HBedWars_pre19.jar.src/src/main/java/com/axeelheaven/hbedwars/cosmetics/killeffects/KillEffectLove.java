package com.axeelheaven.hbedwars.cosmetics.killeffects;

import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class KillEffectLove extends KillEffect {
    private final BedWars plugin;
    
    public KillEffectLove(BedWars plugin) {
        super(plugin);
        this.plugin = plugin;
    }
    
    @Override
    public void play(Player killer, Player victim) {
        Location location = victim.getLocation();
        
        for (int i = 0; i < 10; i++) {
            location.getWorld().playEffect(location.clone().add(0, 1, 0), Effect.HEART, 0);
        }
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\killeffects\KillEffectLove.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */