package com.axeelheaven.hbedwars.custom.holograms;

import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.ArrayList;
import java.util.List;

public class HologramManager implements Listener {
    private final BedWars plugin;
    private final List<Hologram> holograms;

    public HologramManager(BedWars plugin) {
        this.plugin = plugin;
        this.holograms = new ArrayList<>();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        check(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        check(event.getPlayer());
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent event) {
        check(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        check(event.getPlayer());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        check(event.getEntity());
    }

    @EventHandler
    public void changeWorld(PlayerChangedWorldEvent event) {
        check(event.getPlayer());
    }

    public void check(Player player) {
        for (Hologram hologram : this.holograms) {
            hologram.update(player);
        }
    }

    public Hologram createHologram(Location location) {
        Hologram hologram = null;
        try {
            Class<?>[] paramTypes = new Class<?>[2];
            paramTypes[0] = BedWars.class;
            paramTypes[1] = Location.class;
            Object[] params = new Object[2];
            params[0] = this.plugin;
            params[1] = location.clone();
            hologram = new Hologram(this.plugin, location.clone());
            this.holograms.add(hologram);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hologram;
    }

    public void removeHologram(Hologram hologram) {
        if (this.holograms.contains(hologram)) {
            hologram.remove();
            this.holograms.remove(hologram);
        }
    }

    public List<Hologram> getHolograms() {
        return this.holograms;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\holograms\HologramManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */