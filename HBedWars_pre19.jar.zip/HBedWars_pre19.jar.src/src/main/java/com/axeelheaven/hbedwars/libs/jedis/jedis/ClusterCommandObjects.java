/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.commands.ProtocolCommand;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.IParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.params.ScanParams;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.resps.ScanResult;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.JedisClusterHashTag;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class ClusterCommandObjects
/*    */   extends CommandObjects
/*    */ {
/*    */   private static final String CLUSTER_UNSUPPORTED_MESSAGE = "Not supported in cluster mode.";
/*    */   private static final String KEYS_PATTERN_MESSAGE = "Cluster mode only supports KEYS command with pattern containing hash-tag ( curly-brackets enclosed string )";
/*    */   private static final String SCAN_PATTERN_MESSAGE = "Cluster mode only supports SCAN command with MATCH pattern containing hash-tag ( curly-brackets enclosed string )";
/*    */   
/*    */   protected ClusterCommandArguments commandArguments(ProtocolCommand command) {
/* 18 */     return new ClusterCommandArguments(command);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CommandObject<Long> dbSize() {
/* 25 */     throw new UnsupportedOperationException("Not supported in cluster mode.");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final CommandObject<Set<String>> keys(String pattern) {
/* 36 */     if (!JedisClusterHashTag.isClusterCompliantMatchPattern(pattern)) {
/* 37 */       throw new IllegalArgumentException("Cluster mode only supports KEYS command with pattern containing hash-tag ( curly-brackets enclosed string )");
/*    */     }
/* 39 */     return new CommandObject<>(commandArguments(Protocol.Command.KEYS).key(pattern).processKey(pattern), BuilderFactory.STRING_SET);
/*    */   }
/*    */ 
/*    */   
/*    */   public final CommandObject<Set<byte[]>> keys(byte[] pattern) {
/* 44 */     if (!JedisClusterHashTag.isClusterCompliantMatchPattern(pattern)) {
/* 45 */       throw new IllegalArgumentException("Cluster mode only supports KEYS command with pattern containing hash-tag ( curly-brackets enclosed string )");
/*    */     }
/* 47 */     return new CommandObject<>(commandArguments(Protocol.Command.KEYS).key(pattern).processKey(pattern), BuilderFactory.BINARY_SET);
/*    */   }
/*    */ 
/*    */   
/*    */   public final CommandObject<ScanResult<String>> scan(String cursor) {
/* 52 */     throw new IllegalArgumentException("Cluster mode only supports SCAN command with MATCH pattern containing hash-tag ( curly-brackets enclosed string )");
/*    */   }
/*    */ 
/*    */   
/*    */   public final CommandObject<ScanResult<String>> scan(String cursor, ScanParams params) {
/* 57 */     String match = params.match();
/* 58 */     if (match == null || !JedisClusterHashTag.isClusterCompliantMatchPattern(match)) {
/* 59 */       throw new IllegalArgumentException("Cluster mode only supports SCAN command with MATCH pattern containing hash-tag ( curly-brackets enclosed string )");
/*    */     }
/* 61 */     return new CommandObject<>(commandArguments(Protocol.Command.SCAN).add(cursor).addParams((IParams)params).processKey(match), BuilderFactory.SCAN_RESPONSE);
/*    */   }
/*    */ 
/*    */   
/*    */   public final CommandObject<ScanResult<String>> scan(String cursor, ScanParams params, String type) {
/* 66 */     String match = params.match();
/* 67 */     if (match == null || !JedisClusterHashTag.isClusterCompliantMatchPattern(match)) {
/* 68 */       throw new IllegalArgumentException("Cluster mode only supports SCAN command with MATCH pattern containing hash-tag ( curly-brackets enclosed string )");
/*    */     }
/* 70 */     return new CommandObject<>(commandArguments(Protocol.Command.SCAN).add(cursor).addParams((IParams)params).processKey(match).add(Protocol.Keyword.TYPE).add(type), BuilderFactory.SCAN_RESPONSE);
/*    */   }
/*    */ 
/*    */   
/*    */   public final CommandObject<ScanResult<byte[]>> scan(byte[] cursor) {
/* 75 */     throw new IllegalArgumentException("Cluster mode only supports SCAN command with MATCH pattern containing hash-tag ( curly-brackets enclosed string )");
/*    */   }
/*    */ 
/*    */   
/*    */   public final CommandObject<ScanResult<byte[]>> scan(byte[] cursor, ScanParams params) {
/* 80 */     byte[] match = params.binaryMatch();
/* 81 */     if (match == null || !JedisClusterHashTag.isClusterCompliantMatchPattern(match)) {
/* 82 */       throw new IllegalArgumentException("Cluster mode only supports SCAN command with MATCH pattern containing hash-tag ( curly-brackets enclosed string )");
/*    */     }
/* 84 */     return new CommandObject<>(commandArguments(Protocol.Command.SCAN).add(cursor).addParams((IParams)params).processKey(match), BuilderFactory.SCAN_BINARY_RESPONSE);
/*    */   }
/*    */ 
/*    */   
/*    */   public final CommandObject<ScanResult<byte[]>> scan(byte[] cursor, ScanParams params, byte[] type) {
/* 89 */     byte[] match = params.binaryMatch();
/* 90 */     if (match == null || !JedisClusterHashTag.isClusterCompliantMatchPattern(match)) {
/* 91 */       throw new IllegalArgumentException("Cluster mode only supports SCAN command with MATCH pattern containing hash-tag ( curly-brackets enclosed string )");
/*    */     }
/* 93 */     return new CommandObject<>(commandArguments(Protocol.Command.SCAN).add(cursor).addParams((IParams)params).processKey(match).add(Protocol.Keyword.TYPE).add(type), BuilderFactory.SCAN_BINARY_RESPONSE);
/*    */   }
/*    */ 
/*    */   
/*    */   public final CommandObject<Long> waitReplicas(int replicas, long timeout) {
/* 98 */     throw new UnsupportedOperationException("Not supported in cluster mode.");
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\ClusterCommandObjects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */