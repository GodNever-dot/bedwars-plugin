package com.axeelheaven.hbedwars.custom.menus.interfaces;

import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public interface MenuActionInterface {
  Object content();
  
  String serialize();
  
  boolean execute(Player paramPlayer);
  
  void onClick(Player player, InventoryClickEvent event);
  
  String name(Player paramPlayer, String paramString);
  
  List<String> lore(Player paramPlayer, List<String> paramList);
  
  void execute(Player player, ItemStack item);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\menus\interfaces\MenuActionInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */