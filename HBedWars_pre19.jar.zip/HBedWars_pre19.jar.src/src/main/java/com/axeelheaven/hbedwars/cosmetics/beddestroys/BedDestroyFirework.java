package com.axeelheaven.hbedwars.cosmetics.beddestroys;

import com.axeelheaven.hbedwars.BedWars;
import java.util.Random;

public class BedDestroyFirework extends BedDestroy {
  public void execute(boolean llllllllllllllllllIllllllIIIllII) {
    // Byte code:
    //   0: aload_0
    //   1: getfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   4: invokevirtual getUtil : ()Lcom/axeelheaven/hbedwars/util/Util;
    //   7: aload_1
    //   8: invokestatic builder : ()Lorg/bukkit/FireworkEffect$Builder;
    //   11: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   14: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   17: iconst_1
    //   18: iaload
    //   19: iaload
    //   20: invokevirtual flicker : (Z)Lorg/bukkit/FireworkEffect$Builder;
    //   23: getstatic org/bukkit/FireworkEffect$Type.BALL : Lorg/bukkit/FireworkEffect$Type;
    //   26: invokevirtual with : (Lorg/bukkit/FireworkEffect$Type;)Lorg/bukkit/FireworkEffect$Builder;
    //   29: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   32: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   35: iconst_2
    //   36: iaload
    //   37: iaload
    //   38: anewarray org/bukkit/Color
    //   41: dup
    //   42: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   45: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   48: iconst_3
    //   49: iaload
    //   50: iaload
    //   51: aload_0
    //   52: getfield random : Ljava/util/Random;
    //   55: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   58: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   61: bipush #9
    //   63: iaload
    //   64: iaload
    //   65: invokevirtual nextInt : (I)I
    //   68: aload_0
    //   69: getfield random : Ljava/util/Random;
    //   72: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   75: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   78: bipush #9
    //   80: iaload
    //   81: iaload
    //   82: invokevirtual nextInt : (I)I
    //   85: aload_0
    //   86: getfield random : Ljava/util/Random;
    //   89: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   92: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   95: bipush #9
    //   97: iaload
    //   98: iaload
    //   99: invokevirtual nextInt : (I)I
    //   102: invokestatic fromBGR : (III)Lorg/bukkit/Color;
    //   105: aastore
    //   106: dup
    //   107: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   110: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   113: iconst_1
    //   114: iaload
    //   115: iaload
    //   116: aload_0
    //   117: getfield random : Ljava/util/Random;
    //   120: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   123: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   126: bipush #9
    //   128: iaload
    //   129: iaload
    //   130: invokevirtual nextInt : (I)I
    //   133: aload_0
    //   134: getfield random : Ljava/util/Random;
    //   137: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   140: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   143: bipush #9
    //   145: iaload
    //   146: iaload
    //   147: invokevirtual nextInt : (I)I
    //   150: aload_0
    //   151: getfield random : Ljava/util/Random;
    //   154: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   157: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   160: bipush #9
    //   162: iaload
    //   163: iaload
    //   164: invokevirtual nextInt : (I)I
    //   167: invokestatic fromBGR : (III)Lorg/bukkit/Color;
    //   170: aastore
    //   171: invokevirtual withColor : ([Lorg/bukkit/Color;)Lorg/bukkit/FireworkEffect$Builder;
    //   174: aload_0
    //   175: getfield random : Ljava/util/Random;
    //   178: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   181: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   184: bipush #9
    //   186: iaload
    //   187: iaload
    //   188: invokevirtual nextInt : (I)I
    //   191: aload_0
    //   192: getfield random : Ljava/util/Random;
    //   195: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   198: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   201: bipush #9
    //   203: iaload
    //   204: iaload
    //   205: invokevirtual nextInt : (I)I
    //   208: aload_0
    //   209: getfield random : Ljava/util/Random;
    //   212: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIIII : [I
    //   215: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   218: bipush #9
    //   220: iaload
    //   221: iaload
    //   222: invokevirtual nextInt : (I)I
    //   225: invokestatic fromBGR : (III)Lorg/bukkit/Color;
    //   228: invokevirtual withFade : (Lorg/bukkit/Color;)Lorg/bukkit/FireworkEffect$Builder;
    //   231: invokevirtual build : ()Lorg/bukkit/FireworkEffect;
    //   234: invokevirtual instantFirework : (Lorg/bukkit/Location;Lorg/bukkit/FireworkEffect;)V
    //   237: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	238	0	llllllllllllllllllIllllllIIIllll	D
    //   0	238	0	llllllllllllllllllIllllllIIIllIl	J
    //   0	238	0	llllllllllllllllllIllllllIIlIIII	Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework;
    //   0	238	1	llllllllllllllllllIllllllIIlIIIl	Lorg/bukkit/Location;
    //   0	238	1	llllllllllllllllllIllllllIIIllII	Z
    //   0	238	1	llllllllllllllllllIllllllIIIlllI	Ljava/lang/String;
  }
  
  private static String lIIIIllllIII(int llllllllllllllllllIlllllIllIIIIl, double llllllllllllllllllIlllllIllIIIII) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   22: bipush #14
    //   24: iaload
    //   25: invokestatic copyOf : ([BI)[B
    //   28: ldc 'DES'
    //   30: invokespecial <init> : ([BLjava/lang/String;)V
    //   33: astore_2
    //   34: ldc 'DES'
    //   36: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   39: astore_3
    //   40: aload_3
    //   41: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   44: iconst_3
    //   45: iaload
    //   46: aload_2
    //   47: invokevirtual init : (ILjava/security/Key;)V
    //   50: new java/lang/String
    //   53: dup
    //   54: aload_3
    //   55: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   58: aload_0
    //   59: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   62: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   65: invokevirtual decode : ([B)[B
    //   68: invokevirtual doFinal : ([B)[B
    //   71: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   74: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   77: areturn
    //   78: astore_2
    //   79: aload_2
    //   80: invokevirtual printStackTrace : ()V
    //   83: aconst_null
    //   84: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	85	3	llllllllllllllllllIlllllIlIllllI	D
    //   0	85	1	llllllllllllllllllIlllllIllIIIlI	Ljava/lang/String;
    //   0	85	2	llllllllllllllllllIlllllIlIlllll	I
    //   0	85	0	llllllllllllllllllIlllllIllIIIll	Ljava/lang/String;
    //   0	85	1	llllllllllllllllllIlllllIllIIIII	D
    //   0	85	0	llllllllllllllllllIlllllIllIIIIl	I
    //   79	4	2	llllllllllllllllllIlllllIllIIlII	Ljava/lang/Exception;
    //   40	38	3	llllllllllllllllllIlllllIllIIlIl	Ljavax/crypto/Cipher;
    //   34	44	2	llllllllllllllllllIlllllIllIIllI	Ljavax/crypto/spec/SecretKeySpec;
    // Exception table:
    //   from	to	target	type
    //   0	77	78	java/lang/Exception
  }
  
  public BedDestroyFirework(String llllllllllllllllllIlllllIllllIll, String llllllllllllllllllIllllllIIIIIIl, char llllllllllllllllllIlllllIllllllI, boolean llllllllllllllllllIlllllIlllllll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: iload_3
    //   3: iload #4
    //   5: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   8: aload_0
    //   9: aload_1
    //   10: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   13: aload_0
    //   14: new java/util/Random
    //   17: dup
    //   18: invokespecial <init> : ()V
    //   21: putfield random : Ljava/util/Random;
    //   24: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	25	2	llllllllllllllllllIlllllIllllIlI	Ljava/lang/String;
    //   0	25	3	llllllllllllllllllIllllllIIIIllI	I
    //   0	25	3	llllllllllllllllllIlllllIllllllI	C
    //   0	25	4	llllllllllllllllllIlllllIllllIII	Ljava/lang/String;
    //   0	25	2	llllllllllllllllllIllllllIIIIIIl	Ljava/lang/String;
    //   0	25	3	llllllllllllllllllIlllllIllllIIl	F
    //   0	25	4	llllllllllllllllllIlllllIlllllll	Z
    //   0	25	1	llllllllllllllllllIllllllIIIIIll	Lcom/axeelheaven/hbedwars/BedWars;
    //   0	25	0	llllllllllllllllllIlllllIlllllII	Ljava/lang/String;
    //   0	25	2	llllllllllllllllllIllllllIIIIIlI	I
    //   0	25	1	llllllllllllllllllIlllllIllllIll	Ljava/lang/String;
    //   0	25	1	llllllllllllllllllIllllllIIIIlIl	I
    //   0	25	0	llllllllllllllllllIllllllIIIIIII	C
    //   0	25	0	llllllllllllllllllIlllllIlllllIl	Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework;
    //   0	25	4	llllllllllllllllllIllllllIIIIlII	B
  }
  
  static {
    lIIIIlllllll();
    lIIIIllllIIl();
    llIIII();
  }
  
  private static void llIIII() {
    lIIII = new int[lIlIlIIIll[0]];
    lIIII[lIlIlIIIll[1]] = lIlIlIIIIl[lIlIlIIIll[1]].length();
    lIIII[lIlIlIIIll[2]] = lIlIlIIIIl[lIlIlIIIll[2]].length();
    lIIII[lIlIlIIIll[3]] = (lIlIlIIIll[4] ^ lIlIlIIIll[5]) & (lIlIlIIIll[6] ^ lIlIlIIIll[7] ^ lIlIlIIIll[8]);
    lIIII[lIlIlIIIll[9]] = lIlIlIIIll[10] + lIlIlIIIll[11] - lIlIlIIIll[12] + lIlIlIIIll[13];
  }
  
  private static void lIIIIlllllll() {
    lIlIlIIIll = new int[15];
    lIlIlIIIll[0] = 37 + 16 - 41 + 183 ^ 56 + 129 - 69 + 83;
    lIlIlIIIll[1] = (0x1E ^ 0x77 ^ 0x1 ^ 0x35) & (0x82 ^ 0xAE ^ 0x26 ^ 0x57 ^ -" ".length());
    lIlIlIIIll[2] = " ".length();
    lIlIlIIIll[3] = "  ".length();
    lIlIlIIIll[4] = 0x24 ^ 0x11 ^ 0x6A ^ 0x1E;
    lIlIlIIIll[5] = 0xD8 ^ 0xB5;
    lIlIlIIIll[6] = 187 + 91 - 160 + 72;
    lIlIlIIIll[7] = (0xB1 ^ 0xAE) + (0x90 ^ 0x80) - -(0x7B ^ 0x72) + (0xE2 ^ 0xB8);
    lIlIlIIIll[8] = -" ".length();
    lIlIlIIIll[9] = "   ".length();
    lIlIlIIIll[10] = 0xA2 ^ 0xAA ^ 0x3A ^ 0x48;
    lIlIlIIIll[11] = 5 + 91 - -26 + 41;
    lIlIlIIIll[12] = 0x3D ^ 0x6F;
    lIlIlIIIll[13] = 129 + 92 - 159 + 116 ^ 123 + 93 - 215 + 133;
    lIlIlIIIll[14] = 0x14 ^ 0x1C;
  }
  
  private static String lIIIIlllIIll(String llllllllllllllllllIlllllIllIlllI, float llllllllllllllllllIlllllIllIllIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc 'Blowfish'
    //   21: invokespecial <init> : ([BLjava/lang/String;)V
    //   24: astore_2
    //   25: ldc 'Blowfish'
    //   27: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   30: astore_3
    //   31: aload_3
    //   32: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyFirework.lIlIlIIIll : [I
    //   35: iconst_3
    //   36: iaload
    //   37: aload_2
    //   38: invokevirtual init : (ILjava/security/Key;)V
    //   41: new java/lang/String
    //   44: dup
    //   45: aload_3
    //   46: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   49: aload_0
    //   50: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   53: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   56: invokevirtual decode : ([B)[B
    //   59: invokevirtual doFinal : ([B)[B
    //   62: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   65: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   68: areturn
    //   69: astore_2
    //   70: aload_2
    //   71: invokevirtual printStackTrace : ()V
    //   74: aconst_null
    //   75: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	76	3	llllllllllllllllllIlllllIllIlIll	F
    //   0	76	0	llllllllllllllllllIlllllIlllIIII	Ljava/lang/String;
    //   0	76	0	llllllllllllllllllIlllllIllIlllI	Ljava/lang/String;
    //   70	4	2	llllllllllllllllllIlllllIlllIIIl	Ljava/lang/Exception;
    //   0	76	1	llllllllllllllllllIlllllIllIllll	Ljava/lang/String;
    //   0	76	1	llllllllllllllllllIlllllIllIllIl	F
    //   0	76	2	llllllllllllllllllIlllllIllIllII	Ljava/lang/Exception;
    //   31	38	3	llllllllllllllllllIlllllIlllIIlI	Ljavax/crypto/Cipher;
    //   25	44	2	llllllllllllllllllIlllllIlllIIll	Ljavax/crypto/spec/SecretKeySpec;
    // Exception table:
    //   from	to	target	type
    //   0	68	69	java/lang/Exception
  }
  
  private static void lIIIIllllIIl() {
    lIlIlIIIIl = new String[lIlIlIIIll[3]];
    lIlIlIIIIl[lIlIlIIIll[1]] = lIIIIlllIIll("grXDuK7AZ04=", "DALIY");
    lIlIlIIIIl[lIlIlIIIll[2]] = lIIIIllllIII("MiGE0YtM2go=", "HyalN");
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\beddestroys\BedDestroyFirework.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */