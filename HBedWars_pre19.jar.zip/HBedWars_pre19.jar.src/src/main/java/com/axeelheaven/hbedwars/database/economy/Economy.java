package com.axeelheaven.hbedwars.database.economy;

import org.bukkit.entity.Player;

public interface Economy {
  void removePoints(Player paramPlayer, double paramDouble);
  
  double getPoints(Player paramPlayer);
  
  void addPoints(Player paramPlayer, double paramDouble);
  
  void setPoints(Player paramPlayer, double paramDouble);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\database\economy\Economy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */