/*     */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*     */ 
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.StreamEntryID;
/*     */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XAddParams
/*     */   implements IParams
/*     */ {
/*  16 */   private static final byte[] NEW_ENTRY = SafeEncoder.encode(StreamEntryID.NEW_ENTRY.toString());
/*     */   
/*     */   private byte[] id;
/*     */   
/*     */   private Long maxLen;
/*     */   
/*     */   private boolean approximateTrimming;
/*     */   
/*     */   private boolean exactTrimming;
/*     */   
/*     */   private boolean nomkstream;
/*     */   
/*     */   private String minId;
/*     */   
/*     */   private Long limit;
/*     */   
/*     */   public static XAddParams xAddParams() {
/*  33 */     return new XAddParams();
/*     */   }
/*     */   
/*     */   public XAddParams noMkStream() {
/*  37 */     this.nomkstream = true;
/*  38 */     return this;
/*     */   }
/*     */   
/*     */   public XAddParams id(byte[] id) {
/*  42 */     this.id = Arrays.copyOf(id, id.length);
/*  43 */     return this;
/*     */   }
/*     */   
/*     */   public XAddParams id(String id) {
/*  47 */     this.id = SafeEncoder.encode(id);
/*  48 */     return this;
/*     */   }
/*     */   
/*     */   public XAddParams id(StreamEntryID id) {
/*  52 */     return id(id.toString());
/*     */   }
/*     */   
/*     */   public XAddParams id(long time, long sequence) {
/*  56 */     return id(time + "-" + sequence);
/*     */   }
/*     */   
/*     */   public XAddParams id(long time) {
/*  60 */     return id(time + "-*");
/*     */   }
/*     */   
/*     */   public XAddParams maxLen(long maxLen) {
/*  64 */     this.maxLen = Long.valueOf(maxLen);
/*  65 */     return this;
/*     */   }
/*     */   
/*     */   public XAddParams minId(String minId) {
/*  69 */     this.minId = minId;
/*  70 */     return this;
/*     */   }
/*     */   
/*     */   public XAddParams approximateTrimming() {
/*  74 */     this.approximateTrimming = true;
/*  75 */     return this;
/*     */   }
/*     */   
/*     */   public XAddParams exactTrimming() {
/*  79 */     this.exactTrimming = true;
/*  80 */     return this;
/*     */   }
/*     */   
/*     */   public XAddParams limit(long limit) {
/*  84 */     this.limit = Long.valueOf(limit);
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParams(CommandArguments args) {
/*  91 */     if (this.nomkstream) {
/*  92 */       args.add(Protocol.Keyword.NOMKSTREAM.getRaw());
/*     */     }
/*     */     
/*  95 */     if (this.maxLen != null) {
/*  96 */       args.add(Protocol.Keyword.MAXLEN.getRaw());
/*     */       
/*  98 */       if (this.approximateTrimming) {
/*  99 */         args.add(Protocol.BYTES_TILDE);
/* 100 */       } else if (this.exactTrimming) {
/* 101 */         args.add(Protocol.BYTES_EQUAL);
/*     */       } 
/*     */       
/* 104 */       args.add(Protocol.toByteArray(this.maxLen.longValue()));
/* 105 */     } else if (this.minId != null) {
/* 106 */       args.add(Protocol.Keyword.MINID.getRaw());
/*     */       
/* 108 */       if (this.approximateTrimming) {
/* 109 */         args.add(Protocol.BYTES_TILDE);
/* 110 */       } else if (this.exactTrimming) {
/* 111 */         args.add(Protocol.BYTES_EQUAL);
/*     */       } 
/*     */       
/* 114 */       args.add(SafeEncoder.encode(this.minId));
/*     */     } 
/*     */     
/* 117 */     if (this.limit != null) {
/* 118 */       args.add(Protocol.Keyword.LIMIT.getRaw());
/* 119 */       args.add(Protocol.toByteArray(this.limit.longValue()));
/*     */     } 
/*     */     
/* 122 */     args.add((this.id != null) ? this.id : NEW_ENTRY);
/*     */   }
/*     */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\XAddParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */