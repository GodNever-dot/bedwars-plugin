/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.json;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
/*    */ import com.axeelheaven.hbedwars.libs.json.JSONArray;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public interface RedisJsonPipelineCommands
/*    */ {
/*    */   default Response<String> jsonSet(String key, Object object) {
/* 11 */     return jsonSet(key, Path2.ROOT_PATH, object);
/*    */   }
/*    */   
/*    */   default Response<String> jsonSetWithEscape(String key, Object object) {
/* 15 */     return jsonSetWithEscape(key, Path2.ROOT_PATH, object);
/*    */   }
/*    */   
/*    */   default Response<String> jsonSetLegacy(String key, Object pojo) {
/* 19 */     return jsonSet(key, Path.ROOT_PATH, pojo);
/*    */   }
/*    */   
/*    */   default Response<String> jsonSet(String key, Object object, JsonSetParams params) {
/* 23 */     return jsonSet(key, Path2.ROOT_PATH, object, params);
/*    */   }
/*    */   
/*    */   default Response<String> jsonSetWithEscape(String key, Object object, JsonSetParams params) {
/* 27 */     return jsonSetWithEscape(key, Path2.ROOT_PATH, object, params);
/*    */   }
/*    */   
/*    */   default Response<String> jsonSetLegacy(String key, Object pojo, JsonSetParams params) {
/* 31 */     return jsonSet(key, Path.ROOT_PATH, pojo, params);
/*    */   }
/*    */ 
/*    */   
/*    */   Response<String> jsonSet(String paramString, Path2 paramPath2, Object paramObject);
/*    */ 
/*    */   
/*    */   Response<String> jsonSetWithEscape(String paramString, Path2 paramPath2, Object paramObject);
/*    */ 
/*    */   
/*    */   Response<String> jsonSet(String paramString, Path paramPath, Object paramObject);
/*    */ 
/*    */   
/*    */   Response<String> jsonSet(String paramString, Path2 paramPath2, Object paramObject, JsonSetParams paramJsonSetParams);
/*    */   
/*    */   Response<String> jsonSetWithEscape(String paramString, Path2 paramPath2, Object paramObject, JsonSetParams paramJsonSetParams);
/*    */   
/*    */   Response<String> jsonSet(String paramString, Path paramPath, Object paramObject, JsonSetParams paramJsonSetParams);
/*    */   
/*    */   Response<Object> jsonGet(String paramString);
/*    */   
/*    */   <T> Response<T> jsonGet(String paramString, Class<T> paramClass);
/*    */   
/*    */   Response<Object> jsonGet(String paramString, Path2... paramVarArgs);
/*    */   
/*    */   Response<Object> jsonGet(String paramString, Path... paramVarArgs);
/*    */   
/*    */   <T> Response<T> jsonGet(String paramString, Class<T> paramClass, Path... paramVarArgs);
/*    */   
/*    */   Response<List<JSONArray>> jsonMGet(String... keys) {
/* 61 */     return jsonMGet(Path2.ROOT_PATH, keys);
/*    */   }
/*    */   
/*    */   <T> Response<List<T>> jsonMGet(Class<T> clazz, String... keys) {
/* 65 */     return jsonMGet(Path.ROOT_PATH, clazz, keys);
/*    */   }
/*    */   
/*    */   Response<List<JSONArray>> jsonMGet(Path2 paramPath2, String... paramVarArgs);
/*    */   
/*    */   <T> Response<List<T>> jsonMGet(Path paramPath, Class<T> paramClass, String... paramVarArgs);
/*    */   
/*    */   Response<Long> jsonDel(String paramString);
/*    */   
/*    */   Response<Long> jsonDel(String paramString, Path2 paramPath2);
/*    */   
/*    */   Response<Long> jsonDel(String paramString, Path paramPath);
/*    */   
/*    */   Response<Long> jsonClear(String paramString);
/*    */   
/*    */   Response<Long> jsonClear(String paramString, Path2 paramPath2);
/*    */   
/*    */   Response<Long> jsonClear(String paramString, Path paramPath);
/*    */   
/*    */   Response<List<Boolean>> jsonToggle(String paramString, Path2 paramPath2);
/*    */   
/*    */   Response<String> jsonToggle(String paramString, Path paramPath);
/*    */   
/*    */   Response<Class<?>> jsonType(String paramString);
/*    */   
/*    */   Response<List<Class<?>>> jsonType(String paramString, Path2 paramPath2);
/*    */   
/*    */   Response<Class<?>> jsonType(String paramString, Path paramPath);
/*    */   
/*    */   Response<Long> jsonStrAppend(String paramString, Object paramObject);
/*    */   
/*    */   Response<List<Long>> jsonStrAppend(String paramString, Path2 paramPath2, Object paramObject);
/*    */   
/*    */   Response<Long> jsonStrAppend(String paramString, Path paramPath, Object paramObject);
/*    */   
/*    */   Response<Long> jsonStrLen(String paramString);
/*    */   
/*    */   Response<List<Long>> jsonStrLen(String paramString, Path2 paramPath2);
/*    */   
/*    */   Response<Long> jsonStrLen(String paramString, Path paramPath);
/*    */   
/*    */   Response<List<Long>> jsonArrAppend(String paramString, Path2 paramPath2, Object... paramVarArgs);
/*    */   
/*    */   Response<List<Long>> jsonArrAppendWithEscape(String paramString, Path2 paramPath2, Object... paramVarArgs);
/*    */   
/*    */   Response<Long> jsonArrAppend(String paramString, Path paramPath, Object... paramVarArgs);
/*    */   
/*    */   Response<List<Long>> jsonArrIndex(String paramString, Path2 paramPath2, Object paramObject);
/*    */   
/*    */   Response<List<Long>> jsonArrIndexWithEscape(String paramString, Path2 paramPath2, Object paramObject);
/*    */   
/*    */   Response<Long> jsonArrIndex(String paramString, Path paramPath, Object paramObject);
/*    */   
/*    */   Response<List<Long>> jsonArrInsert(String paramString, Path2 paramPath2, int paramInt, Object... paramVarArgs);
/*    */   
/*    */   Response<List<Long>> jsonArrInsertWithEscape(String paramString, Path2 paramPath2, int paramInt, Object... paramVarArgs);
/*    */   
/*    */   Response<Long> jsonArrInsert(String paramString, Path paramPath, int paramInt, Object... paramVarArgs);
/*    */   
/*    */   Response<Object> jsonArrPop(String paramString);
/*    */   
/*    */   <T> Response<T> jsonArrPop(String paramString, Class<T> paramClass);
/*    */   
/*    */   Response<List<Object>> jsonArrPop(String paramString, Path2 paramPath2);
/*    */   
/*    */   Response<Object> jsonArrPop(String paramString, Path paramPath);
/*    */   
/*    */   <T> Response<T> jsonArrPop(String paramString, Class<T> paramClass, Path paramPath);
/*    */   
/*    */   Response<List<Object>> jsonArrPop(String paramString, Path2 paramPath2, int paramInt);
/*    */   
/*    */   Response<Object> jsonArrPop(String paramString, Path paramPath, int paramInt);
/*    */   
/*    */   <T> Response<T> jsonArrPop(String paramString, Class<T> paramClass, Path paramPath, int paramInt);
/*    */   
/*    */   Response<Long> jsonArrLen(String paramString);
/*    */   
/*    */   Response<List<Long>> jsonArrLen(String paramString, Path2 paramPath2);
/*    */   
/*    */   Response<Long> jsonArrLen(String paramString, Path paramPath);
/*    */   
/*    */   Response<List<Long>> jsonArrTrim(String paramString, Path2 paramPath2, int paramInt1, int paramInt2);
/*    */   
/*    */   Response<Long> jsonArrTrim(String paramString, Path paramPath, int paramInt1, int paramInt2);
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\json\RedisJsonPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */