/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ public class InvalidURIException
/*    */   extends JedisException {
/*    */   private static final long serialVersionUID = -781691993326357802L;
/*    */   
/*    */   public InvalidURIException(String message) {
/*  8 */     super(message);
/*    */   }
/*    */   
/*    */   public InvalidURIException(Throwable cause) {
/* 12 */     super(cause);
/*    */   }
/*    */   
/*    */   public InvalidURIException(String message, Throwable cause) {
/* 16 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\InvalidURIException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */