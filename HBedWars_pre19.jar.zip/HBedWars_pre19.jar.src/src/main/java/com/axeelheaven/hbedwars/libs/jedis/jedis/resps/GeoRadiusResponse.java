/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.GeoCoordinate;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class GeoRadiusResponse
/*    */ {
/*    */   private byte[] member;
/*    */   private double distance;
/*    */   private GeoCoordinate coordinate;
/*    */   private long rawScore;
/*    */   
/*    */   public GeoRadiusResponse(byte[] member) {
/* 15 */     this.member = member;
/*    */   }
/*    */   
/*    */   public void setDistance(double distance) {
/* 19 */     this.distance = distance;
/*    */   }
/*    */   
/*    */   public void setCoordinate(GeoCoordinate coordinate) {
/* 23 */     this.coordinate = coordinate;
/*    */   }
/*    */   
/*    */   public byte[] getMember() {
/* 27 */     return this.member;
/*    */   }
/*    */   
/*    */   public String getMemberByString() {
/* 31 */     return SafeEncoder.encode(this.member);
/*    */   }
/*    */   
/*    */   public double getDistance() {
/* 35 */     return this.distance;
/*    */   }
/*    */   
/*    */   public GeoCoordinate getCoordinate() {
/* 39 */     return this.coordinate;
/*    */   }
/*    */   
/*    */   public long getRawScore() {
/* 43 */     return this.rawScore;
/*    */   }
/*    */   
/*    */   public void setRawScore(long rawScore) {
/* 47 */     this.rawScore = rawScore;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 52 */     if (obj == this) {
/* 53 */       return true;
/*    */     }
/*    */     
/* 56 */     if (!(obj instanceof GeoRadiusResponse)) {
/* 57 */       return false;
/*    */     }
/*    */     
/* 60 */     GeoRadiusResponse response = (GeoRadiusResponse)obj;
/* 61 */     return (Double.compare(this.distance, response.getDistance()) == 0 && this.rawScore == response
/* 62 */       .getRawScore() && this.coordinate.equals(response.coordinate) && 
/* 63 */       Arrays.equals(this.member, response.getMember()));
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\GeoRadiusResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */