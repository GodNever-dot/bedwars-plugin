/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.exceptions;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.HostAndPort;
/*    */ 
/*    */ public class JedisMovedDataException
/*    */   extends JedisRedirectionException {
/*    */   private static final long serialVersionUID = 3878126572474819403L;
/*    */   
/*    */   public JedisMovedDataException(String message, HostAndPort targetNode, int slot) {
/* 10 */     super(message, targetNode, slot);
/*    */   }
/*    */   
/*    */   public JedisMovedDataException(Throwable cause, HostAndPort targetNode, int slot) {
/* 14 */     super(cause, targetNode, slot);
/*    */   }
/*    */   
/*    */   public JedisMovedDataException(String message, Throwable cause, HostAndPort targetNode, int slot) {
/* 18 */     super(message, cause, targetNode, slot);
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\exceptions\JedisMovedDataException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */