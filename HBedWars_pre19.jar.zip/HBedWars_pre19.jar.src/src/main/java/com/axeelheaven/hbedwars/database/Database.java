package com.axeelheaven.hbedwars.database;

import com.axeelheaven.hbedwars.database.cache.Callback;
import com.axeelheaven.hbedwars.database.profile.HData;
import java.util.UUID;

public abstract class Database {
  public abstract boolean connect();
  
  public abstract void get(Callback paramCallback);
  
  static {
  
  }
  
  public abstract boolean exists(UUID paramUUID);
  
  public abstract void create(UUID paramUUID, String paramString);
  
  public abstract void load(HData paramHData);
  
  public abstract void save(HData paramHData);
  
  public abstract boolean tables();
  
  public abstract void close();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\database\Database.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */