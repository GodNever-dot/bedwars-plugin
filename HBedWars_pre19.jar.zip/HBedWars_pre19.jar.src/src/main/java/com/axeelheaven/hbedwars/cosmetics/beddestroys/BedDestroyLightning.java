package com.axeelheaven.hbedwars.cosmetics.beddestroys;

import java.lang.reflect.Constructor;
import org.bukkit.Bukkit;
import org.bukkit.Location;

public class BedDestroyLightning extends BedDestroy {
  static {
    lIllIllIIIll();
    lIllIIlIIlIl();
    lIIIIIlIll();
    lIIIIIlIlI();
  }
  
  private static boolean lIllIllIIllI(boolean lllllllllllllllllIlIIIlIlllIIIll, float lllllllllllllllllIlIIIlIlllIIIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public static Class<?> getNMSClass(String lllllllllllllllllIlIIIlllIIIIIIl) {
    String lllllllllllllllllIlIIIllIlllllII = Bukkit.getServer().getClass().getPackage().getName().split(lIllIlIl[lIllIllI[llIIllllIl[29]]])[lIllIllI[llIIllllIl[24]]];
    try {
      return Class.forName(String.valueOf((new StringBuilder()).append(lIllIlIl[lIllIllI[llIIllllIl[17]]]).append(lllllllllllllllllIlIIIllIlllllII).append(lIllIlIl[lIllIllI[llIIllllIl[33]]]).append(lllllllllllllllllIlIIIlllIIIIIIl)));
    } catch (ClassNotFoundException lllllllllllllllllIlIIIllIlllllll) {
      ClassNotFoundException classNotFoundException1;
      classNotFoundException1.printStackTrace();
      return null;
    } 
  }
  
  private static void lIllIllIIIll() {
    llIIllllIl = new int[100];
    llIIllllIl[0] = 0x9B ^ 0xA5 ^ 0xB2 ^ 0x81;
    llIIllllIl[1] = (71 + 67 - 11 + 26 ^ 87 + 21 - 106 + 130) & (0xB6 ^ 0xA2 ^ 0x49 ^ 0x40 ^ -" ".length());
    llIIllllIl[2] = 0x37 ^ 0x5F;
    llIIllllIl[3] = 0x50 ^ 0x79;
    llIIllllIl[4] = 0xC9 ^ 0xC7;
    llIIllllIl[5] = 0x7F ^ 0x39;
    llIIllllIl[6] = 0xA2 ^ 0x8E ^ 0x18 ^ 0x52;
    llIIllllIl[7] = 0xA3 ^ 0xBE;
    llIIllllIl[8] = 0x6B ^ 0x7C ^ 0x28 ^ 0x6B;
    llIIllllIl[9] = 0x3E ^ 0x57;
    llIIllllIl[10] = 174 + 81 - 74 + 39 ^ 170 + 134 - 225 + 104;
    llIIllllIl[11] = 0xD ^ 0x26 ^ 0x5 ^ 0x1E;
    llIIllllIl[12] = 123 + 100 - 180 + 185 ^ 29 + 101 - 13 + 60;
    llIIllllIl[13] = 0x2A ^ 0x67;
    llIIllllIl[14] = 0x9A ^ 0xB0;
    llIIllllIl[15] = 0x5B ^ 0x37;
    llIIllllIl[16] = 0x95 ^ 0xAA;
    llIIllllIl[17] = " ".length();
    llIIllllIl[18] = 0x8F ^ 0x89 ^ 0xC ^ 0x4D;
    llIIllllIl[19] = 78 + 34 - 78 + 154 ^ 133 + 133 - 250 + 129;
    llIIllllIl[20] = "   ".length() + (0x87 ^ 0xC3) - -(0x6E ^ 0x23) + (0x29 ^ 0x3E);
    llIIllllIl[21] = 187 + 166 - 325 + 171;
    llIIllllIl[22] = "  ".length();
    llIIllllIl[23] = "   ".length();
    llIIllllIl[24] = 0x3B ^ 0x79 ^ 0x2E ^ 0x68;
    llIIllllIl[25] = 0x9B ^ 0xB3 ^ 0x2A ^ 0x7;
    llIIllllIl[26] = 0xFF ^ 0x9F ^ 0xDB ^ 0x80;
    llIIllllIl[27] = 0x61 ^ 0x69;
    llIIllllIl[28] = 0xE6 ^ 0x85;
    llIIllllIl[29] = 0x27 ^ 0x21;
    llIIllllIl[30] = 0xC2 ^ 0x8E ^ 0xA5 ^ 0x95;
    llIIllllIl[31] = 0xAA ^ 0xC0;
    llIIllllIl[32] = 0xB1 ^ 0x83 ^ 0xE9 ^ 0xA3;
    llIIllllIl[33] = 71 + 29 - 97 + 149 ^ 42 + 95 - 0 + 22;
    llIIllllIl[34] = (0xEB ^ 0xC7) + (0x5F ^ 0x3) - 83 + 3 - -43 + 6 + 9 + 55 - -50 + 24;
    llIIllllIl[35] = 31 + 20 - -11 + 95;
    llIIllllIl[36] = 78 + 38 - 109 + 141;
    llIIllllIl[37] = (0x78 ^ 0x4E) + (0x56 ^ 0x6E) - (0x17 ^ 0x50) + (0xD9 ^ 0x87);
    llIIllllIl[38] = 0xF9 ^ 0x8A ^ 0xDD ^ 0x9F;
    llIIllllIl[39] = 0x6D ^ 0x50;
    llIIllllIl[40] = 91 + 107 - 74 + 20 ^ 108 + 126 - 223 + 142;
    llIIllllIl[41] = 0xDC ^ 0x92;
    llIIllllIl[42] = 0x77 ^ 0x7D;
    llIIllllIl[43] = 195 + 17 - 125 + 133 ^ 117 + 133 - 214 + 108;
    llIIllllIl[44] = 0xAF ^ 0x97;
    llIIllllIl[45] = 0x34 ^ 0x22 ^ 0x25 ^ 0x4E;
    llIIllllIl[46] = 147 + 173 - 186 + 69 ^ 63 + 52 - -41 + 36;
    llIIllllIl[47] = 0x3E ^ 0x49;
    llIIllllIl[48] = 0x5F ^ 0x7D;
    llIIllllIl[49] = 0x68 ^ 0x3E ^ 0xDD ^ 0xA8;
    llIIllllIl[50] = 0x63 ^ 0x5A;
    llIIllllIl[51] = (0x7A ^ 0x38) + ((0x39 ^ 0x7C) & (0x1C ^ 0x59 ^ 0xFFFFFFFF)) - -(0x3B ^ 0x28) + (0xC1 ^ 0x87);
    llIIllllIl[52] = 0xD9 ^ 0x9C;
    llIIllllIl[53] = 0x13 ^ 0x7D;
    llIIllllIl[54] = 0x47 ^ 0x75;
    llIIllllIl[55] = 0x3D ^ 0x31;
    llIIllllIl[56] = (0x97 ^ 0xBF) + (0xEA ^ 0xB7) - (0xC9 ^ 0x8D) + 49 + 36 - -41 + 43;
    llIIllllIl[57] = 137 + 17 - 1 + 5;
    llIIllllIl[58] = 50 + 126 - 112 + 88 ^ 27 + 34 - 31 + 111;
    llIIllllIl[59] = 59 + 180 - 168 + 135 ^ 28 + 75 - 21 + 81;
    llIIllllIl[60] = 172 + 40 - 179 + 212 ^ 112 + 95 - 132 + 89;
    llIIllllIl[61] = 0x62 ^ 0x7E;
    llIIllllIl[62] = (0xB3 ^ 0xBD) + (0xE0 ^ 0xA5) - (0xB7 ^ 0xBB) + 156 + 123 - 222 + 104;
    llIIllllIl[63] = 65 + 80 - 90 + 103 + 129 + 76 - 132 + 57 - 171 + 125 - 179 + 133 + (0x4B ^ 0x30);
    llIIllllIl[64] = 134 + 114 - 95 + 37 ^ 138 + 31 - 50 + 42;
    llIIllllIl[65] = 0xBC ^ 0x90;
    llIIllllIl[66] = 0x57 ^ 0x73;
    llIIllllIl[67] = 0x1F ^ 0x30 ^ 0x82 ^ 0x86;
    llIIllllIl[68] = 0x48 ^ 0x1;
    llIIllllIl[69] = 65 + 90 - 70 + 120 ^ 77 + 51 - 95 + 112;
    llIIllllIl[70] = 0x4B ^ 0x52 ^ 0xCA ^ 0xB4;
    llIIllllIl[71] = 0x41 ^ 0x51;
    llIIllllIl[72] = 0x67 ^ 0x52;
    llIIllllIl[73] = (0x50 ^ 0x11) + (0x15 ^ 0x0) - -(0x32 ^ 0x7E) + (0x43 ^ 0xC);
    llIIllllIl[74] = 117 + 8 - 89 + 102;
    llIIllllIl[75] = 0x78 ^ 0xE;
    llIIllllIl[76] = 0xD ^ 0x44 ^ 0x2C ^ 0x37;
    llIIllllIl[77] = 0x3F ^ 0x61;
    llIIllllIl[78] = 92 + 19 - 19 + 64 + 128 + 66 - 183 + 124 - 61 + 7 - -37 + 104 + (0xDA ^ 0x85);
    llIIllllIl[79] = 57 + 132 - 61 + 21 + (0xA6 ^ 0xC7) - (0xD3 ^ 0xB0) + (0x7C ^ 0x56);
    llIIllllIl[80] = -" ".length();
    llIIllllIl[81] = 153 + 52 - 186 + 156;
    llIIllllIl[82] = 0xB8 ^ 0xB7;
    llIIllllIl[83] = 0xB8 ^ 0xA9;
    llIIllllIl[84] = 0x63 ^ 0x71;
    llIIllllIl[85] = 0x3B ^ 0x28;
    llIIllllIl[86] = 0xD7 ^ 0xC3;
    llIIllllIl[87] = 0x72 ^ 0x64;
    llIIllllIl[88] = 0x68 ^ 0x7F;
    llIIllllIl[89] = 104 + 120 - 154 + 85 ^ 20 + 56 - -47 + 8;
    llIIllllIl[90] = 0x41 ^ 0x58;
    llIIllllIl[91] = 0x96 ^ 0x81 ^ 0x6 ^ 0xB;
    llIIllllIl[92] = 0x10 ^ 0x67 ^ 0x6E ^ 0x2;
    llIIllllIl[93] = 0x6E ^ 0x70;
    llIIllllIl[94] = 0x76 ^ 0x56;
    llIIllllIl[95] = 0x8A ^ 0xAB;
    llIIllllIl[96] = 0xB3 ^ 0x96;
    llIIllllIl[97] = 0x37 ^ 0x11;
    llIIllllIl[98] = 0x7A ^ 0x5D;
    llIIllllIl[99] = 0xA0 ^ 0x88;
  }
  
  private static boolean lIllIllIIlIl(byte lllllllllllllllllIlIIIlIllIlllll, char lllllllllllllllllIlIIIlIllIllllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 >= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static String lIllIIlIIIlI(long lllllllllllllllllIlIIIllIIIIlllI, int lllllllllllllllllIlIIIllIIIIllII) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   22: bipush #27
    //   24: iaload
    //   25: invokestatic copyOf : ([BI)[B
    //   28: ldc 'DES'
    //   30: invokespecial <init> : ([BLjava/lang/String;)V
    //   33: astore_2
    //   34: ldc 'DES'
    //   36: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   39: astore_3
    //   40: aload_3
    //   41: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   44: bipush #22
    //   46: iaload
    //   47: aload_2
    //   48: invokevirtual init : (ILjava/security/Key;)V
    //   51: new java/lang/String
    //   54: dup
    //   55: aload_3
    //   56: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   59: aload_0
    //   60: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   63: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   66: invokevirtual decode : ([B)[B
    //   69: invokevirtual doFinal : ([B)[B
    //   72: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   75: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   78: areturn
    //   79: astore_2
    //   80: aload_2
    //   81: invokevirtual printStackTrace : ()V
    //   84: aconst_null
    //   85: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   40	39	3	lllllllllllllllllIlIIIllIIIlIIlI	Ljavax/crypto/Cipher;
    //   0	86	1	lllllllllllllllllIlIIIllIIIIllll	Ljava/lang/String;
    //   0	86	0	lllllllllllllllllIlIIIllIIIlIIII	Ljava/lang/String;
    //   0	86	0	lllllllllllllllllIlIIIllIIIIlllI	J
    //   80	4	2	lllllllllllllllllIlIIIllIIIlIIIl	Ljava/lang/Exception;
    //   0	86	2	lllllllllllllllllIlIIIllIIIIllII	I
    //   34	45	2	lllllllllllllllllIlIIIllIIIlIIll	Ljavax/crypto/spec/SecretKeySpec;
    //   0	86	1	lllllllllllllllllIlIIIllIIIIllIl	D
    //   0	86	3	lllllllllllllllllIlIIIllIIIIlIll	C
    // Exception table:
    //   from	to	target	type
    //   0	78	79	java/lang/Exception
  }
  
  public static void sendPacket(short lllllllllllllllllIlIIIlllIlIlIIl, double lllllllllllllllllIlIIIlllIllIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getClass : ()Ljava/lang/Class;
    //   4: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIlIl : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   10: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   13: bipush #27
    //   15: iaload
    //   16: iaload
    //   17: aaload
    //   18: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   21: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   24: iconst_1
    //   25: iaload
    //   26: iaload
    //   27: anewarray java/lang/Class
    //   30: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   33: aload_0
    //   34: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   40: iconst_1
    //   41: iaload
    //   42: iaload
    //   43: anewarray java/lang/Object
    //   46: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   49: astore_2
    //   50: aload_2
    //   51: invokevirtual getClass : ()Ljava/lang/Class;
    //   54: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIlIl : [Ljava/lang/String;
    //   57: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   60: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   63: bipush #40
    //   65: iaload
    //   66: iaload
    //   67: aaload
    //   68: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   71: aload_2
    //   72: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   75: astore_3
    //   76: aload_3
    //   77: invokevirtual getClass : ()Ljava/lang/Class;
    //   80: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIlIl : [Ljava/lang/String;
    //   83: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   86: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   89: bipush #42
    //   91: iaload
    //   92: iaload
    //   93: aaload
    //   94: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   97: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   100: bipush #22
    //   102: iaload
    //   103: iaload
    //   104: anewarray java/lang/Class
    //   107: dup
    //   108: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   111: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   114: iconst_1
    //   115: iaload
    //   116: iaload
    //   117: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIlIl : [Ljava/lang/String;
    //   120: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   123: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   126: bipush #46
    //   128: iaload
    //   129: iaload
    //   130: aaload
    //   131: invokestatic getNMSClass : (Ljava/lang/String;)Ljava/lang/Class;
    //   134: aastore
    //   135: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   138: aload_3
    //   139: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   142: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   145: bipush #22
    //   147: iaload
    //   148: iaload
    //   149: anewarray java/lang/Object
    //   152: dup
    //   153: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   156: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   159: iconst_1
    //   160: iaload
    //   161: iaload
    //   162: aload_1
    //   163: aastore
    //   164: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   167: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   170: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   173: bipush #24
    //   175: iaload
    //   176: aaload
    //   177: invokevirtual length : ()I
    //   180: pop2
    //   181: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   184: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   187: bipush #25
    //   189: iaload
    //   190: aaload
    //   191: invokevirtual length : ()I
    //   194: ldc ''
    //   196: invokevirtual length : ()I
    //   199: pop2
    //   200: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   203: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   206: bipush #29
    //   208: iaload
    //   209: aaload
    //   210: invokevirtual length : ()I
    //   213: ineg
    //   214: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   217: bipush #60
    //   219: iaload
    //   220: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   223: bipush #61
    //   225: iaload
    //   226: ixor
    //   227: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   230: bipush #62
    //   232: iaload
    //   233: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   236: bipush #63
    //   238: iaload
    //   239: ixor
    //   240: ixor
    //   241: invokestatic lIllIllIIlIl : (II)Z
    //   244: ifeq -> 253
    //   247: return
    //   248: astore_2
    //   249: aload_2
    //   250: invokevirtual printStackTrace : ()V
    //   253: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	254	0	lllllllllllllllllIlIIIlllIlIllIl	D
    //   0	254	0	lllllllllllllllllIlIIIlllIlIlIIl	S
    //   0	254	1	lllllllllllllllllIlIIIlllIlIlIII	C
    //   76	105	3	lllllllllllllllllIlIIIlllIlIlIll	Ljava/lang/Object;
    //   0	254	0	lllllllllllllllllIlIIIlllIlIlllI	Lorg/bukkit/entity/Player;
    //   0	254	3	lllllllllllllllllIlIIIlllIlIIllI	F
    //   50	131	2	lllllllllllllllllIlIIIlllIlIllII	Ljava/lang/Object;
    //   249	4	2	lllllllllllllllllIlIIIlllIlIlIlI	Ljava/lang/Exception;
    //   0	254	2	lllllllllllllllllIlIIIlllIllIIIl	Z
    //   0	254	1	lllllllllllllllllIlIIIlllIllIIlI	D
    //   0	254	3	lllllllllllllllllIlIIIlllIlIllll	I
    //   0	254	2	lllllllllllllllllIlIIIlllIlIIlll	I
    //   0	254	1	lllllllllllllllllIlIIIlllIllIIII	Ljava/lang/Object;
    // Exception table:
    //   from	to	target	type
    //   0	181	248	java/lang/Exception
  }
  
  public void execute(double lllllllllllllllllIlIIIllIlIIIlll) {
    lllllllllllllllllIlIIIllIlIIIlll.getWorld().getNearbyEntities(lllllllllllllllllIlIIIllIlIIIlll, 50.0D, 50.0D, 50.0D).forEach(lllllllllllllllllIlIIIlllIlllIll -> {
          // Byte code:
          //   0: aload_2
          //   1: instanceof org/bukkit/entity/Player
          //   4: invokestatic lIIIIIllII : (I)Z
          //   7: invokestatic lIllIllIIlII : (I)Z
          //   10: ifeq -> 22
          //   13: aload_0
          //   14: aload_2
          //   15: checkcast org/bukkit/entity/Player
          //   18: aload_1
          //   19: invokespecial sendLightning : (Lorg/bukkit/entity/Player;Lorg/bukkit/Location;)V
          //   22: return
          // Local variable table:
          //   start	length	slot	name	descriptor
          //   0	23	1	lllllllllllllllllIlIIIlllIllllIl	B
          //   0	23	0	lllllllllllllllllIlIIIlllIlllllI	I
          //   0	23	1	lllllllllllllllllIlIIIlllIlllIlI	Lorg/bukkit/Location;
          //   0	23	1	lllllllllllllllllIlIIIlllIlllIII	B
          //   0	23	2	lllllllllllllllllIlIIIlllIllllll	Lorg/bukkit/entity/Entity;
          //   0	23	0	lllllllllllllllllIlIIIlllIlllIIl	J
          //   0	23	2	lllllllllllllllllIlIIIlllIlllIll	F
          //   0	23	0	lllllllllllllllllIlIIIlllIllllII	Lcom/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning;
          //   0	23	2	lllllllllllllllllIlIIIlllIllIlll	Z
        });
  }
  
  private static String lIIIIIlIIl(int lllllllllllllllllIlIIIllIIIllIll, String lllllllllllllllllIlIIIllIIlIIIII) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   10: iconst_4
    //   11: iaload
    //   12: aaload
    //   13: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   16: aload_1
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   23: invokevirtual digest : ([B)[B
    //   26: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   29: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   32: bipush #82
    //   34: iaload
    //   35: aaload
    //   36: invokespecial <init> : ([BLjava/lang/String;)V
    //   39: astore_2
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   43: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   46: bipush #71
    //   48: iaload
    //   49: aaload
    //   50: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   53: astore_3
    //   54: aload_3
    //   55: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   58: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   61: bipush #23
    //   63: iaload
    //   64: iaload
    //   65: aload_2
    //   66: invokevirtual init : (ILjava/security/Key;)V
    //   69: new java/lang/String
    //   72: dup
    //   73: aload_3
    //   74: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   77: aload_0
    //   78: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   81: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   84: invokevirtual decode : ([B)[B
    //   87: invokevirtual doFinal : ([B)[B
    //   90: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   93: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   96: areturn
    //   97: astore_2
    //   98: aload_2
    //   99: invokevirtual printStackTrace : ()V
    //   102: aconst_null
    //   103: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	104	3	lllllllllllllllllIlIIIllIIIllIII	B
    //   98	4	2	lllllllllllllllllIlIIIllIIIlllII	Ljava/lang/Exception;
    //   0	104	1	lllllllllllllllllIlIIIllIIIllIlI	I
    //   0	104	0	lllllllllllllllllIlIIIllIIlIIlII	I
    //   40	57	2	lllllllllllllllllIlIIIllIIlIIIlI	Ljavax/crypto/spec/SecretKeySpec;
    //   54	43	3	lllllllllllllllllIlIIIllIIIlllIl	Ljavax/crypto/Cipher;
    //   0	104	2	lllllllllllllllllIlIIIllIIIlllll	B
    //   0	104	2	lllllllllllllllllIlIIIllIIIllIIl	D
    //   0	104	1	lllllllllllllllllIlIIIllIIlIIIII	Ljava/lang/String;
    //   0	104	0	lllllllllllllllllIlIIIllIIIllIll	I
    //   0	104	0	lllllllllllllllllIlIIIllIIIllllI	Ljava/lang/String;
    //   0	104	1	lllllllllllllllllIlIIIllIIlIIIll	F
    //   0	104	3	lllllllllllllllllIlIIIllIIlIIIIl	Z
    // Exception table:
    //   from	to	target	type
    //   0	96	97	java/lang/Exception
  }
  
  private static void lIIIIIlIlI() {
    lIllIlIl = new String[lIllIllI[llIIllllIl[55]]];
    lIllIlIl[lIllIllI[llIIllllIl[1]]] = lIIIIIIlll(llIIllllII[llIIllllIl[83]], llIIllllII[llIIllllIl[84]]);
    lIllIlIl[lIllIllI[llIIllllIl[22]]] = lIIIIIIlll(llIIllllII[llIIllllIl[85]], llIIllllII[llIIllllIl[86]]);
    lIllIlIl[lIllIllI[llIIllllIl[23]]] = lIIIIIlIII(llIIllllII[llIIllllIl[58]], llIIllllII[llIIllllIl[87]]);
    lIllIlIl[lIllIllI[llIIllllIl[24]]] = lIIIIIlIIl(llIIllllII[llIIllllIl[88]], llIIllllII[llIIllllIl[89]]);
    lIllIlIl[lIllIllI[llIIllllIl[25]]] = lIIIIIlIII(llIIllllII[llIIllllIl[90]], llIIllllII[llIIllllIl[91]]);
    lIllIlIl[lIllIllI[llIIllllIl[29]]] = lIIIIIlIIl(llIIllllII[llIIllllIl[92]], llIIllllII[llIIllllIl[61]]);
    lIllIlIl[lIllIllI[llIIllllIl[17]]] = lIIIIIlIII(llIIllllII[llIIllllIl[7]], llIIllllII[llIIllllIl[93]]);
    lIllIlIl[lIllIllI[llIIllllIl[33]]] = lIIIIIlIIl(llIIllllII[llIIllllIl[64]], llIIllllII[llIIllllIl[94]]);
    lIllIlIl[lIllIllI[llIIllllIl[27]]] = lIIIIIIlll(llIIllllII[llIIllllIl[95]], llIIllllII[llIIllllIl[48]]);
    lIllIlIl[lIllIllI[llIIllllIl[40]]] = lIIIIIIlll(llIIllllII[llIIllllIl[49]], llIIllllII[llIIllllIl[66]]);
    lIllIlIl[lIllIllI[llIIllllIl[42]]] = lIIIIIlIIl(llIIllllII[llIIllllIl[96]], llIIllllII[llIIllllIl[97]]);
    lIllIlIl[lIllIllI[llIIllllIl[46]]] = lIIIIIIlll(llIIllllII[llIIllllIl[98]], llIIllllII[llIIllllIl[99]]);
  }
  
  private static void lIIIIIlIll() {
    lIllIllI = new int[llIIllllIl[0]];
    lIllIllI[llIIllllIl[1]] = (llIIllllIl[2] + llIIllllIl[3] - llIIllllIl[4] + llIIllllIl[5] ^ llIIllllIl[6] + llIIllllIl[7] - llIIllllIl[8] + llIIllllIl[9]) & (llIIllllIl[10] + llIIllllIl[11] - llIIllllIl[12] + llIIllllIl[13] ^ llIIllllIl[14] + llIIllllIl[15] - llIIllllIl[16] + llIIllllIl[10] ^ -llIIllllII[llIIllllIl[1]].length());
    lIllIllI[llIIllllIl[17]] = llIIllllIl[18] ^ llIIllllIl[19] ^ llIIllllIl[20] ^ llIIllllIl[21];
    lIllIllI[llIIllllIl[22]] = llIIllllII[llIIllllIl[17]].length();
    lIllIllI[llIIllllIl[23]] = llIIllllII[llIIllllIl[22]].length();
    lIllIllI[llIIllllIl[24]] = llIIllllII[llIIllllIl[23]].length();
    lIllIllI[llIIllllIl[25]] = llIIllllIl[26] ^ llIIllllIl[27] ^ llIIllllIl[8] ^ llIIllllIl[28];
    lIllIllI[llIIllllIl[29]] = llIIllllIl[30] ^ llIIllllIl[31] ^ llIIllllIl[10] ^ llIIllllIl[32];
    lIllIllI[llIIllllIl[33]] = llIIllllIl[34] ^ llIIllllIl[35] ^ llIIllllIl[36] ^ llIIllllIl[37];
    lIllIllI[llIIllllIl[27]] = llIIllllIl[38] ^ llIIllllIl[39] ^ llIIllllIl[23] ^ llIIllllIl[33];
    lIllIllI[llIIllllIl[40]] = llIIllllIl[41] ^ llIIllllIl[18];
    lIllIllI[llIIllllIl[42]] = llIIllllIl[43] ^ llIIllllIl[23] ^ llIIllllIl[44] ^ llIIllllIl[45];
    lIllIllI[llIIllllIl[46]] = llIIllllIl[47] + llIIllllIl[48] - llIIllllIl[49] + llIIllllIl[50] ^ llIIllllIl[51] + llIIllllIl[52] - llIIllllIl[53] + llIIllllIl[54];
    lIllIllI[llIIllllIl[55]] = llIIllllIl[56] ^ llIIllllIl[57] ^ llIIllllIl[58] ^ llIIllllIl[59];
  }
  
  private static void lIllIIlIIlIl() {
    llIIllllII = new String[llIIllllIl[3]];
    llIIllllII[llIIllllIl[1]] = lIllIIlIIIlI("2nJVTzxsDTk=", "qThQk");
    llIIllllII[llIIllllIl[17]] = lIllIIlIIIll("cQ==", "QUXOh");
    llIIllllII[llIIllllIl[22]] = lIllIIlIIIlI("gxfV8u4lNl8=", "wZXJJ");
    llIIllllII[llIIllllIl[23]] = lIllIIlIIIlI("aivE6a0O8W4=", "DzZKl");
    llIIllllII[llIIllllIl[24]] = lIllIIlIIlII("INtWgHHyNNo=", "XbDfI");
    llIIllllII[llIIllllIl[25]] = lIllIIlIIlII("fS7B8o+krrU=", "ObzXc");
    llIIllllII[llIIllllIl[29]] = lIllIIlIIlII("VAJLI3prtCY=", "jxjlp");
    llIIllllII[llIIllllIl[33]] = lIllIIlIIIlI("PgHwSrrqWhM=", "FBNDX");
    llIIllllII[llIIllllIl[27]] = lIllIIlIIIll("", "zXnXu");
    llIIllllII[llIIllllIl[40]] = lIllIIlIIlII("p9k2xl7u2LE=", "flXRY");
    llIIllllII[llIIllllIl[42]] = lIllIIlIIlII("jSXjRtpvLR8=", "BzVpc");
    llIIllllII[llIIllllIl[46]] = lIllIIlIIIll("FRYU", "QSGdc");
    llIIllllII[llIIllllIl[55]] = lIllIIlIIIll("LiAF", "jeVsf");
    llIIllllII[llIIllllIl[0]] = lIllIIlIIIll("", "Ajnqy");
    llIIllllII[llIIllllIl[4]] = lIllIIlIIIlI("y3Zn49Vdn7U=", "ldkSb");
    llIIllllII[llIIllllIl[82]] = lIllIIlIIIlI("jz0a80jkZHIe0/k/Q3QyYQ==", "CKjwd");
    llIIllllII[llIIllllIl[71]] = lIllIIlIIIlI("gfWnPyLn3aLRcnG5HE4VTg==", "utWHF");
    llIIllllII[llIIllllIl[83]] = lIllIIlIIIll("CzJSZhs7AAgcBSJ8JgIPEQ8QAT8=", "AEjPV");
    llIIllllII[llIIllllIl[84]] = lIllIIlIIIll("GxQtMCs=", "yucjn");
    llIIllllII[llIIllllIl[85]] = lIllIIlIIIlI("whPWhUgQJ+DU0gNUoFpQrA==", "JVcqe");
    llIIllllII[llIIllllIl[86]] = lIllIIlIIIll("ACQwPh0=", "xebjx");
    llIIllllII[llIIllllIl[58]] = lIllIIlIIlII("a9pj3bOHq0jYoqP/A6K8AcCAUw2ry5bsp1ywRO1pnFc=", "ljCDu");
    llIIllllII[llIIllllIl[87]] = lIllIIlIIlII("CFA7iVeHT5Q=", "LTfHV");
    llIIllllII[llIIllllIl[88]] = lIllIIlIIIlI("RHFuAHpqiIWyhVi135Z1JTE4qFDAxcUaawF3u3gyOOX3MlZI4V8J763/OGMuSJge", "ksasc");
    llIIllllII[llIIllllIl[89]] = lIllIIlIIlII("ecAG75IUwXw=", "RfHnj");
    llIIllllII[llIIllllIl[90]] = lIllIIlIIlII("cNK06D/mPbT7p3GQVuKzOg==", "CdbzY");
    llIIllllII[llIIllllIl[91]] = lIllIIlIIIll("HTkpIw4=", "GocQm");
    llIIllllII[llIIllllIl[92]] = lIllIIlIIIlI("Ef6Zul6HOEfLS+x1RnalsQ==", "fIqkv");
    llIIllllII[llIIllllIl[61]] = lIllIIlIIlII("XjVQgc7w9Ig=", "wALaA");
    llIIllllII[llIIllllIl[7]] = lIllIIlIIIlI("Aj4Cxm0pZ4FMErXQr2XIY0cVnaDXVeUQQxz/NpVJp3VyS4g+Ij+eMg==", "ttkgD");
    llIIllllII[llIIllllIl[93]] = lIllIIlIIlII("Q8aSX8bQnLg=", "eryOU");
    llIIllllII[llIIllllIl[64]] = lIllIIlIIIlI("Gx4coL6B6Gz/rRGMbiC5PA==", "ckYKI");
    llIIllllII[llIIllllIl[94]] = lIllIIlIIlII("Mv61giIxMRo=", "tbCKW");
    llIIllllII[llIIllllIl[95]] = lIllIIlIIIlI("lMECdKSsNIsJqFH22gR4iw==", "ZnhTn");
    llIIllllII[llIIllllIl[48]] = lIllIIlIIIlI("6c3Pe8K2WE4=", "FsUmL");
    llIIllllII[llIIllllIl[49]] = lIllIIlIIIll("Aw4vMyoIJlceLzszMiNYPzkVC0cGJl9n", "LwbZl");
    llIIllllII[llIIllllIl[66]] = lIllIIlIIIlI("+JRgeEUX1Bs=", "QFLkW");
    llIIllllII[llIIllllIl[96]] = lIllIIlIIIll("CwosHwwtAW0gBA4MazRyNS07JQgSGGdx", "boZLF");
    llIIllllII[llIIllllIl[97]] = lIllIIlIIlII("xZbyhQRzVjg=", "sYdnf");
    llIIllllII[llIIllllIl[98]] = lIllIIlIIlII("CJvRVYeB+WHLVbRe2owX2w==", "pKFPX");
    llIIllllII[llIIllllIl[99]] = lIllIIlIIIlI("PbbIdPVAnuQ=", "XcBmk");
  }
  
  private static String lIIIIIlIII(char lllllllllllllllllIlIIIllIlIlIIlI, boolean lllllllllllllllllIlIIIllIlIlIllI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   10: bipush #42
    //   12: iaload
    //   13: aaload
    //   14: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   17: aload_1
    //   18: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   21: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   24: invokevirtual digest : ([B)[B
    //   27: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   30: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   33: bipush #27
    //   35: iaload
    //   36: iaload
    //   37: invokestatic copyOf : ([BI)[B
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   43: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   46: bipush #46
    //   48: iaload
    //   49: aaload
    //   50: invokespecial <init> : ([BLjava/lang/String;)V
    //   53: astore_2
    //   54: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   57: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   60: bipush #55
    //   62: iaload
    //   63: aaload
    //   64: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   67: astore_3
    //   68: aload_3
    //   69: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   72: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   75: bipush #23
    //   77: iaload
    //   78: iaload
    //   79: aload_2
    //   80: invokevirtual init : (ILjava/security/Key;)V
    //   83: new java/lang/String
    //   86: dup
    //   87: aload_3
    //   88: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   91: aload_0
    //   92: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   95: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   98: invokevirtual decode : ([B)[B
    //   101: invokevirtual doFinal : ([B)[B
    //   104: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   107: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   110: areturn
    //   111: astore_2
    //   112: aload_2
    //   113: invokevirtual printStackTrace : ()V
    //   116: aconst_null
    //   117: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	118	3	lllllllllllllllllIlIIIllIlIIllll	J
    //   68	43	3	lllllllllllllllllIlIIIllIlIlIlll	Ljavax/crypto/Cipher;
    //   0	118	2	lllllllllllllllllIlIIIllIlIllIll	S
    //   0	118	2	lllllllllllllllllIlIIIllIlIlIIII	D
    //   0	118	3	lllllllllllllllllIlIIIllIlIlIIll	Z
    //   0	118	1	lllllllllllllllllIlIIIllIlIlIIIl	Ljava/lang/Exception;
    //   112	4	2	lllllllllllllllllIlIIIllIlIlIlII	Ljava/lang/Exception;
    //   0	118	0	lllllllllllllllllIlIIIllIlIlIlIl	Ljava/lang/String;
    //   0	118	1	lllllllllllllllllIlIIIllIlIlIllI	Z
    //   0	118	0	lllllllllllllllllIlIIIllIlIlIIlI	C
    //   0	118	0	lllllllllllllllllIlIIIllIlIllIII	S
    //   0	118	1	lllllllllllllllllIlIIIllIlIllIIl	Ljava/lang/String;
    //   54	57	2	lllllllllllllllllIlIIIllIlIllIlI	Ljavax/crypto/spec/SecretKeySpec;
    // Exception table:
    //   from	to	target	type
    //   0	110	111	java/lang/Exception
  }
  
  private static boolean lIllIllIIlII(char lllllllllllllllllIlIIIlIllIllIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static String lIIIIIIlll(String lllllllllllllllllIlIIIlllIIlIIIl, long lllllllllllllllllIlIIIlllIIIllII) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   40: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   43: iconst_1
    //   44: iaload
    //   45: iaload
    //   46: istore #4
    //   48: aload_0
    //   49: invokevirtual toCharArray : ()[C
    //   52: astore #5
    //   54: aload #5
    //   56: arraylength
    //   57: istore #6
    //   59: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.lIllIllI : [I
    //   62: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   65: iconst_1
    //   66: iaload
    //   67: iaload
    //   68: istore #7
    //   70: iload #7
    //   72: iload #6
    //   74: invokestatic lIIIIIllIl : (II)Z
    //   77: invokestatic lIllIllIIlII : (I)Z
    //   80: ifeq -> 305
    //   83: aload #5
    //   85: iload #7
    //   87: caload
    //   88: istore #8
    //   90: aload_2
    //   91: iload #8
    //   93: aload_3
    //   94: iload #4
    //   96: aload_3
    //   97: arraylength
    //   98: irem
    //   99: caload
    //   100: ixor
    //   101: i2c
    //   102: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   105: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   108: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   111: bipush #33
    //   113: iaload
    //   114: aaload
    //   115: invokevirtual length : ()I
    //   118: pop2
    //   119: iinc #4, 1
    //   122: iinc #7, 1
    //   125: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   128: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   131: bipush #27
    //   133: iaload
    //   134: aaload
    //   135: invokevirtual length : ()I
    //   138: ldc ''
    //   140: invokevirtual length : ()I
    //   143: pop2
    //   144: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   147: bipush #47
    //   149: iaload
    //   150: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   153: bipush #64
    //   155: iaload
    //   156: iadd
    //   157: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   160: bipush #16
    //   162: iaload
    //   163: isub
    //   164: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   167: bipush #65
    //   169: iaload
    //   170: iadd
    //   171: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   174: bipush #66
    //   176: iaload
    //   177: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   180: bipush #60
    //   182: iaload
    //   183: iadd
    //   184: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   187: bipush #67
    //   189: iaload
    //   190: isub
    //   191: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   194: bipush #39
    //   196: iaload
    //   197: iadd
    //   198: ixor
    //   199: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   202: bipush #68
    //   204: iaload
    //   205: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   208: bipush #69
    //   210: iaload
    //   211: iadd
    //   212: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   215: bipush #15
    //   217: iaload
    //   218: isub
    //   219: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   222: bipush #70
    //   224: iaload
    //   225: iadd
    //   226: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   229: bipush #71
    //   231: iaload
    //   232: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   235: bipush #72
    //   237: iaload
    //   238: iadd
    //   239: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   242: bipush #11
    //   244: iaload
    //   245: isub
    //   246: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   249: bipush #45
    //   251: iaload
    //   252: iadd
    //   253: ixor
    //   254: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   257: bipush #73
    //   259: iaload
    //   260: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   263: bipush #74
    //   265: iaload
    //   266: ixor
    //   267: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   270: bipush #75
    //   272: iaload
    //   273: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   276: bipush #16
    //   278: iaload
    //   279: ixor
    //   280: ixor
    //   281: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllII : [Ljava/lang/String;
    //   284: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   287: bipush #40
    //   289: iaload
    //   290: aaload
    //   291: invokevirtual length : ()I
    //   294: ineg
    //   295: ixor
    //   296: iand
    //   297: invokestatic lIllIllIIllI : (II)Z
    //   300: ifeq -> 70
    //   303: aconst_null
    //   304: areturn
    //   305: aload_2
    //   306: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   309: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	310	0	lllllllllllllllllIlIIIlllIIIllIl	C
    //   90	32	8	lllllllllllllllllIlIIIlllIIlIIII	C
    //   48	262	4	lllllllllllllllllIlIIIlllIIllIll	I
    //   0	310	5	lllllllllllllllllIlIIIlllIIIlIII	Z
    //   0	310	6	lllllllllllllllllIlIIIlllIIlIllI	C
    //   0	310	7	lllllllllllllllllIlIIIlllIIIIllI	F
    //   0	310	2	lllllllllllllllllIlIIIlllIIlIIll	S
    //   0	310	4	lllllllllllllllllIlIIIlllIIIllll	F
    //   0	310	1	lllllllllllllllllIlIIIlllIIlIlIl	Ljava/lang/String;
    //   0	310	2	lllllllllllllllllIlIIIlllIIIlIll	Ljava/lang/Exception;
    //   32	278	2	lllllllllllllllllIlIIIlllIIllIIl	Ljava/lang/StringBuilder;
    //   0	310	0	lllllllllllllllllIlIIIlllIIlIIIl	Ljava/lang/String;
    //   0	310	5	lllllllllllllllllIlIIIlllIIllIlI	Z
    //   0	310	6	lllllllllllllllllIlIIIlllIIIIlll	F
    //   0	310	3	lllllllllllllllllIlIIIlllIIlllII	B
    //   0	310	4	lllllllllllllllllIlIIIlllIIIlIIl	I
    //   37	273	3	lllllllllllllllllIlIIIlllIIlIIlI	[C
    //   0	310	1	lllllllllllllllllIlIIIlllIIIllII	J
    //   0	310	0	lllllllllllllllllIlIIIlllIIllIII	Ljava/lang/String;
    //   0	310	3	lllllllllllllllllIlIIIlllIIIlIlI	J
    //   0	310	1	lllllllllllllllllIlIIIlllIIIlllI	Ljava/lang/String;
    //   0	310	8	lllllllllllllllllIlIIIlllIIIIlIl	C
    //   0	310	8	lllllllllllllllllIlIIIlllIIlIlII	F
    //   0	310	7	lllllllllllllllllIlIIIlllIIlIlll	Ljava/lang/String;
  }
  
  private static String lIllIIlIIIll(String lllllllllllllllllIlIIIlIllllIIll, long lllllllllllllllllIlIIIlIlllIllIl) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   40: iconst_1
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   58: iconst_1
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic lIllIllIIlll : (II)Z
    //   69: ifeq -> 122
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: ldc '   '
    //   114: invokevirtual length : ()I
    //   117: ifgt -> 62
    //   120: aconst_null
    //   121: areturn
    //   122: aload_2
    //   123: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   126: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	127	8	lllllllllllllllllIlIIIlIlllIIllI	C
    //   0	127	0	lllllllllllllllllIlIIIlIlllIlllI	I
    //   0	127	4	lllllllllllllllllIlIIIlIlllIlIlI	I
    //   0	127	1	lllllllllllllllllIlIIIlIllllIIlI	Ljava/lang/String;
    //   0	127	7	lllllllllllllllllIlIIIlIlllIIlll	Z
    //   0	127	6	lllllllllllllllllIlIIIlIlllIlIII	I
    //   0	127	2	lllllllllllllllllIlIIIlIlllIllII	B
    //   44	83	4	lllllllllllllllllIlIIIlIlllIllll	I
    //   37	90	3	lllllllllllllllllIlIIIlIllllIIII	[C
    //   0	127	1	lllllllllllllllllIlIIIlIlllIllIl	J
    //   79	24	8	lllllllllllllllllIlIIIlIllllIlII	C
    //   32	95	2	lllllllllllllllllIlIIIlIllllIIIl	Ljava/lang/StringBuilder;
    //   0	127	0	lllllllllllllllllIlIIIlIllllIIll	Ljava/lang/String;
    //   0	127	3	lllllllllllllllllIlIIIlIlllIlIll	I
    //   0	127	5	lllllllllllllllllIlIIIlIlllIlIIl	D
  }
  
  private static boolean lIIIIIllIl(String lllllllllllllllllIlIIIllIlllIlIl, byte lllllllllllllllllIlIIIllIlllIllI) {
    if (lIllIllIIlll(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if ((0x22 ^ 0x26) <= "   ".length())
        return (0x85 ^ 0x97) & (0x73 ^ 0x61 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIIllllIl[1];
  }
  
  private static String lIllIIlIIlII(short lllllllllllllllllIlIIIllIIIIIIIl, String lllllllllllllllllIlIIIllIIIIIIlI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: ldc_w 'Blowfish'
    //   22: invokespecial <init> : ([BLjava/lang/String;)V
    //   25: astore_2
    //   26: ldc_w 'Blowfish'
    //   29: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   32: astore_3
    //   33: aload_3
    //   34: getstatic com/axeelheaven/hbedwars/cosmetics/beddestroys/BedDestroyLightning.llIIllllIl : [I
    //   37: bipush #22
    //   39: iaload
    //   40: aload_2
    //   41: invokevirtual init : (ILjava/security/Key;)V
    //   44: new java/lang/String
    //   47: dup
    //   48: aload_3
    //   49: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   52: aload_0
    //   53: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   56: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   59: invokevirtual decode : ([B)[B
    //   62: invokevirtual doFinal : ([B)[B
    //   65: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   68: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   71: areturn
    //   72: astore_2
    //   73: aload_2
    //   74: invokevirtual printStackTrace : ()V
    //   77: aconst_null
    //   78: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	79	2	lllllllllllllllllIlIIIlIllllllll	I
    //   73	4	2	lllllllllllllllllIlIIIllIIIIIlII	Ljava/lang/Exception;
    //   0	79	0	lllllllllllllllllIlIIIllIIIIIIll	Ljava/lang/String;
    //   0	79	3	lllllllllllllllllIlIIIlIlllllllI	D
    //   26	46	2	lllllllllllllllllIlIIIllIIIIIllI	Ljavax/crypto/spec/SecretKeySpec;
    //   0	79	0	lllllllllllllllllIlIIIllIIIIIIIl	S
    //   0	79	1	lllllllllllllllllIlIIIllIIIIIIII	I
    //   0	79	1	lllllllllllllllllIlIIIllIIIIIIlI	Ljava/lang/String;
    //   33	39	3	lllllllllllllllllIlIIIllIIIIIlIl	Ljavax/crypto/Cipher;
    // Exception table:
    //   from	to	target	type
    //   0	71	72	java/lang/Exception
  }
  
  private static boolean lIllIllIIlll(short lllllllllllllllllIlIIIlIllIllIll, float lllllllllllllllllIlIIIlIllIllIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public BedDestroyLightning(Exception lllllllllllllllllIlIIIllIllIIlIl, short lllllllllllllllllIlIIIllIllIIlII, int lllllllllllllllllIlIIIllIllIIIll) {
    super((String)lllllllllllllllllIlIIIllIllIIlIl, lllllllllllllllllIlIIIllIllIIlII, lllllllllllllllllIlIIIllIllIIIll);
  }
  
  private static boolean lIIIIIllII(short lllllllllllllllllIlIIIllIllIIIII) {
    if (lIllIllIIlII(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ("  ".length() == -" ".length())
        return (0xAF ^ 0x9C) & (0x24 ^ 0x17 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return llIIllllIl[1];
  }
  
  private void sendLightning(double lllllllllllllllllIlIIIllIIlIllll, int lllllllllllllllllIlIIIllIIlIllIl) {
    Class<?> lllllllllllllllllIlIIIllIIlllIIl = getNMSClass(lIllIlIl[lIllIllI[llIIllllIl[1]]]);
    try {
      (new Class[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[1]]] = getNMSClass(lIllIlIl[lIllIllI[llIIllllIl[22]]]);
      (new Class[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[22]]] = double.class;
      (new Class[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[23]]] = double.class;
      (new Class[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[24]]] = double.class;
      (new Class[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[25]]] = boolean.class;
      (new Class[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[29]]] = boolean.class;
      Constructor<?> lllllllllllllllllIlIIIllIIllIlII = lllllllllllllllllIlIIIllIIlllIIl.getConstructor(new Class[lIllIllI[llIIllllIl[17]]]);
      Object lllllllllllllllllIlIIIllIIllIlIl = lllllllllllllllllIlIIIllIIlIllll.getWorld().getClass().getMethod(lIllIlIl[lIllIllI[llIIllllIl[23]]], new Class[lIllIllI[llIIllllIl[1]]]).invoke(lllllllllllllllllIlIIIllIIlIllll.getWorld(), new Object[lIllIllI[llIIllllIl[1]]]);
      (new Object[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[1]]] = lllllllllllllllllIlIIIllIIllIlIl;
      (new Object[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[22]]] = Double.valueOf(lllllllllllllllllIlIIIllIIlllllI.getX());
      (new Object[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[23]]] = Double.valueOf(lllllllllllllllllIlIIIllIIlllllI.getY());
      (new Object[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[24]]] = Double.valueOf(lllllllllllllllllIlIIIllIIlllllI.getZ());
      (new Object[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[25]]] = Boolean.valueOf(lIllIllI[llIIllllIl[1]]);
      (new Object[lIllIllI[llIIllllIl[17]]])[lIllIllI[llIIllllIl[29]]] = Boolean.valueOf(lIllIllI[llIIllllIl[1]]);
      Object lllllllllllllllllIlIIIllIIlllIll = lllllllllllllllllIlIIIllIIllIlII.newInstance(new Object[lIllIllI[llIIllllIl[17]]]);
      (new Class[lIllIllI[llIIllllIl[22]]])[lIllIllI[llIIllllIl[1]]] = getNMSClass(lIllIlIl[lIllIllI[llIIllllIl[25]]]);
      (new Object[lIllIllI[llIIllllIl[22]]])[lIllIllI[llIIllllIl[1]]] = lllllllllllllllllIlIIIllIIlllIll;
      Object lllllllllllllllllIlIIIllIIllIlll = getNMSClass(lIllIlIl[lIllIllI[llIIllllIl[24]]]).getConstructor(new Class[lIllIllI[llIIllllIl[22]]]).newInstance(new Object[lIllIllI[llIIllllIl[22]]]);
      sendPacket(lllllllllllllllllIlIIIllIIlIllll, lllllllllllllllllIlIIIllIIllIlll);
      "".length();
      if (lIllIllIIlIl((llIIllllIl[76] ^ llIIllllIl[77]) & (llIIllllIl[78] ^ llIIllllIl[79] ^ llIIllllIl[80]), llIIllllIl[20] ^ llIIllllIl[81]))
        return; 
    } catch (NoSuchMethodException|SecurityException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|InstantiationException lllllllllllllllllIlIIIllIIlllIII) {
      NoSuchMethodException noSuchMethodException;
      noSuchMethodException.printStackTrace();
    } 
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\beddestroys\BedDestroyLightning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */