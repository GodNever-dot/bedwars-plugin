/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.graph.entities;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Point
/*    */ {
/*    */   private static final double EPSILON = 1.0E-5D;
/*    */   private final double latitude;
/*    */   private final double longitude;
/*    */   
/*    */   public Point(double latitude, double longitude) {
/* 21 */     this.latitude = latitude;
/* 22 */     this.longitude = longitude;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Point(List<Double> values) {
/* 29 */     if (values == null || values.size() != 2) {
/* 30 */       throw new IllegalArgumentException("Point requires two doubles.");
/*    */     }
/* 32 */     this.latitude = ((Double)values.get(0)).doubleValue();
/* 33 */     this.longitude = ((Double)values.get(1)).doubleValue();
/*    */   }
/*    */   
/*    */   public double getLatitude() {
/* 37 */     return this.latitude;
/*    */   }
/*    */   
/*    */   public double getLongitude() {
/* 41 */     return this.longitude;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object other) {
/* 46 */     if (this == other) return true; 
/* 47 */     if (!(other instanceof Point)) return false; 
/* 48 */     Point o = (Point)other;
/* 49 */     return (Math.abs(this.latitude - o.latitude) < 1.0E-5D && 
/* 50 */       Math.abs(this.longitude - o.longitude) < 1.0E-5D);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 55 */     return Objects.hash(new Object[] { Double.valueOf(this.latitude), Double.valueOf(this.longitude) });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     return "Point{latitude=" + this.latitude + ", longitude=" + this.longitude + "}";
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\graph\entities\Point.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */