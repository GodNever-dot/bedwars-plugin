/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ public class StrAlgoLCSParams
/*    */   extends Params
/*    */   implements IParams
/*    */ {
/*    */   private static final String IDX = "idx";
/*    */   private static final String LEN = "len";
/*    */   private static final String WITHMATCHLEN = "withmatchlen";
/*    */   private static final String MINMATCHLEN = "minmatchlen";
/*    */   
/*    */   public static StrAlgoLCSParams StrAlgoLCSParams() {
/* 17 */     return new StrAlgoLCSParams();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StrAlgoLCSParams idx() {
/* 27 */     addParam("idx");
/* 28 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StrAlgoLCSParams len() {
/* 36 */     addParam("len");
/* 37 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StrAlgoLCSParams withMatchLen() {
/* 45 */     addParam("withmatchlen");
/* 46 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StrAlgoLCSParams minMatchLen(long minMatchLen) {
/* 54 */     addParam("minmatchlen", Long.valueOf(minMatchLen));
/* 55 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 60 */     if (contains("idx")) {
/* 61 */       args.add("idx");
/*    */     }
/* 63 */     if (contains("len")) {
/* 64 */       args.add("len");
/*    */     }
/* 66 */     if (contains("withmatchlen")) {
/* 67 */       args.add("withmatchlen");
/*    */     }
/*    */     
/* 70 */     if (contains("minmatchlen")) {
/* 71 */       args.add("minmatchlen");
/* 72 */       args.add(Protocol.toByteArray(((Long)getParam("minmatchlen")).longValue()));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\StrAlgoLCSParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */