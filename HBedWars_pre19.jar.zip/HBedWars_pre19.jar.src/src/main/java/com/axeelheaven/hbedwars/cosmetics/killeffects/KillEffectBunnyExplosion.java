package com.axeelheaven.hbedwars.cosmetics.killeffects;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.libs.xseries.XSound;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.Effect;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Rabbit;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

public class KillEffectBunnyExplosion extends KillEffect {
  private static String llllIlIllIII(float llllllllllllllllIlIlIIlIIIIllIII, String llllllllllllllllIlIlIIlIIIIllIIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc 'MD5'
    //   6: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   9: aload_1
    //   10: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   13: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   16: invokevirtual digest : ([B)[B
    //   19: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectBunnyExplosion.lIIIIIlIIlI : [I
    //   22: bipush #25
    //   24: iaload
    //   25: invokestatic copyOf : ([BI)[B
    //   28: ldc 'DES'
    //   30: invokespecial <init> : ([BLjava/lang/String;)V
    //   33: astore_2
    //   34: ldc 'DES'
    //   36: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   39: astore_3
    //   40: aload_3
    //   41: getstatic com/axeelheaven/hbedwars/cosmetics/killeffects/KillEffectBunnyExplosion.lIIIIIlIIlI : [I
    //   44: iconst_3
    //   45: iaload
    //   46: aload_2
    //   47: invokevirtual init : (ILjava/security/Key;)V
    //   50: new java/lang/String
    //   53: dup
    //   54: aload_3
    //   55: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   58: aload_0
    //   59: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   62: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   65: invokevirtual decode : ([B)[B
    //   68: invokevirtual doFinal : ([B)[B
    //   71: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   74: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   77: areturn
    //   78: astore_2
    //   79: aload_2
    //   80: invokevirtual printStackTrace : ()V
    //   83: aconst_null
    //   84: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   40	38	3	llllllllllllllllIlIlIIlIIIIlllII	Ljavax/crypto/Cipher;
    //   0	85	3	llllllllllllllllIlIlIIlIIIIlIlIl	B
    //   0	85	2	llllllllllllllllIlIlIIlIIIIlIllI	D
    //   0	85	0	llllllllllllllllIlIlIIlIIIIllIlI	Ljava/lang/String;
    //   34	44	2	llllllllllllllllIlIlIIlIIIIlllIl	Ljavax/crypto/spec/SecretKeySpec;
    //   79	4	2	llllllllllllllllIlIlIIlIIIIllIll	Ljava/lang/Exception;
    //   0	85	1	llllllllllllllllIlIlIIlIIIIlIlll	Ljava/lang/Exception;
    //   0	85	0	llllllllllllllllIlIlIIlIIIIllIII	F
    //   0	85	1	llllllllllllllllIlIlIIlIIIIllIIl	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	77	78	java/lang/Exception
  }
  
  private static boolean llllIllIIllI(Exception llllllllllllllllIlIlIIIllllIlIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static void llllIlIllIIl() {
    lIIIIIlIIIl = new String[lIIIIIlIIlI[32]];
    lIIIIIlIIIl[lIIIIIlIIlI[1]] = llllIlIlIllI("NzZeQBQkMCM7AjAmKwAYTA==", "uejwQ");
    lIIIIIlIIIl[lIIIIIlIIlI[2]] = llllIlIlIlll("tTpqse5R6ao=", "feJZp");
    lIIIIIlIIIl[lIIIIIlIIlI[3]] = llllIlIlIllI("", "DIFHC");
    lIIIIIlIIIl[lIIIIIlIIlI[4]] = llllIlIlIlll("QmoLVnMuupY=", "MFLcB");
    lIIIIIlIIIl[lIIIIIlIIlI[0]] = llllIlIlIlll("5Fpka8kcBDg=", "qTHMZ");
    lIIIIIlIIIl[lIIIIIlIIlI[5]] = llllIlIllIII("J674Vqs4BEs=", "GwafU");
    lIIIIIlIIIl[lIIIIIlIIlI[8]] = llllIlIlIllI("", "FkHvX");
    lIIIIIlIIIl[lIIIIIlIIlI[21]] = llllIlIlIlll("utqeSP0pZUo=", "kSGXi");
    lIIIIIlIIIl[lIIIIIlIIlI[25]] = llllIlIlIllI("Yw==", "CMtuZ");
    lIIIIIlIIIl[lIIIIIlIIlI[28]] = llllIlIlIllI("bw==", "OnXSX");
  }
  
  private static boolean llllIllIlIII(float llllllllllllllllIlIlIIIllllIIllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 > null);
  }
  
  private static String lIIllIIlllI(String llllllllllllllllIlIlIIlIIllIIIII, String llllllllllllllllIlIlIIlIIllIIIIl) {
    String str = new String(Base64.getDecoder().decode(llllllllllllllllIlIlIIlIIllIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlIlIIlIIlIllIII = new StringBuilder();
    char[] llllllllllllllllIlIlIIlIIlIllIll = llllllllllllllllIlIlIIlIIllIIIIl.toCharArray();
    int llllllllllllllllIlIlIIlIIlIlIlII = llIIIllIl[lIIIIIlIIlI[1]];
    char[] arrayOfChar1 = str.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIllIl[lIIIIIlIIlI[1]];
    while (llllIllIIllI(lIIllIlIIIl(j, i))) {
      char llllllllllllllllIlIlIIlIIlIlIlll = arrayOfChar1[j];
      lIIIIIlIIIl[lIIIIIlIIlI[3]].length();
      llllllllllllllllIlIlIIlIIlIlIlII++;
      j++;
      "".length();
      if (llllIllIIlll(null))
        return null; 
    } 
    return String.valueOf(llllllllllllllllIlIlIIlIIlIllIII);
  }
  
  private static boolean llllIllIIlll(long llllllllllllllllIlIlIIIllllIlIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  public void execute(String llllllllllllllllIlIlIIlIIIllIlll, Player llllllllllllllllIlIlIIlIIlIIIIll) {
    List<Entity> llllllllllllllllIlIlIIlIIIllllll = new ArrayList<>();
    int llllllllllllllllIlIlIIlIIIlllllI = llIIIllIl[lIIIIIlIIlI[1]];
    while (llllIllIIllI(lIIllIlIIIl(llllllllllllllllIlIlIIlIIIlllllI, llIIIllIl[lIIIIIlIIlI[2]] + this.random.nextInt(llIIIllIl[lIIIIIlIIlI[3]])))) {
      Rabbit llllllllllllllllIlIlIIlIIlIIIlII = (Rabbit)llllllllllllllllIlIlIIlIIIllIlll.getWorld().spawn(llllllllllllllllIlIlIIlIIIllIlll.getLocation(), Rabbit.class);
      llllllllllllllllIlIlIIlIIlIIIlII.setMetadata(llIIIllII[llIIIllIl[lIIIIIlIIlI[1]]], (MetadataValue)new FixedMetadataValue((Plugin)this.plugin, getId()));
      llllllllllllllllIlIlIIlIIlIIIlII.damage(0.01D, (Entity)llllllllllllllllIlIlIIlIIlIIIIll);
      llllllllllllllllIlIlIIlIIlIIIlII.setMaxHealth(5000.0D);
      llllllllllllllllIlIlIIlIIlIIIlII.setHealth(llllllllllllllllIlIlIIlIIlIIIlII.getMaxHealth());
      llllllllllllllllIlIlIIlIIlIIIlII.setRemoveWhenFarAway(llIIIllIl[lIIIIIlIIlI[1]]);
      llllllllllllllllIlIlIIlIIlIIIlII.setNoDamageTicks(llIIIllIl[lIIIIIlIIlI[4]]);
      llllllllllllllllIlIlIIlIIlIIIlII.setRabbitType(Rabbit.Type.values()[this.random.nextInt((Rabbit.Type.values()).length)]);
      llllllllllllllllIlIlIIlIIlIIIlII.setAdult();
      if (llllIllIIllI(lIIllIlIIlI(this.random.nextBoolean())))
        llllllllllllllllIlIlIIlIIlIIIlII.setBaby(); 
      llllllllllllllllIlIlIIlIIlIIIlII.setAgeLock(llIIIllIl[lIIIIIlIIlI[0]]);
      llllllllllllllllIlIlIIlIIlIIIlII.setTarget((LivingEntity)llllllllllllllllIlIlIIlIIlIIIIll);
      llllllllllllllllIlIlIIlIIlIIIlII.setVelocity(new Vector(0.0D, 1.0D, 0.0D));
      lIIIIIlIIIl[lIIIIIlIIlI[0]].length();
      llllllllllllllllIlIlIIlIIIlllllI++;
      "".length();
      if (llllIllIlIII(-(lIIIIIlIIlI[6] ^ lIIIIIlIIlI[7])))
        return; 
    } 
    lIIIIIlIIIl[lIIIIIlIIlI[8]].length();
  }
  
  private static void lIIllIlIIII() {
    llIIIllIl = new int[lIIIIIlIIlI[8]];
    llIIIllIl[lIIIIIlIIlI[1]] = (lIIIIIlIIlI[9] + lIIIIIlIIlI[10] - lIIIIIlIIlI[11] + lIIIIIlIIlI[12] ^ lIIIIIlIIlI[13] + lIIIIIlIIlI[14] - lIIIIIlIIlI[15] + lIIIIIlIIlI[16]) & (lIIIIIlIIlI[17] ^ lIIIIIlIIlI[18] ^ lIIIIIlIIlI[19] ^ lIIIIIlIIlI[20] ^ -lIIIIIlIIIl[lIIIIIlIIlI[21]].length());
    llIIIllIl[lIIIIIlIIlI[2]] = lIIIIIlIIlI[22] ^ lIIIIIlIIlI[23];
    llIIIllIl[lIIIIIlIIlI[3]] = lIIIIIlIIlI[14] ^ lIIIIIlIIlI[24];
    llIIIllIl[lIIIIIlIIlI[4]] = -lIIIIIlIIIl[lIIIIIlIIlI[25]].length() & lIIIIIlIIlI[26] & lIIIIIlIIlI[27];
    llIIIllIl[lIIIIIlIIlI[0]] = lIIIIIlIIIl[lIIIIIlIIlI[28]].length();
    llIIIllIl[lIIIIIlIIlI[5]] = lIIIIIlIIlI[29] ^ lIIIIIlIIlI[15] ^ lIIIIIlIIlI[30] ^ lIIIIIlIIlI[31];
  }
  
  private static boolean llllIllIlIIl(char llllllllllllllllIlIlIIIllllIllIl, byte llllllllllllllllIlIlIIIllllIllII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  public KillEffectBunnyExplosion(BedWars llllllllllllllllIlIlIIlIIlllIIll, boolean llllllllllllllllIlIlIIlIIlllIIlI, int llllllllllllllllIlIlIIlIIllllIlI, long llllllllllllllllIlIlIIlIIlllIllI) {
    super(llllllllllllllllIlIlIIlIIlllIIlI, llllllllllllllllIlIlIIlIIllllIlI, llllllllllllllllIlIlIIlIIlllIllI);
    this.plugin = llllllllllllllllIlIlIIlIIlllIIll;
    this.random = new Random();
  }
  
  private static boolean lIIllIlIIIl(short llllllllllllllllIlIlIIlIIIlIIIll, double llllllllllllllllIlIlIIlIIIlIIIlI) {
    if (llllIllIlIIl(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (-"  ".length() >= 0)
        return (0xCA ^ 0x8B) & (0x55 ^ 0x14 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIIIIIlIIlI[1];
  }
  
  private static String llllIlIlIllI(Exception llllllllllllllllIlIlIIlIIIIIIlIl, String llllllllllllllllIlIlIIlIIIIIlIIl) {
    llllllllllllllllIlIlIIlIIIIIlIlI = new String(Base64.getDecoder().decode(llllllllllllllllIlIlIIlIIIIIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlIlIIlIIIIIlIII = new StringBuilder();
    char[] llllllllllllllllIlIlIIlIIIIIIlll = llllllllllllllllIlIlIIlIIIIIlIIl.toCharArray();
    int llllllllllllllllIlIlIIlIIIIIIllI = lIIIIIlIIlI[1];
    char[] arrayOfChar1 = llllllllllllllllIlIlIIlIIIIIlIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIIIIIlIIlI[1];
    while (llllIllIlIIl(j, i)) {
      char llllllllllllllllIlIlIIlIIIIIlIll = arrayOfChar1[j];
      "".length();
      llllllllllllllllIlIlIIlIIIIIIllI++;
      j++;
      "".length();
      if (" ".length() > "  ".length())
        return null; 
    } 
    return String.valueOf(llllllllllllllllIlIlIIlIIIIIlIII);
  }
  
  private static String llllIlIlIlll(String llllllllllllllllIlIlIIIlllllIlIl, String llllllllllllllllIlIlIIIlllllIlII) {
    try {
      SecretKeySpec llllllllllllllllIlIlIIIllllllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIlIIIlllllIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIlIlIIIlllllIlll = Cipher.getInstance("Blowfish");
      llllllllllllllllIlIlIIIlllllIlll.init(lIIIIIlIIlI[3], llllllllllllllllIlIlIIIllllllIII);
      return new String(llllllllllllllllIlIlIIIlllllIlll.doFinal(Base64.getDecoder().decode(llllllllllllllllIlIlIIIlllllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception llllllllllllllllIlIlIIIlllllIllI) {
      llllllllllllllllIlIlIIIlllllIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllIIlIl() {
    lIIIIIlIIlI = new int[33];
    lIIIIIlIIlI[0] = 0x31 ^ 0x35;
    lIIIIIlIIlI[1] = (0xCD ^ 0x86 ^ 0xD2 ^ 0xBD) & (70 + 104 - 120 + 90 ^ 118 + 86 - 129 + 105 ^ -" ".length());
    lIIIIIlIIlI[2] = " ".length();
    lIIIIIlIIlI[3] = "  ".length();
    lIIIIIlIIlI[4] = "   ".length();
    lIIIIIlIIlI[5] = 87 + 106 - 132 + 70 ^ 121 + 46 - 70 + 37;
    lIIIIIlIIlI[6] = 0x4B ^ 0x51;
    lIIIIIlIIlI[7] = 105 + 102 - 114 + 40 ^ 120 + 125 - 228 + 138;
    lIIIIIlIIlI[8] = 0xA5 ^ 0xA3;
    lIIIIIlIIlI[9] = 79 + 49 - 13 + 12;
    lIIIIIlIIlI[10] = 0xBE ^ 0x80;
    lIIIIIlIIlI[11] = 0xC9 ^ 0x90;
    lIIIIIlIIlI[12] = 0x59 ^ 0x44;
    lIIIIIlIIlI[13] = 0x41 ^ 0xA;
    lIIIIIlIIlI[14] = 25 + 43 - -46 + 25;
    lIIIIIlIIlI[15] = 0x16 ^ 0x7D;
    lIIIIIlIIlI[16] = 0x61 ^ 0x5C;
    lIIIIIlIIlI[17] = 0x22 ^ 0x8;
    lIIIIIlIIlI[18] = 0x98 ^ 0xB0 ^ 0x43 ^ 0x67;
    lIIIIIlIIlI[19] = 0xF6 ^ 0xB6 ^ 0xD3 ^ 0x8A;
    lIIIIIlIIlI[20] = 0x69 ^ 0x42 ^ 0x1E ^ 0x23;
    lIIIIIlIIlI[21] = 0x6F ^ 0x68;
    lIIIIIlIIlI[22] = 0x57 ^ 0x5A ^ 0x60 ^ 0x21;
    lIIIIIlIIlI[23] = 169 + 190 - 229 + 91 ^ 39 + 99 - 118 + 129;
    lIIIIIlIIlI[24] = (0x28 ^ 0x7D) + (0xD3 ^ 0xC2) - -(0x29 ^ 0x38) + (0xA9 ^ 0xBE);
    lIIIIIlIIlI[25] = 84 + 92 - 41 + 1 ^ 7 + 2 - -56 + 63;
    lIIIIIlIIlI[26] = -" ".length();
    lIIIIIlIIlI[27] = 0xFFFFFFFF & Integer.MAX_VALUE;
    lIIIIIlIIlI[28] = 0x8 ^ 0x6 ^ 0x7E ^ 0x79;
    lIIIIIlIIlI[29] = 0x9E ^ 0xBF ^ 0xE0 ^ 0x97;
    lIIIIIlIIlI[30] = 0x88 ^ 0x87 ^ (0x77 ^ 0x25) & (0x59 ^ 0xB ^ 0xFFFFFFFF);
    lIIIIIlIIlI[31] = 0x6 ^ 0x3E;
    lIIIIIlIIlI[32] = 0x33 ^ 0x39;
  }
  
  static {
    llllIllIIlIl();
    llllIlIllIIl();
    lIIllIlIIII();
    lIIllIIllll();
  }
  
  private static boolean lIIllIlIIlI(boolean llllllllllllllllIlIlIIlIIIllIIIl) {
    if (llllIllIIllI(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ("   ".length() <= 0)
        return (0xC0 ^ 0x86 ^ 0xE ^ 0x1C) & (24 + 75 - -12 + 97 ^ 9 + 104 - 7 + 26 ^ -" ".length()); 
    } else {
    
    } 
    return lIIIIIlIIlI[1];
  }
  
  private static void lIIllIIllll() {
    llIIIllII = new String[llIIIllIl[lIIIIIlIIlI[0]]];
    llIIIllII[llIIIllIl[lIIIIIlIIlI[1]]] = lIIllIIlllI(lIIIIIlIIIl[lIIIIIlIIlI[1]], lIIIIIlIIIl[lIIIIIlIIlI[2]]);
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\killeffects\KillEffectBunnyExplosion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */