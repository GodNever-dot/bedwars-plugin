package com.axeelheaven.hbedwars.commands;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.database.profile.HData;
import com.axeelheaven.hbedwars.languague.Language;
import com.axeelheaven.hbedwars.languague.LanguageProvider;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PointsCommand implements CommandExecutor {
  private static boolean llIlIllIllll(String llllllllllllllllIllllIllIlllIIll, char llllllllllllllllIllllIllIlllIIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 <= SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private Player getOnlinePlayer(double llllllllllllllllIllllIlllIllllII) {
    Iterator<Player> iterator = Bukkit.getOnlinePlayers().iterator();
    while (llIlIllIllII(lllIIIIlIl(iterator.hasNext()))) {
      Player llllllllllllllllIllllIllllIIIIII = iterator.next();
      if (llIlIllIllII(lllIIIIlIl(llllllllllllllllIllllIllllIIIIII.getName().equalsIgnoreCase(llllllllllllllllIllllIlllIllllII))))
        return llllllllllllllllIllllIllllIIIIII; 
      "".length();
      if (llIlIllIllll(lllIlIlIIl[96] ^ lllIlIlIIl[97], lllIlIlIII[lllIlIlIIl[98]].length()))
        return null; 
    } 
    return null;
  }
  
  private static boolean llIlIllIllIl(boolean llllllllllllllllIllllIllIlllIlll, int llllllllllllllllIllllIllIlllIllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 < SYNTHETIC_LOCAL_VARIABLE_1);
  }
  
  private static boolean lllIIIIlll(long llllllllllllllllIllllIlllIlIllII) {
    if (llIlIlllIIII(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (-" ".length() != -" ".length())
        return (0x7B ^ 0x30 ^ 0x15 ^ 0x68) & (27 + 129 - 143 + 131 ^ 102 + 85 - 138 + 117 ^ -" ".length()); 
    } else {
    
    } 
    return lllIlIlIIl[1];
  }
  
  public boolean onCommand(double llllllllllllllllIlllllIIIIIlIIll, String llllllllllllllllIlllllIIIIlIIIIl, Exception llllllllllllllllIlllllIIIIlIIIll, Exception llllllllllllllllIlllllIIIIIlIIIl) {
    Language llllllllllllllllIlllllIIIIlIIlII;
    if (llIlIllIllII(lllIIIIlIl(llllllllllllllllIlllllIIIIIlIIll instanceof Player))) {
      Player llllllllllllllllIlllllIIIIIlIllI = (Player)llllllllllllllllIlllllIIIIIlIIll;
      HData llllllllllllllllIlllllIIIIIlllll = this.plugin.getGameManager().getData(llllllllllllllllIlllllIIIIIlIllI.getUniqueId());
      Language llllllllllllllllIlllllIIIIlIIIlI = this.plugin.getLanguageManager().getLanguage(llllllllllllllllIlllllIIIIIlllll.getLanguage());
      if (llIlIllIllII(lllIIIIllI(llllllllllllllllIlllllIIIIlIIIll.length, lIIIllllI[lllIlIlIIl[1]]))) {
        llllllllllllllllIlllllIIIIlIIIlI.send((CommandSender)llllllllllllllllIlllllIIIIIlIllI, LanguageProvider.POINTS_SEE, new String[lIIIllllI[lllIlIlIIl[0]]]);
        return lIIIllllI[lllIlIlIIl[1]];
      } 
      if (llIlIllIllII(lllIIIIlll(llllllllllllllllIlllllIIIIIlIllI.hasPermission(lIIIlllIl[lIIIllllI[lllIlIlIIl[0]]])))) {
        llllllllllllllllIlllllIIIIlIIIlI.send((CommandSender)llllllllllllllllIlllllIIIIIlIllI, LanguageProvider.COMMAND_PERMISSION, new String[lIIIllllI[lllIlIlIIl[0]]]);
        return lIIIllllI[lllIlIlIIl[1]];
      } 
      "".length();
      if (llIlIllIllIl(lllIlIlIII[lllIlIlIIl[18]].length(), -lllIlIlIII[lllIlIlIIl[23]].length()))
        return (lllIlIlIIl[73] ^ lllIlIlIIl[74]) & (lllIlIlIIl[75] ^ lllIlIlIIl[59] ^ lllIlIlIIl[76]); 
    } else {
      llllllllllllllllIlllllIIIIlIIlII = this.plugin.getLanguageManager().getDefaultLanguage();
      if (llIlIllIllII(lllIIIIllI(llllllllllllllllIlllllIIIIlIIIll.length, lIIIllllI[lllIlIlIIl[1]]))) {
        llllllllllllllllIlllllIIIIIlIIll.sendMessage(String.valueOf((new StringBuilder()).append(ChatColor.RED).append(lIIIlllIl[lIIIllllI[lllIlIlIIl[1]]])));
        return lIIIllllI[lllIlIlIIl[1]];
      } 
    } 
    if (llIlIllIllII(lllIIIIlIl(llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[0]]].equalsIgnoreCase(lIIIlllIl[lIIIllllI[lllIlIlIIl[14]]])))) {
      llllllllllllllllIlllllIIIIIlIIll.sendMessage(String.valueOf((new StringBuilder()).append(ChatColor.RED).append(lIIIlllIl[lIIIllllI[lllIlIlIIl[15]]])));
      return lIIIllllI[lllIlIlIIl[1]];
    } 
    if (llIlIllIllII(lllIIIIlIl(llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[0]]].equalsIgnoreCase(lIIIlllIl[lIIIllllI[lllIlIlIIl[16]]])))) {
      if (llIlIllIllII(lllIIIIllI(llllllllllllllllIlllllIIIIlIIIll.length, lIIIllllI[lllIlIlIIl[15]]))) {
        llllllllllllllllIlllllIIIIIlIIll.sendMessage(String.valueOf((new StringBuilder()).append(ChatColor.RED).append(lIIIlllIl[lIIIllllI[lllIlIlIIl[18]]])));
        return lIIIllllI[lllIlIlIIl[1]];
      } 
      Player llllllllllllllllIlllllIIIIIllIlI = getOnlinePlayer((String)llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[1]]]);
      if (llIlIllIllII(lllIIIlIII(llllllllllllllllIlllllIIIIIllIlI))) {
        llllllllllllllllIlllllIIIIlIIlII.send(llllllllllllllllIlllllIIIIIlIIll, LanguageProvider.POINTS_ONLINE, new String[lIIIllllI[lllIlIlIIl[0]]]);
        return lIIIllllI[lllIlIlIIl[1]];
      } 
      if (llIlIllIllII(lllIIIIlll(this.plugin.getUtil().isNumeric((String)llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[14]]])))) {
        llllllllllllllllIlllllIIIIlIIlII.send(llllllllllllllllIlllllIIIIIlIIll, LanguageProvider.POINTS_INTEGER, new String[lIIIllllI[lllIlIlIIl[0]]]);
        return lIIIllllI[lllIlIlIIl[1]];
      } 
      HData llllllllllllllllIlllllIIIIlIIlll = this.plugin.getGameManager().getData(llllllllllllllllIlllllIIIIIllIlI.getUniqueId());
      llllllllllllllllIlllllIIIIlIIlll.addPoints(Double.parseDouble((String)llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[14]]]));
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[0]]] = lIIIlllIl[lIIIllllI[lllIlIlIIl[23]]];
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[1]]] = llllllllllllllllIlllllIIIIIllIlI.getName();
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[14]]] = lIIIlllIl[lIIIllllI[lllIlIlIIl[17]]];
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[15]]] = (String)llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[14]]];
      llllllllllllllllIlllllIIIIlIIlII.send(llllllllllllllllIlllllIIIIIlIIll, LanguageProvider.POINTS_SENDER_ADD, new String[lIIIllllI[lllIlIlIIl[16]]]);
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[0]]] = lIIIlllIl[lIIIllllI[lllIlIlIIl[32]]];
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[1]]] = llllllllllllllllIlllllIIIIIlIIll.getName();
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[14]]] = lIIIlllIl[lIIIllllI[lllIlIlIIl[36]]];
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[15]]] = (String)llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[14]]];
      this.plugin.getLanguageManager().getLanguage(llllllllllllllllIlllllIIIIlIIlll.getLanguage()).send((CommandSender)llllllllllllllllIlllllIIIIIllIlI, LanguageProvider.POINTS_TARGET_ADD, new String[lIIIllllI[lllIlIlIIl[16]]]);
      return lIIIllllI[lllIlIlIIl[1]];
    } 
    if (llIlIllIllII(lllIIIIlIl(llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[0]]].equalsIgnoreCase(lIIIlllIl[lIIIllllI[lllIlIlIIl[6]]])))) {
      if (llIlIllIllII(lllIIIIllI(llllllllllllllllIlllllIIIIlIIIll.length, lIIIllllI[lllIlIlIIl[15]]))) {
        llllllllllllllllIlllllIIIIIlIIll.sendMessage(String.valueOf((new StringBuilder()).append(ChatColor.RED).append(lIIIlllIl[lIIIllllI[lllIlIlIIl[41]]])));
        return lIIIllllI[lllIlIlIIl[1]];
      } 
      Player llllllllllllllllIlllllIIIIlIIlIl = getOnlinePlayer((String)llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[1]]]);
      if (llIlIllIllII(lllIIIlIII(llllllllllllllllIlllllIIIIlIIlIl))) {
        llllllllllllllllIlllllIIIIlIIlII.send(llllllllllllllllIlllllIIIIIlIIll, LanguageProvider.POINTS_ONLINE, new String[lIIIllllI[lllIlIlIIl[0]]]);
        return lIIIllllI[lllIlIlIIl[1]];
      } 
      if (llIlIllIllII(lllIIIIlll(this.plugin.getUtil().isNumeric((String)llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[14]]])))) {
        llllllllllllllllIlllllIIIIlIIlII.send(llllllllllllllllIlllllIIIIIlIIll, LanguageProvider.POINTS_INTEGER, new String[lIIIllllI[lllIlIlIIl[0]]]);
        return lIIIllllI[lllIlIlIIl[1]];
      } 
      HData llllllllllllllllIlllllIIIIIllllI = this.plugin.getGameManager().getData(llllllllllllllllIlllllIIIIlIIlIl.getUniqueId());
      llllllllllllllllIlllllIIIIIllllI.removePoints(Double.parseDouble((String)llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[14]]]));
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[0]]] = lIIIlllIl[lIIIllllI[lllIlIlIIl[46]]];
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[1]]] = llllllllllllllllIlllllIIIIlIIlIl.getName();
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[14]]] = lIIIlllIl[lIIIllllI[lllIlIlIIl[48]]];
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[15]]] = (String)llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[14]]];
      llllllllllllllllIlllllIIIIlIIlII.send(llllllllllllllllIlllllIIIIIlIIll, LanguageProvider.POINTS_SENDER_REMOVE, new String[lIIIllllI[lllIlIlIIl[16]]]);
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[0]]] = lIIIlllIl[lIIIllllI[lllIlIlIIl[53]]];
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[1]]] = llllllllllllllllIlllllIIIIIlIIll.getName();
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[14]]] = lIIIlllIl[lIIIllllI[lllIlIlIIl[47]]];
      (new String[lIIIllllI[lllIlIlIIl[16]]])[lIIIllllI[lllIlIlIIl[15]]] = (String)llllllllllllllllIlllllIIIIlIIIll[lIIIllllI[lllIlIlIIl[14]]];
      this.plugin.getLanguageManager().getLanguage(llllllllllllllllIlllllIIIIIllllI.getLanguage()).send((CommandSender)llllllllllllllllIlllllIIIIlIIlIl, LanguageProvider.POINTS_TARGET_REMOVE, new String[lIIIllllI[lllIlIlIIl[16]]]);
      return lIIIllllI[lllIlIlIIl[1]];
    } 
    llllllllllllllllIlllllIIIIIlIIll.sendMessage(String.valueOf((new StringBuilder()).append(ChatColor.RED).append(lIIIlllIl[lIIIllllI[lllIlIlIIl[62]]])));
    return lIIIllllI[lllIlIlIIl[0]];
  }
  
  private static void lllIIIIIll() {
    lIIIlllIl = new String[lIIIllllI[lllIlIlIIl[69]]];
    lIIIlllIl[lIIIllllI[lllIlIlIIl[0]]] = lllIIIIIII(lllIlIlIII[lllIlIlIIl[36]], lllIlIlIII[lllIlIlIIl[6]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[1]]] = lllIIIIIIl(lllIlIlIII[lllIlIlIIl[41]], lllIlIlIII[lllIlIlIIl[46]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[14]]] = lllIIIIIlI(lllIlIlIII[lllIlIlIIl[48]], lllIlIlIII[lllIlIlIIl[53]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[15]]] = lllIIIIIIl(lllIlIlIII[lllIlIlIIl[47]], lllIlIlIII[lllIlIlIIl[62]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[16]]] = lllIIIIIIl(lllIlIlIII[lllIlIlIIl[69]], lllIlIlIII[lllIlIlIIl[2]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[18]]] = lllIIIIIII(lllIlIlIII[lllIlIlIIl[35]], lllIlIlIII[lllIlIlIIl[77]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[23]]] = lllIIIIIIl(lllIlIlIII[lllIlIlIIl[78]], lllIlIlIII[lllIlIlIIl[56]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[17]]] = lllIIIIIIl(lllIlIlIII[lllIlIlIIl[72]], lllIlIlIII[lllIlIlIIl[79]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[32]]] = lllIIIIIIl(lllIlIlIII[lllIlIlIIl[80]], lllIlIlIII[lllIlIlIIl[81]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[36]]] = lllIIIIIlI(lllIlIlIII[lllIlIlIIl[82]], lllIlIlIII[lllIlIlIIl[59]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[6]]] = lllIIIIIIl(lllIlIlIII[lllIlIlIIl[83]], lllIlIlIII[lllIlIlIIl[84]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[41]]] = lllIIIIIII(lllIlIlIII[lllIlIlIIl[9]], lllIlIlIII[lllIlIlIIl[85]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[46]]] = lllIIIIIII(lllIlIlIII[lllIlIlIIl[86]], lllIlIlIII[lllIlIlIIl[87]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[48]]] = lllIIIIIII(lllIlIlIII[lllIlIlIIl[88]], lllIlIlIII[lllIlIlIIl[10]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[53]]] = lllIIIIIIl(lllIlIlIII[lllIlIlIIl[58]], lllIlIlIII[lllIlIlIIl[73]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[47]]] = lllIIIIIIl(lllIlIlIII[lllIlIlIIl[45]], lllIlIlIII[lllIlIlIIl[89]]);
    lIIIlllIl[lIIIllllI[lllIlIlIIl[62]]] = lllIIIIIII(lllIlIlIII[lllIlIlIIl[90]], lllIlIlIII[lllIlIlIIl[7]]);
  }
  
  private static boolean llIlIllIlllI(short llllllllllllllllIllllIllIlllIIII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static boolean llIlIlllIIII(float llllllllllllllllIllllIllIllIlIlI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static boolean lllIIIIllI(short llllllllllllllllIllllIllllIIIlll, short llllllllllllllllIllllIllllIIIllI) {
    if (llIlIllIllIl(SYNTHETIC_LOCAL_VARIABLE_0, SYNTHETIC_LOCAL_VARIABLE_1)) {
      "".length();
      if (-" ".length() == (0x13 ^ 0x17))
        return (0xD3 ^ 0xC7) & (0x8D ^ 0x99 ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lllIlIlIIl[1];
  }
  
  private static boolean lllIIIIlIl(int llllllllllllllllIllllIlllIlIllll) {
    if (llIlIllIllII(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if ((0xCF ^ 0x90 ^ 0xD2 ^ 0x89) <= "   ".length())
        return (227 + 114 - 200 + 104 ^ 20 + 19 - -17 + 108) & (0x82 ^ 0x8C ^ 0xC6 ^ 0x99 ^ -" ".length()); 
    } else {
    
    } 
    return lllIlIlIIl[1];
  }
  
  private static String llIlIlIIlIIl(Exception llllllllllllllllIllllIlllIlIIIlI, float llllllllllllllllIllllIlllIlIIIIl) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   23: bipush #32
    //   25: iaload
    //   26: invokestatic copyOf : ([BI)[B
    //   29: ldc_w 'DES'
    //   32: invokespecial <init> : ([BLjava/lang/String;)V
    //   35: astore_2
    //   36: ldc_w 'DES'
    //   39: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   42: astore_3
    //   43: aload_3
    //   44: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   47: bipush #14
    //   49: iaload
    //   50: aload_2
    //   51: invokevirtual init : (ILjava/security/Key;)V
    //   54: new java/lang/String
    //   57: dup
    //   58: aload_3
    //   59: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   62: aload_0
    //   63: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   66: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   69: invokevirtual decode : ([B)[B
    //   72: invokevirtual doFinal : ([B)[B
    //   75: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   78: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   81: areturn
    //   82: astore_2
    //   83: aload_2
    //   84: invokevirtual printStackTrace : ()V
    //   87: aconst_null
    //   88: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   43	39	3	llllllllllllllllIllllIlllIlIIllI	Ljavax/crypto/Cipher;
    //   0	89	1	llllllllllllllllIllllIlllIlIIIll	Ljava/lang/String;
    //   0	89	2	llllllllllllllllIllllIlllIlIIIII	Z
    //   83	4	2	llllllllllllllllIllllIlllIlIIlIl	Ljava/lang/Exception;
    //   36	46	2	llllllllllllllllIllllIlllIlIIlll	Ljavax/crypto/spec/SecretKeySpec;
    //   0	89	1	llllllllllllllllIllllIlllIlIIIIl	F
    //   0	89	0	llllllllllllllllIllllIlllIlIIlII	Ljava/lang/String;
    //   0	89	0	llllllllllllllllIllllIlllIlIIIlI	Ljava/lang/Exception;
    //   0	89	3	llllllllllllllllIllllIlllIIlllll	Z
    // Exception table:
    //   from	to	target	type
    //   0	81	82	java/lang/Exception
  }
  
  private static String lllIIIIIlI(int llllllllllllllllIllllIllllIIllll, byte llllllllllllllllIllllIllllIIlllI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIII : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   10: bipush #92
    //   12: iaload
    //   13: aaload
    //   14: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   17: aload_1
    //   18: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   21: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   24: invokevirtual digest : ([B)[B
    //   27: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIII : [Ljava/lang/String;
    //   30: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   33: bipush #93
    //   35: iaload
    //   36: aaload
    //   37: invokespecial <init> : ([BLjava/lang/String;)V
    //   40: astore_2
    //   41: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIII : [Ljava/lang/String;
    //   44: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   47: bipush #94
    //   49: iaload
    //   50: aaload
    //   51: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   54: astore_3
    //   55: aload_3
    //   56: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lIIIllllI : [I
    //   59: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   62: bipush #14
    //   64: iaload
    //   65: iaload
    //   66: aload_2
    //   67: invokevirtual init : (ILjava/security/Key;)V
    //   70: new java/lang/String
    //   73: dup
    //   74: aload_3
    //   75: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   78: aload_0
    //   79: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   82: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   85: invokevirtual decode : ([B)[B
    //   88: invokevirtual doFinal : ([B)[B
    //   91: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   94: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   97: areturn
    //   98: astore_2
    //   99: aload_2
    //   100: invokevirtual printStackTrace : ()V
    //   103: aconst_null
    //   104: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   99	4	2	llllllllllllllllIllllIllllIlIlII	Ljava/lang/Exception;
    //   0	105	2	llllllllllllllllIllllIllllIlIlll	F
    //   55	43	3	llllllllllllllllIllllIllllIlIIII	Ljavax/crypto/Cipher;
    //   41	57	2	llllllllllllllllIllllIllllIlIlIl	Ljavax/crypto/spec/SecretKeySpec;
    //   0	105	2	llllllllllllllllIllllIllllIIllIl	C
    //   0	105	1	llllllllllllllllIllllIllllIlIllI	Ljava/lang/Exception;
    //   0	105	0	llllllllllllllllIllllIllllIlIIll	Ljava/lang/String;
    //   0	105	1	llllllllllllllllIllllIllllIIlllI	B
    //   0	105	3	llllllllllllllllIllllIllllIllIII	B
    //   0	105	1	llllllllllllllllIllllIllllIlIIIl	Ljava/lang/String;
    //   0	105	3	llllllllllllllllIllllIllllIIllII	B
    //   0	105	0	llllllllllllllllIllllIllllIIllll	I
    //   0	105	0	llllllllllllllllIllllIllllIlIIlI	J
    // Exception table:
    //   from	to	target	type
    //   0	97	98	java/lang/Exception
  }
  
  private static boolean llIlIllIllII(char llllllllllllllllIllllIllIllIllII) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 != null);
  }
  
  private static String lllIIIIIII(boolean llllllllllllllllIllllIlllllIIIlI, String llllllllllllllllIllllIlllllIIIll) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIII : [Ljava/lang/String;
    //   7: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   10: bipush #34
    //   12: iaload
    //   13: aaload
    //   14: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   17: aload_1
    //   18: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   21: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   24: invokevirtual digest : ([B)[B
    //   27: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lIIIllllI : [I
    //   30: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   33: bipush #32
    //   35: iaload
    //   36: iaload
    //   37: invokestatic copyOf : ([BI)[B
    //   40: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIII : [Ljava/lang/String;
    //   43: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   46: bipush #91
    //   48: iaload
    //   49: aaload
    //   50: invokespecial <init> : ([BLjava/lang/String;)V
    //   53: astore_2
    //   54: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIII : [Ljava/lang/String;
    //   57: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   60: bipush #19
    //   62: iaload
    //   63: aaload
    //   64: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   67: astore_3
    //   68: aload_3
    //   69: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lIIIllllI : [I
    //   72: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   75: bipush #14
    //   77: iaload
    //   78: iaload
    //   79: aload_2
    //   80: invokevirtual init : (ILjava/security/Key;)V
    //   83: new java/lang/String
    //   86: dup
    //   87: aload_3
    //   88: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   91: aload_0
    //   92: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   95: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   98: invokevirtual decode : ([B)[B
    //   101: invokevirtual doFinal : ([B)[B
    //   104: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   107: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   110: areturn
    //   111: astore_2
    //   112: aload_2
    //   113: invokevirtual printStackTrace : ()V
    //   116: aconst_null
    //   117: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	118	1	llllllllllllllllIllllIllllIlllll	F
    //   0	118	3	llllllllllllllllIllllIllllIlllIl	Z
    //   0	118	0	llllllllllllllllIllllIlllllIIIIl	Ljava/lang/String;
    //   54	57	2	llllllllllllllllIllllIlllllIlIIl	Ljavax/crypto/spec/SecretKeySpec;
    //   0	118	2	llllllllllllllllIllllIlllllIIllI	Ljava/lang/Exception;
    //   0	118	0	llllllllllllllllIllllIlllllIIIlI	Z
    //   0	118	2	llllllllllllllllIllllIllllIllllI	F
    //   0	118	1	llllllllllllllllIllllIlllllIIIll	Ljava/lang/String;
    //   68	43	3	llllllllllllllllIllllIlllllIIlII	Ljavax/crypto/Cipher;
    //   0	118	1	llllllllllllllllIllllIlllllIIlIl	J
    //   0	118	0	llllllllllllllllIllllIlllllIIIII	B
    //   0	118	3	llllllllllllllllIllllIlllllIIlll	B
    //   112	4	2	llllllllllllllllIllllIlllllIlIII	Ljava/lang/Exception;
    // Exception table:
    //   from	to	target	type
    //   0	110	111	java/lang/Exception
  }
  
  private static String llIlIlIIlIlI(double llllllllllllllllIllllIlllIIIllll, boolean llllllllllllllllIllllIlllIIIllIl) {
    // Byte code:
    //   0: new java/lang/String
    //   3: dup
    //   4: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   7: aload_0
    //   8: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   11: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   14: invokevirtual decode : ([B)[B
    //   17: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   20: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   23: astore_0
    //   24: new java/lang/StringBuilder
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: astore_2
    //   32: aload_1
    //   33: invokevirtual toCharArray : ()[C
    //   36: astore_3
    //   37: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   40: iconst_1
    //   41: iaload
    //   42: istore #4
    //   44: aload_0
    //   45: invokevirtual toCharArray : ()[C
    //   48: astore #5
    //   50: aload #5
    //   52: arraylength
    //   53: istore #6
    //   55: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   58: iconst_1
    //   59: iaload
    //   60: istore #7
    //   62: iload #7
    //   64: iload #6
    //   66: invokestatic llIlIllIllIl : (II)Z
    //   69: ifeq -> 140
    //   72: aload #5
    //   74: iload #7
    //   76: caload
    //   77: istore #8
    //   79: aload_2
    //   80: iload #8
    //   82: aload_3
    //   83: iload #4
    //   85: aload_3
    //   86: arraylength
    //   87: irem
    //   88: caload
    //   89: ixor
    //   90: i2c
    //   91: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: iinc #4, 1
    //   103: iinc #7, 1
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: bipush #62
    //   114: bipush #126
    //   116: iadd
    //   117: bipush #123
    //   119: isub
    //   120: bipush #126
    //   122: iadd
    //   123: bipush #100
    //   125: bipush #91
    //   127: iadd
    //   128: bipush #11
    //   130: isub
    //   131: bipush #6
    //   133: iadd
    //   134: ixor
    //   135: ifne -> 62
    //   138: aconst_null
    //   139: areturn
    //   140: aload_2
    //   141: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   144: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	145	0	llllllllllllllllIllllIlllIIlIlII	Ljava/lang/String;
    //   0	145	3	llllllllllllllllIllllIlllIIIllII	F
    //   79	24	8	llllllllllllllllIllllIlllIIlIlIl	C
    //   0	145	5	llllllllllllllllIllllIlllIIIlIlI	D
    //   0	145	2	llllllllllllllllIllllIlllIIIllIl	Z
    //   32	113	2	llllllllllllllllIllllIlllIIlIIlI	Ljava/lang/StringBuilder;
    //   0	145	8	llllllllllllllllIllllIlllIIIIlll	D
    //   44	101	4	llllllllllllllllIllllIlllIIlIIII	I
    //   37	108	3	llllllllllllllllIllllIlllIIlIIIl	[C
    //   0	145	1	llllllllllllllllIllllIlllIIIlllI	Ljava/lang/String;
    //   0	145	1	llllllllllllllllIllllIlllIIlIIll	Ljava/lang/String;
    //   0	145	7	llllllllllllllllIllllIlllIIIlIII	D
    //   0	145	4	llllllllllllllllIllllIlllIIIlIll	F
    //   0	145	0	llllllllllllllllIllllIlllIIIllll	D
    //   0	145	6	llllllllllllllllIllllIlllIIIlIIl	S
  }
  
  private static String lllIIIIIIl(String llllllllllllllllIllllIllllllIlll, String llllllllllllllllIllllIlllllllIII) {
    String str = new String(Base64.getDecoder().decode(llllllllllllllllIllllIllllllIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIllllIlllllllIIl = new StringBuilder();
    char[] llllllllllllllllIlllllIIIIIIIIIl = llllllllllllllllIllllIlllllllIII.toCharArray();
    int llllllllllllllllIlllllIIIIIIIIlI = lIIIllllI[lllIlIlIIl[0]];
    char[] arrayOfChar1 = str.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIIIllllI[lllIlIlIIl[0]];
    while (llIlIllIllII(lllIIIIllI(j, i))) {
      char llllllllllllllllIllllIllllllllIl = arrayOfChar1[j];
      lllIlIlIII[lllIlIlIIl[17]].length();
      llllllllllllllllIlllllIIIIIIIIlI++;
      j++;
      "".length();
      if (llIlIllIlllI(null))
        return null; 
    } 
    return String.valueOf(llllllllllllllllIllllIlllllllIIl);
  }
  
  private static String llIlIlIIlIll(boolean llllllllllllllllIllllIllIlllllIl, String llllllllllllllllIllllIllIllllllI) {
    // Byte code:
    //   0: new javax/crypto/spec/SecretKeySpec
    //   3: dup
    //   4: ldc_w 'MD5'
    //   7: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   10: aload_1
    //   11: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   14: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   17: invokevirtual digest : ([B)[B
    //   20: ldc_w 'Blowfish'
    //   23: invokespecial <init> : ([BLjava/lang/String;)V
    //   26: astore_2
    //   27: ldc_w 'Blowfish'
    //   30: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
    //   33: astore_3
    //   34: aload_3
    //   35: getstatic com/axeelheaven/hbedwars/commands/PointsCommand.lllIlIlIIl : [I
    //   38: bipush #14
    //   40: iaload
    //   41: aload_2
    //   42: invokevirtual init : (ILjava/security/Key;)V
    //   45: new java/lang/String
    //   48: dup
    //   49: aload_3
    //   50: invokestatic getDecoder : ()Ljava/util/Base64$Decoder;
    //   53: aload_0
    //   54: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   57: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   60: invokevirtual decode : ([B)[B
    //   63: invokevirtual doFinal : ([B)[B
    //   66: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   69: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   72: areturn
    //   73: astore_2
    //   74: aload_2
    //   75: invokevirtual printStackTrace : ()V
    //   78: aconst_null
    //   79: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	80	2	llllllllllllllllIllllIllIllllIll	Ljava/lang/Exception;
    //   0	80	0	llllllllllllllllIllllIllIlllllll	Ljava/lang/String;
    //   34	39	3	llllllllllllllllIllllIlllIIIIIIl	Ljavax/crypto/Cipher;
    //   27	46	2	llllllllllllllllIllllIlllIIIIIlI	Ljavax/crypto/spec/SecretKeySpec;
    //   74	4	2	llllllllllllllllIllllIlllIIIIIII	Ljava/lang/Exception;
    //   0	80	0	llllllllllllllllIllllIllIlllllIl	Z
    //   0	80	1	llllllllllllllllIllllIllIlllllII	Z
    //   0	80	1	llllllllllllllllIllllIllIllllllI	Ljava/lang/String;
    //   0	80	3	llllllllllllllllIllllIllIllllIlI	I
    // Exception table:
    //   from	to	target	type
    //   0	72	73	java/lang/Exception
  }
  
  private static boolean llIlIllIlIll(char llllllllllllllllIllllIllIllIlllI) {
    return (SYNTHETIC_LOCAL_VARIABLE_0 == null);
  }
  
  private static void llIlIllIlIlI() {
    lllIlIlIIl = new int[100];
    lllIlIlIIl[0] = " ".length();
    lllIlIlIIl[1] = (0x92 ^ 0xB6) & (0x93 ^ 0xB7 ^ 0xFFFFFFFF);
    lllIlIlIIl[2] = 177 + 2 - 168 + 180 ^ 76 + 152 - 169 + 114;
    lllIlIlIIl[3] = 0xE5 ^ 0xBD ^ 0xFF ^ 0xC1;
    lllIlIlIIl[4] = 133 + 184 - 105 + 2;
    lllIlIlIIl[5] = 26 + 95 - 109 + 116;
    lllIlIlIIl[6] = 0x42 ^ 0x2 ^ 0x12 ^ 0x58;
    lllIlIlIIl[7] = 0x1B ^ 0x42 ^ 0xD9 ^ 0xAA;
    lllIlIlIIl[8] = -(0x34 ^ 0x7E);
    lllIlIlIIl[9] = 0x36 ^ 0x29;
    lllIlIlIIl[10] = 0x4C ^ 0x68;
    lllIlIlIIl[11] = 26 + 1 - -25 + 94;
    lllIlIlIIl[12] = 98 + 150 - 111 + 28;
    lllIlIlIIl[13] = 115 + 109 - 137 + 69;
    lllIlIlIIl[14] = "  ".length();
    lllIlIlIIl[15] = "   ".length();
    lllIlIlIIl[16] = 0x4 ^ 0x0;
    lllIlIlIIl[17] = 0x76 ^ 0x71;
    lllIlIlIIl[18] = " ".length() ^ 0x33 ^ 0x37;
    lllIlIlIIl[19] = 25 + 39 - 9 + 85 ^ 25 + 152 - 93 + 77;
    lllIlIlIIl[20] = 98 + 150 - 161 + 101 ^ 176 + 170 - 288 + 138;
    lllIlIlIIl[21] = 75 + 17 - -2 + 71 + (0xAB ^ 0xA5) - (0xA4 ^ 0xC4) + 50 + 38 - 7 + 46;
    lllIlIlIIl[22] = 121 + 51 - 143 + 101;
    lllIlIlIIl[23] = 16 + 189 - 92 + 83 ^ 142 + 159 - 184 + 77;
    lllIlIlIIl[24] = 30 + 22 - 0 + 109 + 99 + 125 - 191 + 122 - (0xFFFFB35F & 0x4DAD) + 173 + 85 - 208 + 126;
    lllIlIlIIl[25] = (0x54 ^ 0x4D) + 104 + 65 - 92 + 54 - 85 + 102 - 71 + 17 + (0x6 ^ 0x68);
    lllIlIlIIl[26] = (0x5B ^ 0x4B) + 100 + 138 - 84 + 1 - (0x3A ^ 0x51) + 63 + 149 - 162 + 112;
    lllIlIlIIl[27] = 166 + 148 - 305 + 181;
    lllIlIlIIl[28] = (0xA1 ^ 0xB6) + (0x57 ^ 0xF) - -(0x1E ^ 0x3B) + (0x2D ^ 0x6);
    lllIlIlIIl[29] = (0x94 ^ 0xC4) + (0xD9 ^ 0xBB) - (0xFF ^ 0xC1) + (0xA2 ^ 0xB9);
    lllIlIlIIl[30] = 130 + 196 - 283 + 202 ^ 27 + 46 - -58 + 1;
    lllIlIlIIl[31] = 0x5C ^ 0x50 ^ 0xD5 ^ 0x9F;
    lllIlIlIIl[32] = 0x21 ^ 0x29;
    lllIlIlIIl[33] = 0x22 ^ 0x4C ^ 0x6E ^ 0x56;
    lllIlIlIIl[34] = 0x4E ^ 0x65;
    lllIlIlIIl[35] = 163 + 173 - 148 + 24 ^ 5 + 93 - 10 + 111;
    lllIlIlIIl[36] = 0x6A ^ 0x63;
    lllIlIlIIl[37] = 0x26 ^ 0x38 ^ 0xCD ^ 0xBD;
    lllIlIlIIl[38] = 0x80 ^ 0x86 ^ 0x4E ^ 0x2F;
    lllIlIlIIl[39] = (0x2B ^ 0x73) + (0xF0 ^ 0x81) - 50 + 45 - -78 + 2 + 87 + 110 - 125 + 86;
    lllIlIlIIl[40] = 55 + 8 - -95 + 20;
    lllIlIlIIl[41] = 0x5B ^ 0x4E ^ 0x56 ^ 0x48;
    lllIlIlIIl[42] = 67 + 119 - 93 + 42 ^ 128 + 169 - 133 + 28;
    lllIlIlIIl[43] = 0x6B ^ 0x2B ^ 0x2D ^ 0x31;
    lllIlIlIIl[44] = 119 + 37 - -46 + 34 ^ 151 + 10 - 41 + 43;
    lllIlIlIIl[45] = 0x7 ^ 0x5B ^ 0x76 ^ 0xD;
    lllIlIlIIl[46] = 0x22 ^ 0x2E;
    lllIlIlIIl[47] = 0x1B ^ 0x14;
    lllIlIlIIl[48] = 0xA1 ^ 0xAC;
    lllIlIlIIl[49] = 230 + 146 - 314 + 171 + (0x5C ^ 0x17) - 123 + 40 - 88 + 74 + (0x71 ^ 0x27);
    lllIlIlIIl[50] = 174 + 46 - 212 + 171;
    lllIlIlIIl[51] = 34 + 189 - 92 + 89;
    lllIlIlIIl[52] = (0x92 ^ 0x9E) + (0x76 ^ 0x33) - (0xA3 ^ 0x9A) + 82 + 115 - 149 + 79;
    lllIlIlIIl[53] = 0x69 ^ 0x34 ^ 0x47 ^ 0x14;
    lllIlIlIIl[54] = 78 + 159 - 93 + 62;
    lllIlIlIIl[55] = (0xE ^ 0x16) + 8 + 86 - 88 + 142 - (0xE2 ^ 0x84) + (0x30 ^ 0x4A);
    lllIlIlIIl[56] = 0x91 ^ 0xBE ^ 0x56 ^ 0x6F;
    lllIlIlIIl[57] = -(0x35 ^ 0x12);
    lllIlIlIIl[58] = 0xC0 ^ 0x98 ^ 0xCD ^ 0xB0;
    lllIlIlIIl[59] = 76 + 30 - 74 + 149 ^ 164 + 139 - 271 + 137;
    lllIlIlIIl[60] = 5 + 131 - 73 + 69 + (0x49 ^ 0x30) - 26 + 148 - 146 + 125 + (0x64 ^ 0x41);
    lllIlIlIIl[61] = 0x98 ^ 0xA6;
    lllIlIlIIl[62] = 0x24 ^ 0x23 ^ 0x0 ^ 0x17;
    lllIlIlIIl[63] = (0x23 ^ 0x36) + (0x36 ^ 0x19) - -(0x3B ^ 0xF) + (0x3D ^ 0x25);
    lllIlIlIIl[64] = (0x4D ^ 0x5A) + (0x5 ^ 0x60) - (0x21 ^ 0x45) + 99 + 69 - 107 + 119;
    lllIlIlIIl[65] = 17 + 128 - 11 + 65;
    lllIlIlIIl[66] = 60 + 103 - 105 + 116 + (0x3B ^ 0xB) - (0x5C ^ 0x6C) + (0xB2 ^ 0xB4);
    lllIlIlIIl[67] = (0x5F ^ 0x2B) + (0x3B ^ 0x79) - 150 + 150 - 185 + 47 + 97 + 8 - 67 + 153;
    lllIlIlIIl[68] = (0xE2 ^ 0x80) + (0xBA ^ 0x98) - (0x21 ^ 0x38) + (0xE ^ 0x2E);
    lllIlIlIIl[69] = 93 + 98 - 132 + 85 ^ 2 + 51 - 20 + 96;
    lllIlIlIIl[70] = 168 + 176 - 288 + 163 + (0xBE ^ 0x8F) - (0xBC ^ 0x94) + (0x8F ^ 0x95);
    lllIlIlIIl[71] = 117 + 11 - 24 + 79;
    lllIlIlIIl[72] = 0xBE ^ 0xA9;
    lllIlIlIIl[73] = 0x93 ^ 0xB5;
    lllIlIlIIl[74] = 0x73 ^ 0x8;
    lllIlIlIIl[75] = 0x7B ^ 0x3A;
    lllIlIlIIl[76] = -" ".length();
    lllIlIlIIl[77] = 0xCA ^ 0xAC ^ 0x5E ^ 0x2C;
    lllIlIlIIl[78] = 116 + 11 - 56 + 60 ^ 104 + 135 - 125 + 36;
    lllIlIlIIl[79] = 0x61 ^ 0x77 ^ 0x99 ^ 0x97;
    lllIlIlIIl[80] = 0x5A ^ 0x43;
    lllIlIlIIl[81] = 0x3F ^ 0x5D ^ 0xD6 ^ 0xAE;
    lllIlIlIIl[82] = 0x57 ^ 0x4C;
    lllIlIlIIl[83] = 107 + 63 - 37 + 48 ^ 71 + 40 - -54 + 3;
    lllIlIlIIl[84] = 0x27 ^ 0x39;
    lllIlIlIIl[85] = 0x46 ^ 0x66;
    lllIlIlIIl[86] = 0x97 ^ 0xB6;
    lllIlIlIIl[87] = 120 + 96 - 100 + 50 ^ 113 + 106 - 99 + 12;
    lllIlIlIIl[88] = 168 + 71 - 202 + 153 ^ 20 + 39 - -26 + 72;
    lllIlIlIIl[89] = 0xA9 ^ 0x81;
    lllIlIlIIl[90] = 0x34 ^ 0x1D;
    lllIlIlIIl[91] = 0x2E ^ 0x2;
    lllIlIlIIl[92] = 0xC3 ^ 0xB7 ^ 0x29 ^ 0x73;
    lllIlIlIIl[93] = 0x89 ^ 0xA6;
    lllIlIlIIl[94] = 0x91 ^ 0xA1;
    lllIlIlIIl[95] = 0x35 ^ 0x17 ^ 0x42 ^ 0x51;
    lllIlIlIIl[96] = 32 + 110 - 138 + 197 ^ 2 + 172 - 23 + 36;
    lllIlIlIIl[97] = 0x26 ^ 0x52 ^ "  ".length();
    lllIlIlIIl[98] = 95 + 1 - 38 + 99 ^ 82 + 79 - 114 + 128;
    lllIlIlIIl[99] = 0x93 ^ 0xA0;
  }
  
  public PointsCommand(BedWars llllllllllllllllIllllIlllIllIlll) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: putfield plugin : Lcom/axeelheaven/hbedwars/BedWars;
    //   9: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	10	1	llllllllllllllllIllllIlllIllIlII	Z
    //   0	10	1	llllllllllllllllIllllIlllIllIlll	Lcom/axeelheaven/hbedwars/BedWars;
    //   0	10	1	llllllllllllllllIllllIlllIllIIlI	C
    //   0	10	0	llllllllllllllllIllllIlllIllIIll	J
    //   0	10	0	llllllllllllllllIllllIlllIllIllI	B
    //   0	10	0	llllllllllllllllIllllIlllIllIlIl	Lcom/axeelheaven/hbedwars/commands/PointsCommand;
  }
  
  private static void lllIIIIlII() {
    lIIIllllI = new int[lllIlIlIIl[2]];
    lIIIllllI[lllIlIlIIl[1]] = lllIlIlIII[lllIlIlIIl[1]].length();
    lIIIllllI[lllIlIlIIl[0]] = (lllIlIlIIl[1] ^ lllIlIlIIl[3] ^ lllIlIlIIl[4] ^ lllIlIlIIl[5]) & (lllIlIlIIl[6] + lllIlIlIIl[7] - lllIlIlIIl[8] + lllIlIlIIl[9] ^ lllIlIlIIl[10] + lllIlIlIIl[11] - lllIlIlIIl[12] + lllIlIlIIl[13] ^ -lllIlIlIII[lllIlIlIIl[0]].length());
    lIIIllllI[lllIlIlIIl[14]] = lllIlIlIII[lllIlIlIIl[14]].length();
    lIIIllllI[lllIlIlIIl[15]] = lllIlIlIII[lllIlIlIIl[15]].length();
    lIIIllllI[lllIlIlIIl[16]] = lllIlIlIIl[15] ^ lllIlIlIIl[17];
    lIIIllllI[lllIlIlIIl[18]] = lllIlIlIIl[19] ^ lllIlIlIIl[20] ^ lllIlIlIIl[21] ^ lllIlIlIIl[22];
    lIIIllllI[lllIlIlIIl[23]] = lllIlIlIIl[24] ^ lllIlIlIIl[25] ^ lllIlIlIIl[26] ^ lllIlIlIIl[27];
    lIIIllllI[lllIlIlIIl[17]] = lllIlIlIIl[28] ^ lllIlIlIIl[29] ^ lllIlIlIIl[30] ^ lllIlIlIIl[31];
    lIIIllllI[lllIlIlIIl[32]] = lllIlIlIIl[33] ^ lllIlIlIIl[34] ^ lllIlIlIIl[35] ^ lllIlIlIIl[3];
    lIIIllllI[lllIlIlIIl[36]] = lllIlIlIIl[37] ^ lllIlIlIIl[38];
    lIIIllllI[lllIlIlIIl[6]] = lllIlIlIIl[39] ^ lllIlIlIIl[40];
    lIIIllllI[lllIlIlIIl[41]] = lllIlIlIIl[13] + lllIlIlIIl[42] - lllIlIlIIl[42] + lllIlIlIIl[41] ^ lllIlIlIIl[20] + lllIlIlIIl[43] - lllIlIlIIl[44] + lllIlIlIIl[45];
    lIIIllllI[lllIlIlIIl[46]] = lllIlIlIIl[47] ^ lllIlIlIIl[15];
    lIIIllllI[lllIlIlIIl[48]] = lllIlIlIIl[49] ^ lllIlIlIIl[50] ^ lllIlIlIIl[51] ^ lllIlIlIIl[52];
    lIIIllllI[lllIlIlIIl[53]] = lllIlIlIIl[54] ^ lllIlIlIIl[55];
    lIIIllllI[lllIlIlIIl[47]] = lllIlIlIIl[9] + lllIlIlIIl[56] - lllIlIlIIl[57] + lllIlIlIIl[58] ^ lllIlIlIIl[59] + lllIlIlIIl[60] - lllIlIlIIl[61] + lllIlIlIIl[45];
    lIIIllllI[lllIlIlIIl[62]] = lllIlIlIIl[42] + lllIlIlIIl[63] - lllIlIlIIl[64] + lllIlIlIIl[65] ^ lllIlIlIIl[33] + lllIlIlIIl[66] - lllIlIlIIl[67] + lllIlIlIIl[68];
    lIIIllllI[lllIlIlIIl[69]] = lllIlIlIIl[70] ^ lllIlIlIIl[71] ^ lllIlIlIIl[44] ^ lllIlIlIIl[72];
  }
  
  private static void llIlIlIIllII() {
    lllIlIlIII = new String[lllIlIlIIl[99]];
    lllIlIlIII[lllIlIlIIl[1]] = llIlIlIIlIIl("y6sJwQUA9DE=", "qokhh");
    lllIlIlIII[lllIlIlIIl[0]] = llIlIlIIlIlI("ag==", "JzCXL");
    lllIlIlIII[lllIlIlIIl[14]] = llIlIlIIlIIl("eB4jAOvB/Ho=", "EVIdL");
    lllIlIlIII[lllIlIlIIl[15]] = llIlIlIIlIlI("RWJl", "eBEJk");
    lllIlIlIII[lllIlIlIIl[16]] = llIlIlIIlIIl("UxscaUQ5zcs=", "enyza");
    lllIlIlIII[lllIlIlIIl[18]] = llIlIlIIlIll("EeGOCRq4D98=", "eTdyG");
    lllIlIlIII[lllIlIlIIl[23]] = llIlIlIIlIIl("C3zUmeuXtVI=", "WFcFO");
    lllIlIlIII[lllIlIlIIl[17]] = llIlIlIIlIIl("coLiNRzJ4ZI=", "MQQcN");
    lllIlIlIII[lllIlIlIIl[32]] = llIlIlIIlIIl("NuLInegIfrg=", "yHnJv");
    lllIlIlIII[lllIlIlIIl[36]] = llIlIlIIlIIl("C9w64xLl/eTU5tPIeS7dHsE2wWKLV3MAqAogi0DCXTrCySdRyS0+yA==", "ogczs");
    lllIlIlIII[lllIlIlIIl[6]] = llIlIlIIlIlI("JTwhFA4=", "rvYLK");
    lllIlIlIII[lllIlIlIIl[41]] = llIlIlIIlIIl("4Jf/mJUZ5vUk08Y2J3zV2dWNN1vAqmekVrXN+FVLA1esQi8taH0n1ypfNkCjcBu1A6tY8njasWA=", "roTsa");
    lllIlIlIII[lllIlIlIIl[46]] = llIlIlIIlIIl("IZu63KY0auc=", "pANye");
    lllIlIlIII[lllIlIlIIl[48]] = llIlIlIIlIlI("BhYAKA0WD3RTP094", "wEDeW");
    lllIlIlIII[lllIlIlIIl[53]] = llIlIlIIlIll("fJQHFuQD7oI=", "UnoxJ");
    lllIlIlIII[lllIlIlIIl[47]] = llIlIlIIlIlI("AS8dQhovATQ1JDV7PTQMAQIiOyIRL04PLjgJMDAeDz49Jy4eLEQZPhEKLx8FEiA6", "VHvvJ");
    lllIlIlIII[lllIlIlIIl[62]] = llIlIlIIlIll("5mnrzLk3NRg=", "ZrIsL");
    lllIlIlIII[lllIlIlIIl[69]] = llIlIlIIlIll("IgnttcbWwKE=", "kuDDQ");
    lllIlIlIII[lllIlIlIIl[2]] = llIlIlIIlIll("4J6OEIMuUTY=", "sWZuO");
    lllIlIlIII[lllIlIlIIl[35]] = llIlIlIIlIll("AB4Al20LMhm81ETEJ6jPN/svZQnNZDjUAqY4TQDoOmOfbJlNk8om8xalovixskC3", "ghYVa");
    lllIlIlIII[lllIlIlIIl[77]] = llIlIlIIlIlI("EwcCADs=", "eUlWC");
    lllIlIlIII[lllIlIlIIl[78]] = llIlIlIIlIIl("ISCKlqatmmBbx5WQx9e3dA==", "tVGtv");
    lllIlIlIII[lllIlIlIIl[56]] = llIlIlIIlIIl("oVV5pFZ4QLg=", "dJqZY");
    lllIlIlIII[lllIlIlIIl[72]] = llIlIlIIlIlI("NTwQLCUsLA0PDQJ2", "mKUNf");
    lllIlIlIII[lllIlIlIIl[79]] = llIlIlIIlIIl("14k17dU1840=", "YtlVL");
    lllIlIlIII[lllIlIlIIl[80]] = llIlIlIIlIIl("lxsJVzqXTKdzueQVlXmtTw==", "erzSN");
    lllIlIlIII[lllIlIlIIl[81]] = llIlIlIIlIIl("aWDAc11vdJc=", "eNxCo");
    lllIlIlIII[lllIlIlIIl[82]] = llIlIlIIlIll("w35KoRZJkk6J+O1dNGlJTywoh2cvhQ0H7ScJwsEnQ6Y=", "YSBEz");
    lllIlIlIII[lllIlIlIIl[59]] = llIlIlIIlIlI("HQI3Ays=", "ntusQ");
    lllIlIlIII[lllIlIlIIl[83]] = llIlIlIIlIlI("LAAkMgwqIhw=", "nQOpK");
    lllIlIlIII[lllIlIlIIl[84]] = llIlIlIIlIlI("Ex4IGQo=", "drdnG");
    lllIlIlIII[lllIlIlIIl[9]] = llIlIlIIlIIl("bfKEFLVYvy1Y3LJ9d4VLK1kqGKnl3Sdg6F8C/GCCcY/nvXZqagss8wrcpCyiGPIdAPTzwQwiacH7fxqS7ewBPQ==", "LqZgU");
    lllIlIlIII[lllIlIlIIl[85]] = llIlIlIIlIll("SAd8pSRhbZk=", "tUxzP");
    lllIlIlIII[lllIlIlIIl[86]] = llIlIlIIlIlI("AG0TIygCdTQvFT5/", "UBQBm");
    lllIlIlIII[lllIlIlIIl[87]] = llIlIlIIlIlI("BScLEy8=", "gtRPe");
    lllIlIlIII[lllIlIlIIl[88]] = llIlIlIIlIlI("O0cuMzouW3oDJAM/exFaNjAMMlYnNXRE", "LtIyn");
    lllIlIlIII[lllIlIlIIl[10]] = llIlIlIIlIlI("KxgUECI=", "mVAXv");
    lllIlIlIII[lllIlIlIIl[58]] = llIlIlIIlIll("+qg4/wI+wRoInVuNUvN3CA==", "xzTDH");
    lllIlIlIII[lllIlIlIIl[73]] = llIlIlIIlIIl("HrcpHXngBvQ=", "fdGRB");
    lllIlIlIII[lllIlIlIIl[45]] = llIlIlIIlIIl("XN2ERQ3K0GjPPjAZiKH7Fg==", "xvCDZ");
    lllIlIlIII[lllIlIlIIl[89]] = llIlIlIIlIIl("51RS/7LBceo=", "nGTEK");
    lllIlIlIII[lllIlIlIIl[90]] = llIlIlIIlIIl("IYmwIuJHVHCbAjVA41tbW9lrJDJOg5MmqWo1ZIFkSk8=", "CNpbB");
    lllIlIlIII[lllIlIlIIl[7]] = llIlIlIIlIll("EKRDd61BQME=", "daabD");
    lllIlIlIII[lllIlIlIIl[34]] = llIlIlIIlIll("24Q2eQyIakw=", "QKzhZ");
    lllIlIlIII[lllIlIlIIl[91]] = llIlIlIIlIlI("DxAH", "KUTYd");
    lllIlIlIII[lllIlIlIIl[19]] = llIlIlIIlIll("asE/RpL5B88=", "OSGZk");
    lllIlIlIII[lllIlIlIIl[92]] = llIlIlIIlIll("K0HQ5RJuMaw=", "nudIN");
    lllIlIlIII[lllIlIlIIl[93]] = llIlIlIIlIIl("vQ+mLJVy3K1Iy0nYCCo8jQ==", "IHmip");
    lllIlIlIII[lllIlIlIIl[94]] = llIlIlIIlIlI("KjYOPy8BKQk=", "hZaHI");
    lllIlIlIII[lllIlIlIIl[95]] = llIlIlIIlIll("y5UDd+EZWGM=", "iJRHS");
    lllIlIlIII[lllIlIlIIl[98]] = llIlIlIIlIll("3gNSo1hb3w0=", "LzuIP");
  }
  
  private static boolean lllIIIlIII(short llllllllllllllllIlllllIIIIlIlllI) {
    if (llIlIllIlIll(SYNTHETIC_LOCAL_VARIABLE_0)) {
      "".length();
      if (((10 + 122 - -23 + 31 ^ 99 + 44 - 53 + 57) & ("  ".length() ^ 0x90 ^ 0xBB ^ -" ".length())) != 0)
        return (142 + 76 - 0 + 12 ^ 143 + 106 - 220 + 159) & (210 + 92 - 104 + 27 ^ 30 + 27 - -94 + 36 ^ -" ".length()); 
    } else {
    
    } 
    return lllIlIlIIl[1];
  }
  
  static {
    llIlIllIlIlI();
    llIlIlIIllII();
    lllIIIIlII();
    lllIIIIIll();
  }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\commands\PointsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */