package com.axeelheaven.hbedwars.libs.jedis.jedis.commands;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import java.util.List;

public interface ScriptingKeyPipelineBinaryCommands {
  Response<Object> eval(byte[] paramArrayOfbyte);
  
  Response<Object> eval(byte[] paramArrayOfbyte, int paramInt, byte[]... paramVarArgs);
  
  Response<Object> eval(byte[] paramArrayOfbyte, List<byte[]> paramList1, List<byte[]> paramList2);
  
  Response<Object> evalReadonly(byte[] paramArrayOfbyte, List<byte[]> paramList1, List<byte[]> paramList2);
  
  Response<Object> evalsha(byte[] paramArrayOfbyte);
  
  Response<Object> evalsha(byte[] paramArrayOfbyte, int paramInt, byte[]... paramVarArgs);
  
  Response<Object> evalsha(byte[] paramArrayOfbyte, List<byte[]> paramList1, List<byte[]> paramList2);
  
  Response<Object> evalshaReadonly(byte[] paramArrayOfbyte, List<byte[]> paramList1, List<byte[]> paramList2);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\commands\ScriptingKeyPipelineBinaryCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */