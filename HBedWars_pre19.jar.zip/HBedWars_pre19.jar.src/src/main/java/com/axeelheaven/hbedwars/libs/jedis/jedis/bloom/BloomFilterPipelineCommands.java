package com.axeelheaven.hbedwars.libs.jedis.jedis.bloom;

import com.axeelheaven.hbedwars.libs.jedis.jedis.Response;
import java.util.List;
import java.util.Map;

public interface BloomFilterPipelineCommands {
  Response<String> bfReserve(String paramString, double paramDouble, long paramLong);
  
  Response<String> bfReserve(String paramString, double paramDouble, long paramLong, BFReserveParams paramBFReserveParams);
  
  Response<Boolean> bfAdd(String paramString1, String paramString2);
  
  Response<List<Boolean>> bfMAdd(String paramString, String... paramVarArgs);
  
  Response<List<Boolean>> bfInsert(String paramString, String... paramVarArgs);
  
  Response<List<Boolean>> bfInsert(String paramString, BFInsertParams paramBFInsertParams, String... paramVarArgs);
  
  Response<Boolean> bfExists(String paramString1, String paramString2);
  
  Response<List<Boolean>> bfMExists(String paramString, String... paramVarArgs);
  
  Response<Map<String, Object>> bfInfo(String paramString);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\bloom\BloomFilterPipelineCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */