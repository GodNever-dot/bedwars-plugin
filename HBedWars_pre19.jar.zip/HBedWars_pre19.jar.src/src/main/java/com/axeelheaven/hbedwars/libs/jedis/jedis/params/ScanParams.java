/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.util.SafeEncoder;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.EnumMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScanParams
/*    */   implements IParams
/*    */ {
/* 18 */   private final Map<Protocol.Keyword, ByteBuffer> params = new EnumMap<>(Protocol.Keyword.class);
/*    */   
/* 20 */   public static final String SCAN_POINTER_START = String.valueOf(0);
/* 21 */   public static final byte[] SCAN_POINTER_START_BINARY = SafeEncoder.encode(SCAN_POINTER_START);
/*    */   
/*    */   public ScanParams match(byte[] pattern) {
/* 24 */     this.params.put(Protocol.Keyword.MATCH, ByteBuffer.wrap(pattern));
/* 25 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ScanParams match(String pattern) {
/* 32 */     this.params.put(Protocol.Keyword.MATCH, ByteBuffer.wrap(SafeEncoder.encode(pattern)));
/* 33 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ScanParams count(Integer count) {
/* 40 */     this.params.put(Protocol.Keyword.COUNT, ByteBuffer.wrap(Protocol.toByteArray(count.intValue())));
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 46 */     for (Map.Entry<Protocol.Keyword, ByteBuffer> param : this.params.entrySet()) {
/* 47 */       args.add(param.getKey());
/* 48 */       args.add(((ByteBuffer)param.getValue()).array());
/*    */     } 
/*    */   }
/*    */   
/*    */   public byte[] binaryMatch() {
/* 53 */     if (this.params.containsKey(Protocol.Keyword.MATCH)) {
/* 54 */       return ((ByteBuffer)this.params.get(Protocol.Keyword.MATCH)).array();
/*    */     }
/* 56 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String match() {
/* 61 */     if (this.params.containsKey(Protocol.Keyword.MATCH)) {
/* 62 */       return new String(((ByteBuffer)this.params.get(Protocol.Keyword.MATCH)).array());
/*    */     }
/* 64 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\ScanParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */