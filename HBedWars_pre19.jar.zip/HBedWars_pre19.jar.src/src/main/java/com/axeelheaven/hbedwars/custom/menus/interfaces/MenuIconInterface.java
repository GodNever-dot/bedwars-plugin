package com.axeelheaven.hbedwars.custom.menus.interfaces;

import com.axeelheaven.hbedwars.libs.json.simple.JSONObject;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public interface MenuIconInterface {
  ItemStack getIcon(Player player);
  
  String getName(Player player);
  
  List<String> getLore(Player player);
  
  int getSlot();
  
  boolean isEnabled();
  
  ItemStack getItemStack();
  
  void onClick(Player player, ItemStack item);
  
  List<MenuActionInterface> getActions();
  
  JSONObject getJsonObject();
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\custom\menus\interfaces\MenuIconInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */