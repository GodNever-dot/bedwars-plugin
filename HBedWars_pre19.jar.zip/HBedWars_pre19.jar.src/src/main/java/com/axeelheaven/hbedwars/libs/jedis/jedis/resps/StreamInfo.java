/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.resps;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.StreamEntryID;
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamInfo
/*    */   implements Serializable
/*    */ {
/*    */   public static final String LENGTH = "length";
/*    */   public static final String RADIX_TREE_KEYS = "radix-tree-keys";
/*    */   public static final String RADIX_TREE_NODES = "radix-tree-nodes";
/*    */   public static final String GROUPS = "groups";
/*    */   public static final String LAST_GENERATED_ID = "last-generated-id";
/*    */   public static final String FIRST_ENTRY = "first-entry";
/*    */   public static final String LAST_ENTRY = "last-entry";
/*    */   private final long length;
/*    */   private final long radixTreeKeys;
/*    */   private final long radixTreeNodes;
/*    */   private final long groups;
/*    */   private final StreamEntryID lastGeneratedId;
/*    */   private final StreamEntry firstEntry;
/*    */   private final StreamEntry lastEntry;
/*    */   private final Map<String, Object> streamInfo;
/*    */   
/*    */   public StreamInfo(Map<String, Object> map) {
/* 37 */     this.streamInfo = map;
/* 38 */     this.length = ((Long)map.get("length")).longValue();
/* 39 */     this.radixTreeKeys = ((Long)map.get("radix-tree-keys")).longValue();
/* 40 */     this.radixTreeNodes = ((Long)map.get("radix-tree-nodes")).longValue();
/* 41 */     this.groups = ((Long)map.get("groups")).longValue();
/* 42 */     this.lastGeneratedId = (StreamEntryID)map.get("last-generated-id");
/* 43 */     this.firstEntry = (StreamEntry)map.get("first-entry");
/* 44 */     this.lastEntry = (StreamEntry)map.get("last-entry");
/*    */   }
/*    */ 
/*    */   
/*    */   public long getLength() {
/* 49 */     return this.length;
/*    */   }
/*    */   
/*    */   public long getRadixTreeKeys() {
/* 53 */     return this.radixTreeKeys;
/*    */   }
/*    */   
/*    */   public long getRadixTreeNodes() {
/* 57 */     return this.radixTreeNodes;
/*    */   }
/*    */   
/*    */   public long getGroups() {
/* 61 */     return this.groups;
/*    */   }
/*    */   
/*    */   public StreamEntryID getLastGeneratedId() {
/* 65 */     return this.lastGeneratedId;
/*    */   }
/*    */   
/*    */   public StreamEntry getFirstEntry() {
/* 69 */     return this.firstEntry;
/*    */   }
/*    */   
/*    */   public StreamEntry getLastEntry() {
/* 73 */     return this.lastEntry;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Object> getStreamInfo() {
/* 80 */     return this.streamInfo;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\resps\StreamInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */