package com.axeelheaven.hbedwars.cosmetics.trails;

import com.axeelheaven.hbedwars.BedWars;
import com.axeelheaven.hbedwars.custom.config.HConfiguration;
import org.bukkit.configuration.ConfigurationSection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TrailManager {
    private final BedWars plugin;
    private final HashMap<String, Trail> trails;
    
    public TrailManager(BedWars plugin) {
        this.plugin = plugin;
        this.trails = new HashMap<>();
        reload();
    }
    
    public void reload() {
        trails.clear();
        HConfiguration config = plugin.getTrails();
        ConfigurationSection section = config.getConfigurationSection("trails");
        
        if (section != null) {
            for (String id : section.getKeys(false)) {
                Trail trail = new Trail(plugin, id);
                trails.put(id, trail);
            }
        }
    }
    
    public Trail getTrail(String id) {
        return trails.get(id);
    }
    
    public List<Trail> getPurchased(String player) {
        List<Trail> purchased = new ArrayList<>();
        for (Trail trail : trails.values()) {
            if (trail.hasPurchased(player)) {
                purchased.add(trail);
            }
        }
        return purchased;
    }
    
    public HashMap<String, Trail> getTrails() {
        return trails;
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\trails\TrailManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */