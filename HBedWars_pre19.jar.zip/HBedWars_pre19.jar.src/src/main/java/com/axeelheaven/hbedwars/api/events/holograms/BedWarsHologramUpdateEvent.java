/*    */ package com.axeelheaven.hbedwars.api.events.holograms;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.custom.holograms.Hologram;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsHologramUpdateEvent extends Event {
/*    */   private final Player player;
/*    */   private final Hologram hologram;
/* 11 */   private static final HandlerList handlerList = new HandlerList(); public Player getPlayer() {
/* 12 */     return this.player; } public Hologram getHologram() {
/* 13 */     return this.hologram;
/*    */   }
/*    */   public BedWarsHologramUpdateEvent(Player player, Hologram hologram) {
/* 16 */     this.player = player;
/* 17 */     this.hologram = hologram;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 22 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 26 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\holograms\BedWarsHologramUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */