package com.axeelheaven.hbedwars.cosmetics.windances;

import com.axeelheaven.hbedwars.BedWars;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.metadata.FixedMetadataValue;
import java.util.Random;

public class WinDanceWarSheep extends WinDance {
    private final BedWars plugin;
    private final Random random;
    
    public WinDanceWarSheep(BedWars plugin) {
        super(plugin);
        this.plugin = plugin;
        this.random = new Random();
    }
    
    @Override
    public void play(Player player, Location location) {
        Location spawnLoc = location.clone().add(0, 3, 0);
        
        for (int i = 0; i < 5; i++) {
            Sheep sheep = location.getWorld().spawn(spawnLoc, Sheep.class);
            sheep.setMetadata("WinDance", new FixedMetadataValue(plugin, true));
            sheep.setCustomName("§c❤ " + player.getName() + " ❤");
            sheep.setCustomNameVisible(true);
        }
    }
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\cosmetics\windances\WinDanceWarSheep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */