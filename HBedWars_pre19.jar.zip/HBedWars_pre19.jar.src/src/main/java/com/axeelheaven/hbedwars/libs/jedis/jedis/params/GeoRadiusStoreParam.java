/*    */ package com.axeelheaven.hbedwars.libs.jedis.jedis.params;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandArguments;
/*    */ import com.axeelheaven.hbedwars.libs.jedis.jedis.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeoRadiusStoreParam
/*    */   implements IParams
/*    */ {
/*    */   private boolean store = false;
/*    */   private boolean storeDist = false;
/*    */   private String key;
/*    */   
/*    */   public static GeoRadiusStoreParam geoRadiusStoreParam() {
/* 17 */     return new GeoRadiusStoreParam();
/*    */   }
/*    */   
/*    */   public GeoRadiusStoreParam store(String key) {
/* 21 */     if (key != null) {
/* 22 */       this.store = true;
/* 23 */       this.key = key;
/*    */     } 
/* 25 */     return this;
/*    */   }
/*    */   
/*    */   public GeoRadiusStoreParam storeDist(String key) {
/* 29 */     if (key != null) {
/* 30 */       this.storeDist = true;
/* 31 */       this.key = key;
/*    */     } 
/* 33 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addParams(CommandArguments args) {
/* 45 */     if (this.storeDist) {
/* 46 */       args.add(Protocol.Keyword.STOREDIST).key(this.key);
/* 47 */     } else if (this.store) {
/* 48 */       args.add(Protocol.Keyword.STORE).key(this.key);
/*    */     } else {
/* 50 */       throw new IllegalArgumentException(getClass().getSimpleName() + " must has store or storedist option");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\params\GeoRadiusStoreParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */