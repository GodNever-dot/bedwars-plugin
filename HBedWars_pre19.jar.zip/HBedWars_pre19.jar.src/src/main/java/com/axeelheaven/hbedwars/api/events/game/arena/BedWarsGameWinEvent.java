/*    */ package com.axeelheaven.hbedwars.api.events.game.arena;
/*    */ 
/*    */ import com.axeelheaven.hbedwars.api.arena.Arena;
/*    */ import com.axeelheaven.hbedwars.arena.ArenaTeam;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BedWarsGameWinEvent extends Event {
/*    */   private final Arena arena;
/*    */   private final ArenaTeam arenaTeam;
/* 11 */   private static final HandlerList handlerList = new HandlerList(); public Arena getArena() {
/* 12 */     return this.arena; } public ArenaTeam getArenaTeam() {
/* 13 */     return this.arenaTeam;
/*    */   }
/*    */   public BedWarsGameWinEvent(Arena arena, ArenaTeam arenaTeam) {
/* 16 */     this.arena = arena;
/* 17 */     this.arenaTeam = arenaTeam;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 22 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 26 */     return handlerList;
/*    */   }
/*    */ }


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\api\events\game\arena\BedWarsGameWinEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */