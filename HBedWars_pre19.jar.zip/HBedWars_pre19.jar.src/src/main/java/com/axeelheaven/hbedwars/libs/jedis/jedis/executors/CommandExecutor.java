package com.axeelheaven.hbedwars.libs.jedis.jedis.executors;

import com.axeelheaven.hbedwars.libs.jedis.jedis.CommandObject;

public interface CommandExecutor extends AutoCloseable {
  <T> T executeCommand(CommandObject<T> paramCommandObject);
}


/* Location:              E:\addon hbedwars\HBedWars_pre19.jar!\com\axeelheaven\hbedwars\libs\jedis\jedis\executors\CommandExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */